import EVENTS from './eventdeclara'
import Util from '../util'
class EventManager{
    constructor(main){
        this.main = main
        //渲染的主画布，暂时不监听
        this.canvasDom = main.canvasDom
        //画布的父dom
        this.canvasContent = main.param.dom
        this.addEvent()
    }
    addEvent=()=>{
        let canvasContent = this.canvasContent
        //全局键盘事件
        window.addEventListener('keydown',this.keydown)
        window.addEventListener('keyup',this.keyup)

        window.addEventListener('mousemove',this.mousemove)
        window.addEventListener('mouseup',this.mouseup)
        document.getElementsByClassName("sigma-mouse")[0].addEventListener('mousemove',this.canvasMousemove)
        document.getElementsByClassName("sigma-mouse")[0].addEventListener('mousedown',this.canvasMousedown)
        document.getElementsByClassName("sigma-mouse")[0].addEventListener('mouseup',this.canvasMouseup)
        //canvasContent.addEventListener('contextmenu',this.contextmenu)
        canvasContent.addEventListener('mousedown',this.mousedown)
        //canvasContent.addEventListener('focus',this.focus)
        //canvasContent.addEventListener('blur',this.blur)
        
    }
    removeEvent = ()=>{
        let canvasContent = this.canvasContent
        window.removeEventListener('keydown',this.keydown)
        window.removeEventListener('keyup',this.keyup)

        window.removeEventListener('mousemove',this.mousemove)
        window.removeEventListener('mouseup',this.mouseup)
        document.getElementsByClassName("sigma-mouse")[0].removeEventListener('mousemove',this.canvasMousemove)
        document.getElementsByClassName("sigma-mouse")[0].removeEventListener('mousedown',this.canvasMousedown)
        document.getElementsByClassName("sigma-mouse")[0].removeEventListener('mouseup',this.canvasMouseup)
        //canvasContent.removeEventListener('contextmenu',this.contextmenu)
        canvasContent.removeEventListener('mousedown',this.mousedown)
        //canvasContent.removeEventListener('focus',this.focus)
        //canvasContent.removeEventListener('blur',this.blur)
    }
    keydown=(event)=>{
        //删除键 ,但是需要判断是否在画布上
        if(event.keyCode == 46){
            this.main.trigger(EVENTS['deleteEvent'])
        }
        //ctrl键
        if(event.ctrlKey){
            this.main.trigger(EVENTS['ctrlKey'],true)
        }
    }
    keyup=(event)=>{
        //ctrl键取消
        if(!event.ctrlKey){
            this.main.trigger(EVENTS['ctrlKey'],false)
        }
    }
    mousemove=(event)=>{
        let x = event.clientX
        let y = event.clientY
        let pos = Util.windowToCanvasLeftRight(this.main.canvasDom,x,y)

        let eWidth = this.main.param.dom.offsetWidth - 0
        let eHeight = this.main.param.dom.offsetHeight - 0
        let xy = this.main.s.camera.cameraPosition(
            pos.x - eWidth/2,
            pos.y - eHeight/2,
        )
        this.main.trigger(EVENTS['mousemove'],pos,event,xy)
    }
    canvasMousemove=(event)=>{
        this.main.trigger(EVENTS['canvasMousemove'],event)
    }
    canvasMousedown=(event)=>{
        this.main.trigger(EVENTS['canvasMousedown'],event)
    }
    canvasMouseup=(event)=>{
        this.main.trigger(EVENTS['canvasMouseup'],event)
    }
    mouseup=(event)=>{
        let x = event.clientX
        let y = event.clientY
        let pos = Util.windowToCanvasLeftRight(this.main.canvasDom,x,y)
        let eWidth = this.main.param.dom.offsetWidth - 0
        let eHeight = this.main.param.dom.offsetHeight - 0
        let xy = this.main.s.camera.cameraPosition(
            pos.x - eWidth/2,
            pos.y - eHeight/2,
        )
        this.main.trigger(EVENTS['mouseup'],pos,event,xy)
    }
    mousedown=(event)=>{
        //防止鼠标右键点击导致的触发
        if(event.button!==0){
            return
        }
        let x = event.clientX
        let y = event.clientY
        let pos = Util.windowToCanvasLeftRight(this.main.canvasDom,x,y)
        let eWidth = this.main.param.dom.offsetWidth - 0
        let eHeight = this.main.param.dom.offsetHeight - 0
        let xy = this.main.s.camera.cameraPosition(
            pos.x - eWidth/2,
            pos.y - eHeight/2,
        )
        this.main.trigger(EVENTS['mousedown'],pos,event,xy)
    }
    contextmenu=(event)=>{

    }
    focus=(event)=>{

    }
    blur=(event)=>{

    }
}

export default EventManager