const EVENTS = {
    //鼠标键盘事件
    'mousedown':'mousedown',
    'mousemove':'mousemove',
    'mouseup':'mouseup',
    'contextmenu':'contextmenu',
    //ctrl键信息
    'ctrlKey':'ctrlKey',
    //ctrl键多选 设定多选次数
    'ctrlSelectCount':'ctrlSelectCount',
    //画布上的move事件
    'canvasMousemove':'canvasMousemove',
    //画布上的down事件
    'canvasMousedown':'canvasMousedown',
    //画布上的up事件
    'canvasMouseup':'canvasMouseup',
    
    //删除事件
    'deleteEvent':'deleteEvent',
    //通知消息 消息分多种类型  成功。失败。提示
    'messageTip':'messageTip',
    //通知保存画布
    'updateCanvas':'updateCanvas',
    //是否启用拖拽功能，包括监听拖拽，尤其是在可编辑的
    'dragEnable':'dragEnable',
    //关闭drag
    'dragDisabled':'dragDisabled',
    
    //居中定位
    'autoExtent':'autoExtent',
    
    //布局信息 网格
    'gridLayout':'gridLayout',
    //布局信息 力导向
    'forceLayout':'forceLayout',
    //布局信息 圆形
    'circleLayout':'circleLayout',
    //布局 层级布局
    'hierarchyLayout':'hierarchyLayout',
    //停止一切动画，例如退出等动作
    'stopAnimation':'stopAnimation',
    
    //框选事件
    'extentSelect':'extentSelect',
    //选中的点和边的id
    'selectNodesAndEdges':'selectNodesAndEdges',
    //选中的点和边的id的对象数组
    'selectNodesAndEdgesObjs':'selectNodesAndEdgesObjs',
    //更新选中的信息
    'updateSelectByIds':'updateSelectByIds',
    //选中事件。包括拖拽等过程需要样式变动
    'selectOneNode':'selectOneNode',
    //节点点击事件，改为drag边启用
    'nodeClickEvent':'nodeClickEvent',
    
    //右键事件
    'rightClickNodeEvent':'rightClickNodeEvent',
    'rightClickEdgeEvent':'rightClickEdgeEvent',
    'rightClickStageEvent':'rightClickStageEvent',
    

    //编辑添加结点和边
    'addNodesAndEdges':'addNodesAndEdges',
    //编辑事件
    'endEdit':'endEdit',
    //删除结点
    'deleteNodes':'deleteNodes',
    //业务拖拽添加
    'mouseDownDragAdd':'mouseDownDragAdd',
    //添加边的结果回调
    'mouseDownDragAddRelation':'mouseDownDragAddRelation',
    //添加边的结果回调
    'mouseDownDragAddRelationCallBack':'mouseDownDragAddRelationCallBack',
    //更新历史
    'updateHistory':'updateHistory',
    //更新选中历史
    'updateHistorySelect':'updaeaHistorySelect',
    //更新视角历史
    'updateHistoryView':'updateHistoryView',
    //上一步按钮的状态通知
    'prevStatus':'prevStatus',
    //通知保存历史的状态，特殊情况下解决多重历史的保存
    'unHistory':'unHistory',
    //触发上一步
    'getPreHis':'getPreHis',
    //清空历史
    'clearHistory':'clearHistory',


    //改变视图,监听所有的视图改变
    'changeView':'changeView',
    //跳转至视图
    'gotoView':'gotoView',
    //修改样式状态事件
    'styleStatus':'styleStatus',
    //设置单个边的样式
    'setEdgeStyle':'setEdgeStyle',
    //设置单个点的样式
    'setNodeStyle':'setNodeStyle'
}

export default EVENTS