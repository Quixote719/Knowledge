import EVENTS from '../event/eventdeclara'
import Util from '../util'
/**
 * 拖拽交互动作
 * 结合选中进行拖动
 */
class DragInteract{
    constructor(main){
        this.main = main
        this.s = this.main.s
        //是否拖拽
        this.isDrag = false
        //监听是否启用
        main.bind(EVENTS['dragEnable'],this.dragEnable,this)
        //由于右键会触发drag事件，所以在这里进行监听屏蔽
        main.bind(EVENTS['dragDisabled'],this.dragDisabled,this)
        this.selectNodes = {}
        main.bind(EVENTS['selectNodesAndEdgesObjs'],(selectNodes)=>{this.selectNodes = selectNodes})
        this.initDrag()
    }
    /**
     * 是否支持拖拽功能
     */
    initDrag = ()=>{
        this.dragListener = null
        // Initialize the dragNodes plugin:
        this.dragListener = sigma.plugins.dragNodes(this.s, this.s.renderers[0]);

        this.startDragHandler = this.dragListener.bind('startdrag', (e)=> {
            this.startDragEvent(e)
        });
        this.dragListener.bind('drag', (event)=> {
            /** 暂时不做多选的群体移动
            let curNode = event.data.node
            let changeX = this.firstX - curNode.x
            let changeY = this.firstY - curNode.y 
            for(let curNodeId in this.selectNodes){
                let node = this.selectNodes[curNodeId]
                if(node.id != curNode.id){
                    let oldNode = this.oldSelectNodes[curNodeId]
                    node.x = oldNode.x - changeX
                    node.y = oldNode.y - changeY
                }
            }
            */
        });
        this.dragListener.bind('drop', function(event) {

        });
        this.dragListener.bind('dragend', (e)=> {
            if(!this.isDrag){
                return
            }
            this.main.trigger(EVENTS['endEdit'],true)
            //提前通知无需进行历史存储,延迟，因为会提前在click之前
            setTimeout(()=>{
                console.log('unHistory  false')
                this.main.trigger(EVENTS['unHistory'],false)
            },1000)
            
        });
        this.isDrag = true
    }
    startDragEvent = (e)=>{
        if(!this.isDrag){
            return
        }
        //存储历史
        this.main.trigger(EVENTS['updateHistory'])
        //提前通知选中无需进行历史存储
        this.main.trigger(EVENTS['unHistory'],true)
        //进行选中，需要说明的是要取消掉原来的点击事件
        
        this.main.trigger(EVENTS['nodeClickEvent'],e)
        this.firstX = e.data.node.x
        this.firstY = e.data.node.y

        this.oldSelectNodes = Util.cloneDeep(this.selectNodes)
    }
    dragEnable = ()=>{
        //debugger
        //this.startDragHandler = this.dragListener.bind('startdrag', this.startDragEvent)
        this.isDrag = true
    }
    dragDisabled = ()=>{
        //debugger
        //sigma.plugins.killDragNodes(this.s)
        this.isDrag = false
        //this.dragListener.unbindAll()
        //this.startDragHandler.unbindAll()
        
        //this.dragListener.unbind('startdrag',this.startDragHandler)
    }
}
export default DragInteract