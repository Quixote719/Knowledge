import EVENTS from '../event/eventdeclara'
import Util from '../util'
/**
 * 框选交互动作
 * 实现思路，创建临时的canvas画布，框选动作
 */
class BoxSelect{
    constructor(main){
        this.main = main
        this.param = main.param
        //是否框选
        this.isBoxSelect = false
        this.boxSelectStart = []
        this.boxSelectEnd = []
        this.boxSelectDrawStart = []
        this.boxSelectDrawEnd = []
        //监听框选
        main.bind(EVENTS['extentSelect'],this.extentSelect,this)
        main.bind(EVENTS['mouseup'],this.mouseup,this)
        main.bind(EVENTS['mousedown'],this.mousedown,this)
        main.bind(EVENTS['mousemove'],this.mousemove,this)
        main.bind(EVENTS['updateSelectByIds'],this.updateSelectByIds,this)
        this.selectNodeIds=[]
        this.selectEdgeIds=[]
        main.bind(EVENTS['selectNodesAndEdges'],(selectNodeIds,selectEdgeIds)=>{
            this.selectNodeIds = selectNodeIds
            this.selectEdgeIds = selectEdgeIds
        })
        
    }
    extentSelect = ()=>{
        console.log('框选动作111')
        //覆盖在之前的画布之上
        const el = this.main.param.dom
        this.canvasDom = document.createElement('canvas')
        el.appendChild(this.canvasDom)
        //改变鼠标移动上的样式，up即取消框选，
        this.canvasDom.style.cursor = 'crosshair'
        this.canvasDom.style.zIndex = 51
        //this.canvasDom.style.backgroundColor = '#000000' 测试
        this.canvasDom.height = this.main.param.dom.clientHeight
        this.canvasDom.width = this.main.param.dom.clientWidth
        this.isBoxSelect = true
        this.sigmaEventDom = document.getElementsByClassName("sigma-mouse")[0]
        this.sigmaEventDom.style.display = 'none'
        this.canvasDom.style.cursor = 'crosshair'
    }
    mousedown = (pos,event,xy)=>{
        if(!this.isBoxSelect){
            return
        }
        this.boxSelectStart = [xy.x,xy.y]

        this.boxSelectDrawStart = [pos.x,pos.y]
        console.log(this.boxSelectStart)
    }

    mouseup = (pos,event,xy)=>{
        if(!this.isBoxSelect){
            return
        }
        let oldSelectNodeIds = this.selectNodeIds.slice()
        let oldSelectEdgeIds = this.selectEdgeIds.slice()
        this.selectNodes = {}
        this.selectEdges = {}
        this.selectNodeIds = []
        this.selectEdgeIds = []

        this.boxSelectEnd = [xy.x,xy.y]
        //console.log(this.boxSelectEnd)
        this.isBoxSelect = false
        this.sigmaEventDom.style.display = 'block'
        const el = this.main.param.dom
        el.removeChild(this.canvasDom)
        this.canvasDom = null
        if(this.boxSelectStart.length > 0 && this.boxSelectEnd.length > 0){
            let startX = this.boxSelectStart[0] <= this.boxSelectEnd[0]
                ? this.boxSelectStart[0]
                : this.boxSelectEnd[0]
            let startY = this.boxSelectStart[1] <= this.boxSelectEnd[1]
                ? this.boxSelectStart[1]
                : this.boxSelectEnd[1]
            let endX = this.boxSelectStart[0] <= this.boxSelectEnd[0]
                ? this.boxSelectEnd[0]
                : this.boxSelectStart[0]
            let endY = this.boxSelectStart[1] <= this.boxSelectEnd[1]
                ? this.boxSelectEnd[1]
                : this.boxSelectStart[1]
            /*
            //从数据里面执行框选动作，并执行选中 this.main.param.dom.clientWidth
            let targetWidth = document.getElementsByClassName("sigma-scene")[0].width - 0
            let targetHeight = document.getElementsByClassName("sigma-scene")[0].height - 0
            console.log(startX,startY,endX,endY)
            //调用自带的坐标转换
            let xy0 = sigma.utils.mouseCoords({clientX:startX,clientY:startY,target:{width:targetWidth,height:targetHeight,namespaceURI:[]}})
            let xy1 = sigma.utils.mouseCoords({clientX:endX,clientY:endY,target:{width:targetWidth,height:targetHeight,namespaceURI:[]}})
            let render = this.main.s.renderers[0]
            let modifiedX0 = xy0.x + render.width / 2
            let modifiedY0 = xy0.y + render.height / 2
            let modifiedX1 = xy1.x + render.width / 2
            let modifiedY1 = xy1.y + render.height / 2
            //console.log(this.main.s.camera.graphPosition(startX,startY,{x:startX,y:startY}))
            //console.log(this.main.s.camera.cameraPosition(xy0.x,xy0.y),)
            console.log(modifiedX0,modifiedY0,modifiedX1,modifiedY1)
            let prefix = 'renderer1'
            */
            //let 
            let nodes = this.main.s.graph.nodes()
            let edges = this.main.s.graph.edges()
            let nodesOfStyle = {},edgesOfStyle = {},isAllStyle = true
            for(let i=0;i<nodes.length;i++){
                let node = nodes[i]
                //let size = node[prefix + ':size']
                let x = node.x
                let y = node.y
                //if(x>=modifiedX0 && x<=modifiedX1 && y>=modifiedY0 && y<=modifiedY1){
                if(x>=startX && x<=endX && y>=startY && y<=endY){
                    this.selectNodes[node.id] = node
                    this.selectNodeIds.push(node.id)
                    nodesOfStyle[node.id] = 'selected'
                }
            }
            for(let i=0;i<edges.length;i++){
                let e = edges[i]
                if (this.selectNodes[e.source] && this.selectNodes[e.target]){
                    this.selectEdges[e.id] = e
                    this.selectEdgeIds.push(e.id)
                    edgesOfStyle[e.id] = 'selected'
                }
            }
            //使用全局改变样式，这样只标定需要改进的，其它都会进行默认计算为default或者unSelected
            this.main.trigger(EVENTS['styleStatus'],nodesOfStyle,edgesOfStyle,isAllStyle)
            this.main.s.refresh()
        }
        
        //还原画布状态
        this.isBoxSelect = false
        this.boxSelectStart = []
        this.boxSelectEnd = []
        this.boxSelectDrawStart = []
        this.boxSelectDrawEnd = []
        //todo his 判断两个数组有一个不相等则，进行历史变更
        this.main.trigger(EVENTS['updateHistorySelect'],oldSelectNodeIds,oldSelectEdgeIds,this.selectNodeIds,this.selectEdgeIds)
        //被选中的ID数组
        this.main.trigger(EVENTS['selectNodesAndEdges'],this.selectNodeIds,this.selectEdgeIds)
        //被选中的点和边的对象
        this.main.trigger(EVENTS['selectNodesAndEdgesObjs'],this.selectNodes,this.selectEdges)
        
        
    }
    mousemove = (pos,event,xy)=>{
        if(!this.isBoxSelect){
            return
        }
        this.boxSelectDrawEnd = [pos.x,pos.y]
        if(this.boxSelectDrawStart.length > 0 && this.boxSelectDrawEnd.length > 0){
            let startX = this.boxSelectDrawStart[0] <= this.boxSelectDrawEnd[0]
                ? this.boxSelectDrawStart[0]
                : this.boxSelectDrawEnd[0]
            let startY = this.boxSelectDrawStart[1] <= this.boxSelectDrawEnd[1]
                ? this.boxSelectDrawStart[1]
                : this.boxSelectDrawEnd[1]
            let endX = this.boxSelectDrawStart[0] <= this.boxSelectDrawEnd[0]
                ? this.boxSelectDrawEnd[0]
                : this.boxSelectDrawStart[0]
            let endY = this.boxSelectDrawStart[1] <= this.boxSelectDrawEnd[1]
                ? this.boxSelectDrawEnd[1]
                : this.boxSelectDrawStart[1]
            let ctx = this.canvasDom.getContext('2d')
            Util.clearCanvasAndDrawBack(ctx,this.canvasDom.width,this.canvasDom.height,'rgba(255,255,255,0)')
            ctx.fillStyle = 'rgba(100,150,185,0.5)'
            ctx.fillRect(startX,startY,endX-startX,endY-startY)
        }
        
    }
    /**
     * 更新被选中的节点和边
     */
    updateSelectByIds = (selectNodeIds,selectEdgeIds,isNotRefresh) => {
        this.selectNodes = {}
        this.selectEdges = {}
        this.selectNodeIds = selectNodeIds
        this.selectEdgeIds = selectEdgeIds
        /*
        let nodes = this.main.s.graph.nodes()
        let edges = this.main.s.graph.edges()
        let selectNodeColor = this.param.node.style.selectNodeColor
        let unColor = this.param.node.style.unColor
        let selectEdgeColor = this.param.edge.style.selectEdgeColor
        let unEdgeColor = this.param.edge.style.unColor
        for(let i=0;i<nodes.length;i++){
            let node = nodes[i]
            if(selectNodeIds.indexOf(node.id)>-1){
                this.selectNodes[node.id] = node
                node.color = selectNodeColor
            }else{
                node.color = unColor
            }
        }
        for(let i=0;i<edges.length;i++){
            let e = edges[i]
            if (selectEdgeIds.indexOf(e.id)>-1){
                this.selectEdges[e.id] = e
                e.color = selectEdgeColor
            }else{
                e.color = unEdgeColor
            }
        }*/
        let nodesOfStyle = {},edgesOfStyle = {},isAllStyle = true
        for(let i=0;i<selectNodeIds.length;i++){
            nodesOfStyle[selectNodeIds[i]] = 'selected'
        }
        for(let i=0;i<selectEdgeIds.length;i++){
            edgesOfStyle[selectEdgeIds[i]] = 'selected'
        }
        //使用全局改变样式，这样只标定需要改进的，其它都会进行默认计算为default或者unSelected
        this.main.trigger(EVENTS['styleStatus'],nodesOfStyle,edgesOfStyle,isAllStyle)
        if(!isNotRefresh){
            this.main.s.refresh()
        }
        //被选中的ID数组
        this.main.trigger(EVENTS['selectNodesAndEdges'],this.selectNodeIds,this.selectEdgeIds)
        //被选中的点和边的对象
        this.main.trigger(EVENTS['selectNodesAndEdgesObjs'],this.selectNodes,this.selectEdges)
    }
}
export default BoxSelect