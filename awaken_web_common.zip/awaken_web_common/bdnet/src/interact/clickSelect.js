import EVENTS from '../event/eventdeclara'
import Util from '../util/index'
/**
 * 点击交互动作
 * 
 */
class ClickSelect{
    constructor(main){
        this.main = main
        this.param = this.main.param
        this.s = this.main.s
        //是否ctrl
        this.isctrl = false
        this.selectNodes = {}
        this.selectEdges = {}
        this.selectNodeIds = []
        this.selectEdgeIds = []
        this.mousedownXY = {}
        this.mouseupXY = {}
        this.bindEvent()
        //不执行历史存储
        this.unHistory = false
        this.styleNConfig = this.param.node.style
        this.styleEConfig = this.param.edge.style
        main.bind(EVENTS['nodeClickEvent'],this.nodeClickEvent,this)
        main.bind(EVENTS['selectOneNode'],this.selectOneNode,this)
        main.bind(EVENTS['unHistory'],(isUnHis)=>{
            this.unHistory = isUnHis
        })
        main.bind(EVENTS['selectNodesAndEdges'],(selectNodeIds,selectEdgeIds)=>{
            this.selectNodeIds = selectNodeIds
            this.selectEdgeIds = selectEdgeIds
        })
        main.bind(EVENTS['styleStatus'],this.styleStatus)

        main.bind(EVENTS['setNodeStyle'],this.setNodeStyle)
        main.bind(EVENTS['setEdgeStyle'],this.setEdgeStyle)
        
        

        //设定多选个数，达到后就停止多选
        this.selectCtrlCount = 0
        this.isCtrlSelect = false
        main.bind(EVENTS['ctrlSelectCount'],(selectCtrlCount)=>{
            if(selectCtrlCount>0){
                this.selectCtrlCount = selectCtrlCount
                this.isCtrlSelect = true
            }else{
                this.selectCtrlCount = 0
                this.isCtrlSelect = false
            }
        })
        //测试
        //this.main.trigger(EVENTS['ctrlSelectCount'],2)
    }
    /**
     * 事件绑定
     */
    bindEvent = ()=>{
        /*
        this.s.bind('overNode outNode clickNode doubleClickNode rightClickNode', function(e) {
            console.log(e.type, e.data.node.label, e.data.captor);
        });
        this.s.bind('overEdge outEdge clickEdge doubleClickEdge rightClickEdge', function(e) {
            console.log(e.type, e.data.edge, e.data.captor);
        });
        this.s.bind('clickStage', function(e) {
            console.log(e.type, e.data.captor);
        });
        this.s.bind('doubleClickStage rightClickStage', function(e) {
            console.log(e.type, e.data.captor);
        });
        */
        //鼠标是否移动的监听
        this.main.bind(EVENTS['mousedown'],this.mousedown,this)
        this.main.bind(EVENTS['mouseup'],this.mouseup,this)
        //右键菜单点击到节点
        this.s.bind('rightClickNode', (e) => {
            //先关闭拖拽，因为右键也会触发拖拽
            this.main.trigger(EVENTS['dragDisabled']) 
            //单个选中节点
            let oldSelectNodeIds = this.selectNodeIds.slice()
            let oldSelectEdgeIds = this.selectEdgeIds.slice()
            
            let node = e.data.node
            this.selectOneNode(node)
            this.main.trigger(EVENTS['rightClickNodeEvent'],e,node)
            //his 判断两个数组有一个不相等则，进行历史变更
            this.main.trigger(EVENTS['updateHistorySelect'],oldSelectNodeIds,oldSelectEdgeIds,this.selectNodeIds,this.selectEdgeIds)
            //再开启拖拽，因为右键也会触发拖拽
            setTimeout(()=>{this.main.trigger(EVENTS['dragEnable'])},100)
        })
        this.s.bind('rightClickEdge', (e) => {
            //单个选中边
            let oldSelectNodeIds = this.selectNodeIds.slice()
            let oldSelectEdgeIds = this.selectEdgeIds.slice()
            
            let edge = e.data.edge
            this.selectOneEdge(edge)
            this.main.trigger(EVENTS['rightClickEdgeEvent'],e,edge)
            //his 判断两个数组有一个不相等则，进行历史变更
            this.main.trigger(EVENTS['updateHistorySelect'],oldSelectNodeIds,oldSelectEdgeIds,this.selectNodeIds,this.selectEdgeIds)
        })
        //右键空白点击
        this.s.bind('rightClickStage', (e) => {
            //this.clickStage(e)
            this.main.trigger(EVENTS['rightClickStageEvent'],e)
        })
        //左键点击画布空白
        this.s.bind('clickStage', (e) => {
                this.clickStage(e)
        })
        //取消点击事件，代替为drag的点击事件
        //this.nodeClickEvent(this)
        this.bindEdgeEvent(this)
        //绑定ctrl键的信息
        this.main.bind(EVENTS['ctrlKey'],this.ctrlChange,this)
    }
    mousedown = (e)=>{
        this.mousedownXY = e
    }
    mouseup = (e)=>{
        this.mouseupXY = e
    }
    /**
     * 点击空白处事件
     */
    clickStage = (e)=>{
        console.log('clickStage')
        //当两次的坐标不相等，说明是做了平移
        if(this.mousedownXY.x != this.mouseupXY.x && this.mousedownXY.y != this.mouseupXY.y ){
            console.log('做了平移')
            return
        }
        /* 测试获得画布位置失败
        let eWidth = this.main.param.dom.offsetWidth - 0
        let eHeight = this.main.param.dom.offsetHeight - 0
        //let xy = this.main.s.camera.graphPosition(e.data.captor.x,e.data.captor.y)
        
        //this.main.s.camera.graphPosition(e.data.captor.x,e.data.captor.y)
        //console.log(xy.x,xy.y)
        let xy = this.main.s.camera.cameraPositionToScreenErr(e.data.captor.x,e.data.captor.y,eWidth,eHeight)
        //xy = {x:xy.x + eWidth/2,y:xy.y + eHeight/2}
        console.log(xy.x,xy.y)
        */
        let oldSelectNodeIds = this.selectNodeIds.slice()
        let oldSelectEdgeIds = this.selectEdgeIds.slice()
        /*
        //两次坐标相当，是做了选择清空操作
        let defaultNodeColor = this.param.node.style.defaultColor
        let defaultEdgeColor = this.param.edge.style.defaultColor
        this.s.graph.nodes().forEach(function(n) {
            n.color = defaultNodeColor
        })
  
        this.s.graph.edges().forEach(function(e) {
            e.color = defaultEdgeColor
        })*/
        this.selectNodes = {}
        this.selectEdges = {}
        this.selectNodeIds = []
        this.selectEdgeIds = []
        let nodesOfStyle = {}
        let edgesOfStyle = {}
        let isAllStyle = true
        this.main.trigger(EVENTS['styleStatus'],nodesOfStyle,edgesOfStyle,isAllStyle)
        //被选中的ID数组
        this.main.trigger(EVENTS['selectNodesAndEdges'],this.selectNodeIds,this.selectEdgeIds)
        //被选中的点和边的对象
        this.main.trigger(EVENTS['selectNodesAndEdgesObjs'],this.selectNodes,this.selectEdges)
        this.s.refresh()
        //his 判断两个数组有一个不相等则，进行历史变更
        this.main.trigger(EVENTS['updateHistorySelect'],oldSelectNodeIds,oldSelectEdgeIds,this.selectNodeIds,this.selectEdgeIds)

    }
    /**
     * ctrl改变状态
     */
    ctrlChange = (isctrl)=>{
        this.isctrl = isctrl
    }
    /**
     * 绑定点击事件
     */
    nodeClickEvent = (e)=>{
        //this.s.bind('clickNode', (e)=> {
        let nodeId = e.data.node.id
        //要解决和drag冲突，drag会做个事情，就是选中
        let oldSelectNodeIds = this.selectNodeIds.slice()
        let oldSelectEdgeIds = this.selectEdgeIds.slice()

        let nodesOfStyle = {}
        let edgesOfStyle = {}
        let isAllStyle = true
        //*******分清ctrl版本***********/
        if(this.isctrl || this.isCtrlSelect){
            //使用ctrl，不启用邻居
            //先判断是否重复点，重复则删除
            let isAdd = false
            if(this.selectNodes[nodeId]){
                //删除选中  ,,暂时选中不做删除
                //delete this.selectNodes[nodeId]
                for(let i=0;i<this.selectNodeIds.length;i++){
                    if(this.selectNodeIds[i] === nodeId){
                        this.selectNodeIds.splice(i,1)
                        break
                    }
                }
            }else{
                isAdd = true
            }
            isAllStyle = false
            this.s.graph.nodes().forEach((n)=> {
                //加入选中
                if (isAdd && n.id === nodeId){
                    this.selectNodes[n.id] = n
                    this.selectNodeIds.push(n.id)
                    nodesOfStyle[n.id] = 'selected'
                }
            })
            //判断设定多选已经结束
            if(this.isCtrlSelect){
                let count = this.selectNodeIds.length
                console.log('被选中的数据量：：：：：：' + count)
                if(count >= this.selectCtrlCount){
                    this.selectCtrlCount = 0
                    this.isCtrlSelect = false
                }
            }
        }else if(!this.isctrl){
            //不使用ctrl，启用邻居，然后需要提前清空
            //是否启用邻居选中选项 todo，或者单选用框选解决好了呢
            let toKeep = this.s.graph.neighbors(nodeId)
            //toKeep[nodeId] = e.data.node
            //全部清空
            this.selectNodes = {}
            this.selectEdges = {}
            this.selectNodeIds = []
            this.selectEdgeIds = []

            
            isAllStyle = true
            this.s.graph.nodes().forEach((n)=> {
                if (toKeep[n.id]){
                    //this.selectNodes[n.id] = n
                    //this.selectNodeIds.push(n.id)
                    //和边相关联的点是relation 相关联状态,并且下面一起进行强制的样式覆盖
                    nodesOfStyle[n.id] = 'relation'
                }else{
                    //不相关的话默认是未选中
                    //nodesOfStyle[n.id] = 'unSelected'
                    nodesOfStyle[n.id] = 'default'
                }
            })
            this.selectNodes[nodeId] = e.data.node
            this.selectNodeIds.push(nodeId)
            nodesOfStyle[nodeId] = 'selected'
            this.s.graph.edges().forEach((e)=> {
                if (e.source === nodeId || e.target === nodeId){
                    edgesOfStyle[e.id] = 'relation'
                }else
                    //edgesOfStyle[e.id] = 'unSelected'
                    edgesOfStyle[e.id] = 'default'
                }
            )
            
        }
        
        
        
        //派发事件，边的选中和节点选中


        /* 非邻居选中选项
        if(!this.isctrl){
            this.selectNodes = {}
        }
        this.selectNodes[nodeId] = e.data.node

        this.s.graph.nodes().forEach((n)=> {
            if (this.selectNodes[n.id])
                n.color = '#ff0000'
            else
                n.color = '#000'
        });
        this.main.s.refresh()
        */
        this.main.trigger(EVENTS['styleStatus'],nodesOfStyle,edgesOfStyle,isAllStyle)
        this.s.refresh()
        //被选中的ID数组
        this.main.trigger(EVENTS['selectNodesAndEdges'],this.selectNodeIds,this.selectEdgeIds)
        //被选中的点和边的对象
        this.main.trigger(EVENTS['selectNodesAndEdgesObjs'],this.selectNodes,this.selectEdges)
        //his 判断两个数组有一个不相等则，进行历史变更
        if(!this.unHistory){
            this.main.trigger(EVENTS['updateHistorySelect'],oldSelectNodeIds,oldSelectEdgeIds,this.selectNodeIds,this.selectEdgeIds)
        }
        //})
    }
    bindEdgeEvent = ()=>{
        this.s.bind('clickEdge', (e)=> {
            console.log('clickEdge')
            let oldSelectNodeIds = this.selectNodeIds.slice()
            let oldSelectEdgeIds = this.selectEdgeIds.slice()
            let selectEdgeId = e.data.edge.id
            let sourceId = e.data.edge.source
            let targetId = e.data.edge.target
            let nodesOfStyle = {}
            let edgesOfStyle = {}
            let isAllStyle = true
            //*******分清ctrl版本***********/
            if(!this.isctrl){
                //全部清空
                this.selectNodes = {}
                this.selectEdges = {}
                this.selectNodeIds = []
                this.selectEdgeIds = []
                isAllStyle = true
                this.s.graph.nodes().forEach((n)=> {
                    if(n.id == sourceId || n.id == targetId){
                        //this.selectNodes[n.id] = n
                        //this.selectNodeIds.push(n.id)
                        //和边相关联的点是relation 相关联状态,并且下面一起进行强制的样式覆盖
                        nodesOfStyle[n.id] = 'relation'
                    }else{
                        //不相关的话默认是未选中
                        //nodesOfStyle[n.id] = 'unSelected'
                        nodesOfStyle[n.id] = 'default'
                    }
                    
                })
                
                this.s.graph.edges().forEach((e)=> {
                    if (e.id == selectEdgeId){
                        this.selectEdges[e.id] = e
                        this.selectEdgeIds.push(e.id)
                        edgesOfStyle[e.id] = 'selected'
                    }else
                        //edgesOfStyle[e.id] = 'unSelected'
                        edgesOfStyle[e.id] = 'default'
                    }
                )
            }else{
                //使用ctrl，不启用邻居
                //先判断是否重复边，重复则删除
                let isAdd = false
                isAllStyle = false
                if(this.selectEdges[selectEdgeId]){
                    //删除选中 ,,暂时选中不做删除
                    //delete this.selectEdges[selectEdgeId]
                    for(let i=0;i<this.selectEdgeIds.length;i++){
                        if(this.selectEdgeIds[i] === selectEdgeId){
                            this.selectEdgeIds.splice(i,1)
                            break
                        }
                    }
                }else{
                    isAdd = true
                }

                this.s.graph.edges().forEach((edge)=> {
                    //加入选中
                    if (isAdd && edge.id === selectEdgeId){
                        this.selectEdges[edge.id] = edge
                        this.selectEdgeIds.push(edge.id)
                        edgesOfStyle[edge.id] = 'selected'
                    }
                })
            }
            //样式的派发 ,找不到的话就使用默认
            /*
            this.defaultNodeIds = []
            this.selectedNodeIds = []
            this.relationNodeIds = []
            this.unSelectedNodeIds = []
            this.defaultEdgeIds = []
            this.selectedEdgeIds = []
            this.relationEdgeIds = []
            this.unSelectedEdgeIds = []
            */
            this.main.trigger(EVENTS['styleStatus'],nodesOfStyle,edgesOfStyle,isAllStyle)
            this.s.refresh()
            //被选中的ID数组
            this.main.trigger(EVENTS['selectNodesAndEdges'],this.selectNodeIds,this.selectEdgeIds)
            //被选中的点和边的对象
            this.main.trigger(EVENTS['selectNodesAndEdgesObjs'],this.selectNodes,this.selectEdges)
            //his 判断两个数组有一个不相等则，进行历史变更
            this.main.trigger(EVENTS['updateHistorySelect'],oldSelectNodeIds,oldSelectEdgeIds,this.selectNodeIds,this.selectEdgeIds)
        })
    }
    //单个选中节点 ,暂时不做历史存储
    selectOneNode = (node) => {
        //let oldSelectNodeIds = this.selectNodeIds.slice()
        //let oldSelectEdgeIds = this.selectEdgeIds.slice()
        //let selectNodeColor = this.param.node.style.selectNodeColor
        //let unColor = this.param.node.style.unColor
        let unEdgeColor = this.param.edge.style.unColor
        this.selectNodes = {}
        this.selectEdges = {}
        this.selectNodeIds = []
        this.selectEdgeIds = []
        let id = node.id
        this.selectNodes[id] = node
        this.selectNodeIds = [id]
        let nodesOfStyle = {}
        nodesOfStyle[id] = 'selected'
        let edgesOfStyle = {}
        let isAllStyle = true
        /*
        this.s.graph.nodes().forEach((n)=> {
            if (this.selectNodes[n.id]){
                n.color = selectNodeColor
            }else
                n.color = unColor
        })
        
        this.s.graph.edges().forEach((e)=> {
            e.color = unEdgeColor
        })
        */
        this.main.trigger(EVENTS['styleStatus'],nodesOfStyle,edgesOfStyle,isAllStyle)
        this.s.refresh()
        //被选中的ID数组
        this.main.trigger(EVENTS['selectNodesAndEdges'],this.selectNodeIds,this.selectEdgeIds)
        //被选中的点和边的对象
        this.main.trigger(EVENTS['selectNodesAndEdgesObjs'],this.selectNodes,this.selectEdges)
        //his 判断两个数组有一个不相等则，进行历史变更
        //this.main.trigger(EVENTS['updateHistorySelect'],oldSelectNodeIds,oldSelectEdgeIds,this.selectNodeIds,this.selectEdgeIds)
    }
    //单个选中边
    selectOneEdge = (edge) => {
        let oldSelectNodeIds = this.selectNodeIds.slice()
        let oldSelectEdgeIds = this.selectEdgeIds.slice()
        let unColor = this.param.node.style.unColor
        let selectEdgeColor = this.param.edge.style.selectEdgeColor
        let unEdgeColor = this.param.edge.style.unColor
        this.selectNodes = {}
        this.selectEdges = {}
        this.selectNodeIds = []
        this.selectEdgeIds = []
        let id = edge.id
        this.selectEdges[id] = edge
        this.selectEdgeIds = [id]
        let nodesOfStyle = {}
        let edgesOfStyle = {}
        let isAllStyle = true
        /*
        this.s.graph.nodes().forEach((n)=> {
            n.color = unColor
        })

        this.s.graph.edges().forEach((e)=> {
            if (e.id == edge.id){
                e.color = selectEdgeColor
            }else
                e.color = unEdgeColor
        })
        */
        this.s.graph.nodes().forEach((n)=> {
            if(n.id == edge.sourceId || n.id == edge.targetId){
                nodesOfStyle[n.id] = 'relation'
            }else{
                //不相关的话默认是未选中
                //nodesOfStyle[n.id] = 'unSelected'
                nodesOfStyle[n.id] = 'default'
            }
        })
        edgesOfStyle[id] = 'selected'
        this.main.trigger(EVENTS['styleStatus'],nodesOfStyle,edgesOfStyle,isAllStyle)
        this.s.refresh()
        
        //被选中的ID数组
        this.main.trigger(EVENTS['selectNodesAndEdges'],this.selectNodeIds,this.selectEdgeIds)
        //被选中的点和边的对象
        this.main.trigger(EVENTS['selectNodesAndEdgesObjs'],this.selectNodes,this.selectEdges)
        //his 判断两个数组有一个不相等则，进行历史变更
        this.main.trigger(EVENTS['updateHistorySelect'],oldSelectNodeIds,oldSelectEdgeIds,this.selectNodeIds,this.selectEdgeIds)
    }
    /**
     * nodesOfStyle 对象 类型
     * edgesOfStyle 对象 类型
     * isAllStyle 是否需要全部设置样式   单选 true ctrl选 false 框选 true
     */
    styleStatus = (nodesOfStyle,edgesOfStyle,isAllStyle) => {
        if(isAllStyle){
            //全部都要设置一遍，没有的话就使用默认的未选中或 常规状态
            //判断节点和边没有选中的内容，则全部常规状态
            let isNodes = false,isEdges = false
            for(let id in nodesOfStyle){
                isNodes = true
                break
            }
            for(let id in edgesOfStyle){
                isEdges = true
                break
            }
            if(!isNodes && !isEdges){
                this.s.graph.nodes().forEach((n)=> {
                    this.setNodeStyle(n,'default')
                })
        
                this.s.graph.edges().forEach((e)=> {
                    this.setEdgeStyle(e,'default')
                })
            }else{
                //判断没有的节点使用未选中状态
                this.s.graph.nodes().forEach((n)=> {
                    if(typeof(nodesOfStyle[n.id])!='undefined'){
                        let style = nodesOfStyle[n.id]
                        this.setNodeStyle(n,style)
                    }else{
                        //this.setNodeStyle(n,'unSelected')
                        this.setNodeStyle(n,'default')
                    }
                })
        
                this.s.graph.edges().forEach((e)=> {
                    if(typeof(edgesOfStyle[e.id])!='undefined'){
                        let style = edgesOfStyle[e.id]
                        this.setEdgeStyle(e,style)
                    }else{
                        //this.setEdgeStyle(e,'unSelected')
                        this.setEdgeStyle(e,'default')
                    }
                })
            }
            
        }else{
            //不需要全部设置，只设置当前标定的点,尤其是ctrl多选的时候
            this.s.graph.nodes().forEach((n)=> {
                if(typeof(nodesOfStyle[n.id])!='undefined'){
                    let style = nodesOfStyle[n.id]
                    this.setNodeStyle(n,style)
                }
            })
    
            this.s.graph.edges().forEach((e)=> {
                if(typeof(edgesOfStyle[e.id])!='undefined'){
                    let style = edgesOfStyle[e.id]
                    this.setEdgeStyle(e,style)
                }
            })
        }
    }
    /**
     * 设置节点的样式
     */
    setNodeStyle = (node,styleType) => {
        /*
        default:{
                    icon:{
                        color:'#305555',
                        size:10,
                        border_size:0,
                    },
                    //文字暂时还不确定能否一起改变
                    font:{
                        color:'#305555',
                        size:10,
                        border_size:1,
                    }
                },
        */
        const imgTypes = ['person','anjian','car','phone','card','camera','entity','event','place','goods','rfid','wifi']
        //前缀和后缀
        const urlPrefix = `${window.basename}/img/nettype/`
        const urlSuffix = '.png'
        let type = 'def'
        let url = ''
        let cfg = this.styleNConfig.status[styleType]
        node.color = cfg.icon.color
        //node.size = cfg.icon.size
        if(Util.isContain(imgTypes,node.subClass)){
            type = 'image'
            url = urlPrefix + node.subClass + '_' + styleType + urlSuffix
            //if(styleType!='selected'){node.color = 'rgba(255,255,255,0)'}
            node.color = 'rgba(255,255,255,0)'
        }
        node.type = type
        //矩形，不管是不是图片都会变成方形
        if(node.class === 'EVENTS'){
            //node.type = 'square'
            node.type = 'image'
            url = urlPrefix +  'anjian_' + styleType + urlSuffix
            node.color = 'rgba(255,255,255,0)'
        }
        if(node.type != 'image'){
            node.type = 'image'
            url = urlPrefix + 'entity_' + styleType + urlSuffix
            node.color = 'rgba(255,255,255,0)'
        }
        node.url = url
    }
    /**
     * 设置边的样式
     */
    setEdgeStyle = (edge,type) => {
        /*
        default:{
                    icon:{
                        color:'#305555',
                        size:10,
                        border_size:0,
                    },
                    //文字暂时还不确定能否一起改变
                    font:{
                        color:'#305555',
                        size:10,
                        border_size:1,
                    }
                },
        */
        let cfg = this.styleEConfig.status[type]
        edge.color = cfg.color
        edge.size = cfg.size
    }
}
export default ClickSelect