import EVENTS from '../event/eventdeclara'
import Util from '../util'
import GridLayout from './grid'
import ForceLayout from './force'
import CircleLayout from './circle'
import HierarchyLayout from './hierarchy'
/**
 * 框选交互动作
 * 实现思路，创建临时的canvas画布，框选动作
 */
class LayoutManager{
    constructor(main){
        this.main = main
        this.param = main.param
        this.s = main.s
        this.gridLayout = new GridLayout(main)
        this.forceLayout = new ForceLayout(main)
        this.circleLayout = new CircleLayout(main)
        this.hierarchyLayout = new HierarchyLayout(main)
        //监听框选
        main.bind(EVENTS['gridLayout'],this.grid,this)
        main.bind(EVENTS['forceLayout'],this.force,this)
        main.bind(EVENTS['circleLayout'],this.circle,this)
        main.bind(EVENTS['hierarchyLayout'],this.hierarchy,this)
        main.bind(EVENTS['stopAnimation'],this.stopLayout,this)
    }
    force = (isNotHis)=>{
        this.stopLayout(this)
        if(!isNotHis){
            this.main.trigger(EVENTS['updateHistory'])
        }
        this.forceLayout.force()
    }
    grid = (isNotHis)=>{
        this.stopLayout(this)
        if(!isNotHis){
            this.main.trigger(EVENTS['updateHistory'])
        }
        setTimeout(()=>{
            this.gridLayout.grid()
        },50)
    }
    circle = (isNotHis)=>{
        this.stopLayout(this)
        if(!isNotHis){
            this.main.trigger(EVENTS['updateHistory'])
        }
        this.circleLayout.circle()
    }
    hierarchy = (isNotHis)=>{
        this.stopLayout(this)
        if(!isNotHis){
            this.main.trigger(EVENTS['updateHistory'])
        }
        this.hierarchyLayout.hierarchy()
    }
    //清除正在布局的过程
    stopLayout = ()=>{
        this.forceLayout.stop()
    }
}
export default LayoutManager