import EVENTS from '../event/eventdeclara'
import Util from '../util'
/**
 * 层次布局
 * 
 */
class HierarchyLayout{
    constructor(main){
        this.main = main
        this.param = main.param
        this.s = main.s
        
    }
    hierarchy = ()=>{
        const nodes = this.s.graph.nodes()
        const edges = this.s.graph.edges()
        const allNodeIds = nodes.map((n) => n.id)
        const res = []
        const nodesInEachLevel = this.putNodesByHierarchy(nodes,edges,allNodeIds)
        const tempRes = this.calcHierarchyPos(nodesInEachLevel,{
            fit:true,
            horizontalGap:40,
            verticalGap:140,
        })
        //更改坐标
        this.changeNodesXY(tempRes)
    }
    putNodesByHierarchy = (nodes,edges,allNodeIds,root)=>{
        const nodeToEdgeMap = this.getNodeToEdgeMap(edges)
        const res = []
        let nodesAdded = []
        let nodesInOneLevel
        if(root){
            nodesInOneLevel = [root]
        }else {
            nodesInOneLevel = this.getNodesWithMostEdges(nodes,nodeToEdgeMap)
        }
        while (nodesInOneLevel.length > 0) {
            res.push(nodesInOneLevel)
            nodesAdded = nodesAdded.concat(nodesInOneLevel.map((n) => n.id))
            nodesInOneLevel = this.getNextLevelNodes(nodesInOneLevel, nodeToEdgeMap ,nodesAdded, allNodeIds)
        }
        return res
    }
    getNodeToEdgeMap = (edges) => {
        const nodeEdgeMap = {}
        for (const key in edges) {
            const edge = edges[key]
            this.buildNodeEdgeMap(nodeEdgeMap, edge.source, edge)
            this.buildNodeEdgeMap(nodeEdgeMap, edge.target, edge)
        }
        return nodeEdgeMap
    }
    buildNodeEdgeMap = (map, key, edge) => {
        if(!map.hasOwnProperty(key)){
            map[key] = [edge]
        }else {
            map[key].push(edge)
        }
    }
    getNodesWithMostEdges = (nodes, nodeToEdgeMap) => {
        let maxEdgeCount = 0
        let res = []
        for (const node of nodes) {
            const id = node.id
            const edgeLen = nodeToEdgeMap[id] ? nodeToEdgeMap[id].length : 0
            if(maxEdgeCount < edgeLen){
                maxEdgeCount = edgeLen
                res = [node]
            }else if (maxEdgeCount === edgeLen) {
                res.push(node)
            }
        }
        return res
    }
    /**
     * 找到下一层级的数据
     */
    getNextLevelNodes = (nodesInOneLevel, nodeToEdgeMap ,nodesAdded, allNodeIds) => {
        let res = []
        nodesInOneLevel.forEach((n) => {
            const edges = nodeToEdgeMap[n.id]
            if (!edges){
                return
            }
            edges.forEach((edge) => {
                if (edge.source &&
                    !nodesAdded.includes(edge.source) &&
                    allNodeIds.includes(edge.source) &&
                    !res.includes(edge.source)) {
                        res.push(this.getNodeById(edge.source))
                }
                if (edge.target &&
                    !nodesAdded.includes(edge.target) &&
                    allNodeIds.includes(edge.target) &&
                    !res.includes(edge.target)) {
                        let target = this.getNodeById(edge.target)
                        res.push(target)
                }
            })
        })
        return res
    }
    getNodeById = (id) => {
        const nodes = this.s.graph.nodes()
        let node = {}
        for(let i=0;i<nodes.length;i++){
            let node = nodes[i]
            if(node.id === id){
                return node
            }
        }
    }
    /**
     * 计算层次布局中每个点的位置
     */
    calcHierarchyPos = (cluster,options) => {
        const res = {}
        const sx = 0
        const sy = 0
        let tempY = sy
        //每个簇的起始位置
        let tempX = sx
        let maxLevelWidth = -Infinity
        cluster.forEach((nodeInOneLevel) => {
            maxLevelWidth = Math.max(maxLevelWidth, this.widthOfLevel(nodeInOneLevel, options))
        })
        cluster.forEach((nodeInOneLevel) => {
            const levelWidth = this.widthOfLevel(nodeInOneLevel, options)
            const levelHeight = this.heightOfLevel(nodeInOneLevel)
            // 每一行的起始位置 = 行中点 - 行宽/2
            tempX += maxLevelWidth / 2 - levelWidth / 2
            nodeInOneLevel.forEach((n) => {
                res[n.id] = {
                    x: tempX + n.size/2,
                    y: tempY + (levelHeight - 12) / 2
                }
                tempX += n.size + options.horizontalGap
            })
            tempX = sx
            tempY += levelHeight + options.verticalGap 
        })
        return res
    }
    //计算某一层点的宽度
    widthOfLevel = (nodes, options) => {
        let width = -options.horizontalGap
        nodes.forEach((n) => {
            width += options.horizontalGap + n.size
        })
        return width
    }
    //计算层的高度
    heightOfLevel = (nodes) => {
        let height = 0
        nodes.forEach((n) => {
            height = Math.max(height, n.size)
        })
        return height
    }
    changeNodesXY = (res) => {
        let nodes = this.s.graph.nodes()
        nodes.forEach(function(node,index) {
            if(res[node.id]){
                node.x = res[node.id].x
                node.y = res[node.id].y
            }
            
        })
        this.main.trigger(EVENTS['autoExtent'],true)
        this.s.refresh()
    }
}
export default HierarchyLayout