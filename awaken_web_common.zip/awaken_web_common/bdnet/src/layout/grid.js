import EVENTS from '../event/eventdeclara'
import Util from '../util'
/**
 * 网格布局
 * 
 */
class GridLayout{
    constructor(main){
        this.main = main
        this.param = main.param
        this.s = main.s
        
    }
    grid = ()=>{
        let nodes = this.s.graph.nodes()
        let nodeNum = nodes.length
        let L = Math.floor(Math.sqrt(nodeNum))
        //点与点的距离
        let distance = 20
        nodes.forEach((node,index)=> {
            //index + 1避免0的情况
            node.x = (index) % L * distance
            node.y = Math.floor((index) / L) * distance
        })
        this.main.trigger(EVENTS['autoExtent'],true)
        this.s.refresh()
    }
}
export default GridLayout