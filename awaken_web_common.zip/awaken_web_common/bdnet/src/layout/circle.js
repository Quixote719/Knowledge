import EVENTS from '../event/eventdeclara'
import Util from '../util'
/**
 * 圆形布局
 * 
 */
class CircleLayout{
    constructor(main){
        this.main = main
        this.param = main.param
        this.s = main.s
        
    }
    circle = ()=>{
        let nodes = this.s.graph.nodes()
        let nodeNum = nodes.length
        //let L = Math.floor(Math.sqrt(nodeNum))
        //点与点的距离
        let r = Math.max(nodes.length * 10,30)
        //圆上的数量
        let N = nodeNum
        nodes.forEach((node,index)=> {
            //index + 1避免0的情况
            node.x = r * Math.cos(Math.PI * 2 * index / N - Math.PI / 2)
            node.y = r * Math.sin(Math.PI * 2 * index / N - Math.PI / 2)
        })
        this.main.trigger(EVENTS['autoExtent'],true)
        this.s.refresh()
    }
}
export default CircleLayout