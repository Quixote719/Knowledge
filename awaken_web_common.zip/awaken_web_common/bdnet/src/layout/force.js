import EVENTS from '../event/eventdeclara'
import Util from '../util'
import * as d3 from 'd3'
/**
 * 力导向布局
 *
 */
class ForceLayout{
    constructor(main){
        this.main = main
        this.param = main.param
        this.s = main.s
    }
    force = ()=>{
        //一定要把数据的x y记录属性给删除，否则重复力导向不一致
        this.data = {
            nodes:Util.cloneDeep(this.s.graph.nodes()),
            edges:Util.cloneDeep(this.s.graph.edges()),
        }

        this.data.nodes.forEach((n)=>{
            if(typeof n.x != 'undefined'){
                delete n.x
                delete n.y
            }
        })
        this.simulation = d3.forceSimulation(this.data.nodes)
        //.force('collision',d3.forceCollide(12))
        //.force('charge', d3.forceManyBody().strength(-32))
        .force('collision', d3.forceCollide(150))//点与点的排斥力
        .force('charge', d3.forceManyBody().strength(-18))
        .force('link', d3.forceLink(this.data.edges).iterations(4).distance(300).id(function(d){return d.id}))
        //300次的默认，还是减少一下时间
        .alphaMin(0.5)
        //.force('x',d3.forceX())
        //.force('y',d3.forceY())
        //.force('center', d3.forceCenter(this.param.dom.clientWidth / 2, this.param.dom.clientHeight/ 2))
        // .force('center',d3.forceCenter(this.s.graph.nodes()[0].x,this.s.graph.nodes()[0].y))
        .on('tick', this.ticked)
    }
    ticked = () => {
        let nodes = this.s.graph.nodes()
        let dataset = this.data
        nodes.forEach(function(node,index) {
            node.x = dataset.nodes[index].x
            node.y = dataset.nodes[index].y
        })
        //自适应，但是不做历史存储
        this.main.trigger(EVENTS['autoExtent'],true)
        this.s.refresh()
    }
    stop = () => {
        if(typeof(this.simulation)!='undefined'){
            this.simulation.stop()
        }
    }
}
export default ForceLayout
