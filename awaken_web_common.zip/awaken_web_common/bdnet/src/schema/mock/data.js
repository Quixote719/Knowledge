/**
 * Created by yaojia7 on 2020/2/23.
 */
export default ({
    nodes: [{
        id: '1',
        label: '实体人',
        class: 'ENTITY',
        subClass: 'human',
        url:`${window.basename}/img/nettype/person_default.svg`,
        ok:true,
        error:'实体人错误信息',
        link:true,
        selected:true
    },
    {
        id: '2',
        label: '实体狗',
        class: 'ENTITY',
        subClass: 'dog',
        url:`${window.basename}/img/nettype/person_default.svg`,
        ok:true,
    },
    {
        id: '3',
        label: '实体猫',
        class: 'ENTITY',
        subClass: 'cat',
        url:`${window.basename}/img/nettype/person_default.svg`,
        ok:false
    },
    {
        id: '4',
        label: '实体房子',
        class: 'ENTITY',
        subClass: 'house',
        url:`${window.basename}/img/nettype/person_default.svg`,
        ok:false
    },
    {
        id: '5',
        label: '实体车辆',
        class: 'ENTITY',
        subClass: 'car',
        url:`${window.basename}/img/nettype/car_default.svg`,
        ok:false
    },
    {
        id: '6',
        label: '实体公司',
        class: 'ENTITY',
        subClass: 'company',
        url:`${window.basename}/img/nettype/anjian_default.svg`,
        ok:true,
        error:'fhhhhhhhhhhhhh',
        link:true,
        selected:true
    },
    {
        id: '7',
        label: '年龄sadkjfhgasdkjhfgaksd',
        class: 'ATTR',
        subClass: 'age'
    },
    {
        id: '9',
        label: '性别',
        class: 'ATTR',
        subClass: 'gender'
    },{
        id: '99',
        label: '地址',
        class: 'ATTR',
        subClass: 'address'
    },{
        id: '991',
        label: '国籍',
        class: 'ATTR',
        subClass: 'country'
    },{
        id: '992',
        label: '肤色',
        class:  'ATTR',
        subClass: 'color'
    }, {
        id: '993',
        label: '职业',
        class: 'ATTR',
        subClass: 'job'
    }
    ],
    edges: [{
        id: '8',
        class: 'edge',
        source: '7',
        target: '1'
    },{
        id: '101',
        class: 'edge',
        source: '9',
        target: '1'
    },{
        id: '102',
        class: 'edge',
        source: '99',
        target: '1'
    },{
        id: '103',
        class: 'edge',
        source: '991',
        target: '1'
    },{
        id: '104',
        class: 'edge',
        source: '992',
        target: '1'
    },{
        id: '105',
        class: 'edge',
        source: '993',
        target: '1'
    },{
        id: '11',
        class: 'RELATION',
        label: '伙伴',
        source: '2',
        target: '3'
    },{
        id: '12',
        class: 'RELATION',
        label: '拥有',
        source: '1',
        target: '5'
    },{
        id: '14',
        class: 'RELATION',
        label: '任职1231231242342342342131',
        source: '1',
        target: '6',
        error: 'asdfads'
    }
    ]
})
