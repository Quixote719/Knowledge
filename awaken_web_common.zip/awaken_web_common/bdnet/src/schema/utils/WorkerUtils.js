/**
 * Created by yaojia7 on 2019/10/16.
 */
class WorkerUtil {
    _listeners = {
        /**
         * [eventType]: [handler1, handler2,...]
         */
    }

    static extend(worker) {
        Object.assign(worker, new WorkerUtil())
    }

    removeMessageListener = (eventType, handler) => {
        if (this._listeners[eventType]) {
            if (this._listeners[eventType].includes(handler))
                this._listeners[eventType].splice(
                    this._listeners[eventType].indexOf(handler),
                    1
                )
            else if (!handler) this._listeners[eventType] = []
        }
    }

    addMessageListener = (eventType, handler) => {
        const handlerList = this._listeners[eventType]
        if (!handlerList) this._listeners[eventType] = [handler]
        else handlerList.push(handler)
    }

    onmessage = e => {
        const { data, eventType } = e.data
        const handlerList = this._listeners[eventType]
        for (let handler of handlerList) handler(data)
    }
}

export default WorkerUtil
