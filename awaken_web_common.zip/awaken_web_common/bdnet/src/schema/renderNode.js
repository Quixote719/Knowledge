/**
 * 渲染节点
 * 
 *
 */
class RenderNode{
    constructor(main){
        this.main = main
        this.param = this.main.param
        this.cy = this.main.cy
        
        //提前加载必要的渲染图谱的图片
        this.loadImg()
    }
    /**
     * 加载工具图片，加载完毕后再启用渲染监听
     */
    loadImg = ()=>{
        this.IMGS = []
        this.IMGTOOL = {
            ready : new Image(),
            noready : new Image(),
            addLink : new Image(),
            error : new Image()
        }
        this.IMGTOOL.ready.src = `${window.basename}/img/nettool/ready.svg`
        this.IMGTOOL.noready.src = `${window.basename}/img/nettool/noready.svg`
        this.IMGTOOL.addLink.src = `${window.basename}/img/nettool/add_link.svg`
        this.IMGTOOL.error.src = `${window.basename}/img/nettool/error.svg`
        this.IMGTOOL.error.onload = ()=>{
            this.addRenderEvent()
        }
    }
    /**
     * 添加渲染事件
     */
    addRenderEvent = ()=>{
        //渲染扩展
        let cy = this.cy
        const bottomLayer = cy.cyCanvas({
            zIndex: 3,
        })
        const canvas = bottomLayer.getCanvas()
        const ctx = canvas.getContext("2d")
        /*
        //移动元素
        var eless = document.getElementById('networkBody').childNodes
        var eles = null
        for(var i=0;i<eless.length;i++){
          var oneEle = eless[i]
          if(oneEle.nodeName == 'DIV'){
            oneEle.appendChild(canvas)
            break;
          }
        }*/
        cy.on("render cyCanvas.resize", (evt) => {
             
            bottomLayer.resetTransform(ctx)
            bottomLayer.clear(ctx)
                        bottomLayer.setTransform(ctx)
            let nodes = cy.nodes()
            for(let i=0;i<nodes.length;i++){
                let node = nodes[i]
                if(node.data('class') === 'ATTR'){
                    continue
                }
                const pos = node.position()
                /* 有图片解决了渲染
                ctx.beginPath()
                ctx.save()
                //ctx.shadowColor = "black"
                //ctx.shadowBlur = 25 * cy.zoom()
                //外蓝环
                if(node.data('selected')){
                    
                    ctx.arc(pos.x, pos.y, 30, 0, 2 * Math.PI, false)
                    //ctx.strokeStyle = "rgba(31,128,247,1)"//"white";
                    //默认
                    if(node.data('class') === 'ENTITY'){
                        ctx.strokeStyle = "rgba(91,68,255,1)"//"white";
                    }else{
                        //EVENT
                        ctx.strokeStyle = "rgba(31,128,247,1)"//"white";
                    }
                    ctx.lineWidth = 2
                    ctx.stroke()
                }
                ctx.restore()
                
                //内白环
                ctx.beginPath()
                ctx.save()
                ctx.arc(pos.x, pos.y, 26, 0, 2 * Math.PI, false)
                ctx.strokeStyle = "rgba(255,255,255,1)"//"white";
                ctx.lineWidth = 6
                ctx.stroke()
                ctx.restore()

                //内背景
                ctx.beginPath()
                ctx.save()
                ctx.arc(pos.x, pos.y, 24, 0, 2 * Math.PI, false)
                
                //渐变
                if(node.data('selected')){
                    //选中 实体
                    
                    let radialGradient = ctx.createRadialGradient(pos.x-24,pos.y-24,24,pos.x+24,pos.y+24,24)
                    if(node.data('class') === 'ENTITY'){
                        radialGradient.addColorStop(0, 'rgba(138,121,255,1)')
                        radialGradient.addColorStop(1, 'rgba(91,68,255,1)')
                    }else{
                        //EVENT
                        radialGradient.addColorStop(0, 'rgba(79,166,249,1)')
                        radialGradient.addColorStop(1, 'rgba(72,104,229,1)')
                    }
                    ctx.fillStyle = radialGradient
                    
                }else if(node.data('selected')){
                    //移上
                    let radialGradient = ctx.createRadialGradient(pos.x-24,pos.y-24,24,pos.x+24,pos.y+24,24)
                    radialGradient.addColorStop(0, 'rgba(212,226,255,1)')
                    radialGradient.addColorStop(1, 'rgba(168,183,255,1)')
                    ctx.fillStyle = radialGradient
                }
                
                //else if(node.data('selected')){
                    //未选
                //} 
                else{//背景色
                    //默认
                    if(node.data('class') === 'ENTITY'){
                        ctx.fillStyle = 'rgba(218,223,247,1)'
                    }else{
                        //EVENT
                        ctx.fillStyle = 'rgba(200,220,252,1)'
                    }
                    
                }
                */
                //ctx.lineWidth = 0
                //ctx.stroke()
                ctx.fill()
                ctx.restore()
                //渲染类型图
                let imageR = 64
                let url = node.data('url')
                if(!url && node.data('iconName')){
                    url = node.data('iconName')
                    let urlPrefix = `${window.basename}/img/netImage/`
                    let urlSuffix = '.svg'
                    let selected = node.data('selected')?'_selected':''
                    url = urlPrefix + url + selected + urlSuffix
                }
                if(!url){
                    url = ''
                    ctx.beginPath()
                    ctx.arc(pos.x, pos.y, imageR/2, 0, 2 * Math.PI, false)
                    ctx.strokeStyle = "rgba(0,0,0,0.5)"//"white";
                    ctx.lineWidth = 1
                    ctx.stroke()
                    this.addStatusImg(ctx,node,pos)
                }else{
                    let IMGS = this.IMGS
                    if(typeof(IMGS[url])=='undefined'){
                        let img = new Image()
                        //使用图片的前缀后缀
                        img.src = url
                        img.onload = (e)=>{
                            ctx.drawImage(img,pos.x-imageR/2,pos.y-imageR/2,imageR,imageR)
                            IMGS[url] = img
                            this.addStatusImg(ctx,node,pos)
                        }
                        img.onerror = (e)=>{
                            img.src = ''
                            IMGS[url] = img
                            this.addStatusImg(ctx,node,pos)
                        }
                    }else{
                        ctx.drawImage(IMGS[url],pos.x-imageR/2,pos.y-imageR/2,imageR,imageR)
                        this.addStatusImg(ctx,node,pos)
                    }
                }
            }
            // Draw text that is fixed in the canvas
            bottomLayer.resetTransform(ctx)
        })
    }
    /**
     * 添加状态图片
     */
    addStatusImg = (ctx,node,pos)=>{
        //右下角的图标 ok属性
        if(typeof(node.data('ok'))!='undefined'){
            if(node.data('ok')){
                ctx.drawImage(this.IMGTOOL.ready,pos.x+12,pos.y+13,12,12)
            }else{
                ctx.drawImage(this.IMGTOOL.noready,pos.x+12,pos.y+13,12,12)
            }
        }
        //可连接状态 link
        if(typeof(node.data('link'))!='undefined'){
            if(node.data('link')){
                ctx.drawImage(this.IMGTOOL.addLink,pos.x-20,pos.y-8,12,12)
            }
        }
        //错误状态
        if(typeof(node.data('error'))!='undefined' && node.data('error')){
            ctx.drawImage(this.IMGTOOL.error,pos.x+13,pos.y-22,12,12)
        }
    }
}
export default RenderNode
