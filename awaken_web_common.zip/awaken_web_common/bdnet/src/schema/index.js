import EventEmitter from 'eventemitter3'
import Util from '../util'
import cytoscape from 'cytoscape'
import cyCanvas from 'cytoscape-canvas'
import navigator from 'cytoscape-navigator'
import { addClass, delClass } from 'parthenon-lib'
import paramMode from '../config/schemaConfig'
import layout from './Layout'
import { extent, createLabel, initLabel, removeLabels, destroyPopper } from './Labels'
import mockData from './mock/data'
import RenderNode from './renderNode'
import Interact from './interact'
import './index.less'
import('../../lib/cytoscape-navigator/cytoscape.js-navigator.css')
//require('../../lib/cytoscape-navigator/cytoscape.js-navigator.css')
//import navigator from '../../lib/cytoscape-navigator/cytoscape-navigator'
extent(cytoscape)

const calcPolygonShape = (number = 36) =>{
    const points = []
    for(let i = 0; i < number; ++i){
        const deg = 2 * Math.PI / 36 * i
        const cos = Math.cos(deg)
        const sin = Math.sin(deg)
        if(Math.abs(cos) > 0.2) {
            if (cos > 0)
                points.push((cos + 1) / 2, sin)
            else
                points.push((cos - 1) / 2, sin)
        }
    }
    return points
}
export default class {
    /**
     * 初始化
     * @param {*} param 画布状态、事件、菜单的定义
     * @param {*} canvas 实例画布信息，包含 画布id 画布名称 画布当前状态 画布当前的数据
     */
    constructor(param, canvas) {
        this.param = Util.deepCover(paramMode, param)
        this.canvas = canvas
        this.emitter = new EventEmitter()
        this.IMGS = []
        this.cy = null
        this.status = 'edit'
        this.initGraph()
    }

    destroy() {
        destroyPopper()
        if(this.cy && this.cy.destroyed){
            this.cy.destroyed()
        }
    }

    /**
     * 初始化画布渲染相关
     */
    initInteract = () => {}
    initGraphModule = () => {
        //注册扩展
        if (typeof this.cy.cyCanvas == 'undefined') {
            cyCanvas(cytoscape)
            navigator(cytoscape)
            
            
        }
        this.initNav()
        this.renderNode = new RenderNode(this)
        this.interact = new Interact(this)
    }
    /**
     * 事件绑定，用于监听关系网络内容
     * @param {*} eventName
     * @param {*} fun
     */
    bind = (eventName, fun, context) => {
        this.emitter.on(eventName, fun, context)
    }
    /**
     * 事件触发
     */
    trigger() {
        this.emitter.emit(...arguments)
    }
    /**
     * 初始化画布渲染
     */
    initGraph = () => {
        const el = this.param.dom

        //使用配置的颜色或者背景图，背景图todo
        el.style.background = '#363740'
        const ready = new Image()
        const noready = new Image()
        const entityImg = new Image()
        const addLinkImg = new Image()
        ready.src = `${window.basename}/img/nettool/ready.svg`
        noready.src = `${window.basename}/img/nettool/noready.svg`
        entityImg.src = `${window.basename}/img/nettype/entity_default.svg`
        addLinkImg.src = `${window.basename}/img/nettool/add_link.svg`
        entityImg.onload = () => {
            //渲染扩展
            this.cy = cytoscape({
                container: el,
                style: [
                    {
                        selector: 'node',
                        style: {
                            width: 55,
                            height: 55,
                            color: '#eee',
                            'text-valign': 'center',
                            'background-opacity':1,
                            'z-index':8
                        }
                    },
                    {
                        selector: 'node:selected',
                        style: {
                            'background-color': '#222',
                            'background-opacity':1
                        }
                    },
                    {
                        selector: '.ENTITY',
                        style: {
                            // label: 'data(label)',
                            color: '#333',
                            'background-opacity':1,
                            'font-size': 14,
                            'text-valign': 'bottom',
                            'text-wrap': 'ellipsis',
                            'text-max-width': 50,
                            'line-height': 25,
                            'background-color': '#0079AD',//'#DADFF7',
                            'z-index':8
                        }
                    },
                    {
                        selector: '.ENTITY:selected',
                        style: {
                            color: '#333',
                            'background-opacity':1,
                            'background-color': '#0079AD',
                            'z-index':25
                        }
                    },
                    {
                        selector: '.EVENT',
                        style: {
                            // label: 'data(label)',
                            color: '#333',
                            'background-opacity':1,
                            'font-size': 14,
                            'text-valign': 'bottom',
                            'text-wrap': 'ellipsis',
                            'text-max-width': 50,
                            'line-height': 25,
                            'background-color': '#006F3D',
                            'z-index':8
                        }
                    },
                    {
                        selector: '.EVENT:selected',
                        style: {
                            color: '#333',
                            'background-opacity':1,
                            'background-color': '#006F3D',
                            'z-index':25
                        }
                    },
                    {
                        selector: '.ATTR',
                        style: {
                            label: 'data(label)',
                            width: 80,
                            height: 36,
                            // opacity: 0,
                            shape: 'polygon',
                            'shape-polygon-points': calcPolygonShape(),
                            'background-color': '#f4f4f4',
                            color: '#696969',
                            'font-size': 12,
                            'font-family': 'MicrosoftYaHei',
                            'text-wrap': 'ellipsis',
                            'text-max-width': 60,
                            'text-justification': 'center',
                            'line-height': 16,
                            
                            'border-width': 1,
                            'border-color': ele => {
                                const label = ele.data('label')
                                if(!label || !label.trim())
                                    return '#ff5722'
                                return '#cfcfcf'
                            },
                            'background-opacity':0,
                            'z-index':5,
                        }
                    },
                    {
                        selector: '.ATTR:selected',
                        style: {
                            color: '#5b44ff',
                            'border-color':'#5b44ff',
                            'background-opacity':1,
                            'z-index':20
                        }
                    },
                    {
                        selector: '.ATTR[dbLabelElement="EVENT"]:selected',
                        style: {
                            color: '#1f80f7',
                            'border-color':'#1f80f7',
                            'z-index':20
                        }
                    },
                    {
                        selector: 'edge',
                        style: {
                            'curve-style': 'bezier',
                            'line-color': '#1F80F7',
                            width: 1,
                            'target-arrow-color': '#1F80F7',
                            'target-arrow-shape': 'triangle',
                            'z-index':7
                        }
                    },
                    {
                        selector: 'edge:selected',
                        style: {
                            'line-color': '#1F80F7',
                            width: 2,
                            'target-arrow-color': '#1F80F7',
                            'z-index':21
                        }
                    },
                    {
                        selector: '.RELATION[dbType="v2v"]',
                        style: {
                            'line-color': '#00EBFF',
                            width: 1,
                            'target-arrow-color': '#00EBFF',
                            'z-index':7
                        }
                    },
                    {
                        selector: '.RELATION:selected[dbType="v2v"]',
                        style: {
                            'line-color': '#00EBFF',
                            width: 2,
                            'target-arrow-color': '#00EBFF',
                            'z-index':21
                        }
                    },
                    {
                        selector: '.RELATION[dbType="v2e"]',
                        style: {
                            'line-color': '#0FED89',
                            width: 1,
                            'target-arrow-color': '#0FED89',
                            'z-index':7
                        }
                    },
                    {
                        selector: '.RELATION:selected[dbType="v2e"]',
                        style: {
                            'line-color': '#0FED89',
                            width: 2,
                            'target-arrow-color': '#0FED89',
                            'z-index':21
                        }
                    },
                    {
                        selector: '.EDGE[dbType="v2e"]',
                        style: {
                            'line-color': '#0FED89',
                            width: 1,
                            'target-arrow-color': '#0FED89',
                            'z-index':7
                        }
                    },
                    {
                        selector: '.EDGE:selected[dbType="v2e"]',
                        style: {
                            'line-color': '#0FED89',
                            width: 2,
                            'target-arrow-color': '#0FED89',
                            'z-index':21
                        }
                    },
                    
                    //属性样式 实体的
                    {
                        selector: '.EDGE[dbType="v2p"]',
                        style: {
                            'line-color': '#CFCFCF',
                            width: 1,
                            'target-arrow-color': '#1F80F7',
                            'z-index':7
                        }
                    },
                    {
                        selector: '.EDGE:selected[dbType="v2p"]',
                        style: {
                            'line-color': '#CFCFCF',
                            width: 2,
                            'target-arrow-color': '#CFCFCF',
                            'z-index':21
                        }
                    },
                    
                     //属性样式 事件的
                    {
                        selector: '.EDGE[dbType="e2p"]',
                        style: {
                            'line-color': '#CFCFCF',
                            width: 1,
                            'target-arrow-color': '#CFCFCF',
                            'z-index':7
                        }
                    },
                    {
                        selector: '.EDGE:selected[dbType="e2p"]',
                        style: {
                            'line-color': '#CFCFCF',
                            width: 2,
                            'target-arrow-color': '#CFCFCF',
                            'z-index':21
                        }
                    },
                     //属性样式自连接的
                     {
                        selector: 'edge[source=target]',
                        style: {
                            "curve-style":'loop',
                            color:'#FF0000',
                            "loop-direction":0,
                            "loop-sweep":90,
                            "control-point-step-size":function(ele){
                                if(!ele.data('stepSize')){
                                    return 60
                                }else{
                                    return ele.data('stepSize')
                                }
                            }
                        }
                    },
                    
                ],
                elements: {
                    nodes: [],
                    edges: []
                },
                //滚轮灵敏度1太快
                wheelSensitivity: 0.25,
                hideLabelsOnViewport: true,
                hideEdgesOnViewport: false
            })
            //加载完毕才能加载渲染相关的cy内容
            this.cy.ready(() => {
                this.initGraphModule()

                window.cy = this.cy
                initLabel(this.cy, (id, value) => {
                    //此处调用修改节点label的方法
                    this.interact.changeLabel(id, value)
                })

                if(this.renderParamCache){
                    const {rawData, isforce} = this.renderParamCache
                    this.render(rawData, isforce)
                    this.renderParamCache = null
                }
            })
        }
    }
    initNav = () => {
        const el = this.param.dom
        let pDom = el.parentNode.parentNode
        let dom = document.createElement('div')
        dom.style.width = '296px'
        dom.style.height = '192px'
        dom.style.backgroundColor = "#1A1D24"
        dom.style.position = 'absolute'
        dom.style.left = '2px'
        dom.style.bottom = '2px'
        dom.style.border = '0px solid #A8A9A9'
        dom.style.zIndex = 10
        dom.style.overflow = 'hidden'
        dom.id = 'cynavigator'
        dom.className = 'cytoscape-navigator'
        pDom.appendChild(dom)
        const conf = {
            container:'#cynavigator',
            
            viewLiveFramerate:0,
            thumbnailEventFramerate:30,
            thumbnailLiveFramerate:true,
            dblClickDelay:200,
            removeCustomContainer:true,
            rerenderDelay:100
            
        }
        this.cy.navigator(conf)
    }
    setLayout = (layoutName, params) => {
        layout(layoutName, this.cy, params, this.interact)
    }

    /**
     * 添加点[业务层直接调用]
     * @param id 当前节点的id
     * @param url 当前添加点的鼠标图片url
     */
    addPoint = (id, url) => {
        this.interact.addPoint(id, url)
    }
    /**
     * 添加边[业务层直接调用]
     * @param id 当前边的id
     * @param url 当前添加点的鼠标图片url
     */
    addLink = (id, url) => {
        this.interact.addLink(id,url)
    }
    /**
     * 添加状态移除
     */
    clearAddLink = () => {
        this.interact.clearAddLink()
    }
    /**
     * 删除元素
     */
    deleteElement = () => {
        this.interact.deleteElement()
    }

    renderParamCache = null
    /**
     * 渲染画布
     * @param data 数据结构
     * {
        "status":"edit",//"view"
        "data":
          {
          "edges":
            [
              {"id":"accompany:person:81924104:phone:81924200","label":"accompany","class":"RELATION","subClass":"accompany","source":"person:81924104","target":"phone:81924200","dbSourceId":"81924104","dbSourceLabel":"person","dbSourceElement":"ENTITY","dbTargetId":"81924200","dbTargetLabel":"phone","dbTargetElement":"ENTITY"}
            ],
          "nodes":
            [
              {"id":"car:40972488","label":"小型汽车","class":"ENTITY","subClass":"car","x":23.36133126007892,"y":-6.579799309449868,ok:false}
            ]
          }
        }
        注意：
        label 属性是标签名称 
        class 大类
        subClass：小类
        link 只有在连接过程中，才会显示其属性，link为false或 无此属性都不会显示link标签	
        selected 只有在画布渲染中才需要标识被选中
        error 只有在画布发布时，才会添加其属性
     * @param isforce 是否启用力导向
     */
    render = (rawData = { data: mockData }, isforce = true ,isAttrLayout = false,isLoopLinkLayout = true) => {
        const { cy, setLayout } = this
        const { data, status } = rawData

        if (cy) {
            this.status = status
            cy.status = status
            cy.elements().remove()
            cy.add(
                data.nodes.map(n => ({
                    data: n,
                    position: n.x && n.y ? { x: n.x, y: n.y } : null,
                    classes: n.class,
                    selected: n.selected || false
                }))
            )
            cy.add(
                data.edges.map(e => ({
                    data: e,
                    classes: e.class,
                    selected: e.selected || false
                }))
            )
            //触发单独属性的位置重构。但是不确定是否要重构后保存 ，不知道有没有触发 positionChangeEvent 方法 即cy的 position事件，调用试试看先 
            if(isAttrLayout){
                this.trigger('attrLayout')
            }
            //触发自连接线的位置重构
            if(isLoopLinkLayout){
                this.trigger('loopLinkLayout')
            }
            if(
                !isforce &&
                data.nodes.some(
                    n =>
                    n.x === null || n.x === undefined ||
                    n.y === null || n.y === undefined
                )
            )
                isforce = true

            setLayout(isforce ? 'force' : 'preset', {
                nodes: data.nodes.slice(),
                edges: data.edges.slice()
            })

            this.createLabels()
        } else {
            this.renderParamCache = {rawData, isforce}
        }

    }

    enableLabe = ele => ['ENTITY', 'EVENT', 'RELATION', 'ATTR'].includes(ele.data('class'))
    createLabels = () => {
        removeLabels()
        const popperList = Array.from(document.querySelectorAll('.pop-over'))
        for (let p of popperList) {
            delClass(p, 'popper-selected')
        }
        this.cy.elements().each(ele => {
            if (this.enableLabe(ele)) {
                const className = ['pop-over', `popper-${ele.data('class')}`]

                if (ele.selected() && ele.data('class') !== 'ATTR')
                    className.push('popper-selected')
                
                if (ele.data('class') === 'RELATION' && ele.data('dbType')==="v2v")
                    className.push('pop-over-v2v')

                if (ele.data('class') === 'RELATION' && ele.data('dbType')==="v2e")
                    className.push('pop-over-v2e')
                createLabel({
                    cy: this.cy,
                    ele,
                    text: ele.data('label'),
                    className,
                    onClick: this.handleLabelClick
                })
            }
        })
    }

    handleLabelClick = (ele) => {
        if(ele.data('class') === 'RELATION') {
            this.trigger('selectedElementReturn', {
                data: {node: [], edge: [ele.data()]}
            })
        }
    }
}
