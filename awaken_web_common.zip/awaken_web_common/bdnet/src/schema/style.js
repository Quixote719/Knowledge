export default
[
    {
        selector: 'node',
        style: {
            //width:10,
            //height:10,
            //'text-margin-y': 7,
            width:15,
            height:15,
            'text-margin-y': 10,
            'border-width':0,
            'label': 'data(name)',
            'background-color': 'rgba(255,255,255)',
            'background-opacity':'0',
            'background-image':`${window.basename}/img/node/label-0.svg`,
            'background-fit':'cover cover',
            "font-size":3,
            //文字横向和竖向居中
            "text-valign": "top",
            "text-halign": "center",
            
            //缩放到一定后才显示文字
            "min-zoomed-font-size": 15,

            'font-family': 'MicrosoftYaHei',
            'color': '#A2D4D4',
            'z-index':50
        }
    },
    {
        selector: 'node:selected',
        style: {
            'background-image':`${window.basename}/img/node/label-0_select.svg`,
            'color':'#FFFFFF',
            'z-index':50
        }
    }
]