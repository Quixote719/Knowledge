/**
 * Created by yaojia7 on 2020/2/24.
 */
// import popper from 'cytoscape-popper'
import moment from 'moment'
import popper from './../cytoscape-popper'
import {message} from 'antd'
import tippy, {sticky} from 'tippy.js'
import { throttle } from 'parthenon-lib'
import 'tippy.js/dist/tippy.css'

let cy = null
let visibleTip = null
let popperContainer = null
let containerTop = 0
let containerLeft = 0
let handleLabelSave = null
let input = null
let inputVisible = false
let attrInputWidth = 65
let attrInputHeight = 32
let entityInputWidth = 60
let entityInputHeight = 18
let inputFontSize = 12
let editEleId = null
const labels = []

//cytoscape 中各种元素对应的 tip 触发方式
const eleTipConfig = {
    ENTITY: {
        label: {
            tipTarget: 'dom', //鼠标移动到该元素标签的dom节点上时触发
            placement: 'bottom'
        },
        error: {
            tipTarget: 'element', //鼠标移动到该元素上时触发
            placement: 'top'
        }
    },
    EVENT:{
        label: {
            tipTarget: 'dom', //鼠标移动到该元素标签的dom节点上时触发
            placement: 'bottom'
        },
        error: {
            tipTarget: 'element', //鼠标移动到该元素上时触发
            placement: 'top'
        }
    },
    RELATION: {
        label: {
            tipTarget: 'dom',
            placement: 'top'
        },
        error: {
            tipTarget: 'dom',
            placement: 'top'
        },
    },
    ATTR: {
        label: {
            tipTarget: 'element',
            placement: 'top'
        },
        error: {
            tipTarget: 'element',
            placement: 'top'
        },
    }
}

export const extent = cytoscape => {
    try {
        cytoscape.use(popper)
    } catch (e) {
        console.log(e)
    }
}

export const initLabel = (_cy, handleSave) => {
    cy = _cy
    initPopper(_cy)
    createInput(_cy)
    handleLabelSave = handleSave

    bindCyEvents(_cy)
}

const initPopper = cy => {
    popperContainer = document.createElement('div')
    const cyContainer = cy.container()
    if(!cyContainer || !cyContainer.parentElement) return


    let {left, top, width, height} = cyContainer.parentElement.getBoundingClientRect()
    top = 89
    left = 80
    popperContainer.classList.add('popper-container')
    popperContainer.style.top = top + 'px'
    popperContainer.style.left = left + 'px'
    containerTop = top
    containerLeft = left
    popperContainer.style.width = width + 'px'
    popperContainer.style.height = (height + 200) + 'px'

    document.body.appendChild(popperContainer)

}

const renderDiv = (text, id, className, error) => {
    const div = document.createElement('div')
    if(text && text.trim()){
        div.innerText = text
        div.style.border = 'none'
    } else {
        div.style.border = '1px solid #ff5722'
    }
    if(error){
        const image = document.createElement('img')
        image.setAttribute('src', `${window.basename}/img/nettool/error.svg`)
        image.style.width = '15px'
        image.style.height = '15px'
        image.style.position = 'absolute'
        image.style.top = '-5px'
        image.style.right = '0px'
        div.appendChild(image)
    }

    div.style.overflow = 'initial'
    div.setAttribute('id', `popper-${id}`)

    if (className) {
        if (Array.isArray(className)) {
            for (let c of className) div.classList.add(c)
        } else {
            div.classList.add(className)
        }
    }

    popperContainer.appendChild(div)

    return div
}

const dblDelay = 400
const bindCyEvents = cy => {
    //模拟双击事件
    cy.on('mouseup', evt => {
        const start = moment().valueOf()
        if (evt.target && evt.target.data('class') === 'ATTR') {
            cy.one('mouseup', e => {
                const {target} = e
                if(moment().valueOf() - start > dblDelay) return
                const isAttrNode = target && target.id && target.data('class') === 'ATTR'
                if (isAttrNode) {
                    handleDoubleClick(target)
                }
            })
        }
    })
    cy.on('mouseover', e => {
        const {target} = e
        if(target && target.id && !visibleTip){
            const isAttrNode = target.data('class') === 'ATTR'
            if(isAttrNode){
                //如果是属性节点，则鼠标悬浮时提示属性label或者error
                if(target.data('error')) showTip(target.id(), 'error')
                else showTip(target.id(), 'label')
            }
            if(isEntity(target)){
                //如果是实体或者事件，则鼠标悬浮时提示 error
                showTip(target.id(), 'error')
            }
        }
    })
    cy.on('mouseout', e => {
        const {target} = e
        if(target && target.id) hideTip()
    })
}

const bindMouseEvents = (ele, label, onClick) => {
    const dom = label.popper
    const notAttrElement = dom && ele.id && ele.data('class') !== 'ATTR'
    if(notAttrElement){
        //double click
        const doubleClickHandler = (evt) => {
            handleDoubleClick(ele, evt)
        }
        dom.addEventListener('dblclick', doubleClickHandler)

        //mouseenter
        const mouseenterHandler = () => {
            const isRelation = ele.data('class') === 'RELATION'
            if(isRelation) {
                if (ele.data('error')) showTip(ele.id(), 'error')
                else showTip(ele.id(), 'label')
            }
            if(isEntity(ele)){
                showTip(ele.id(), 'label')
            }
        }
        dom.addEventListener('mouseenter', mouseenterHandler)

        //mousewheel
        const mousewheelHandler = (e) => {
            const container = cy.container().parentElement.parentElement
            cy.zoom({
                level: cy.zoom() * (e.deltaY < 0 ? 1.3 : 0.77),
                renderedPosition: {
                    x: e.clientX - container.offsetLeft,
                    y: e.clientY - container.offsetTop
                }
            })
        }
        dom.addEventListener('mousewheel', mousewheelHandler)

        //mouseleave
        const mouseleaveHandler = () => {
            hideTip()
        }
        dom.addEventListener('mouseleave', mouseleaveHandler)

        //click
        onClick && dom.addEventListener('click', () => onClick(ele))
    }
}

const createInput = () => {
    const inputDom = document.createElement('input')
    inputDom.classList.add('popper-input')
    inputDom.setAttribute('maxlength', '25')
    popperContainer.appendChild(inputDom)

    input = inputDom
}

const displayInput = (type, transform, top, left) => {
    input.style.display = 'block'
    input.style.transform = transform
    input.style.top = top + 'px'
    input.style.left = left + 'px'
    inputVisible = true
    if(cy){
        const zoom = cy.zoom()
        if(type === 'ATTR') {
            input.style.width = attrInputWidth * zoom + 'px'
            input.style.height = attrInputHeight * zoom + 'px'
            input.style['line-height'] = attrInputHeight * zoom + 'px'
        } else if(type === 'ENTITY' || type === 'EVENT'){
            input.style.width = entityInputWidth * zoom + 'px'
            input.style.height = entityInputHeight * zoom + 'px'
            input.style['line-height'] = entityInputHeight * zoom + 'px'
        } else if(type === 'RELATION'){
            input.style.width = entityInputWidth * zoom + 'px'
            input.style.height = entityInputHeight * zoom + 'px'
            input.style['line-height'] = entityInputHeight * zoom + 'px'
        }
        input.style['font-size'] = inputFontSize * zoom + 'px'
    }
    input.focus()
    document.addEventListener('keydown', handleEnter)
}

const hideInput = () => {
    input.style.display = 'none'
    input.style.transform = ''
    input.value = ''
    inputVisible = false
    document.removeEventListener('keydown', handleEnter)
}

const handleDoubleClick = (target, evt) => {
    const targetId = evt ? evt.target.getAttribute('id').split('popper-')[1] : target.id()
    editEleId = targetId
    const popperDom = document.querySelector(`#popper-${targetId}`)
    let transform = ''
    let top = 0
    let left = 0
    if(popperDom) {
        transform = popperDom.style.transform.split('scale(')[0] //删除scale部分的变换
        let scale = cy.zoom()
        left = -containerLeft + 8 - (scale - 1) * 26
        if(target.data('class') === 'RELATION'){
            top  = -containerTop - 12
        } else {
            top  = -containerTop + 3
        }
    }
    else {
        const {x1, y1} = target.renderedBoundingBox()
        transform = `translate3d(${x1}px, ${y1}px, 0px)`
    }

    displayInput(target.data('class'), transform, top, left)

    input.addEventListener('blur', hideInput)

}

const handleEnter = e => {
    if (e.keyCode === 13 && inputVisible && handleLabelSave) {
        handleLabelSave(editEleId, input.value)
        hideInput()
        document.removeEventListener('keydown', handleEnter)
    }
}

const tipCache = {
    /**
     * eleId: tip
     */
}

const isEntity = ele => ['ENTITY', 'EVENT'].includes(ele.data('class'))

export const showTip = (id, type) => {
    hideTip()
    if(tipCache[id] && tipCache[id][type]) {
        visibleTip = tipCache[id][type]
        visibleTip.show()
    }
}

export const hideTip = () => {
    visibleTip = null
    for(let ele of Object.values(tipCache)){
        for(let tip of Object.values(ele)){
            tip && tip.hide()
        }
    }
}

let popoverVisible = true
const setPopoverVisible = (cy) => {
    if(cy.zoom() < 0.6 && popoverVisible && popperContainer){
        popperContainer.style.display = 'none'
        popoverVisible = false
    } else if(cy.zoom() > 0.6 && !popoverVisible && popperContainer){
        popperContainer.style.display = 'block'
        popoverVisible = true
    }

}

export const createLabel = ({ cy, ele, text, className, onClick }) => {
    if(!popperContainer) return

    window.cy = cy
    const isAttr = ele.data('class') === 'ATTR'

    let label = {}
    if(!isAttr) {
        label = ele.popper({
            content: () => renderDiv(
                text,
                ele.id(),
                className,
                isEntity(ele) ? '' : ele.data('error')
            )
        })
        label.scheduleUpdate({
            zoom: cy.zoom(),
            top: containerTop,
            left: containerLeft,
            topOffsetType: ele.data('class')
        })
        labels.push(label)
        bindMouseEvents(ele, label, onClick)

        const update = throttle(() => {
            const params = {
                zoom: cy.zoom(),
                topOffsetType: ele.data('class'),
                top: containerTop,
                left: containerLeft
            }
            label.scheduleUpdate(params)
        }, 25)

        if (ele.isNode()) {
            ele.on('position', update)
        }
        if (ele.isEdge()) {
            ele.connectedNodes().on('position', update)
        }

        cy.on('pan resize zoom', update)

        cy.on('zoom', () => setPopoverVisible(cy))

    }

    // const tip = tipCache[ele.id()]
    // console.log(tip)
    // if(tip){
    //     if(tip.label)
    //         tip.label.setContent(ele.data('label'))
    //     if(tip.error)
    //         tip.error.setContent(ele.data('error'))
    //
    // } else {
    createTip(ele, label)
    // }

    return label
}

const createTip = (ele, label) => {
    const type = ele.data('class')
    const ref = ele.popperRef()
    const dom = label.popper
    const res = {}

    if(ele.data('label')) {
        const tipTargetIsDom = eleTipConfig[type].label.tipTarget === 'dom'
        const dummyDom = document.createElement('div')
        const labelTip = tippy(tipTargetIsDom ? dom : dummyDom, {
            onCreate: function (instance) {
                if (!tipTargetIsDom) instance.popperInstance.reference = ref
            },
            lazy: false,
            trigger: 'manual',
            content: function () {
                const div = document.createElement('div')
                div.innerHTML = ele.data('label')
                return div
            },

            arrow: true,
            placement: eleTipConfig[type].label.placement,
            animation: false,
            hideOnClick: false,
            multiple: true,
            sticky: true,
            plugins: [sticky]
        })
        res.label = labelTip
    }

    if(ele.data('error')) {
        const tipTargetIsDom = eleTipConfig[type].error.tipTarget === 'dom'
        const dummyDom = document.createElement('div')
        const errorTip = tippy(tipTargetIsDom ? dom : dummyDom, {
            onCreate: function (instance) {
                if(!tipTargetIsDom) instance.popperInstance.reference = ref
            },
            lazy: false,
            trigger: 'manual',
            content: function () {
                const div = document.createElement('div')
                div.innerHTML = ele.data('error')
                return div
            },

            arrow: true,
            placement: eleTipConfig[type].error.placement,
            animation: false,
            hideOnClick: false,
            multiple: true,
            sticky: true,
            plugins: [sticky]
        })

        res.error = errorTip
    }

    tipCache[ele.id()] = res
}

export const removeLabels = () => {
    for (let l of labels) {
        l.destroy()
    }

    const labelDomList = Array.from(document.querySelectorAll('.pop-over'))
    for(let dom of labelDomList){
        if(dom.parentElement === popperContainer) popperContainer.removeChild(dom)
    }

    visibleTip = null

    hideTip()
}

export const destroyPopper = () => {
    removeLabels()

    if(popperContainer.parentElement === document.body)
        document.body.removeChild(popperContainer)
}
