/**
 * Created by yaojia7 on 2019/10/16.
 */
import Worker from './forceLayout.worker'
import WorkerUtil from '../../utils/WorkerUtils'

const worker = new Worker()
WorkerUtil.extend(worker)

const forceLayout = {
    run: ({nodes, edges, cy, interact}) => {
        const { clientWidth, clientHeight } = cy.container()

        const handler = ({nodes, finished}) => {
            if(finished) interact.enable()

            for (let n of nodes) {
                cy.$(`node[id = "${n.id}"]`).position({
                    x: n.x,
                    y: n.y
                })
            }
        }

        worker.removeMessageListener('calc')

        worker.addMessageListener('calc', handler)

        interact.disable()
        worker.postMessage({
            eventType: 'calc',
            nodes,
            edges,
            width: clientWidth,
            height: clientHeight
        })
    }
}

export default forceLayout

