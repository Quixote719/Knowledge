/**
 * Created by yaojia7 on 2019/10/15.
 */
import * as d3 from 'd3'

const ALPHA_MIN = 0.05

const calcForceLayout = function({ nodes, edges, width, height }) {
    try {
        //非属性的节点
        let nodeUnAttr = []
        let nodeAttr = []
        for (let i = 0; i < nodes.length; i++) {
            let node = nodes[i]
            if (node.class && node.class !== 'ATTR') {
                nodeUnAttr.push(node)
            } else {
                nodeAttr.push(node)
            }
        }
        //非属性的边
        let edgeUnAttr = []
        for (let i = 0; i < edges.length; i++) {
            let edge = edges[i]
            if (edge.dbSourceElement && edge.dbTargetElement && edge.dbSourceElement !== 'ATTR' && edge.dbTargetElement !== 'ATTR') {
                edgeUnAttr.push(edge)
            }
        }
        const simulation = d3
            .forceSimulation(
                nodeUnAttr.map(n => ({
                    id: n.id,
                    x: n.x || 0,
                    y: n.y || 0
                }))
            )
            .force('center', d3.forceCenter(width / 2, height / 2))//整图中心定位
            .force('collision', d3.forceCollide(150))//点与点的排斥力
            .force('charge', d3.forceManyBody().strength(-18))
            .force(
                'link',
                d3
                    .forceLink(
                        edgeUnAttr.map(e => ({target: e.target, source: e.source, class: e.class}))
                    )
                    .iterations(4)
                    .id(n => n.id)
                    .distance(300)//设定线的长度
            )
            .force('x', d3.forceX())
            .force('y', d3.forceY())
            .alpha(0.2)
            .alphaMin(ALPHA_MIN)

        simulation.on('tick', () => {
            //根据属性，设置
            try {
                const alpha = simulation.alpha()
                let simnodes = simulation.nodes()
                let lengthConf = {
                    10: 100,
                    20: 400
                }
                let allNodes = []
                for (let i = 0; i < simnodes.length; i++) {
                    let node = simnodes[i]
                    let nodeId = node.id
                    let attrArray = []
                    for (let j = 0; j < nodeAttr.length; j++) {
                        let nodeA = nodeAttr[j]
                        if (nodeA.dbLabelId == nodeId) {
                            attrArray.push(nodeA)
                        }
                    }

                    let x = node.x
                    let y = node.y
                    let r = 100
                    let r2 = 160
                    let attrLength = attrArray.length
                    let firstLength = (attrLength>8)?8:attrLength
                    let secondLength = attrLength - firstLength
                    for(let m = 0;m<firstLength;m++){
                        let attrnode = attrArray[m]

                        attrnode.position({
                            x: x + r * Math.cos(m*(360/firstLength)*Math.PI/180),
                            y: y + r * Math.sin(m*(360/firstLength)*Math.PI/180)
                        })
                    }
                    if(secondLength>0){
                        for(let m = 0;m<secondLength;m++){
                            let attrnode = attrArray[8 + m]

                            attrnode.position({
                                x: x + r2 * Math.cos((22.5 + m*(360/firstLength))*Math.PI/180),
                                y: y + r2 * Math.sin((22.5 + m*(360/firstLength))*Math.PI/180)
                            })
                        }
                    }
                    //
                }
                allNodes = allNodes.concat(simnodes)
                //获得所有的相关属性
                self.postMessage({
                    eventType: 'calc',
                    data: {
                        nodes: allNodes,
                        finished: alpha <= ALPHA_MIN
                    }
                })
            } catch(e){
                self.postMessage({
                    eventType: 'calc',
                    data: {
                        nodes: [],
                        finished: true,
                        error: 'error' //e
                    }
                })
                simulation.stop()
            }
        })
    } catch(e){
        self.postMessage({
            eventType: 'calc',
            data: {
                nodes: [],
                finished: true,
                error: 'error'  //e
            }
        })
    }
    // for(let i = 0; i < Math.ceil(Math.log(simulation.alphaMin()) / Math.log(1 - simulation.alphaDecay())); i++){
    //     simulation.tick()
    // }
}

self.onmessage = e => {
    const { eventType } = e.data
    switch (eventType) {
        case 'calc': {
            const { nodes, edges, width, height } = e.data
            calcForceLayout({ nodes, edges, width, height })
            break
        }
        default:
            break
    }
}
