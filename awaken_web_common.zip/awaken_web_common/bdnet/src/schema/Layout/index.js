/**
 * Created by yaojia7 on 2020/2/23.
 */
import forceLayout from './force'

const defaultLayout = {
    run: () => {}
}

export const CYTO_LAYOUTS = [
    'null',
    'random',
    'preset',
    'grid',
    'circle',
    'concentric',
    'breadthfirst',
    'cose',
]

const customLayouts = {
    force: forceLayout
}

export default function(layoutName, cy, params, interact){
    let layout = defaultLayout

    if(CYTO_LAYOUTS.includes(layoutName)){
        layout = cy.elements().not(':invisible, :transparent').layout({
            name: layoutName,
            ...params
        })
    } else {
        layout = customLayouts[layoutName]
    }

    layout.run({...params, cy, interact})
}
