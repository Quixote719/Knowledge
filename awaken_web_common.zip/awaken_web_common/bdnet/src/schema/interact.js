import {debounce} from 'parthenon-lib'
/**
 * 交互动作
 * 有些动作在此做派发，给业务层
 * 包含动作：
 *  删除，之所以放这里，只是返回动作选中而已
 *  选中
 *  鼠标右键
 */
class Interact {
    constructor(main) {
        this.main = main
        this.param = this.main.param
        this.cy = this.main.cy
        this.addCanvasEvent()
        //画布添加点状态变量
        this.isAddPoint = false
        this.addPointId = null
        //画布添加线状态变量
        this.isAddLink = false
        this.isFirstPoint = false
        this.isLastPoint = false
        this.addLinkId = null
        this.disabled = false
        //注册事件属性发生改动
        this.main.bind('attrLayout',this.attrLayoutEvent)
        //注册自连接关系发生改动
        this.main.bind('loopLinkLayout',this.loopLinkLayoutEvent)
    }

    disable = () => {
        this.disabled = true
    }

    enable = () => {
        this.disabled = false
    }

    changeLabel = (id, label) => {
        if(this.disabled) return
        this.main.trigger('labelChangeEvent', {id, label})
    }

    /**
     * 添加点[业务层直接调用]
     * @param id 当前节点的id
     * @param url 当前添加点的鼠标图片url
     */
    addPoint = (id, url) => {
        this.param.dom.style.cursor = 'url("' + url + '"),auto'
        this.isAddLink = false
        this.isAddPoint = true
        this.addPointId = id
    }
    /**
     * 添加边[业务层直接调用]
     * @param id 当前边的id
     * @param url 当前添加点的鼠标图片url
     */
    addLink = (id, url) => {
        this.param.dom.style.cursor = 'url("' + url + '"),auto'
        this.isAddPoint = false
        this.isAddLink = true
        this.isFirstPoint = true
        this.isLastPoint = false
        this.addLinkId = id
    }
    /**
     * 添加状态移除
     */
    clearAddLink = () => {
        this.param.dom.style.cursor = 'auto'
        //添加线状态变量
        this.isAddLink = false
        this.isFirstPoint = false
        this.isLastPoint = false
        this.addLinkId = null
    }
    /**
     * 删除元素的操作，例如菜单点删除，或者删除按钮点击
     */
    deleteElement = () => {
        if(this.disabled) return

        let nodes = this.cy.nodes()
        let selectedNodes = []
        for(let i=0;i<nodes.length;i++){
            let node = nodes[i]
            if(node.data('selected')){
                selectedNodes.push(node.data())
            }
        }
        let edges = this.cy.edges()
        let selectedEdges = []
        for(let i=0;i<edges.length;i++){
            let edge = edges[i]
            if(edge.data('selected')){
                selectedEdges.push(edge.data())
            }
        }
        //获得当前selected的元素,并返还给业务端删除
        this.main.trigger('delectElementReturn', {
            data: {
                node: selectedNodes,
                edge: selectedEdges
            }
        })
    }
    /**
     * 添加画布的事件
     */
    addCanvasEvent = () => {
        let cy = this.cy
        //右键事件
        this.canvasContextEvent(cy)
        //添加节点或边的选中事件
        this.selectEvent(cy)
        //添加节点坐标变动
        this.positionChangeEvent(cy)
        //添加节点拖动事件
        this.dragEvent(cy)
    }
    /**
     * 节点或边的鼠标右键事件
     */
    canvasContextEvent = cy => {
        cy.on('cxttap', event => {
            if(this.disabled) return
            let ele = event.target

            if (ele.data()) {
                let data = {

                }
                if (typeof ele.isNode == 'undefined') {
                    data.node = []
                    data.edge = []
                }else{
                    if(ele.isNode()){
                        data.node = [ele.data()]
                        data.edge = []
                    }else{
                        data.node = []
                        data.edge = [ele.data()]
                    }
                }
                //获得当前selected的元素,返还给业务端右键菜单
                this.main.trigger('contextMenu', {
                    data,
                    x: event.renderedPosition.x,
                    y: event.renderedPosition.y
                })
            }
        })
    }

    /**
     * 添加节点或边的选中事件
     */
    selectEvent = cy => {
        //点击事件，选中高亮
        cy.on('tap', evt => {
            this.addClick(evt)
            this.tapHandler(evt)
        })
    }
    /**
     * 坐标改变事件
     */
    positionChangeEvent = (cy)=>{
        cy.on('position',
            debounce(e => {
                if(this.disabled) return
                this.main.trigger('positionChangeEvent',cy.$('node').jsons())
            }, 100)
        )
    }
    /**
     * 拖拽事件
     */
    dragEvent = (cy) => {
        cy.on('drag',debounce(evt => {
            this.attrLayout()
        }, 100))
    }
    /**
     * 绑定属性布局事件
     */
    attrLayoutEvent = debounce(() => {
        this.attrLayout()
    }, 100)
    /**
     * 属性重布局
     */
    attrLayout = () => {
        //let ele = evt.target
        //ele是个数组，做全盘的计算好了
        //非属性的节点
        let nodeUnAttr = []
        //属性的节点
        let nodeAttr = []
        let nodes = this.cy.nodes()
        for(let i=0;i<nodes.length;i++){
            let node = nodes[i]
            if(node.data('class') && node.data('class') !== 'ATTR'){
                nodeUnAttr.push(node)
            }else{
                nodeAttr.push(node)
            }
        }
        let lengthConf = {
            10:100,
            20:400
        }
        for(let i=0;i<nodeUnAttr.length;i++){
            let node = nodeUnAttr[i]
            let nodeId = node.data('id')
            let attrArray = []
            for(let j =0;j<nodeAttr.length;j++){
                let nodeA = nodeAttr[j]
                if(nodeA.data('dbLabelId') == nodeId){
                    attrArray.push(nodeA)
                }
            }
            let x = node.position('x')
            let y = node.position('y')
            let r = 100
            let r2 = 160
            let attrLength = attrArray.length
            let firstLength = (attrLength>8)?8:attrLength
            let secondLength = attrLength - firstLength
            for(let m = 0;m<firstLength;m++){
                let attrnode = attrArray[m]

                attrnode.position({
                    x: x + r * Math.cos(m*(360/firstLength)*Math.PI/180),
                    y: y + r * Math.sin(m*(360/firstLength)*Math.PI/180)
                })
            }
            if(secondLength>0){
                for(let m = 0;m<secondLength;m++){
                    let attrnode = attrArray[8 + m]

                    attrnode.position({
                        x: x + r2 * Math.cos((22.5 + m*(360/firstLength))*Math.PI/180),
                        y: y + r2 * Math.sin((22.5 + m*(360/firstLength))*Math.PI/180)
                    })
                }
            }
        }
    }
    /**
     * 自连接重设置属性事件
     */
    loopLinkLayoutEvent = () => {
        debounce(() => { 
            this.loopLinkLayout()
        }, 100)
    }
    /**
     * 自连接重设置属性
     */
    loopLinkLayout = () => {
        //过滤线，判断线的source和target是否一致
        let edges = this.cy.edges()
        //每次添加的stepSize数量为
        const stepCount = 11
        for (let i = 0; i < edges.length; i++) {
            let edge = edges[i]
            if (edge.data('source') && edge.data('target') && edge.data('source') == edge.data('target')) {
                let node = this.cy.$id(edge.data('source'))
                let stepNum = node.data('stepNum')?node.data('stepNum'):1
                if(!node.data('stepNum')){
                    node.data('stepNum',1)
                }else{
                    stepNum += 1
                    node.data('stepNum',stepNum)
                }
                edge.data('stepSize',60 + (stepNum-1) * stepCount)
            }
        }
    }
    /**
     * 添加点的操作
     */
    addClick = event => {
        //鼠标状态
        if(this.disabled) return
        if(this.isAddPoint) {
            this.param.dom.style.cursor = 'auto'
            //坐标
            let position = event.position
            //通知[业务层]添加点
            this.main.trigger('addPointXY', {
                id: this.addPointId,
                x: position.x,
                y: position.y
            })
            //还原添加状态
            this.isAddPoint = false
            this.addPointId = null
        }
    }
    /**
     * 元素点击事件 包含添加线的逻辑，以及点击的逻辑过滤
     *
     */
    tapHandler = event => {
        if(this.disabled) return
        //正在添加点，不执行tap过程
        if (!this.isAddPoint) {
            //区分点和边的点击操作
            let ele = event.target
            if (typeof ele.isNode == 'undefined') {
                this.clearAddLink()
                //获得当前selected的元素,返还给业务端右键菜单
                this.main.trigger('backgroundClick', {
                    x: event.renderedPosition.x,
                    y: event.renderedPosition.y
                })
                return
            }
            let isnode = ele.isNode()
            if (isnode) {
                this.tapNode(ele,event)
            } else {
                this.tapEdge(ele)
            }
        }
    }
    /**
     * 点击节点
     * node 被点击的节点
     */
    tapNode = (node,event) => {
        if(this.disabled) return
        let nodedata = {
            ...node.data(),
            ...node.position()
        }
        //正在添加边的话，两个阶段，选起点，选终点
        if (this.isAddLink) {
            if(!node.data('link')){
                return
            }
            if (this.isFirstPoint) {
                //传递给起点
                this.main.trigger('linkStarted' , this.addLinkId , nodedata)
                this.isFirstPoint = false
                this.isLastPoint = true
            } else if (this.isLastPoint) {
                //传递给终点
                this.main.trigger('linkEnd' , this.addLinkId , nodedata)
                this.isFirstPoint = false
                this.isLastPoint = false
                this.isAddLink = false
            }
        }
        //节点被选中
        this.main.trigger('selectedElementReturn', {
            data: { node: [nodedata], edge: [] },
            x: event.renderedPosition.x,
            y: event.renderedPosition.y
        })
    }
    /**
     * 点击边
     * edge 被点击的边
     */
    tapEdge = edge => {
        if(this.disabled) return
        this.main.trigger('selectedElementReturn', {
            data: { node: [], edge: [edge.data()] }
        })
    }
}
export default Interact
