import object from 'lodash/fp/object'
import _ from 'lodash'
import uuid from 'node-uuid'
class Util{
    constructor(){

    }
    /**
     * 深度克隆json数据
     */
    static deepClone =(obj)=>{
        let proto = Object.getPrototypeOf(obj)
        return Object.assign({},Object.create(proto),obj)
    }
    /**
     * 深度覆盖 
     * 获得替代对象没有的原始内容，并替换原始对象里面重复的属性
     */
    static deepCover = (original,substitute) => {
        return object.defaultsDeep(original,substitute)
    }
    /**
     * 深度拷贝
     */
    static cloneDeep = (data)=>{
        return _.cloneDeep(data)
    }
    /**
     * 画布坐标推算
     * @param {*} canvas 画布
     * @param {*} x 鼠标事件坐标
     * @param {*} y 
     */
    static windowToCanvasLeftRight(canvas,x,y){
        let bbox = canvas.getBoundingClientRect()
        return {
            x:x - bbox.left * (canvas.width / bbox.width),
            y:y - bbox.top * (canvas.height / bbox.height)
        }
    }
    /**
     * 
     */
    static clearCanvasAndDrawBack = (ctx,width,height,color)=>{
        ctx.save()
        ctx.setTransform(1,0,0,1,0,0)
        ctx.clearRect(0,0,width,height)
        if(color){
            ctx.fillStyle = color
        }else{
            ctx.fillStyle = '#FFFFFF'
        }
        ctx.fillRect(0,0,width,height)
        ctx.restore()
    }
    /**
     * 是否在画布范围内
     * left 相对于画布内的左上角距离
     * top 相对于画布内的左上角距离
     */
    static isInCanvas(canvas,left,top){
        let width = canvas.width
        let height = canvas.height
        if(left>=0 && left<=width && top>=0 && top<=height){
            return true
        }
        return false
    }
    /**
     * 根据左上角坐标 和节点的宽高，获得全部节点的坐标范围
     * data.position.x data.position.y
     */
    static getExtent = (nodes,eWidth,eHeight)=>{
        let minX,minY,maxX,maxY
        for(let i=0;i<nodes.length;i++){
            let node = nodes[i]
            //假定x y 都是存在的，数据需要处理掉，没有坐标则为null
            let x = node.x
            let y = node.y
            if(typeof(x) == 'undefined' || typeof(y) == 'undefined' || x==null || y==null){
                continue
            }
            if(i==0){
                minX = x
                maxX = x+eWidth
                minY = y
                maxY = y+eHeight
            }else{
                if(x<minX){
                    minX = x
                }
                if(x+eWidth>maxX){
                    maxX = x+eWidth
                }
                if(y<minY){
                    minY = y
                }
                if(y+eHeight>maxY){
                    maxY = y + eHeight
                }
            }
        }
        return {minX,minY,maxX,maxY}
    }
    /**
     * 清空画布然后绘制背景色
     * @param {*} ctx 
     * @param {*} width 
     * @param {*} height 
     * @param {*} color 
     */
    static clearCanvasDrawBack = (ctx,width,height,color)=>{
        ctx.save()
        ctx.setTransform(1,0,0,1,0,0)
        ctx.clearRect(0,0,width,height)
        if(color){
            ctx.fillStyle = color
        }else{
            ctx.fillStyle = '#FFFFFF'
        }
        ctx.fillRect(0,0,width,height)
        ctx.restore()
    }
    /**
     * 设置样式，需要特殊处理一些样式设置
     * @param {*} ctx 
     * @param {*} style 
     */
    static setStyle = (ctx,style)=>{
        for(let name in style){
            if(name=='lineDash'){
                ctx.setLineDash(style['lineDash'])
            }else{
                ctx[name] = style[name]
            }
        }
    }
    /**
     * 是否包含属性
     * obj
     * {string} attrName
     */
    static isContain = (obj,attrName)=>{
        if(Array.isArray(obj)){
            if(obj.indexOf(attrName)>-1){
                return true
            }
            if(typeof attrName.length != 'undefined'){
                if(obj.indexOf(parseInt(attrName))>-1) {
                    return true
                }
            }
        }else if(obj && typeof(obj[attrName])!='undefined'){
            return true
        }else{
            return false
        }
    }
}

export default Util