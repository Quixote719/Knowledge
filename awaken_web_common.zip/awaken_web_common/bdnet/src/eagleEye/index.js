import Util from '../util'
import EVENTS from '../event/eventdeclara'
/**
 * 鹰眼
 * 
 * 
 */
class EagleEye{
    constructor(main){
        this.main = main
        this.param = this.main.param
        this.s = this.main.s
        this.camera = this.s.camera
        //画布的父dom
        this.canvasContent = main.param.dom
        this.initDom(this.canvasContent)
        //默认开启
        //this.hide()
        this.draw()
        
        //main.bind(EVENTS['eagleEyeShow'],this.show)
        main.bind(EVENTS['destroy'],this.destroy,this)
    }
    initDom = (dom) => {
        this.canvasEagleEye = document.createElement('div')
        this.canvasEagleEye.style.width = '210px'
        this.canvasEagleEye.style.height = '150px'
        this.canvasEagleEye.style.position = 'absolute'
        this.canvasEagleEye.style.right = '2px'
        this.canvasEagleEye.style.bottom = '2px'
        this.canvasEagleEye.style.border = '2px solid #A8A9A9'
        dom.appendChild(this.canvasEagleEye)
        this.canvasEagleEyeCover = document.createElement('canvas')
        this.canvasEagleEyeCover.width = '210px'
        this.canvasEagleEyeCover.height = '150px'
        this.canvasEagleEyeCover.style.position = 'absolute'
        this.canvasEagleEyeCover.style.right = '5px'
        this.canvasEagleEyeCover.style.bottom = '5px'
        this.canvasEagleEyeCover.style.border = '2px solid #A8A9A9'
        dom.appendChild(this.canvasEagleEyeCover)
        this.overcontract = document.createElement('div')
        this.overcontract.style.width = '16px'
        this.overcontract.style.height = '16px'
        this.overcontract.style.position = 'absolute'
        this.overcontract.style.right = '195px'
        this.overcontract.style.bottom = '135px'
        this.overcontract.style.border = '0px solid #A8A9A9'
        this.overcontract.style.display = 'block'
        this.overcontract.style.cursor = 'pointer'
        this.overcontract.style.background = `url(${window.basename}/img/over/overcontract_rb.gif)`
        dom.appendChild(this.overcontract)
        this.overcontract.addEventListener('mousedown',this.hide)
        this.overexpand = document.createElement('div')
        this.overexpand.style.width = '16px'
        this.overexpand.style.height = '16px'
        this.overexpand.style.position = 'absolute'
        this.overexpand.style.right = '2px'
        this.overexpand.style.bottom = '2px'
        this.overexpand.style.border = '0px solid #A8A9A9'
        this.overexpand.style.display = 'none'
        this.overexpand.style.cursor = 'pointer'
        this.overexpand.style.background = `url(${window.basename}/img/over/overexpand_rb.gif)`
        dom.appendChild(this.overexpand)
        this.overexpand.addEventListener('mousedown',this.show)
    }
    /**
     * 
     */
    draw = () => {

        this.render = this.s.addRenderer({
            container:this.canvasEagleEye,
            type:'canvas',
            //camera:this.s.camera,
            settings:{
                
                
                autoResize:true,
                autoRescale: true,
                
                //停止hover
                enableHover:false,
                //不画文字
                drawLabels:false,
                drawEdgeLabels:false,
                defaultLabelColor:'#fff',
                //不画线
                drawEdges:true,
                //事件响应
                touchEnabled: false,
                mouseEnabled: false,
                mouseWheelEnabled: false,
                doubleClickEnabled: false,
                eventsEnabled: false,


                /*
                minNodeSize: this.param.node.style.minNodeSize,
                maxNodeSize: this.param.node.style.maxNodeSize,
                
                //缩放最小比例
                zoomMin: 0.0625,
                //缩放最大比例
                zoomMax: 12,
                //缩放大小默认1.7 太大不舒服 小于1是反向
                zoomingRatio: 1.1,
                //滚动渲染延迟
                mouseZoomDuration: 100,
                //双击不执行放大
                doubleClickEnabled:false,

                enableEdgeHovering: true,//webgl 下不支持
                edgeHoverColor: 'edge',
                defaultEdgeHoverColor: '#000', 
                edgeHoverSizeRatio: 1,
                edgeHoverExtremities: true,
                */
            }

        })
        this.curCamera = this.render.camera
        //定时蛮好，就是太耗费
        //setInterval(()=>{this.autoExtent()},1000)
        this.autoExtent()
        this.main.bind(EVENTS['updateCanvas'],this.autoExtent)
        this.main.bind(EVENTS['addNodesAndEdges'],this.autoExtent)
        
        //this.resizeEagle(this.canvasEagleEye,this.canvasEagleEyeCover)
    }
    /**
     * 
     */
    resizeEagle = (canvasEagleEye,canvasEagleEyeCover) => {
        //let ctx = canvasEagleEye.getContext('2d')
        let eWidth = this.main.param.dom.offsetWidth - 0
        let eHeight = this.main.param.dom.offsetHeight - 0
        let canvasWidth = parseInt(canvasEagleEye.style.width)
        let canvasHeight = parseInt(canvasEagleEye.style.height)
        //获得最小矩形
        let nodes = this.s.graph.nodes()
        let {minX,minY,maxX,maxY} = Util.getExtent(nodes,eWidth,eHeight)
        if(typeof(minX)=='undefined'||
            typeof(minY)=='undefined'||
            typeof(maxX)=='undefined'||
            typeof(maxY)=='undefined'
        ){
            return false
        }
        let centerX = minX +(maxX-minX)/2
        let centerY = minY +(maxY-minY)/2
        //判断长宽比
        let bl = canvasWidth/canvasHeight
        let dagBl = (maxX-minX)/(maxY-minY)
        let num = 1
        //宽为主
        if(dagBl>bl){
            num = (maxX-minX)/canvasWidth
        }else{
            //高为主
            num = (maxY-minY)/canvasHeight
        }
        //num值要进行翻转和大小缩放倍数
        num = (1 / num) * 0.8

        let panX = canvasWidth/2 - centerX * num
        let panY = canvasHeight/2 - centerY * num
        let scaleNum = num
        if(isNaN(scaleNum)){
            scaleNum = 1
            panX = 0
            panY = 0
        }
        this.scaleNum = scaleNum
        //ctx.setTransform(1,0,0,1,0,0)
        //ctx.scale(scaleNum,scaleNum)
        //ctx.translate(panX / scaleNum,panY / scaleNum)
        let tminX = (0 - panX) / scaleNum
        let tminY = (0 - panY) / scaleNum
        let tmaxX = (canvasWidth - panX) / scaleNum
        let tmaxY = (canvasHeight - panY) / scaleNum
        //获得大图的左上角 获得大图的右下角
        let ratio = sigma.utils.getPixelRatio()
        let center =  {
            x: this.main.param.dom.offsetWidth / (2 * ratio),
            y: this.main.param.dom.offsetHeight / (2 * ratio)
        }
        let start = this.main.s.camera.cameraPosition(
            this.main.param.dom.offsetLeft - center.x,
            this.main.param.dom.offsetTop - center.y,
        )
        let end = this.main.s.camera.cameraPosition(
            this.main.param.dom.offsetLeft + this.main.param.dom.offsetWidth  - center.x,
            this.main.param.dom.offsetTop + this.main.param.dom.offsetHeight - center.y,
        )

        let innerStart = {}
        let innerEnd = {}
        let isOnlyBlack = false
        //如果大图超出了范围，则不必绘制当前空白区域
        if(start.x > maxX || start.y > maxY || end.x < minX || end.y < minY){
            //只绘制未覆盖区域
            isOnlyBlack = true
        }
        if(start.x < minX){
            innerStart.x = tminX
        }else {
            innerStart.x = start.x
        }
        if(start.y < minY){
            innerStart.y = tminY
        }else {
            innerStart.y = start.y
        }
        if(end.x < maxX){
            innerEnd.x = end.x
        }else {
            innerEnd.x = tmaxX
        }
        if(end.y < maxY){
            innerEnd.y = end.y
        }else {
            innerEnd.y = tmaxY
        }
        let ctxc = canvasEagleEyeCover.getContext('2d')
        Util.clearCanvasDrawBack(ctxc,this.canvasEagleEyeCover.width,this.canvasEagleEyeCover.height,'rgba(255,255,255,0)')
        if(isOnlyBlack){
            //先绘制全部
            ctxc.fillStyle = 'rgba(155,155,155,0.3)'
            ctxc.fillRect(0, 0, canvasWidth, canvasHeight)
        }else {
            ctxc.save()
            ctxc.fillStyle = 'rgba(155,155,155,0.3)'
            ctxc.fillRect(0, 0, canvasWidth, canvasHeight)
            ctxc.globalCompositeOperation="destination-out"
            ctxc.fillStyle = 'yellow'
            ctxc.fillRect(
                innerStart.x,
                innerStart.y,
                innerEnd.x - innerStart.x,
                innerEnd.y - innerStart.y
            )
            ctxc.restore(); 
        }
    }
    show = () => {
        /*
        this.main.triggerEvent(EVENTS['saveCovers'],'eye',{
            left:5,
            bottom:5,
            width:210,
            height:150
        })
        */
        this.canvasEagleEye.style.display = 'block'
        this.overcontract.style.display = 'block'
        this.overexpand.style.display = 'none'
    }
    hide=()=> {
        //this.main.triggerEvent(EVENTS['deleteCovers'],'eye')
        this.canvasEagleEye.style.display = 'none'
        this.overcontract.style.display = 'none'
        this.overexpand.style.display = 'block'
        
    }
    /**
     * 自适应
     * todo his   添加条件，很多动画中的自适应不需要保存至历史 ，，，按钮的自适应需要保存历史
     */
    autoExtent = (isNotHis)=>{
        this.ISNOTHIS = isNotHis

        let s = this.s
        if (s.graph.nodes().length) {
            let w = this.render.width
            let h = this.render.height

            // The "rescale" middleware modifies the position of the nodes, but we
            // need here the camera to deal with this. Here is the code:
            let xMin = Infinity,
                xMax = -Infinity,
                yMin = Infinity,
                yMax = -Infinity,
                //定义的边距
                margin = 60,
                scale;

            s.graph.nodes().forEach(function(n) {
              xMin = Math.min(n.x, xMin);
              xMax = Math.max(n.x, xMax);
              yMin = Math.min(n.y, yMin);
              yMax = Math.max(n.y, yMax);
            });

            xMax += margin;
            xMin -= margin;
            yMax += margin;
            yMin -= margin;

            scale = Math.min(
              w / Math.max(xMax - xMin, 1),
              h / Math.max(yMax - yMin, 1)
            );
            let viewObj = {
                x: (xMin + xMax) / 2,
                y: (yMin + yMax) / 2,
                ratio: 1 / scale
            }
            this.curCamera.goTo(viewObj)
        }
        //this.resizeEagle(this.canvasEagleEye,this.canvasEagleEyeCover)
    }
    destroy = () => {
        this.overcontract.removeEventListener('mousedown',this.hide)
        this.overexpand.removeEventListener('mousedown',this.show)
        if(this.canvasContent && this.canvasEagleEye){
            this.canvasContent.removeChild(this.canvasEagleEye)
            this.canvasContent.removeChild(this.overcontract)
            this.canvasContent.removeChild(this.overexpand)
            
        }
        this.canvasEagleEye = null
        this.overcontract = null
        this.overexpand = null
    }
}
export default EagleEye