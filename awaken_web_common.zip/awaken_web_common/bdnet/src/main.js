//import ccNetViz from '../submodule/ccNetViz/src/ccNetVizMultiLevel'
import EventEmitter  from 'eventemitter3'
import EVENTS from './event/eventdeclara'
import Util from './util'
import paramMode from './config'
import BoxSelect from './interact/boxSelect'
import DragInteract from './interact/dragInteract'
import ClickSelect from './interact/clickSelect'
import EventManage from './event'
import View from './view'
import LayoutManager from './layout'
import Edit from './edit'
import History from './history'
import EagleEye from './eagleEye'


/*
require('./lib/sigma/src/conrad')
require('./lib/sigma/src/utils/sigma.utils')
require('./lib/sigma/src/utils/sigma.polyfills')
require('./lib/sigma/src/sigma.settings')
require('./lib/sigma/src/classes/sigma.classes.dispatcher')
require('./lib/sigma/src/classes/sigma.classes.configurable')
require('./lib/sigma/src/classes/sigma.classes.graph')
require('./lib/sigma/src/classes/sigma.classes.camera')
require('./lib/sigma/src/classes/sigma.classes.quad')
require('./lib/sigma/src/classes/sigma.classes.edgequad')
require('./lib/sigma/src/captors/sigma.captors.mouse')
require('./lib/sigma/src/captors/sigma.captors.touch')
require('./lib/sigma/src/renderers/sigma.renderers.webgl')
require('./lib/sigma/src/renderers/sigma.renderers.def')
require('./lib/sigma/src/renderers/webgl/sigma.webgl.nodes.def')
require('./lib/sigma/src/renderers/webgl/sigma.webgl.nodes.fast')
require('./lib/sigma/src/renderers/webgl/sigma.webgl.edges.def')
require('./lib/sigma/src/renderers/webgl/sigma.webgl.edges.fast')
require('./lib/sigma/src/renderers/webgl/sigma.webgl.edges.arrow')
require('./lib/sigma/src/renderers/webgl/sigma.webgl.edges.thickLine')
require('./lib/sigma/src/renderers/webgl/sigma.webgl.edges.thickLineCPU')
require('./lib/sigma/src/renderers/webgl/sigma.webgl.edges.thickLineGPU')
require('./lib/sigma/src/middlewares/sigma.middlewares.rescale')
require('./lib/sigma/src/middlewares/sigma.middlewares.copy')
require('./lib/sigma/src/misc/sigma.misc.animation')
require('./lib/sigma/src/misc/sigma.misc.bindDOMEvents')
require('./lib/sigma/src/misc/sigma.misc.bindEvents')
require('./lib/sigma/src/misc/sigma.misc.drawHovers')
require('./lib/sigma/build/plugins/sigma.layout.forceAtlas2.min')
require('./lib/sigma/build/plugins/sigma.plugins.dragNodes.min')
require('./lib/sigma/plugins/sigma.renderers.customShapes/shape-library')
require('./lib/sigma/plugins/sigma.renderers.customShapes/sigma.renderers.customShapes')
require('./lib/sigma/build/plugins/sigma.renderers.edgeLabels.min')
*/
/*
require('./sigma/build/sigma.require')*/
//import sigma from './lib/sigma/src/sigma.core'
window.sigma = null
window.ShapeLibrary = null
import sigma from '../lib/sigma'
window.sigma = window.sigma || sigma

require('../lib/sigma/plugins/sigma.plugins.dragNodes/sigma.plugins.dragNodes')
//需要取出ShapeLibrary ，且设置window环境变量才可使用
import {ShapeLibrary} from '../lib/sigma/plugins/sigma.renderers.customShapes/shape-library'
//require('./lib/sigma/plugins/sigma.renderers.customShapes/shape-library')
window.ShapeLibrary = window.ShapeLibrary || ShapeLibrary
//线的配置
require('../lib/sigma/plugins/sigma.renderers.customShapes/sigma.renderers.customShapes')
//线的配置
//require('../lib/sigma/sigmaBuild/plugins/sigma.renderers.edgeLabels.min')
require('../lib/sigma/src/renderers/canvas/sigma.canvas.edges.curve')
require('../lib/sigma/plugins/sigma.renderers.parallelEdges/utils.js')
require('../lib/sigma/plugins/sigma.renderers.parallelEdges/sigma.canvas.edges.curve')
require('../lib/sigma/plugins/sigma.renderers.parallelEdges/sigma.canvas.edges.curvedArrow')
require('../lib/sigma/plugins/sigma.renderers.parallelEdges/sigma.canvas.edgehovers.curve')
require('../lib/sigma/plugins/sigma.renderers.parallelEdges/sigma.canvas.edgehovers.curvedArrow')
require('../lib/sigma/plugins/sigma.renderers.edgeLabels/settings')
require('../lib/sigma/plugins/sigma.renderers.edgeLabels/sigma.canvas.edges.labels.curve')
require('../lib/sigma/plugins/sigma.renderers.edgeLabels/sigma.canvas.edges.labels.curvedArrow')
require('../lib/sigma/plugins/sigma.renderers.edgeLabels/sigma.canvas.edges.labels.def')

class Bdnet{
    /**
     * 初始化
     * @param {*} param 画布状态、事件、菜单的定义
     * @param {*} canvas 实例画布信息，包含 画布id 画布名称 画布当前状态 画布当前的数据
     */
    constructor(param,canvas){
      console.log('bdnet initparam')
      this.param = Util.deepCover(paramMode,param)
      this.canvas = canvas
      this.emitter = new EventEmitter()
      this.sigmaExtend()
      this.initGraph()
    }
    /**
     * 初始化事件
     */
    initInteract = () =>{
      this.eventManager = new EventManage(this)
      this.boxSelect = new BoxSelect(this)
      this.dragInteract = new DragInteract(this)
      this.clickSelect = new ClickSelect(this)
      this.view = new View(this)
      this.layoutManager = new LayoutManager(this)
      this.edit = new Edit(this)
      this.history = new History(this)
      this.eye = new EagleEye(this)
    }
    /**
     * 事件绑定，用于监听关系网络内容
     * @param {*} eventName
     * @param {*} fun
     */
    bind = (eventName,fun,context)=>{
      this.emitter.on(eventName,fun,context)
    }
    /**
     * 事件触发
     */
    trigger(){
      this.emitter.emit(...arguments)
    }
    /**
     * 清除画布但是会保留基础配置
     */
    clear(){
      if(typeof(this.eventManager)=='undefined'){
        return
      }
      this.eventManager.removeEvent()
      this.s.kill()
    }
    /**
     * 彻底删除关系网络
     */
    destroy(){
      this.clear()
    }
    sigmaExtend=()=>{
      //扩展
      if(typeof(window.sigmaIsExtend)!='undefined'){
        return
      }
      window.sigmaIsExtend = true
      sigma.classes.graph.addMethod('neighbors', function(nodeId) {
        var k,
            neighbors = {},
            index = this.allNeighborsIndex[nodeId] || {};

        for (k in index)
          neighbors[k] = this.nodesIndex[k];

        return neighbors;
      })
      //sigma canvas功能增强，webgl的图片的话需要自己扩展
      sigma.utils.pkg('sigma.canvas.nodes')
      sigma.canvas.nodes.image = (function() {
        var _cache = {},
            _loading = {},
            _callbacks = {}

        // Return the renderer itself:
        var renderer = function(node, context, settings) {
          var args = arguments,
              prefix = settings('prefix') || '',
              size = node[prefix + 'size'],
              color = node.color || settings('defaultNodeColor'),
              url = node.url
          if (_cache[url]) {

            context.save()

            // Draw the clipping disc:
            context.beginPath();
            context.arc(
              node[prefix + 'x'],
              node[prefix + 'y'],
              node[prefix + 'size'],
              0,
              Math.PI * 2,
              true
            )
            context.closePath()
            context.clip()

            // Draw the image
            context.drawImage(
              _cache[url],
              node[prefix + 'x'] - size,
              node[prefix + 'y'] - size,
              2 * size,
              2 * size
            )

            // Quit the "clipping mode":
            context.restore()

            // Draw the border:
            context.beginPath()
            context.arc(
              node[prefix + 'x'],
              node[prefix + 'y'],
              node[prefix + 'size'],
              0,
              Math.PI * 2,
              true
            )
            context.lineWidth = size / 5
            context.strokeStyle = node.color || settings('defaultNodeColor')
            context.stroke()
          } else {
            sigma.canvas.nodes.image.cache(url);
            sigma.canvas.nodes.def.apply(
              sigma.canvas.nodes,
              args
            )
          }
        }

        // Let's add a public method to cache images, to make it possible to
        // preload images before the initial rendering:
        renderer.cache = function(url, callback) {
          if (callback)
            _callbacks[url] = callback

          if (_loading[url])
            return

          var img = new Image()

          img.onload = function() {
            _loading[url] = false
            _cache[url] = img

            if (_callbacks[url]) {
              _callbacks[url].call(this, img)
              delete _callbacks[url]
            }
          }

          _loading[url] = true
          img.src = url
        };

        return renderer
      })()

    }
    /**
     * 初始化画布渲染
     */
    initGraph=()=>{
      const el = this.param.dom

      //使用配置的颜色或者背景图，背景图todo
      el.style.background = this.param.background//'#F0F0F0'
      //el.innerHTML = ''
      let g = {
        nodes: [],
        edges: []
      }
      let urls = [
          `${window.basename}/img/nettype/person_selected.png`,
          `${window.basename}/img/nettype/person_unSelected.png`,
          `${window.basename}/img/nettype/person_default.png`,
          `${window.basename}/img/nettype/person_relation.png`,

          `${window.basename}/img/nettype/anjian_selected.png`,
          `${window.basename}/img/nettype/anjian_unSelected.png`,
          `${window.basename}/img/nettype/anjian_default.png`,
          `${window.basename}/img/nettype/anjian_relation.png`,

          `${window.basename}/img/nettype/car_selected.png`,
          `${window.basename}/img/nettype/car_unSelected.png`,
          `${window.basename}/img/nettype/car_default.png`,
          `${window.basename}/img/nettype/car_relation.png`,

          `${window.basename}/img/nettype/phone_selected.png`,
          `${window.basename}/img/nettype/phone_unSelected.png`,
          `${window.basename}/img/nettype/phone_default.png`,
          `${window.basename}/img/nettype/phone_relation.png`,

          `${window.basename}/img/nettype/entity_selected.png`,
          `${window.basename}/img/nettype/entity_unSelected.png`,
          `${window.basename}/img/nettype/entity_default.png`,
          `${window.basename}/img/nettype/entity_relation.png`,


          `${window.basename}/img/nettype/place_selected.png`,
          `${window.basename}/img/nettype/place_unSelected.png`,
          `${window.basename}/img/nettype/place_default.png`,
          `${window.basename}/img/nettype/place_relation.png`,

          `${window.basename}/img/nettype/goods_selected.png`,
          `${window.basename}/img/nettype/goods_unSelected.png`,
          `${window.basename}/img/nettype/goods_default.png`,
          `${window.basename}/img/nettype/goods_relation.png`,

          `${window.basename}/img/nettype/rfid_selected.png`,
          `${window.basename}/img/nettype/rfid_unSelected.png`,
          `${window.basename}/img/nettype/rfid_default.png`,
          `${window.basename}/img/nettype/rfid_relation.png`,

          `${window.basename}/img/nettype/wifi_selected.png`,
          `${window.basename}/img/nettype/wifi_unSelected.png`,
          `${window.basename}/img/nettype/wifi_default.png`,
          `${window.basename}/img/nettype/wifi_relation.png`,

          `${window.basename}/img/nettype/camera_selected.png`,
          `${window.basename}/img/nettype/camera_unSelected.png`,
          `${window.basename}/img/nettype/camera_default.png`,
          `${window.basename}/img/nettype/camera_relation.png`,

          `${window.basename}/img/nettype/card_selected.png`,
          `${window.basename}/img/nettype/card_unSelected.png`,
          `${window.basename}/img/nettype/card_default.png`,
          `${window.basename}/img/nettype/card_relation.png`,

      ]
      let loaded=0

      urls.forEach((url)=> {
        sigma.canvas.nodes.image.cache(
          url,
          () => {
            if (++loaded === urls.length){
              console.log('loaded')
              // Instantiate sigma:
              if(this.s){
                this.s.kill()
              }

              this.s = new sigma({
                graph: g,
                renderer: {
                  // IMPORTANT:
                  // This works only with the canvas renderer, so the
                  // renderer type set as "canvas" is necessary here.
                  container: el,
                  type: 'canvas'
                  // 目前。图片不支持webgl、形状不支持webgl
                },
                settings: {
                  minNodeSize: this.param.node.style.minNodeSize,
                  maxNodeSize: this.param.node.style.maxNodeSize,
                  minEdgeSize: 0.5,
                  maxEdgeSize: 1,
                  edgeLabelSizePowRatio:2,//调整缩放比例
                  autoResize:false,
                  autoRescale: false,
                  touchEnabled: true,
                  //画边的文字 ,改为true直接报错了
                  //drawEdgeLabels:true,
                  //节点标签和边标签设定两种fixed 和 proportional
                  //labelSize:'fixed',//'proportional',
                  //defaultLabelSize:8,
                  labelSize:'proportional',
                  //比例显示文字
                  labelSizeRatio:0.6,
                  edgeLabelSize:'proportional',
                  defaultEdgeLabelSize:8,
                  edgeLabelSizePowRatio:-3,
                  //缩放最小比例
                  zoomMin: 0.0625,
                  //缩放最大比例
                  zoomMax: 12,
                  //缩放大小默认1.7 太大不舒服 小于1是反向
                  zoomingRatio: 1.1,
                  //滚动渲染延迟
                  mouseZoomDuration: 100,
                  //双击不执行放大
                  doubleClickEnabled:false,

                  enableEdgeHovering: true,//webgl 下不支持
                  edgeHoverColor: 'edge',
                  defaultEdgeHoverColor: '#000',
                  //默认节点的字体颜色
                  defaultLabelColor:'#959FC7',
                  edgeHoverSizeRatio: 1,
                  edgeHoverExtremities: true,
                  //缩放时的比例
                  nodesPowRatio: 0.2,
                  minArrowSize: 2,
                }
              })



              //由于生成canvas有时间延迟，所以后续等待
              setTimeout(()=>{
                this.canvasDom = document.getElementsByClassName("sigma-scene")[0]
                this.initInteract()
                if(typeof(this.canvas.data)!='undefined' && this.canvas.data){
                  //this.convertData()
                  this.graphDraw()
                }
                }

                ,200)

            }

          }
        )
      })

      //构建鹰眼
      if(this.param.eagleEye.isCreate){

      }
    }
    /**
     * 转换数据边指向的是ID
     */
    convertData(){
      let data = this.canvas.data
      let idIndex = {}
      //先生成一个id的键值对，再直接取，减少时间
      for(let i=0;i<data.nodes.length;i++){
        idIndex[data.nodes[i].id] = i
      }
      data.edgesIndex = Util.deepCover(data.edges[i],{})
      for(let i=0;i<data.edges.length;i++){
        let edge = data.edges[i]
        let edgeIndex = data.edgeIndex[i]
        edgeIndex.source = idIndex[edge.source]
        edgeIndex.target = idIndex[edge.target]
      }
    }

    /**
     * 渲染画布
     */
    graphDraw(){
      let data = this.canvas.data
      let view = typeof(this.canvas.view)!='undefined'?this.canvas.view:null
      let isInitLayout = false
      //判断是否需要做数据的
      if(!data || typeof(data.nodes) == 'undefined' || !data.nodes){
        return
      }
      data.nodes.map((d)=>{
        if( typeof(d.x)=='undefined' || typeof(d.y)=='undefined'){
          isInitLayout = true
        }
      })


      //是否进行数据的转换过滤 进行数据的转换
      let isCovert = true
      //是否更新到服务器 不更新
      let isNotUpdate = true
      //是否存储为历史，不存储，否则会存储空白，导致清空操作
      let isNotHistory = true
      this.trigger(EVENTS['addNodesAndEdges'],data.nodes,data.edges,isCovert,isNotUpdate,isNotHistory)
      //默认是做力导向布局，其实是有问题的，应该是如果没有坐标的话
      if(isInitLayout && !view){
        this.trigger(EVENTS['forceLayout'])
      }else{
        let isNotSave = true
        let isNotHis = true
        this.trigger(EVENTS['gotoView'],view,isNotSave,isNotHis)
      }
    }
    /**
     * 切换画布内容
     * 包括画布名称
     */
    switchGraph(param,canvas){
      if(!this.s || !this.s.graph){
        setTimeout(() => {
          this.switchGraph(param,canvas)
        }, 500)
        return
      }
      //停止全部动画
      this.trigger(EVENTS['stopAnimation'])
      //清楚全部历史记录
      this.trigger(EVENTS['clearHistory'])
      //先清空再更新，清空动作不做任何历史保存
      let isRefresh = false
      this.trigger(EVENTS['deleteNodes'],this.s.graph.nodes(),isRefresh)

      this.param = Util.deepCover(paramMode,param)
      this.canvas = canvas
      //this.initGraph()
      this.graphDraw()
    }
    /**
     * 更新画布状态
     * 属性对应的覆盖更新，并通知外围
     */
    updateCanvasStatus(attr){
      for(let name in attr){
        this.canvas[name] = attr[name]
      }
      this.trigger(EVENTS['updateCanvas'],this.canvas)
    }
    extentSelect(){
      this.trigger(EVENTS['extentSelect'])
    }
    /**
     * 自适应范围
     */
    autoExtent=()=>{
      this.view.autoExtent()
    }
    /**
     * 网格布局
     */
    gridLayout=()=>{
      this.trigger(EVENTS['gridLayout'])
    }
    /**
     * 力导向布局
     */
    forceLayout=()=>{
      this.trigger(EVENTS['forceLayout'])
    }
    /**
     * 圆形布局
     */
    circleLayout=()=>{
      this.trigger(EVENTS['circleLayout'])
    }
    /**
     * 层次布局
     */
    hierarchyLayout=()=>{
      this.trigger(EVENTS['hierarchyLayout'])
    }
    /**
     * 删除
     */
    delSelect=()=>{
      this.trigger(EVENTS['deleteEvent'])
    }
    /**
     * 对外接口触发上一步历史还原
     */
    prev=()=>{
      this.trigger(EVENTS['getPreHis'])
    }
    /**
     * 对外接口触发新增 ，且会确定是否对新增的数据进行
       data:{
         //只是新增的点
         nodes:[],
         edges:[],
         //全部点的id，不提供的话，默认认为是全部
         nodeIds:[],
         edgeIds:[]
       }
       config:{
         //是否选中新增的点和边，默认 true，表示选中
        isSelect:true,
        //数据是否进行一定的处理，默认 true，表示需要简单处理，保障
        isConvert:true,
        //是否历史存储方便回退，默认 false，表示存储，非必填
        isNotHistory:false,
        //是否发起后端存储 默认 false，表示存储,非必填
        isNotUpdate:false
       }
     */
    addNet=(data,config)=>{
      let defConfig = {
        //是否选中新增的点和边，默认 true，表示选中
        isSelect:true,
        //数据是否进行一定的处理，默认 true，表示需要简单处理，保障
        isConvert:true,
        //是否历史存储方便回退，默认 false，表示存储，非必填
        isNotHistory:false,
        //是否发起后端存储 默认 false，表示存储,非必填
        isNotUpdate:false,
        //是否强制渲染，默认false
        isForceRendering:false
      }
      config = Util.deepCover(defConfig,config)
      //只做一次历史存储
      if(!config.isNotHistory){
        this.trigger(EVENTS['updateHistory'])
      }
      //不重复存储历史 ，使用总体的是否覆盖，不重复更新到后端
      let isNotaddHistory = true
      let isConvert = config.isConvert
      let isNotaddUpdate = true

      this.trigger(EVENTS['addNodesAndEdges'],data.nodes,data.edges,isNotaddUpdate,isConvert,isNotaddHistory,config.isForceRendering)
      //判断是否高亮
      if(config.isSelect && typeof(data.nodeIds) != 'undefined'){
        let isNotRefresh = true//暂不刷新
        this.trigger(EVENTS['updateSelectByIds'],data.nodeIds,data.edgeIds,isNotRefresh)
      }
      //判断是否存储
      if(!config.isNotUpdate){
        //历史已经做过。做布局的时候不需要做，在运算完毕后会自动发起存储
        let isNotHis = true
        //没有添加点，不做力导向布局，但是这样还有缺陷，就是历史保留没有。默认是不做保留的，所以逻辑还正常
        if(data.nodes.length!=0 || data.edges.length!=0){
          this.trigger(EVENTS['forceLayout'],isNotHis)
        }
      }
    }
}

export default Bdnet
