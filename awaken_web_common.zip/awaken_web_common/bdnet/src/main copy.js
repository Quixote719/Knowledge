import ccNetViz from '../submodule/ccNetViz/src/ccNetVizMultiLevel'
import EventEmitter  from 'eventemitter3'
import EVENTS from './event/eventdeclara'
import Util from './util'
import paramMode from './config'
import BoxSelect from './interact/boxSelect'
import EventManage from './event'
import * as d3 from 'd3'
import {sigma} from 'sigma'
class Bdnet{
    /**
     * 初始化
     * @param {*} param 画布状态、事件、菜单的定义
     * @param {*} canvas 实例画布信息，包含 画布id 画布名称 画布当前状态 画布当前的数据
     */
    constructor(param,canvas){
      console.log('bdnet initparam')
      this.param = Util.deepCover(paramMode,param)
      this.canvas = canvas
      this.emitter = new EventEmitter()
      
      this.initGraph()
      new EventManage(this)
      this.boxSelect = new BoxSelect(this)

      if(this.canvas.data){
        //this.convertData()
        this.graphDraw()
      }

    } 
    /**
     * 事件绑定，用于监听关系网络内容
     * @param {*} eventName 
     * @param {*} fun 
     */
    bind = (eventName,fun,context)=>{
      this.emitter.on(eventName,fun,context)
    }
    /**
     * 事件触发
     */
    trigger(){
      this.emitter.emit(...arguments)
    }
    /**
     * 清除画布但是会保留基础配置 
     */
    clear(){

    }
    /**
     * 彻底删除关系网络
     */
    destroy(){
      this.clear()
    }
    /**
     * 初始化画布渲染
     */
    initGraph(){
      let options = {
        styles: {
          node: {
            size: 20,
            texture: 'example/images/node.png',
          },
          edge: {
            width: 5,
            type: 'dotted',
            color: 'rgb(200, 200, 200)',
/*
            animateType: 'double-gradient', // "basic", "gradient", "double-gradient", "shape-wave", "shape-bubble", "none"
            animateSpeed: 1,
            animateEase: 'quart-out', // default is "linear"
            animateColor: 'rgb(240, 80, 100)',
            animateMaxWidth: 25,
            */
          },
          'people_block':{
            size: 30,
            color:'rgb(120, 120, 120)',
            //texture: 'example/images/people_block.png',
          },
          'people_blue':{
            size: 30,
            texture: 'example/images/people_blue.png',
          },
          'people_green':{
            size: 30,
            texture: 'example/images/people_green.png',
          },
          'people_purple':{
            size: 30,
            texture: 'example/images/people_purple.png',
          },
          'people_red':{
            size: 30,
            texture: 'example/images/people_red.png',
          },
          'people_yellow':{
            size: 30,
            texture: 'example/images/people_yellow.png',
          }
        },
        onDrag:{
          start:(e,viewPort)=>{
            //console.log('start:'+JSON.stringify(e))
          },
          drag:(e,viewPort)=>{
            //console.log('drag:'+e)
          },
        },
        onZoom:(viewPort)=>{
          //console.log('zoom:'+JSON.stringify(viewPort))
        },
        onChangeViewport:(viewPort)=>{
          if(this.timeout){
            clearTimeout(this.timeout)
          }
          this.timeout = setTimeout(() => {
            console.log('onChangeViewport:'+JSON.stringify(viewPort))
            this.updateCanvasStatus({view:viewPort})
          }, 300);
          
        }
      }
      const el = this.param.dom
      el.innerHTML = ''
      
      // if(this.canvas){
      //   el.removeChild(this.canvas)
      // }
      this.canvasDom = document.createElement('canvas')
      this.canvasDom.style.zIndex = 50
      el.appendChild(this.canvasDom)
      if (this.graph) this.graph.remove()
      this.graph = new ccNetViz(this.canvasDom, options)
      //构建鹰眼
      if(this.param.eagleEye.isCreate){

      }
    }
    /**
     * 转换数据边指向的是ID
     */
    convertData(){
      let data = this.canvas.data
      let idIndex = {}
      //先生成一个id的键值对，再直接取，减少时间
      for(let i=0;i<data.nodes.length;i++){
        idIndex[data.nodes[i].id] = i
      }
      for(let i=0;i<data.edges.length;i++){
        let edge = data.edges[i]
        edge.source = idIndex[edge.source]
        edge.target = idIndex[edge.target]
      }
    }
    /**
     * 渲染画布
     */
    graphDraw(){
      let data = this.canvas.data
      
      this.graph.set(data.nodes, data.edges, 'force').then(() => {
        this.graph.draw();
      })

      var simulation = d3.forceSimulation(data.nodes)
        .force("charge", d3.forceManyBody())
        .force("link", d3.forceLink(data.edges))
        .force('center', d3.forceCenter(1920 / 2, 1000 / 2))
        .on('tick', this.ticked);
    }
    ticked = () => {
      let data = this.canvas.data
      this.graph.set(data.nodes, data.edges).then(() => {
        this.graph.draw()
        console.log(data)
      })
    }
    /**
     * 切换画布内容
     * 包括画布名称
     */
    switchGraph(param,canvas){
      this.param = Util.deepCover(this.param,param)
      this.canvas = canvas
      this.initGraph()
      this.graphDraw()
    }
    /**
     * 更新画布状态
     * 属性对应的覆盖更新，并通知外围
     */
    updateCanvasStatus(attr){
      for(let name in attr){
        this.canvas[name] = attr[name]
      }
      this.trigger(EVENTS['updateCanvas'],this.canvas)
    }
    extentSelect(){
      this.trigger(EVENTS['extentSelect'])
    }

}

export default Bdnet