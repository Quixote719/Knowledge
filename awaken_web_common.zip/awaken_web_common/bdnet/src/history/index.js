import EVENTS from '../event/eventdeclara'
import Util from '../util'
/**
 * 历史记录
 *
 */
class History{
    constructor(main){
        this.main = main
        this.param = this.main.param
        this.s = this.main.s
        this.config = {
            //历史存储个数
            time:10
        }
        /*
        historyArr对象数组格式
        {
            id:11,
            view:{x,y,ratio},
            topo:{nodes:[],edges:[]},
            select:{selectNodeIds:[],selectEdgeIds:[]}
        }

        */

       this.selectNodeIds=[]
       this.selectEdgeIds=[]
        this.historyArr = new Array()
        main.bind(EVENTS['selectNodesAndEdges'],(selectNodeIds,selectEdgeIds)=>{
            this.selectNodeIds = selectNodeIds
            this.selectEdgeIds = selectEdgeIds
        })
        //切换画布进行历史清空
        main.bind(EVENTS['clearHistory'],this.clearHistory,this)
        //存储历史，主要问题是如果新增会导致 拓扑和视图双重变动，所以新增的话，会进行一次数据标记()，表示这是同一次的更新 push动作 不写入后端
        main.bind(EVENTS['updateHistory'],this.updateHistory,this)
        main.bind(EVENTS['updateHistorySelect'],this.updateHistorySelect,this)
        main.bind(EVENTS['updateHistoryView'],this.updateHistoryView,this)

        //还原历史，视图变动、拓扑改动、选中（只有选中这步历史不用发起后端存储）  pop动作 写入后端
        main.bind(EVENTS['getPreHis'],this.getPreHis,this)
        //初始化时重设一下

        this.setPrevBtnStatus()
    }
    /**
     * 更新历史
     * 只传个类型好了，统一处理掉，默认应该支持完整历史更新  todo  其中视图和选中需要判断是否是有效的更新（各自单独的业务只更新其中一个 的话）
     * 在改变（视图变动、拓扑改动、选中）前时更新历史 ，严格来讲是在改变一件业务前，例如新增动作发起前（三者都会触发）
     */
    updateHistory = ()=>{
        console.log('updateHistory全套'+this.selectNodeIds.length +'ssss'+this.selectEdgeIds.length)
        let obj = {
            view:{x:this.s.camera.x,y:this.s.camera.y,ratio:this.s.camera.ratio},
            select:{
                selectNodeIds:this.selectNodeIds,
                selectEdgeIds:this.selectEdgeIds
            },
            topo:{nodes:Util.cloneDeep(this.s.graph.nodes()),edges:Util.cloneDeep(this.s.graph.edges())},
        }
        this.historyArr.push(obj)
        this.setPrevBtnStatus()
    }
    //更新选中历史
    updateHistorySelect = (oldNodeIds,oldEdgeIds,nodeIds,edgeIds) => {
        if(oldNodeIds.sort().toString() == nodeIds.sort().toString() && oldEdgeIds.sort().toString() == edgeIds.sort().toString() ){
            return
        }
        this.historyArr.push({
            select:{
                selectNodeIds:oldNodeIds,
                selectEdgeIds:oldEdgeIds
            }
        })
        console.log('updateHistorySelect...........'+this.historyArr.length)
        this.setPrevBtnStatus()
    }
    //更新view视角历史 单独
    updateHistoryView = () => {
        //添加判断。是否和上次历史是一致的
        this.historyArr.push({
            view:{
                x:this.main.canvas.x,
                y:this.main.canvas.y,
                ratio:this.main.canvas.ratio
            }
        })
        console.log(this.main.canvas.x)
        console.log('updateHistoryView...........'+this.historyArr.length)
        this.setPrevBtnStatus()
    }
    /**
     * 获得上一步的历史，且不形成历史
     *
     */
    getPreHis = () => {
        //获得最后加入的，并删除
        let his = this.historyArr.pop()
        //是否进行保存，只有选中的情况下（select）不需要保存
        let isSave = false
        //分三种情况处理,且分别处理对应的停止记录
        if(typeof(his.view)!='undefined'){
            isSave = true
            //实现之前的视图,先不更新
            let isNotSave = true
            //不更新历史
            let isNotHis = true
            this.main.trigger(EVENTS['gotoView'],
                {
                    x:his.view.x,
                    y:his.view.y,
                    ratio:his.view.ratio
                }
                ,isNotSave
                ,isNotHis
            )
        }
        if(typeof(his.topo)!='undefined'){
            isSave = true
            //实现之前数据
            //不更新到服务器 true
            let isNotUpdate = true
            //不需要做数据的转换过程
            let isConvert = false
            //不需要更新历史
            let isNotHistory = true
            //是否强力渲染
            let isForceRendering = true
            //先清空再更新，清空动作不做任何历史保存
            let isRefresh = false
            this.main.trigger(EVENTS['deleteNodes'],this.s.graph.nodes(),isRefresh)
            this.main.trigger(EVENTS['addNodesAndEdges'],his.topo.nodes,his.topo.edges,isNotUpdate,isConvert, isNotHistory, isForceRendering)
        }
        if(typeof(his.select)!='undefined'){
            //实现之前的选中
            this.main.trigger(EVENTS['updateSelectByIds'],his.select.selectNodeIds,his.select.selectEdgeIds)
        }
        //判断是否更新到后端,合并保存
        if(isSave){
            //执行保存动作
            this.main.trigger(EVENTS['updateCanvas'],{canvas:this.main.canvas.canvas,nodes:this.s.graph.nodes(),edges:this.s.graph.edges(),view:{x:his.view.x,y:his.view.y,ratio:his.view.ratio}})
        }
        this.setPrevBtnStatus()
    }
    /**
     * 清空历史
     * 场景：切换掉当前画布时
     */
    clearHistory = () => {
        this.historyArr = []
        this.setPrevBtnStatus()
    }
    /**
     * 根据当前历史数组，判断上一步是否可用的派发
     */
    setPrevBtnStatus = () => {
        if(this.historyArr.length === 0){
            console.log('11111111111')
            this.main.trigger(EVENTS['prevStatus'],'disabled')
        }else{
            this.main.trigger(EVENTS['prevStatus'],false)
        }
    }
}
export default History
