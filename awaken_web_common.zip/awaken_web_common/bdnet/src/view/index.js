import EVENTS from '../event/eventdeclara'
import {debounce} from 'parthenon-lib'
/**
 * 可视缩放平移类
 *
 */
class View{
    constructor(main){
        this.main = main
        this.param = this.main.param
        this.s = this.main.s
        main.bind(EVENTS['autoExtent'],this.autoExtent,this)
        main.bind(EVENTS['updateView'],this.updateView,this)
        this.iTime = null
        this.s.camera.bind('coordinatesUpdated', (e) => {
            this.updateView(e)
        })
        main.bind(EVENTS['changeView'],this.changeView,this)
        //是否不存储历史 默认存储
        this.ISNOTHIS = false
        //是否不存储到后端  默认存储
        this.ISNOTSAVE = false
        //产生跳转
        main.bind(EVENTS['gotoView'],this.gotoView,this)
    }
    /**
     * 自适应
     * todo his   添加条件，很多动画中的自适应不需要保存至历史 ，，，按钮的自适应需要保存历史
     */
    autoExtent = (isNotHis)=>{
        this.ISNOTHIS = isNotHis

        let s = this.s
        if (s.graph.nodes().length) {
            let w = document.getElementsByClassName("sigma-scene")[0].offsetWidth - 0
            let h = document.getElementsByClassName("sigma-scene")[0].offsetHeight - 0

            // The "rescale" middleware modifies the position of the nodes, but we
            // need here the camera to deal with this. Here is the code:
            let xMin = Infinity,
                xMax = -Infinity,
                yMin = Infinity,
                yMax = -Infinity,
                //定义的边距
                margin = 10,
                scale;

            s.graph.nodes().forEach(function(n) {
              xMin = Math.min(n.x, xMin);
              xMax = Math.max(n.x, xMax);
              yMin = Math.min(n.y, yMin);
              yMax = Math.max(n.y, yMax);
            });

            xMax += margin;
            xMin -= margin;
            yMax += margin;
            yMin -= margin;

            scale = Math.min(
              w / Math.max(xMax - xMin, 1),
              h / Math.max(yMax - yMin, 1)
            );
            let viewObj = {
                x: (xMin + xMax) / 2,
                y: (yMin + yMax) / 2,
                ratio: 1 / scale
            }
            s.camera.goTo(viewObj)
        }
    }
    /**
     * 跳转至
     */
    gotoView = (viewObj,isNotSave,isNotHis) => {
        this.ISNOTSAVE = isNotSave
        this.ISNOTHIS = isNotHis
        this.s.camera.goTo(viewObj)
    }
    updateView = debounce(() => {
        /*
        clearTimeout(this.iTime)
        //对于连续事件的处理
        this.iTime = setTimeout(()=>{
            let x = this.s.camera.x
            let y = this.s.camera.y
            let ratio = this.s.camera.ratio
            //没有坐标的情况
            if(typeof(this.main.canvas.x)=='undefined'){
                this.changeView(x,y,ratio,false,this.ISNOTHIS)
                return
            }
            if(this.main.canvas.x != this.s.camera.x || this.main.canvas.y != this.s.camera.y || this.main.canvas.ratio != this.s.camera.ratio){
                this.changeView(x,y,ratio,false)
                return
            }
        },80)
        */

        let x = this.s.camera.x
        let y = this.s.camera.y
        let ratio = this.s.camera.ratio
        //没有坐标的情况
        if(typeof(this.main.canvas.x)=='undefined'){
            this.changeView(x,y,ratio,false,this.ISNOTHIS)
            return
        }
        if(this.main.canvas.x != this.s.camera.x || this.main.canvas.y != this.s.camera.y || this.main.canvas.ratio != this.s.camera.ratio){
            this.changeView(x,y,ratio,false)
            return
        }
    },80)
    /**
     * 执行坐标改变，并不会改变视野，只是改变数据
     * x
     * y
     * ratio
     * isNotSave 是否保存视角，默认保存
     */
    changeView = (x,y,ratio,isNotSave) => {
        if(this.ISNOTSAVE === false || this.ISNOTSAVE === true){
            isNotSave = this.ISNOTSAVE
        }
        //单独保存历史
        if(!this.ISNOTHIS){
            this.main.trigger(EVENTS['updateHistoryView'])
        }else{
            this.ISNOTHIS = false
        }
        this.main.canvas.x = x
        this.main.canvas.y = y
        this.main.canvas.ratio = ratio
        console.log('更新坐标！！！！')
        console.log(this.main.canvas.x)
        if(!isNotSave){
            //执行保存动作
            console.log('更新坐标通知保存！！！！')
            this.main.trigger(EVENTS['updateCanvas'],{canvas:this.main.canvas.canvas,nodes:this.s.graph.nodes().slice(),edges:this.s.graph.edges().slice(),view:{x,y,ratio}})

            this.ISNOTSAVE = null
        }else{
            this.ISNOTSAVE = false
        }
    }
}
export default View
