import EVENTS from '../event/eventdeclara'
import Util from '../util'
/**
 * 编辑画布
 * 包括新增删除
 *
 */
class Edit{
    constructor(main){
        this.main = main
        this.param = this.main.param
        this.s = this.main.s
        this.selectNodeIds = []
        this.selectEdgeIds = []
        //绑定新增的信息
        this.main.bind(EVENTS['deleteNodes'],this.deleteNodes,this)
        this.main.bind(EVENTS['addNodesAndEdges'],this.addNodesAndEdges,this)
        this.main.bind(EVENTS['deleteEvent'],this.deleteEvent,this)
        this.main.bind(EVENTS['selectNodesAndEdges'],this.selectNodesAndEdges)
        //结束编辑
        this.main.bind(EVENTS['endEdit'],this.endEdit,this)
        //拖动新增相关
        this.main.bind(EVENTS['mouseDownDragAdd'],this.mouseDownDragAdd,this)
        this.main.bind(EVENTS['canvasMousemove'],this.mousemove,this)
        this.main.bind(EVENTS['mouseup'],this.mouseup,this)
        /***
         * 1.由业务模块触发点击事件（初始化添加变量）
         * 2.监听（画布上）移动事件，绘制点（判断移动在画布内）
         * 3.监听全局的鼠标up事件，完成添加
         */
        this.isHold = false
        this.addStartMsg = null
        this.addParam = null
        this.isAdding = true
        //是否等待关系线f
        this.isWaitLine = false
        this.waitLineIng = false
        this.addParamLines = null
        this.addParamNodes = null
        this.main.bind(EVENTS['mouseDownDragAddRelationCallBack'],this.mouseDownDragAddRelationCallBack,this)

        this.styleNConfig = this.param.node.style
        this.styleEConfig = this.param.edge.style

        /*
        //测试
        let event = {
            clientX:0,
            clientY:0
        }
        let obj = {
            "id":"555",
            "label": "5",
            "style":"people_yellow",
        }
        this.mouseDownDragAdd(event,obj)
        */

    }
    /**
     * 统一处理结束编辑
     * isNotRefresh 默认刷新  true则不刷新
     * isNotUpdate 默认更新   true则不更新
     */
    endEdit = (isNotRefresh,isNotUpdate)=>{
        if(!isNotRefresh){
            this.s.refresh()
        }
        if(!isNotUpdate){
            this.main.trigger(EVENTS['updateCanvas'],{canvas:this.main.canvas.canvas,nodes:this.s.graph.nodes(),edges:this.s.graph.edges(),view:{x:this.main.canvas.x,y:this.main.canvas.y,ratio:this.main.canvas.ratio}})
        }
    }
    /**
     * 新增关系和节点
     * isNotUpdate 不更新到服务器
     * isConvert 需要做数据的转换过程
     * isNotHistory 默认不更新历史记录
     */
    addNodesAndEdges = (nodes,edges,isNotUpdate,isConvert,isNotHistory,isForceRendering)=>{
        //todo his 进行一次历史保存，包括 select 和 nodes edges
        if(!isNotHistory){
            this.main.trigger(EVENTS['updateHistory'])
        }
        //isForceRendering强制渲染节点，会导致先删除点后删除边，然后，边又不传过来的话边就消失了，所以判断一下
        if(isForceRendering){
            edges = this.edgePatch(edges)
            //清除之前的边
            let allEdges = this.s.graph.edges()
            this.deleteEdges(allEdges,false)
        }
        //不刷新的更新节点
        this.addNodes(nodes,true,isConvert,isNotUpdate,isForceRendering)
        this.addEdges(edges,true,isConvert,isNotUpdate,isForceRendering)
        this.endEdit(false,isNotUpdate)
    }
    /**
     * 移动单个节点
     */
    moveNode = (id,x,y,isNotRefresh,isNotUpdate)=>{
        let nodes = this.s.graph.nodes()
        nodes.forEach((n)=>{
            if(n.id === id){
                n.x = x
                n.y = y
            }
        })
        if(!isNotRefresh){
            this.endEdit(isNotRefresh,isNotUpdate)
        }
    }
    /**
     * 移动多节点
     */
    moveNodes = (concernNodeId,nodes,x,y,isNotRefresh,isNotUpdate)=>{
        //移动的数组
        let arr = []
        let ox = 0
        let oy = 0
        let changex = 0
        let changey = 0
        nodes.forEach((n)=>{
            if(n.id==concernNodeId){
                ox = n.x
                oy = n.y
                changex = x - ox
                changey = y - oy
                n.x = x
                n.y = y
            }
        })
        nodes.forEach((n)=>{
            if(n.id!=concernNodeId){
                n.x = n.x + changex
                n.y = n.y + changey
            }
        })
        if(!isNotRefresh){
            this.endEdit(isNotRefresh,isNotUpdate)
        }
    }
    /**
     * 新增节点
     */
    addNodes = (nodes,isNotRefresh,isConvert,isNotUpdate,isForceRendering)=>{

        nodes.map((d)=>{
            let nodeattr = d
            if(isConvert){
                nodeattr = this.getNodeAttr(d)
            }
            let nodes = this.s.graph.nodes()
            let isContain = false
            nodes.forEach((n)=>{
                if(n.id === nodeattr.id){
                    isContain = true
                }
            })
            //非强制渲染且未添加了的进行添加
            if(!isContain && !isForceRendering){
                this.s.graph.addNode(nodeattr)
            }
            //强制渲染
            if(isForceRendering){
                //已包含则要先删除
                if(isContain){
                    this.s.graph.dropNode(nodeattr.id)
                }
                this.s.graph.addNode(nodeattr)
            }
        })

        if(!isNotRefresh){
            this.endEdit(isNotRefresh,isNotUpdate)
        }
    }
    /**
     * 新增关系
     */
    addEdges = (edges,isNotRefresh,isConvert,isNotUpdate,isForceRendering)=>{
        edges.map((d, t) => {
            let edgeattr = d
            if(isConvert){
                edgeattr = this.getEdgeAttr(d,t)
            }
            let edges = this.s.graph.edges()
            let nodes = this.s.graph.nodes()
            //防止重复添加
            let isContain = false
            edges.forEach((e)=>{
                if(e.id === edgeattr.id){
                    isContain = true
                }
            })
            let sourceId = d.source
            let targetId = d.target
            let containNode = 0
            nodes.forEach((n)=>{
                if(n.id === sourceId){
                    containNode++
                }
                if(n.id === targetId){
                    containNode++
                }
            })
            //非强制渲染只有这一种逻辑
            if(!isContain && containNode === 2 && !isForceRendering){
                this.s.graph.addEdge(edgeattr)
            }else{
                //没有强制渲染的条件
                if(containNode !== 2){
                    //edgeattr.id sourceId targetId 不存在 message todo
                    //edgeattr.id 已经存在   message todo
                }else if(isForceRendering){
                    if(isContain){
                        this.s.graph.dropEdge(edgeattr.id)
                    }
                    this.s.graph.addEdge(edgeattr)
                }
            }

        })
        if(!isNotRefresh){
            this.endEdit(isNotRefresh,isNotUpdate)
        }
    }
    /**
     * 边的修补
     */
    edgePatch = (edges) => {
        let arr = edges
        let canvasEdges =  this.s.graph.edges()
        let arrobj = {}
        for(let i =0;i<arr.length;i++){
            arrobj[arr[i].id] = arr[i]
        }
        for(let i =0;i<canvasEdges.length;i++){
            let obj = canvasEdges[i]
            let id = obj.id
            if(typeof(arrobj[id])=='undefined'){
                arr.push(obj)
            }
        }
        return arr
    }
    /**
     * 删除节点，删除时也要删除对应的边
     */
    deleteNodes = (nodes,isRefresh) => {
        nodes.forEach((n)=>{
            this.s.graph.dropNode(n.id)
        })
        if(isRefresh){
            this.endEdit()
        }
    }
    /**
     * 删除边
     */
    deleteEdges = (edges,isRefresh) => {
        edges.forEach((e)=>{
            this.s.graph.dropEdge(e.id)
        })
        if(isRefresh){
            this.endEdit()
        }
    }
    /**
     * 删除节点，删除时也要删除对应的边
     */
    deleteNodesById = (ids,isRefresh) => {
        ids.forEach((id)=>{
            this.s.graph.dropNode(id)
        })
        if(isRefresh){
            this.endEdit()
        }
    }
    /**
     * 删除边
     */
    deleteEdgesById = (ids,isRefresh) => {
        ids.forEach((id)=>{
            this.s.graph.dropEdge(id)
        })
        if(isRefresh){
            this.endEdit()
        }
    }
    /**
     * 获得最新选中的节点和边
     */
    selectNodesAndEdges = (nodeIds,edgeIds) => {
        this.selectNodeIds = nodeIds
        this.selectEdgeIds = edgeIds
    }
    /**
     * 删除事件
     */
    deleteEvent = () => {
        //his 先判断是否有选中的内容，有则进行一次历史保存，包括 select 和 nodes edges
        if(this.selectEdgeIds.length !=0 || this.selectNodeIds.length != 0){
            //拓扑改变
            this.main.trigger(EVENTS['updateHistory'])
        }else{
            //alert('没有选中内容删除！！')
            this.main.trigger(EVENTS['messageTip'],{index:1,type:'alarm',message:'没有选中内容删除！！'})
            return
        }
        //调用删除，但是不触发结束，最后自己结束
        this.deleteEdgesById(this.selectEdgeIds,false)
        this.deleteNodesById(this.selectNodeIds,false)

        //补充，如果删除的话，需要去除相关联的样式

        this.endEdit()
    }
    /**
     * 设置节点参数
     * @param {*} d
     */
    getNodeAttr(d){
        //样式类型的数据处理
        if(typeof(d.style)!='undefined'){
          d.type = 'image'
          d.url = './example/images/'+d.style+'.png'
        }
        //临时方案，设置初始化渲染样式
        let statusType = 'default'//unSelected
        if(this.selectNodeIds.length>0 || this.selectEdgeIds.length>0){
            statusType = 'unSelected'
        }
        let cfg = this.styleNConfig.status[statusType]
        /** 原数据
        element: "ENTITY"
        id: "330902196010210235"
        label: "person"
        showName: "person"
        uniqueId: "person:330902196010210235"
         */
        const imgTypes = ['person','anjian','car','phone','card','camera','entity','event','place','goods','rfid','wifi']
        //前缀和后缀
        const urlPrefix = `${window.basename}/img/nettype/`
        const urlSuffix = '.png'
        let type = 'def'
        let url = ''
        if(typeof(d.label)!='undefined' && Util.isContain(imgTypes,d.label)){
            type = 'image'
            url = urlPrefix + d.label + '_' + statusType + urlSuffix
        }
        if(typeof(d.subClass)!='undefined' && Util.isContain(imgTypes,d.subClass)){
            type = 'image'
            url = urlPrefix + d.subClass + '_' + statusType + urlSuffix
        }
        let obj = {
            id: d.id+'',
            label: d.label+'', //处理提前处理，没有label的话则空字符串
            //type:(typeof(d.type)=='undefined')?'def':d.type,
            //url:(typeof(d.url)=='undefined')?'':d.url,
            type: type,
            url: url,
            x: typeof(d.x)!='undefined'?d.x:Math.random(),
            y: typeof(d.y)!='undefined'?d.y:Math.random(),
            size: typeof(d.size)!='undefined'?d.size:18,
        }

        obj.color = cfg.icon.color
        //obj.size = cfg.icon.size
        //矩形 换掉
        if(d.class === 'EVENTS'){
            //obj.type = 'square'
            obj.type = 'image'
            obj.url = urlPrefix + 'anjian_' + statusType + urlSuffix
            obj.color = 'rgba(255,255,255,0)'
        }
        if(type == 'image'){
            obj.color = 'rgba(255,255,255,0)'
        }else{
            obj.type = 'image'
            obj.url = urlPrefix + 'entity_' + statusType + urlSuffix
            obj.color = 'rgba(255,255,255,0)'
        }
        
        /**
        let attrArr = ['id','label','type','url','x','y','size']
        for(name in d){
          if(attrArr.indexOf(name)<0){
            obj[name] == d[name]
          }
        }
         */
        obj = Util.deepCover(d,obj)
        return obj
      }
    getEdgeAttr(d,t){
        let count = 0
        let type = 'line'
        //判断是否有重复的重复总和需要一个数据，然后直接使用这个数据做为count，且大于0 的都是curve
        //前提是判断是否已经有了，有了的话，先删除
        let edges = this.s.graph.edges()
        for(let i=0;i<edges.length;i++){
            let edge = edges[i]
            if(d.id != edge.id){
                if((d.source == edge.source && d.target == edge.target) || (d.source == edge.target && d.target == edge.source)){
                    count++
                    type = 'curve'
                }
            }
        }
        let obj = {
            id: d.id+'',
            source: d.source+'',//这里为id
            target: d.target+'',
            size: typeof(d.size)!='undefined'?d.size:1,
            color:(typeof(d.color)=='undefined')?'rgb(0,0,0)':d.color,
            type,//curve
            count
        }
        //临时方案，设置初始化渲染样式
        let statusType = 'default'//unSelected
        if(this.selectNodeIds.length>0 || this.selectEdgeIds.length>0){
            statusType = 'unSelected'
        }
        let cfg = this.styleEConfig.status[statusType]
        obj.color = cfg.color
        obj.size = cfg.size
        obj = Util.deepCover(d,obj)
        return obj
    }
    /**
     * 鼠标移动添加
     */
    mouseDownDragAdd = (event, obj,isWaitLine)=>{
        this.isHold = true
        this.addMoveFirst = true
        //记录坐标，防止点击事件产生添加动作
        this.addStartMsg = { x: event.clientX, y: event.clientY }
        this.addParam = obj
        this.nodes = this.s.graph.nodes()
        this.isWaitLine = isWaitLine
        //记录第一次请求线的标记
        if(this.isWaitLine){
            this.waitLineIng = true
        }
    }
    /**
     * 鼠标移动事件
     * pos {x,y}，canvas位置
     *
     */
    mousemove = (e) => {
        //在画布内且hold住才有效
        if(this.isHold){
            /*
            let left = pos.x
            let top = pos.y
            let isInCanvas = Util.isInCanvas(this.main.canvasDom,left,top)
            if(!isInCanvas){
                return
            }
            */
            //移动的第一次检查是否重复，重复则进行提示消息
            if(this.addMoveFirst){
                this.nodes.forEach((n)=>{
                    if(n.id === this.addParam.id){
                        this.main.trigger(EVENTS['messageTip'],{index:2,type:'alarm',messageId:'addRepeat',messageObj:n,message:this.addParam.label+'已存在!'})
                        this.isHold = false
                        this.isAdding = false
                        return
                    }
                })
                if(!this.isHold){
                    return
                }

            }
            let xy = this.main.s.camera.cameraPosition(
                sigma.utils.getX(e) - sigma.utils.getCenter(e).x,
                sigma.utils.getY(e) - sigma.utils.getCenter(e).y,
            )


            this.addParam.x = xy.x
            this.addParam.y = xy.y
            this.addParam.color = '#ff0000'
            //添加，判断当前在添加的对象是否已经添加，添加不做历史保存和后端保存
            let addConfig = {
                //执行刷新
                isNotRefresh:false,
                //节点进行覆盖改造
                isConvert:true,
                //不更新至后端
                isNotUpdate:true,
                //做强力渲染，因为要换坐标
                isForceRendering:true,
                //不更新到历史
                isNotHistory:true
            }
            if(this.addMoveFirst){
                //发起线的请求
                if(this.waitLineIng){
                    this.main.trigger(EVENTS['mouseDownDragAddRelation'],{obj:this.addParam})
                    this.waitLineIng = false
                }
                //全是不保存的更新
                if(!this.isWaitLine){
                    this.addNodes([this.addParam],addConfig.isNotRefresh,addConfig.isConvert,addConfig.isNotUpdate,addConfig.isForceRendering)
                }else{
                    if(this.addParamLines && this.addParamLines.length > 0){
                        for(let i=0 ;i<this.addParamNodes.length;i++){
                            if(this.addParam.id === this.addParamNodes[i].id){
                                this.addParam = this.addParamNodes[i]
                                this.addParam.x = xy.x
                                this.addParam.y = xy.y
                                //删除此点
                            }
                        }
                        this.addNodesAndEdges([this.addParam],this.addParamLines,addConfig.isNotUpdate,addConfig.isConvert,addConfig.isNotHistory,addConfig.isForceRendering)
                    }else{
                        this.addNodes([this.addParam],addConfig.isNotRefresh,addConfig.isConvert,addConfig.isNotUpdate,addConfig.isForceRendering)
                    }
                }

                //表示正在添加
                this.isAdding = true
                //第一次添加结束
                this.addMoveFirst = false
            }else{
                //移动变换位置
                let isNotRefresh = false
                let isNotUpdate = true
                if(!this.isWaitLine){
                    this.moveNode(this.addParam.id,xy.x,xy.y,isNotRefresh,isNotUpdate)
                }else{
                    if(this.addParamLines && this.addParamLines.length > 0){
                        for(let i=0 ;i<this.addParamNodes.length;i++){
                            if(this.addParam.id === this.addParamNodes[i].id){
                                this.addParam = this.addParamNodes[i]
                                this.addParam.x = xy.x
                                this.addParam.y = xy.y
                                //删除此点
                            }
                        }
                        this.addNodesAndEdges([this.addParam],this.addParamLines,addConfig.isNotUpdate,addConfig.isConvert,addConfig.isNotHistory,addConfig.isForceRendering)
                    }else{
                        this.moveNode(this.addParam.id,xy.x,xy.y,isNotRefresh,isNotUpdate)
                    }
                }

            }
        }
    }
    /**
     * 鼠标抬起事件
     * pos {x,y}，canvas位置
     *
     */
    mouseup = (pos) => {
        this.isHold = false
        //两种业务，第一种不需要添加线等待线的请求，直接保存
        if(!this.isWaitLine){
            this.isAdding = false
            //只有触发了拖拽事件在这里才有用
            if(!this.isAdding || !this.isHold){
                return
            }
            this.endEdit()
            this.resetAdd()
        }else{
            //需要添加线等待线的请求，如果已经成功获得线的数据则进行保存
            //此处应该要等待了，添加一个遮挡
            this.isAdding = true
            //线已经添加过来了,会直接保存
            if(this.addParamLines){
                this.endEdit()
                this.resetAdd()
            }
        }
    }
    /**
     * 添加线过来了
     */
    mouseDownDragAddRelationCallBack = (nodes,edges) => {
        //线的
        this.addParamLines = edges
        //点的
        this.addParamNodes = nodes
        //替换nodes的名字
        for(let i=0;i<nodes.length;i++){
            let node = nodes[i]
            let nodesAll = this.s.graph.nodes()
            for(let i=0;i<nodesAll.length;i++){
                let n = nodesAll[i]
                if(node.id === n.id){
                    n.label = node.label
                    break
                }
            }
        }
        //已经结束了拖动，直接保存 ,和上面操作只会执行一个
        if(!this.isHold){
            //添加，判断当前在添加的对象是否已经添加，添加不做历史保存和后端保存
            let addConfig = {
                //执行刷新
                isNotRefresh:false,
                //节点进行覆盖改造
                isConvert:true,
                //不更新至后端
                isNotUpdate:true,
                //做强力渲染，因为要换坐标
                isForceRendering:true
            }
            this.addEdges(this.addParamLines,addConfig.isNotRefresh,addConfig.isConvert,addConfig.isNotRefresh,addConfig.isForceRendering)
            this.endEdit()
            this.resetAdd()
        }
    }
    resetAdd = () => {
        //重置编辑的状态
        console.log('调用了endEdit')
        this.isHold = false
        this.addStartMsg = null
        this.addParam = null
        this.isAdding = true
        //是否等待关系线f
        this.isWaitLine = false
        this.waitLineIng = false
        this.addParamLines = null
    }
}
export default Edit
