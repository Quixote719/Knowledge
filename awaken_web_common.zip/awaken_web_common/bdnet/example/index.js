import {Bdnet} from '../src/'
import 'jquery'
let bdnet;
function init(){
    let param = {
        dom:document.querySelector('#content'),
        canvasName: {
            isShow:false,
        },
        node: {
            style:{
                //默认颜色 灰色(偏深灰)
                defaultColor:'#C1C1C1',
                //选中颜色 红色
                selectNodeColor:'#ec5148',
                //非选中，浅灰色
                unColor:'#eee',
                isOneSize:false,
                //默认大小
                size:8,
                minNodeSize: 8,
                maxNodeSize: 12,
            },
            //关联选中,建议做成开关来开启关闭，因为删除等确实不需要邻居功能，neighbors
            neighbors:{
                //是否启用
                isNeighbors:false,
                //使用nodeStyle的选中颜色
                
            },
        },
        edges:{
            style:{
                //默认颜色 黑色(偏深灰)
                defaultColor:'#000',
                size:1,
            }
        }
    }
    $.getJSON("./example/data/data.json", function(data){
        let canvas = data
        bdnet = new Bdnet(param,canvas)
        /* 切换画布动作
        setTimeout(() => {
            let canvasData = {
                data:{
                    "nodes": [
                        { "id":"111","label": "1"},
                        { "id":"222","label": "2","style":"people_blue"},
                        { "id":"333","label": "3","style":"people_red"},
                        { "id":"444","label": "4","style":"people_green"},
                        { "id":"555","label": "5","style":"people_yellow"},
                        { "id":"666","label": "6","style":"people_yellow"},
                        { "id":"777","label": "7","style":"people_yellow"},
                        { "id":"888","label": "8","style":"people_yellow"},
                        { "id":"999","label": "9","style":"people_yellow"},
                        { "id":"1110","label": "10","style":"people_yellow"}
                    ],
                    "edges": [
                        { "source": "111", "target": "222","color":"blue" },
                        { "source": "111", "target": "333" },
                        { "source": "111", "target": "444" },
                        { "source": "111", "target": "555" },
                        { "source": "555", "target": "666" },
                        { "source": "555", "target": "777" },
                        { "source": "555", "target": "888" },
                        { "source": "333", "target": "999" },
                        { "source": "333", "target":  "1110"},
                        { "source": "222", "target": "888" }
                    ]
                }
            }
            bdnet.switchGraph(param,canvasData)
        }, 3000);
        */
        //监听画布的变更
        bdnet.bind('updateCanvas',(obj)=>{
            console.log('updateCanvas'+JSON.stringify(obj))
        })
        let extentBtn = document.getElementById('extentBtn')
        extentBtn.onclick = ()=>{
            bdnet.extentSelect()
        }

        let autoBtn = document.getElementById('autoBtn')
        autoBtn.onclick = ()=>{
            bdnet.autoExtent()
        }
        let gridBtn = document.getElementById('gridBtn')
        gridBtn.onclick = ()=>{
            bdnet.gridLayout()
        }
        let forceBtn = document.getElementById('forceBtn')
        forceBtn.onclick = ()=>{
            bdnet.forceLayout()
        }
        let circleBtn = document.getElementById('circleBtn')
        circleBtn.onclick = ()=>{
            bdnet.circleLayout()
        }
        let hierarchyBtn = document.getElementById('hierarchyBtn')
        hierarchyBtn.onclick = ()=>{
            bdnet.hierarchyLayout()
        }
        let delBtn = document.getElementById('delBtn')
        delBtn.onclick = ()=>{
            bdnet.trigger('deleteEvent')
        }
    }) 
}

init()