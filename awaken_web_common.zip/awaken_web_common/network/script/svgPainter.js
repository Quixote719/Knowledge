/**
 * Created by yaojia7 on 2017/9/8.
 */
const fs = require('fs');
const resolve = require('path').resolve;
let configPath = resolve(__dirname, './svgPainterConfig.json');
const config = JSON.parse(fs.readFileSync(configPath));

let colors = {};
let inputFiles = [];

if(config.color){
    for(let key in config.color){
        colors[key] = config.color[key];
    }
}

console.log('--------------------------');

if(config.filename){
    for(let item of config.filename){
        if(item.includes('*')){
            let postfix = item.split('*');
            postfix = postfix[postfix.length - 1];
            let path = item.split('*')[0];
            path = resolve(__dirname, path);
            for(let fp of fs.readdirSync(path)){
                if(fp.endsWith(postfix)){
                    inputFiles.push(path + '/' + fp);
                }
            }
        } else {
            inputFiles.push(item);
        }
    }
}


for(let color in colors){
    let value = colors[color];
    for(let fp of inputFiles) {
        let svgData = fs.readFileSync(fp, 'utf8');
        let oriFillValue = svgData.match(/fill="(#[0-9|A-F|a-f]{6})"/g);
        let dir = fp.split('/');
        let filename = dir[dir.length-1];
        dir.pop();
        dir = dir.join('/');
        if(!fs.existsSync(resolve(dir, 'colored'))){
            fs.mkdirSync(resolve(dir, 'colored'));
        }
        let outputFilename = resolve(dir, 'colored', `${filename.split('.')[0]}_${color}.${filename.split('.')[1]}`);
        console.log('output file name', outputFilename);
        oriFillValue.forEach(ori => {
            svgData = svgData.replace(ori, `fill="${value}"`);
        });
        fs.writeFileSync(outputFilename, svgData);
    }
}

const unselected = "#437873"
const color = "#a5fbf7"
