/**
 * Created by yaojia7 on 2020/4/28.
 */
import ParthenonVis from './parthenon-vis'
import paramModel from './parthenon-vis/config';
import History from './parthenon-vis/history';
import EagleEye from './parthenon-vis/eagleEye';
import util from './parthenon-vis/util'
import {setStyle} from './parthenon-vis/config/style'

/**
 * container: DOM container of network
 * opts: {
     * events: {
         * onSelect: select 事件的回调函数，参数为选中的元素  id
         * onMultiSelect: 框选事件和ctrl多选事件的回调函数，参数为 {nodeIds: [], linkIds: []}，
         *               选中节点和边的id列表
         * onContextMenu: 鼠标右键点击事件的回调函数，参数为 ({x, y, nodeId, linkId, nodeIds, linkIds}).
         *               x, y 为相对于页面左上角的坐标
         *               nodeId 为右键点击的节点id
         *               linkId 为右键点击的节点id
         *               nodeIds 为右键点击多个被选中元素时的节点ids列表
         *               linkIds 为右键点击多个被选中元素时的边ids列表
         * onContextMenuDismiss: 鼠标右键菜单不显示,
         * onSave: 图谱画布信息保存时调用，参数为 （nodes, links）
         * onStateChange: 参数为 {isUndo, isRedo, isEmpty}
     * },
     * style: {
     *  nodeBorderStyle: 节点的边界样式，
     *  nodeBorderAttribute: 节点边界的属性：边框宽度等等
     *  nodeTextStyle: 节点文本样式
     *  linkStyle: 连线样式
     *  selectedBoxColor: 框选区域背景色
     * }
 * }
 */
class Network {
    chart = null
    renderer = null
    history = null
    eagleEye = null
    layout = 'force'

    constructor(container, opts = {}){
        if(!container){
            console.error('container is undefined')
            return
        }

        this.param = util.deepCover(paramModel,opts)

        ParthenonVis.create(container, this.afterCreate, this.handleSave, this.updateHistory)

        const interactor = this.chart.interactor
        this.onZoomIn = interactor.handleZoomByExtTrigger.bind(interactor, 1)
        this.onZoomOut = interactor.handleZoomByExtTrigger.bind(interactor, -1)
    }

    stop(){
        this.chart.running = false
        if(this.eagleEye) this.eagleEye.hide()
        this.chart.stopAnimation()
        this.chart.interactor.removeListeners()
    }

    start(){
        if(!this.chart.running) {
            this.chart.interactor.registerListeners()
            this.chart.running = true
        }
    }

    afterCreate = (err, chart) => {
        if(err)
            throw(err)

        const {history, eagleEye, events, style} = this.param
        const {onInitDone, onStateChange} = events

        this.chart = chart

        this.renderer = chart.getRenderer()

        this.bindEvents(chart)

        setStyle(this.renderer, style)

        if(history.isCreate) {
            this.history = new History({max: history.max, onStateChange})
            window.h = this.history
        }

        if(eagleEye.isCreate)
            this.eagleEye = new EagleEye(chart, eagleEye);

        if(onInitDone)
            this.chart.bind('canvasReady', () => onInitDone(this))
    }

    bindEvents(chart){
        const {onSelect, onMultiSelect, onContextMenu,
            onContextMenuDismiss, onDbClick} = this.param.events

        onSelect && chart.bind('select', onSelect)
        onMultiSelect && chart.bind('multiSelect', onMultiSelect)
        onContextMenu && chart.bind('contextMenu', onContextMenu)
        onDbClick && chart.bind('dbclick', onDbClick)
        onContextMenuDismiss && chart.bind('contextMenuDismiss', onContextMenuDismiss)
    }

    setStyle = (style) => {
        this.param = util.deepCover(this.param, {style})
        setStyle(this.renderer, this.param.style)
    }

    /**
     * 设置布局模式
     * @param layout | string 'force' 'circle' 'grid' 'hierarchy'
     */
    setLayout = (layout, opts = {}) => {
        this.layout = layout
        this.chart.stopAnimation()
        switch (layout){
            case 'circle': {
                this.chart.layout('circle', Object.assign({
                    startAngle: 0,
                    sweep: Math.PI * 2,
                    fit: false,
                }, opts))
                break
            }
            case 'grid': {
                this.chart.layout('grid', opts)
                break
            }
            case 'hierarchy': {
                this.chart.layout('hierarchy', opts)
                break
            }
            case 'force': {
                this.chart.layout('force', opts)
                break
            }
            default:
                break
        }
    }

    handleSave = util.debounce((needUpdateHistory = true, createdNodes = null) => {
        const {onSave} = this.param.events
        if(onSave) {
            const nodes = this.chart.getAllNodes().map(n => ({
                id: n.id,
                x: n.x,
                y: n.y,
                d: n.d
            }))
            const links = this.chart.getAllLinks().map(l => ({
                id: l.id,
                id1: l.id1,
                id2: l.id2,
                d: l.d
            }))
            onSave({
                nodes,
                links,
                canvas: {
                    zoom: this.chart.getZoom(),
                    pan: this.chart.getPan()
                },
                createdNodes,
            })
            if(needUpdateHistory)
                this.updateHistory()
        }
    }, 100)

    /**
     * 载入新的数据，覆盖画布原始数据
     * @param nodes:
     *      [{
     *          id: '',
     *          t: '', //节点的label
     *          imgp: '', //节点不选中时 svg 图片的url
     *          selectedImgp: '', //节点被选中时的 svg 图片的url
     *          defaultImgp: '', //所有节点都没有被选中时 svg 图片的url
     *                          //三种 svg 仅仅是颜色的不同，可以参考 ./example/build/img/colored 里面的图片
     *          x: 1,  //节点位置的横坐标，可不填
     *          y: 1,  //节点位置的纵坐标，可不填
     *          d: {}, //节点的其它数据，与渲染无关
     *      }]
     * @param links:
     *      [{
     *          id: '',
     *          id1: '', //边连接的一个节点的id
     *          id2: '', //边连接的另一个节点的id
     *          t: '', //边的label
     *      }]
     */
    loadData = (nodes, links, hasPosition, opts = {}) => {
        if(this.isUncompletedLinkExist(nodes, links))
            return

        const shouldSave = nodes.length > 0 || links.length > 0
        this.chart.resetData()
        this.chart.upsertData({
            nodeArray: nodes,
            linkArray: links,
        }, false)
        if(!hasPosition){
            this.setLayout(this.layout, {shouldNotSave: !shouldSave})
        } else {
            const {zoom, pan} = opts
            if(zoom)
                this.chart.setZoom(zoom)
            if(pan) {
                this.chart.setPanX(pan.x)
                this.chart.setPanY(pan.y)
            }
            if(!opts.notUpdateHistory){
                this.updateHistory()
            }
        }
    }

    isUncompletedLinkExist = (nodes, links) => {
        const allNodeIds = new Set( [
            ...this.chart.getAllNodes().map(n => n.id),
            ...nodes.map(n => n.id)
        ])
        for(let l of links){
            if(!allNodeIds.has(l.id1) || !allNodeIds.has(l.id2)){
                console.warn('Link ', l, ' 的节点不存在或没有导入')
                return true
            }
        }
        return false
    }

    /**
     * 向画布中追加新的数据
     * @param nodes
     * @param links
     * @param layout 新导入的数据采用的布局，可选 'grid' 和 'force'
     */
    upsertData = (nodes, links, layout = 'force' ) => {
        if(this.isUncompletedLinkExist(nodes, links))
            return
        const selectedNodeIds = this.chart.getSelectedNodes().map(n => n.id)
        this.chart.upsertData({
            nodeArray: nodes,
            linkArray: links,
        }, true)
        setTimeout(() => {
            //需要进行局部布局的节点个数为0时，不进行局部布局
            if(this.chart.getNeedLayoutNodes().length > 0)
                this.setLayout(layout, {nodeIds: selectedNodeIds, createdNodes: this.chart.getNeedLayoutNodes()})
            else
                this.handleSave(true, this.chart.getNeedLayoutNodes())
            //导入数据完成后，将所有选中的点都设为局部布局节点
            this.chart.setNeedLayoutNodes(
                this.getSelectedNodeIds()
            )
        }, 10)
    }

    /**
     * 更新 node 或者 link 里的数据
     * @param nodes: [{
     *      id: '', 必需字段
     *      t: '',
     *      ...
     * }]
     * @param links: [{
     *      id: '', 必需字段
     *      t: '',
     *      ...
     * }]
     */
    updateDatas = (nodes = [], links = []) => {
        for(let n of nodes) {
            const node = this.chart.getNode(n.id)
            if (node)
                node.updateData(n, {posFixed: true})
        }
        for(let l of links) {
            const link = this.chart.getLink(l.id)
            if (link)
                link.updateLink(l)
        }
    }

    /**
     * 导出当前画布的所有节点和边的信息
     * return {nodes, links}
     */
    dumpData = () => {
        const nodes = this.chart.getAllNodes().map(n => n.dumpData())
        const links = this.chart.getAllLinks().map(l => l.dumpData())
        const pan = this.chart.getPan()
        return {
            nodes,
            links,
            chart: {
                zoom: this.chart.getZoom(),
                x: pan.x,
                y: pan.y
            }
        }
    }

    /**
     * 删除当前选中的节点
     */
    removeData(){
        const nodeIds = this.getSelectedNodeIds()
        const linkIds = this.getSelectedLinkIds()
        this.chart.removeData({
            nodeIdArr: nodeIds,
            linkIdArr: linkIds
        })
        this.handleSave()
    }

    updateHistory = (isSelectEvent = false) => {
        if(isSelectEvent){
            const currHistory = this.history.getCurrent()
            const prevHistory = this.history.getPrevious()
            if(
                prevHistory && currHistory
                && currHistory.isSelectEvent
                && prevHistory.isSelectEvent
            ){
                //history 中最多只保存连续两次的history
                this.history.historyArr[this.history.pointer - 1] = currHistory
                this.history.replaceHistory({data: this.dumpData(), isSelectEvent})
                return
            }
        }
        this.history.updateHistory({data: this.dumpData(), isSelectEvent})
    }

    /**
     * 清空画布
     */
    clear(shouldSave = true){
        this.chart.resetData()
        if(shouldSave)
            this.handleSave()
    }

    clearHistory(){
        this.history.clearHistory()
    }

    /**
     * 设置高亮的节点和边
     * @param nodeIds
     * @param linkIds
     */
    setSelect(nodeIds = [], linkIds = []){
        this.chart.deSelectAll()
        this.chart.selectNodes(nodeIds)
        this.chart.selectLinks(linkIds)
    }
    getSelect(){
        return{
            nodeIds:this.getSelectedNodeIds,
            linkIds:this.getSelectedLinkIds
        }
    }
    /**
     * 上一步
     */
    undo(){
        const history = this.history.undo()
        if(history){
            const {nodes, links, chart} = history.data
            this.loadData(nodes, links, true, {notUpdateHistory: true})
            this.chart.setZoom(chart.zoom)
            this.chart.setPanX(chart.x)
            this.chart.setPanY(chart.y)
            this.handleSave(false)
        }
    }

    /**
     * 下一步
     */
    redo(){
        const history = this.history.redo()
        if(history){
            const {nodes, links, chart} = history.data
            this.loadData(nodes, links, true, {notUpdateHistory: true})
            this.chart.setZoom(chart.zoom)
            this.chart.setPanX(chart.x)
            this.chart.setPanY(chart.y)
            this.handleSave(false)
        }
    }

    /**
     * 设置当前鼠标状态为框选状态
     */
    boxSelect(){
        this.chart.interactor.enableBoxSelect()
    }

    /**
     * 获取当前所有被选中的节点
     */
    getSelectedNodeIds(){
        return this.chart.selectedNodeIds
    }

    /**
     * 获取当前所有被选中的线的id
     */
    getSelectedLinkIds(){
        return this.chart.selectedLinkIds
    }
}

export default Network