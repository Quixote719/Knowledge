/**
 * Created by yaojia7 on 2020/4/30.
 */
import Network from '../index';
import { getNodes } from './data/crime';

const { nodes, links } = getNodes(null, 4);

console.log(nodes)
console.log(links)
let network = null
window.onload = function() {
    network = new Network(
        document.querySelector('#network'),
        {
            //事件对象
            events:{
                //初始化后调用
                onInitDone: afterCreate,
                //触发的保存事件
                onSave: (data) => {
                    // console.log(data)
                },
                //只有选中单个时才回调，框选单个也是一样回调,  返回类型和元素 点击画布空处时元素为null
                onSelect:(obj)=>{
                    console.log(obj)
                },
                //选中多个时才回调，选中类型和元素
                onMultiSelect:(obj)=>{
                    console.log(obj)
                },
                //鼠标右键功能，点 线 画布三种 都提供x，y，
                //这个通用来说是否要触发画布单选功能，这可能需要业务配置 isContextMenuSelect ,暂时不用这个
                onContextMenu:(obj)=>{
                    console.log(obj)
                },

                /////////////////状态相关
                /**
                 * obj
                 * {    
                 *      isUndo:false,//是否上一步可用
                 *      isRedo:false,//是否下一步可用
                 *      isEmpty:true,//画布是否为空，对于清空按钮、框选按钮、布局按钮、自适应按钮的可用状态有作用
                 * }
                 */
                onStateChange:(obj)=>{
                    /*
                    {
                        isUndo:false,
                        isRedo:false,
                        isEmpty:true
                    }
                    */
                   console.log(obj)
                }
                
            }
        }
    )
};

function afterCreate(network){
    // network.setLayout('circle')
    // nodes.forEach(n => {
    //     n.x = 100 + Math.random() * 500
    //     n.y = 100 + Math.random() * 400
    // })
    //设置渲染数据，对应有个获得画布数据getData(nodes,links)
    network.loadData(nodes, links, false)
    window.network = network
    window.addEventListener('keyup', (e) => {
        const {keyCode} = e
        switch (keyCode){
            case 81:{ //q
                network.setLayout('force')
                return
            }
            case 87:{ //w
                network.setLayout('circle')
                return
            }
            case 69:{ //e
                network.setLayout('grid')
                return
            }
            case 82:{ //r
                network.setLayout('hierarchy')
                return
            }
            default:
                return
        }
    })
    //设置选中状态,切换画布时使用//对应有个获得选中状态getSelect(nodeIds,linkIds) 选中数组
    network.setSelect(nodeIds,linkIds)
    //todo 设置视角状态,切换画布时使用//对应有个获得视角状态getView(x,y,ratio)  中心点 缩放比例
    network.setView(x,y,ratio)
    //todo 设置历史状态,切换画布时使用//对应有个获得历史状态getHistory(history) 历史对象
    network.setHistory(history)
    
    
}

/*****按钮调用 */
//上一步 todo
network.undo()
//下一步 todo
network.redo()
//框选
network.boxSelect()
//布局
network.setLayout()// 'force' 'circle' 'grid' 'hierarchy'
//自适应 todo
network.selfAdap()
//重渲染。。调用loadData
//删除所选中的数据
network.removeData()

/****业务调用 */
//插入数据
network.upsertData(nodes, links)
//加载数据并清空画布。最后一个参数默认true,分为有坐标和无坐标，导入数据为false无坐标，切换历史等有坐标为true
network.loadData(nodes, links, hasPosition)
//单独清空数据
network.clear()
//重置大小,画布大小变更时调用
network.resize()
















                /*****************************************暂时移除**************** 
                //点的单击事件回调todo nodeId 当前节点对象id
                onNodeClick:(nodeId) => {
                    console.log(nodeId)
                },
                //点的双击事件回调todo nodeId 当前节点对象id
                onNodeDblClick:(nodeId) => {
                    console.log(nodeId)
                },
                //点的右键事件回调todo  三个参数方便右键菜单业务处理
                /* 
                nodeId 当前节点对象id
                nodeIds 当前选中的节点id数组
                linkIds 当前选中的边id数组
                */
                onNodeContext:(nodeId,nodeIds,linkIds) => {
                    console.log(nodeId,nodeIds,linkIds)
                },
                //边的单击事件回调todo linkId 当前边的id
                onlinkClick:(linkId) => {
                    console.log(linkId)
                },
                //边的双击事件回调todo linkId 当前边的id
                onlinkDblClick:(linkId) => {
                    console.log(linkId)
                },
                //边的右键事件回调todo linkId 当前边的id
                /*
                linkId 当前边对象id
                nodeIds 当前选中的节点id数组
                linkIds 当前选中的边id数组
                */
                onlinkContext:(linkId,nodeIds,linkIds) => {
                    console.log(linkId,nodeIds,linkIds)
                },
                //画布的点击事件回调todo，注意：没有点到node或link
                /*
                x 相对于画布左上角x
                y 相对于画布左上角y
                */
                onCanvasClick:(x,y) => {
                    console.log(x,y)
                },
                //画布的右键事件回调todo，注意：没有点到node或link
                onCanvasContext:(x,y) => {
                    console.log(x,y)
                },



                //是否上一步按钮启用todo  默认false
                onIsUndoBtn:(isUndo) => {
                    console.log(isUndo)
                },
                //是否下一步按钮启用todo  默认false
                onIsRedoBtn:(isRedo) => {
                    console.log(isRedo)
                },
                //是否框选按钮启用todo  默认false
                onIsBoxSelectBtn:(isBoxSelect) => {
                    console.log(isBoxSelect)
                },
                //是否布局按钮启用todo  默认false
                onIsLayoutBtn:(isLayout) => {
                    console.log(isLayout)
                },
                //是否自适应按钮启用todo  默认false
                onIsSelfAdapBtn:(isSelfAdap) => {
                    console.log(isSelfAdap)
                },
                //是否删除按钮启用todo  默认false
                onIsDeleteBtn:(isDelete) => {
                    console.log(isDelete)
                },
                ****************************************暂时移除*****************/



                