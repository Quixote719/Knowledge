/**
 * Created by yaojia7 on 2020/4/30.
 */
import Network from '../index';
import { getNodes } from './data/crime';

const { nodes, links } = getNodes(null, 1);

console.log(nodes.length)
window.getNodes = getNodes
let chart = null
window.onload = function() {
    chart = new Network(
        document.querySelector('#network'),
        {
            events: {
                onInitDone: afterCreate,
                onSave: (data) => {
                    console.log(data)
                },
                onSelect: (params) => {
                    console.log(params)
                },
                onMultiSelect: params => {
                    console.log('multi-selection')
                    console.log(params)
                },
                onContextMenu: (params) => {
                    console.log(params)
                },
                onDbClick: (nodeId) => {
                    if (nodeId) {
                        const {nodes, links} = getNodes(nodeId, 0)
                        chart.upsertData(nodes, links)
                    }
                }
            },
            style: {
                nodeBorderStyle:{
                    customNodeStyle: {
                        wifi: {
                            color: '#0079bb',
                            fillColor: '#00000000',
                            hover: {
                                color: '#00e0ff',
                                fillColor: '#00000000'
                            },
                            selected: {
                                color: [ //设置渐变颜色，color为数组时代表是渐变颜色
                                    {
                                        color: '#00ebff',
                                        position: 0 //position为该颜色的起始百分比
                                    },
                                    {
                                        color: '#009eff',
                                        position: 1
                                    }
                                ],
                                fillColor: [
                                    {
                                        color: '#00e1ff4d',
                                        position: 0
                                    },
                                    {
                                        color: '#00a4ff4d',
                                        position: 1
                                    }
                                ],
                            },
                            connToSelected: {
                                color: [
                                    {
                                        color: '#00ebff',
                                        position: 0
                                    },
                                    {
                                        color: '#009eff',
                                        position: 1
                                    }
                                ],
                                fillColor: '#00000000'
                            },
                        }
                    }
                }
            }
        }
    )
};

function afterCreate(chart){
    // chart.setLayout('circle')
    // nodes.forEach(n => {
    //     n.x = 100 + Math.random() * 500
    //     n.y = 100 + Math.random() * 400
    // })
    chart.loadData(nodes, links, false)
    window.chart = chart

    setTimeout(() => {
       chart.setStyle({
           nodeBorderStyle: {
               customNodeStyle: {
                   person: {
                       color: '#8723ff',
                       fillColor: '#00000000',
                       hover: {
                           color: '#927aff',
                           fillColor: '#00000000'
                       },
                       selected: {
                           color: [ //设置渐变颜色，color为数组时代表是渐变颜色
                               {
                                   color: '#9488ff',
                                   position: 0 //position为该颜色的起始百分比
                               },
                               {
                                   color: '#8514ff',
                                   position: 1
                               }
                           ],
                           fillColor: [
                               {
                                   color: '#927cff4d',
                                   position: 0
                               },
                               {
                                   color: '#8622ff4d',
                                   position: 1
                               }
                           ],
                       },
                       connToSelected: {
                           color: [
                               {
                                   color: '#9488ff',
                                   position: 0
                               },
                               {
                                   color: '#8514ff',
                                   position: 1
                               }
                           ],
                           fillColor: '#00000000'
                       },
                   },
                   registration: {
                       color: '#b96400',
                       fillColor: '#00000000',
                       hover: {
                           color: '#ffc450',
                           fillColor: '#00000000'
                       },
                       selected: {
                           color: [ //设置渐变颜色，color为数组时代表是渐变颜色
                               {
                                   color: '#ffce5a',
                                   position: 0 //position为该颜色的起始百分比
                               },
                               {
                                   color: '#ff9319',
                                   position: 1
                               }
                           ],
                           fillColor: [
                               {
                                   color: '#ffc2514d',
                                   position: 0
                               },
                               {
                                   color: '#ff801d4d',
                                   position: 1
                               }
                           ],
                       },
                       connToSelected: {
                           color: [
                               {
                                   color: '#ffce5a',
                                   position: 0
                               },
                               {
                                   color: '#ff9319',
                                   position: 1
                               }
                           ],
                           fillColor: '#00000000'
                       },
                   },
               }
           }
       })
    }, 10000)
    window.addEventListener('keyup', (e) => {
        const {keyCode} = e
        switch (keyCode){
            case 81:{ //q
                chart.setLayout('force')
                return
            }
            case 87:{ //w
                chart.setLayout('circle')
                return
            }
            case 69:{ //e
                chart.setLayout('grid')
                return
            }
            case 82:{ //r
                chart.setLayout('hierarchy')
                return
            }
            default:
                return
        }
    })
}
