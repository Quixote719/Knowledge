import moment from 'moment';

let nid = 1;
let lid = 1;
let eid = 1;

const minDate = new moment().subtract(3, 'years');
const maxDate = new moment();
const duration = maxDate - minDate;

const FamilyName = '赵钱孙李周吴郑王冯陈褚卫蒋沈韩杨朱秦尤许何吕施张孔曹严华金魏陶姜戚谢邹喻柏水窦章云苏潘葛奚范彭郎鲁韦昌马苗凤花方俞任袁柳酆鲍史唐费廉岑薛雷贺倪汤滕殷罗毕郝邬安常乐于时傅皮卞齐康伍余元卜顾平黄和穆萧尹姚邵湛汪祁毛禹狄米贝明臧计伏成戴谈宋茅庞熊纪舒屈项祝董梁杜阮蓝闵席季麻强贾路娄危江童颜郭梅盛林刁钟徐邱骆高夏蔡田樊胡凌霍虞万支柯昝管卢莫经房裘缪干解应宗丁宣贲邓郁单杭洪包诸左石崔吉钮龚程嵇邢滑裴陆荣荀羊於惠甄曲家封芮羿储靳汲邴糜松井段富巫乌焦巴弓牧隗山谷车侯宓蓬全郗班仰秋仲伊宫宁仇栾暴甘钭厉戎'.split(
    ''
);

//const provinces = ['浙江', '广东', '安徽', '江西', '江苏', '山东', '福建']
const provinces = ['浙江', '新疆'];
const provinceLoc = {
    浙江: {
        sx: '118',
        ex: '123',
        sy: '27.12',
        ey: '31.31',
    },
    新疆: {
        sx: '75',
        ex: '95',
        sy: '35',
        ey: '50',
    },
};
const occupation = ['教师', '程序员'];

const RelationTypes = [
    '朋fdkfjlsdfjsldk',
    '同户',
    '邻居',
    '师生fdkfjlsdfjsldk',
    '战友',
    '同行cbelkuhfdiuh',
    '通信',
    '债务fdkfjlsdfjsldk',
    '合伙人',
    '上下级',
];

const EventTypes = ['wifi', 'inHospital', 'registration'];

const getRandomName = () => {
    const fIndex = Math.floor(Math.random() * FamilyName.length);
    const sIndex = Math.floor(Math.random() * FamilyName.length);
    return FamilyName[fIndex] + FamilyName[sIndex];
};

const getRandomRelation = () => {
    const index = Math.floor(Math.random() * RelationTypes.length);
    return RelationTypes[index];
};

const getRandomType = () => {
    const index = Math.floor(Math.random() * EventTypes.length);
    return EventTypes[index];
};

const getRandomProvince = () => {
    const index = Math.floor(Math.random() * provinces.length);
    return provinces[index];
};

const getRandomOccupation = () => {
    const index = Math.floor(Math.random() * occupation.length);
    return occupation[index];
};

const getRandomGender = () => {
    return Math.random() > 0.5 ? 'Female' : 'Male';
};

function getNodes(baseId, linkCount = 2, count = 0) {
    let nodesArr = [];
    let linksArr = [];
    if(count === 4)
        return {nodes: [], links: []}
    if (!baseId) {
        for (let i = 0; i < 1; i++) {
            const root = getPerson(nid++);
            let nodeArr = [root],
                linkArr = [];
            const { nodes, links } = getNodes(
                root.id,
                linkCount
            );
            nodeArr = nodeArr.concat(nodes);
            linkArr = linkArr.concat(links);
            nodesArr = nodesArr.concat(nodeArr);
            linksArr = linksArr.concat(linkArr);
        }
        // nodesArr.push(getPerson(nid++))
    } else {
        let temp = developViaEvent(baseId, linkCount);
        nodesArr = nodesArr.concat(temp.nodes);
        linksArr = linksArr.concat(temp.links);
        temp = developViaRelation(baseId, Math.floor(4), 0);
        // temp = developViaRelation(baseId, Math.floor(Math.random() * 4), 0);
        nodesArr = nodesArr.concat(temp.nodes);
        linksArr = linksArr.concat(temp.links);

        count++
        for(let n of temp.nodes){
            const { nodes, links } = getNodes(
                n.id,
                linkCount,
                count
            );
            nodesArr = nodesArr.concat(nodes);
            linksArr = linksArr.concat(links);
        }
    }
    return { nodes: nodesArr, links: linksArr };
}

const developViaRelation = (baseId, linkCount, eventCount) => {
    const nodes = [],
        links = [];
    for (let i = 0; i < eventCount; i++) {
        const type = getRandomType();
        nodes.push(getEvent(`event-${eid}`, type));
        links.push({
            id: `link-${baseId}-${eid}`,
            t: '',
            id1: baseId,
            id2: `event-${eid}`,
        });
        eid++;
    }

    for (let i = 0; i < linkCount; i++) {
        nodes.push(getPerson(nid++));
        links.push({
            id: 'link_' +  lid++,
            t: getRandomRelation(),
            id1: nid - 1,
            id2: baseId,
        });
    }
    return { nodes, links };
};

const developViaEvent = (baseId, count) => {
    const num = count; //1,2
    let nodesRes = [],
        linksRes = [];
    for (let i = 0; i < num; i++) {
        let { nodes, links } = _getMultiLink(
            baseId,
            count + Math.floor(2)
        );
        nodesRes = nodesRes.concat(nodes);
        linksRes = linksRes.concat(links);
    }
    return { nodes: nodesRes, links: linksRes };
};

const _getMultiLink = (baseId, linkCount) => {
    const nodes = [];
    const links = [];
    const isNodeNeeded = Math.random() < 0.3
    const node = getPerson(nid++);
    if(isNodeNeeded)
        nodes.push(node);
    for (let i = 0; i < linkCount; i++) {
        const type = getRandomType();
        nodes.push(getEvent(`event-${eid}`, type));
        links.push({
            id: `link-${baseId}-${eid}`,
            t: '',
            id1: baseId,
            id2: `event-${eid}`,
        });
        if(isNodeNeeded) {
            links.push({
                id: `link-${node.id}-${eid}`,
                t: '',
                id1: node.id,
                id2: `event-${eid}`,
            });
        }
        eid++;
    }
    return { nodes, links };
};

const getPerson = id => {
    const province = getRandomProvince();
    const impg = 'build/img/colored/person_connToSelected.svg'
    return {
        id: id++,
        imgp: impg,
        t: getRandomName(),
        type: 'person',
        // s: 'circle-image',
        d: {
            type: 'person',
            province,
            time: Math.floor(minDate + duration * Math.random()),
            gender: getRandomGender(),
            occupation: getRandomOccupation(),
        },
    };
};

const getEvent = (id, type) => {
    const impg = 'build/img/colored/event_connToSelected.svg'
    return {
        id,
        imgp: impg,
        t: type,
        s: 'icon-square',
        type,
        d: {
            type,
            time: Math.floor(minDate + duration * Math.random()),
        },
    };
};

export { getNodes };
