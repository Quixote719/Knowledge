import Augments from '../augment';
export const shortestPathTo = (chart, sid, tid) => {
    const source = chart.getNode(sid);
    const target = chart.getNode(tid);
    if (!source) {
        throw new Error(`找不到id为${sid}的点`);
    }
    if (!target) {
        throw new Error(`找不到id为${tid}的点`);
    }
    const res = Augments.dijkstra(chart, { root: source });
    return res.pathTo(target.id);
};
export const resizeByDegreeness = (chart, fn, animate = true, animOpts = {}) => {
    const d = Augments.degreeCentralityNormalized(chart, {});
    const nodes = chart.getVisibleNodes();
    const changes = [];
    fn = typeof fn === 'function' ? fn : (n) => Math.max(n * 70, 25);
    chart.getVisibleNodes().forEach((n) => {
        changes.push({
            r: fn(d.degree(n), d.maxDegree, d.minDegree),
        });
    });
    if (animate) {
        chart.animateByFn(() => {
            chart.animate(nodes, changes, animOpts);
        });
    }
    else {
        nodes.forEach((node, index) => {
            node.r = changes[index].r;
        });
    }
    return chart;
};
export const resizeByCloseness = (chart, fn, animate = true, animOpts = {}) => {
    const d = Augments.closenessCentralityNormalized(chart, {});
    const nodes = chart.getVisibleNodes();
    const changes = [];
    fn = typeof fn === 'function' ? fn : (n) => Math.max(n * 70, 25);
    chart.getVisibleNodes().forEach((n) => {
        changes.push({
            r: fn(d.closeness(n), d.maxCloseness, d.minCloseness),
        });
    });
    if (animate) {
        chart.animateByFn(() => {
            chart.animate(nodes, changes, animOpts);
        });
    }
    else {
        nodes.forEach((node, index) => {
            node.r = changes[index].r;
        });
    }
    return chart;
};
export const resetSize = (chart, animate = true, animOpts = {}) => {
    const changes = [];
    const nodes = chart.getVisibleNodes();
    nodes.forEach((n) => {
        changes.push({ r: n.getInitialSize() });
    });
    if (animate) {
        chart.animateByFn(() => {
            chart.animate(nodes, changes, animOpts);
        });
    }
    else {
        nodes.forEach((node, index) => {
            node.r = changes[index].r;
        });
    }
    return chart;
};
export const filter = (chart, filterFn, amongVisible = false, animate = true, animOpts = {}) => {
    const { nodes, visibles } = Augments.filter(chart, filterFn, amongVisible);
    const opts = nodes.length > 0
        ? { duration: 800, fitWhileAnimation: false }
        : { duration: 100, fitWhileAnimation: false };
    Object.assign(opts, animOpts);
    if (animate) {
        return chart.animateByFn(() => {
            chart
                .animate(nodes, visibles, opts)
                .animate([chart], [{ fit: true }]);
        });
    }
    else {
        nodes.forEach((node, index) => {
            node.visible = visibles[index].visible;
        });
    }
};
