import EventEmitter from 'eventemitter3';
import AnimationCollection from '../animation/AnimationCollection';
import Collection from '../collection';
import Interactor from '../interact';
import LayoutController from '../layout';
import Renderer from '../renderer';
import util from './../util';
window.util = util
class Chart {
    onSave = () => {}
    updateHistory = () => {}

    constructor(container, opts) {
        //用户自定义覆盖参数
        if(opts.onSave)
            this.onSave = opts.onSave
        if(opts.updateHistory)
            this.updateHistory = opts.updateHistory

        this.running = true //标识画布是否正在运行
        this.hoverNodeId = null

        this.layout = (name, layoutOpts, animOpts) => {
            return this.animateByFn(
                () => this.layoutController.run(
                    name,
                    layoutOpts,
                    animOpts, 
                    () => {
                        if(!layoutOpts.shouldNotSave)
                            this.onSave(true, layoutOpts.createdNodes)
                        this.handleViewChange()
                    }
                )
            );
        };
        this.registerSyncLayout = (name, layout) => {
            return this.layoutController.registerSyncLayout(name, layout);
        };
        this.registerAsyncLayout = (name, layout) => {
            return this.layoutController.registerAsyncLayout(name, layout);
        };
        this.updatePosition = (opts, animOpts, cb) => {
            return this.animateByFn(() => this.layoutController.updatePosition(opts, animOpts, cb));
        };
        this.animate = (eles, dest, opts = {}, cb) => {
            return this.animationCollection.animate(eles, dest, opts, cb);
        };
        this.delay = (ms) => {
            return this.animationCollection.delay(ms);
        };
        /**
         * 创建异步动画。
         * 第一个参数为step函数。每一帧调用该函数一次。返回true或false标志该函数运行结束
         */
        this.animateAsync = (step, animOpts, cb) => {
            return this.animationCollection.animateAsync(step, animOpts, cb);
        };
        this.prependAnimate = (eles, dest, opts = {}, cb) => {
            return this.animationCollection.prependAnimate(eles, dest, opts, cb);
        };
        this.animateByFn = (fn) => {
            return this.animationCollection.animateByFn(fn);
        };
        this.stopAnimation = () => {
            return this.animationCollection.stop();
        };
        this.pauseAnimation = () => {
            return this.animationCollection.pause();
        };
        this.registerLayout = (...rest) => {
            return this.registerLayout.apply(this.layoutController, ...rest);
        };
        this.deSelectAll = () => {
            this.selectedNodeIds = this.selectedLinkIds = []
            this.getAllLinks().forEach(l => {
                l.selected = false
            })
            this.getAllNodes().forEach((n) => {
                n.selected = false;
                n.connToSelected = false;
            });
        };
        this.setNeedLayoutNodes = (nodeIds) => {
            const allNodes = this.getAllNodes()
            if(!nodeIds)
                allNodes.forEach(n => n.needLayout = true)
            else {
                allNodes.forEach(n => n.needLayout = false)
                this.getNodes(nodeIds).forEach(n => n.needLayout = true)
            }
        }
        this.selectedLinkIds = []
        this.selectLinks = (linkIds, needUpdateHistory = true) => {
            this.getLinks(linkIds).forEach(l => {
                if(l){
                    l.target.connToSelected = true
                    l.source.connToSelected = true
                    l.selected = true
                }
            })
            this.selectedLinkIds = this._collection.getSelectedLinks().map(l => l.id)
            if(linkIds.length > 0 && needUpdateHistory)
                this.updateHistory(true)
        }
        this.selectedNodeIds = []
        this.selectNodes = (nodeIds, needUpdateHistory = true) => {
            this.getNodes(nodeIds).forEach((n) => {
                if (n) {
                    n.neighborhood().forEach((nn) => (nn.connToSelected = true));
                    n.selected = true;
                }
            });
            this.selectedNodeIds = this._collection.getSelectedNodes().map(n => n.id)
            if(nodeIds.length > 0 && needUpdateHistory)
                this.updateHistory(true)
        };
        this.show = () => {
            this.renderer.show();
        };
        this.hide = () => {
            this.renderer.hide();
        };
        this._collection = new Collection(this);
        this._container = container;
        this._emitter = new EventEmitter();
        this.interactor = new Interactor(this);
        this.renderer = new Renderer(this);
        this.animationCollection = new AnimationCollection(this);
        this.layoutController = new LayoutController(this);
        this.option = {
            selectBoxActivateKey: 16,
            multiSelectActivateKey: 17,
            defaultSelect: true,
        };
        this.bind('pan', this._handleViewChange)
        this.bind('zoom', this._handleViewChange)
        this.bind('hover', this._handleHover)
        this.handleViewChange()
    }

    _handleViewChange = () => {
        this.onSave(false)
        this.handleViewChange()
    }

    _handleHover = (hoverNode) => {
        if(hoverNode)
            this.hoverNodeId = hoverNode.id
        else
            this.hoverNodeId = null
    }

    handleViewChange = util.debounce(() => {
        this.triggerEvent('view-change')
        this.getNeedRenderedNodes()
        this.getNeedRenderedLinks()
    }, 50)
    bind(event, fn) {
        this._emitter.on(event, fn);
    }
    triggerEvent(event, ...args) {
        try {
            this._emitter.emit(event, ...args);
        }
        catch (err) {
            console.error(err);
        }
    }
    removeListener(event, fn) {
        this._emitter.removeListener(event, fn);
    }
    getRenderer() {
        return this.renderer;
    }
    getContainer() {
        return this._container;
    }
    getAllNodes() {
        return this._collection.getAllNodes();
    }
    getAllLinks() {
        return this._collection.getAllLinks();
    }
    getInnerLinks(nodes){
        return this._collection.getInnerLinks(nodes)
    }
    needRenderedNodes = []
    getNeedRenderedNodes(reset = false){
        if(!this.renderer || reset) {
            this.needRenderedNodes = this.getVisibleNodes()
            return
        }
        const [_x0, _y0] = this.interactor.projectPosInView(0, 0)
        const [_x1, _y1] = this.interactor.projectPosInView(this.width(), this.height())
        const x0 = _x0 - 100
        const y0 = _y0 - 100
        const x1 = _x1 + 100
        const y1 = _y1 + 100
        const allNodes = this.getVisibleNodes()
        const res = []
        for(let n of allNodes){
            if(n.x >= x0 && n.x <= x1 && n.y >= y0 && n.y <= y1)
                res.push(n)
        }
        this.needRenderedNodes = res
        return this.needRenderedNodes
    }
    needRenderedLinks = []
    getNeedRenderedLinks(reset = false){
        if(reset){
            this.needRenderedLinks = this.getVisibleLinks()
            return
        }
        const res = {}
        const nodes = this.getNeedRenderedNodes()
        for(let n of nodes){
            for(let l of n.links){
                if(!res.hasOwnProperty(l.id))
                    res[l.id] = l
            }
        }
        this.needRenderedLinks = Object.values(res)
    }
    getNeedLayoutNodes(){
        return this._collection.getNeedLayoutNodes()
    }
    getSelectedNodes() {
        return this._collection.getSelectedNodes()
    }
    getVisibleNodes() {
        return this._collection.getVisibleNodes();
    }
    getLayoutNodes() {
        return this._collection.getLayoutNodes();
    }
    getVisibleLinks() {
        return this._collection.getVisibleLinks();
    }
    getLayoutLinks(nodeIds) {
        return this._collection.getLayoutLinks(nodeIds);
    }
    getNodes(nodeIdArr) {
        return this._collection.getNodes(nodeIdArr);
    }
    getLinks(linkIds) {
        return this._collection.getLinks(linkIds);
    }
    getNode(id) {
        return this._collection.getNode(id);
    }
    getLink(id) {
        return this._collection.getLink(id);
    }
    width() {
        return this.renderer.width;
    }
    height() {
        return this.renderer.height;
    }
    getPan() {
        return this.interactor.pan;
    }
    setPanX(val) {
        this.interactor.pan.x = val;
    }
    setPanY(val) {
        this.interactor.pan.y = val;
    }
    getZoom() {
        return this.interactor.zoom;
    }
    setZoom(val) {
        this.interactor.zoom = val;
    }
    getBoundingBox(nodes) {
        if (!nodes) {
            nodes = this._collection.getVisibleNodes();
        }
        return this._collection.getBoundingBox(nodes);
    }
    clonePos(nodes) {
        const pan = this.getPan();
        const nodeMap = {};
        nodes.forEach((n) => (nodeMap[n.id] = n.clonePos()));
        return {
            visibleIdArr: nodes.map((n) => n.id),
            nodes: nodeMap,
            chart: {
                panX: pan.x,
                panY: pan.y,
                zoom: this.getZoom(),
            },
        };
    }
    upsertData(data, needPartialLayout) {
        const res = this._collection.upsertData(data, needPartialLayout);
        this.handleViewChange()
        this.selectedNodeIds = this._collection.getSelectedNodes().map(n => n.id)
        this.selectedLinkIds = this._collection.getSelectedLinks().map(l => l.id)
        return res
    }
    resetData() {
        this.needRenderedNodes = []
        this.needRenderedLinks = []
        return this._collection.resetData();
    }
    removeData(data) {
        return this._collection.removeData(data);
    }
}
export default Chart;
