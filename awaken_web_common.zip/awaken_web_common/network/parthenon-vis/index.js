import Chart from './chart';
const ParthenonVis = {
    create(container, cb, onSave, updateHistory) {
        const chart = new Chart(container, {onSave, updateHistory});
        cb(null, chart);
    },
};
export default ParthenonVis;
