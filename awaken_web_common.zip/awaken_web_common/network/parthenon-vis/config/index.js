import {nodeBorderStyle, nodeTextStyle, nodeBorderAttribute,
    linkStyle, selectedBoxColor} from './style'

const paramModel = {
    style: {
        nodeBorderStyle,
        nodeBorderAttribute,
        nodeTextStyle,
        linkStyle,
        selectedBoxColor,
    },
    //历史
    history:{
        //默认创建
        isCreate:true,
        //最大历史个数
        max:10
        //内部调用的时候要给个回调方法onStateChange:(obj)=>{
        /*
        {
            isUndo:false,
            isRedo:false
        }*/
    },
    //鹰眼设定
    eagleEye:{
        //默认创建
        isCreate:true,
        //默认显示状态
        isShow:false,
        //显示的位置方位角，默认左下角lb左下 lt左上 rb右下 rt右上 left top right bottom 只会使用该用的两个
        position:{
            type:'lb',
            left:5,
            top:0,
            right:0,
            bottom:5,
        }
    },
    events: {
        onStateChange: () => {}
    },
    //运行状态
    runStatus:{
        //编辑状态，默认 必须要配置一个isDefault
        EDIT:{
            name:'EDIT',
            isDefault:true,
            //此状态下是否进行显示状态
            isShowTip:false,
            tipText:'画布可编辑...',
            //是否支持菜单
            isShowMenu:true,
            //是否支持编辑
            isEditPosition:true,
            isEditTopology:true,
            //是否平移和缩放
            isPanScale:true
        },
        
        //浏览状态
        VIEW:{
            name:'VIEW',
            isShowTip:false,
            //是否支持菜单
            isShowMenu:true,
            //是否支持编辑 主要是图形的位置及图形的拓扑关系
            isEditPosition:false,
            isEditTopology:false,
            isPanScale:true
        }
    },
}
export default paramModel
