/**
 * Created by yaojia7 on 2020/4/29.
 */
export const nodeBorderStyle = {
    color: '#ffffff',
    fillColor: '#00000000',
    hover: {
        color: '#ffffffcc',
        fillColor: '#00000000'
    },
    selected: {
        color: [ //设置渐变颜色，color为数组时代表是渐变颜色
            {
                color: '#ffffff',
                position: 0 //position为该颜色的起始百分比
            },
            {
                color: '#838383',
                position: 1
            }
        ],
        fillColor: [
            {
                color: '#eeeeee4d',
                position: 0
            },
            {
                color: '#8b8b8b4d',
                position: 1
            }
        ],
    },
    connToSelected: {
        color: [
            {
                color: '#ffffff',
                position: 0
            },
            {
                color: '#838383',
                position: 1
            }
        ],
        fillColor: '#00000000'
    }
}

export const nodeBorderAttribute = {
    w: 1,  //节点边框的宽度
    hover: {
        w: 1
    },
    selected: {
        w: 2
    },
    connToSelected: {
        w: 2
    }
}

export const nodeTextStyle = {
    textColor: '#dddddd88',
    textBgColor: '#00000000',
    selected: {
        textColor: '#ffffff'
    }
}

export const linkStyle = {
    lineColor: '#909296dd',
    //lineColor: '#3b384288',
    textColor: '#000',
    textBgColor: '#909296dd',
    lineWidth: 1,
    selected: {
        lineColor: '#eee',
        textColor: '#000',
        textBgColor: '#eee',
        lineWidth: 2
    }
}

export const selectedBoxColor = '#aaaaaa22'

//设置关系网络 SDK 渲染器的样式
export const setStyle = (renderer, style) => {
    try {
        const {border, text} = renderer.nodeTheme.renderUnitMap
        const {nodeBorderStyle, nodeTextStyle, nodeBorderAttribute,
            linkStyle, selectedBoxColor} = style

        border.updateStyle(nodeBorderStyle)
        border.updateAttribute(nodeBorderAttribute)

        text.updateStyle(nodeTextStyle)

        renderer.linkTheme = Object.assign({}, renderer.linkTheme, linkStyle)

        renderer.theme.selectBoxColor = selectedBoxColor

        return true
    } catch (e){
        console.error(e)
        return false
    }
}
