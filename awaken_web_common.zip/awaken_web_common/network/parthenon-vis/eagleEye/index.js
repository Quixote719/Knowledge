import Renderer from './../renderer/EagleEyeRenderer'
/**
 * 鹰眼
 * 1.渲染类和画布使用同一个，后期改变渲染的样式
 * 2.获得view改变消息来告知用户视野改变
 */
class EagleEye{
    constructor(chart, param){
        /*
        //默认创建
        isCreate:true,
        //默认显示状态
        isShow:true,
        //显示的位置方位角，默认左下角lb左下 lt左上 rb右下 rt右上 left top right bottom 只会使用该用的两个
        position:{
            type:'lb',
            left:5,
            top:0,
            right:0,
            bottom:5,
        }
        */
        this.chart = chart
        this.param = param
        this.initDom(chart._container)
        this.initDraw()
        if(!this.param.isShow){
            this.hide()
        }else{
            this.show()
        }
    }
    initDom = (dom) => {
        this.canvasEagleEye = document.createElement('canvas')
        this.canvasEagleEye.width = 210
        this.canvasEagleEye.height = 150
        this.canvasEagleEye.style.position = 'absolute'
        this.canvasEagleEye.style.left = '5px'
        this.canvasEagleEye.style.bottom = '5px'
        this.canvasEagleEye.style.border = '2px solid #A8A9A9'
        this.canvasEagleEye.style.zIndex = 4
        dom.appendChild(this.canvasEagleEye)
        this.canvasEagleEyeCover = document.createElement('canvas')
        this.canvasEagleEyeCover.width = 210
        this.canvasEagleEyeCover.height = 150
        this.canvasEagleEyeCover.style.position = 'absolute'
        this.canvasEagleEyeCover.style.left = '5px'
        this.canvasEagleEyeCover.style.bottom = '5px'
        this.canvasEagleEyeCover.style.border = '2px solid #A8A9A9'
        this.canvasEagleEyeCover.style.zIndex = 5
        this.canvasEagleEyeCover.addEventListener('mousedown',(e)=>{
            e.preventDefault()
        })
        this.canvasEagleEyeCover.addEventListener('mousemove',(e)=>{
            e.preventDefault()
        })
        dom.appendChild(this.canvasEagleEyeCover)
        this.overcontract = document.createElement('div')
        this.overcontract.style.width = '16px'
        this.overcontract.style.height = '16px'
        this.overcontract.style.position = 'absolute'
        this.overcontract.style.left = '202px'
        this.overcontract.style.bottom = '142px'
        this.overcontract.style.border = '0px solid #A8A9A9'
        this.overcontract.style.display = 'none'
        this.overcontract.style.cursor = 'pointer'
        this.overcontract.style.zIndex = 5
        this.overcontract.style.background = `url(${window.basename}/img/over/overcontract.gif)`
        dom.appendChild(this.overcontract)
        this.overcontract.addEventListener('mousedown',()=>{
            this.hide()
        })
        this.overexpand = document.createElement('div')
        this.overexpand.style.width = '16px'
        this.overexpand.style.height = '16px'
        this.overexpand.style.position = 'absolute'
        this.overexpand.style.left = '2px'
        this.overexpand.style.bottom = '2px'
        this.overexpand.style.border = '0px solid #A8A9A9'
        this.overexpand.style.display = 'block'
        this.overexpand.style.cursor = 'pointer'
        this.overexpand.style.zIndex = 5
        this.overexpand.style.background = `url(${window.basename}/img/over/overexpand.gif)`
        dom.appendChild(this.overexpand)
        this.overexpand.addEventListener('mousedown',()=>{
            this.show()
        })
    }
    /**
     * 初始化渲染
     */
    initDraw = () => {
        //默认开启状态下
        if(this.overexpand.style.display == 'none'){
            return
        }
        //初始化render
        this.renderer = new Renderer(this.chart, this.canvasEagleEye)
        //监听view改变事件，来触发resizeEagle，改变后判断当前是否处于显示状态
        this.chart.bind('view-change',()=>{
            if(this.overexpand.style.display == 'none'){
                this.resizeEagle(this.canvasEagleEye,this.canvasEagleEyeCover)
            }
        })
        //第一次直接出发resize，后面都是监听了
        this.resizeEagle(this.canvasEagleEye,this.canvasEagleEyeCover)
    }
    /**
     * 
     */
    resizeEagle = (canvasEagleEye,canvasEagleEyeCover) => {
        let panX = this.renderer.panX
        let panY = this.renderer.panY
        let scaleNum = this.renderer.bb.scale
        let tminX = (0 - panX) / scaleNum
        let tminY = (0 - panY) / scaleNum
        let tmaxX = (canvasEagleEye.width - panX) / scaleNum
        let tmaxY = (canvasEagleEye.height - panY) / scaleNum
        const nodes = this.renderer.chart.getVisibleNodes()
        //获得数据坐标的最小矩形
        let {minX,minY,maxX,maxY} = this.getExtent(nodes,0,0)
        //获得大画布中的实际坐标范围
        let fullStart = this.renderer.fullStart
        let fullEnd = this.renderer.fullEnd
        let innerStart = {}
        let innerEnd = {}
        let isOnlyBlack = false
        //如果大图超出了范围，则不必绘制当前空白区域
        if(fullStart.x > maxX || fullStart.y > maxY || fullEnd.x < minX || fullEnd.y < minY){
            //只绘制未覆盖区域
            isOnlyBlack = true
        }
        if(fullStart.x < minX){
            innerStart.x = tminX
        }else {
            innerStart.x = fullStart.x
        }
        if(fullStart.y < minY){
            innerStart.y = tminY
        }else {
            innerStart.y = fullStart.y
        }
        if(fullEnd.x < maxX){
            innerEnd.x = fullEnd.x
        }else {
            innerEnd.x = tmaxX
        }
        if(fullEnd.y < maxY){
            innerEnd.y = fullEnd.y
        }else {
            innerEnd.y = tmaxY
        }
        let ctxc = canvasEagleEyeCover.getContext('2d')
        this.clearCanvasDrawBack(ctxc,this.canvasEagleEyeCover.width,this.canvasEagleEyeCover.height,'rgba(255,255,255,0)')
        ctxc.setTransform(1,0,0,1,0,0)
        ctxc.scale(scaleNum,scaleNum)
        ctxc.translate(panX / scaleNum, panY / scaleNum)
        if(isOnlyBlack){
            //先绘制全部
            ctxc.fillStyle = 'rgba(155,155,155,0.3)'
            ctxc.fillRect(tminX, tminY, tmaxX - tminX, tmaxY - tminY)
        }else {
            ctxc.save()
            ctxc.fillStyle = 'rgba(155,155,155,0.3)'
            ctxc.fillRect(tminX, tminY, tmaxX - tminX, tmaxY - tminY)
            ctxc.globalCompositeOperation="destination-out"
            ctxc.fillStyle = 'yellow'
            ctxc.fillRect(
                innerStart.x,
                innerStart.y,
                innerEnd.x - innerStart.x,
                innerEnd.y - innerStart.y
            )
            ctxc.restore()
        }
    }
    show = () => {
        this.canvasEagleEye.style.display = 'block'
        this.canvasEagleEyeCover.style.display = 'block'
        this.overcontract.style.display = 'block'
        this.overexpand.style.display = 'none'
        //调用渲染
        if(this.renderer && this.renderer.show){
            this.renderer.show()
        }
    }
    hide=()=> {
        this.canvasEagleEye.style.display = 'none'
        this.canvasEagleEyeCover.style.display = 'none'
        this.overcontract.style.display = 'none'
        this.overexpand.style.display = 'block'
        //停止渲染
        if(this.renderer && this.renderer.hide){
            this.renderer.hide()
        }
    }

    /**
     * 根据左上角坐标 和节点的宽高，获得全部节点的坐标范围
     * data.position.x data.position.y
     */
    getExtent = (datas,eWidth,eHeight)=>{
        let minX,minY,maxX,maxY
        for(let i=0;i<datas.length;i++){
            let data = datas[i]
            //假定x y 都是存在的，数据需要处理掉，没有坐标则为null
            let x = data.x
            let y = data.y
            if(x==null || y==null){
                continue
            }
            if(i==0){
                minX = x
                maxX = x+eWidth
                minY = y
                maxY = y+eHeight
            }else{
                if(x<minX){
                    minX = x
                }
                if(x+eWidth>maxX){
                    maxX = x+eWidth
                }
                if(y<minY){
                    minY = y
                }
                if(y+eHeight>maxY){
                    maxY = y + eHeight
                }
            }
        }
        return {minX,minY,maxX,maxY}
    }
    /**
     * 清空画布然后绘制背景色
     * @param {*} ctx 
     * @param {*} width 
     * @param {*} height 
     * @param {*} color 
     */
    clearCanvasDrawBack = (ctx,width,height,color)=>{
        ctx.save()
        ctx.setTransform(1,0,0,1,0,0)
        ctx.clearRect(0,0,width,height)
        if(color){
            ctx.fillStyle = color
        }else{
            ctx.fillStyle = '#FFFFFF'
        }
        ctx.fillRect(0,0,width,height)
        ctx.restore()
    }
}
export default EagleEye