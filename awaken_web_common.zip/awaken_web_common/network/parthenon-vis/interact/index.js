import collideCheck from './collideCheck';
class Interactor {
    constructor(chart) {
        this.keyMap = {};
        this.chart = chart;
        this.zoom = 1;
        this.pan = {
            x: 0,
            y: 0,
        };
        this.sensitivity = 0.95;
        this.registerListeners();
    }
    registerListeners() {
        this.listenMouseEvents();
        this.listenKeyboardEvents();
    }
    removeListeners() {
        this.removeMouseEvents();
        this.removeKeyboardEvents();
    }
    //单选
    handleSelect(id) {
        if (this.chart.option.defaultSelect) {
            this.chart.deSelectAll();
            this.chart.setNeedLayoutNodes()
            if(this.chart.getNode(id)) {
                this.chart.selectNodes([id]);
                this.chart.setNeedLayoutNodes([id])
                this.chart.triggerEvent('select', {nodeId: id});
                return
            }
            if(id) {
                this.chart.selectLinks([id])
                this.chart.triggerEvent('select', {linkId: id});
                return
            }
            this.chart.triggerEvent('select', {});
        }
    }
    //框选或者 ctrl多选
    handleMultiSelect({nodeIds, linkIds = []}){
        let innerLinks = []

        if (this.chart.option.defaultSelect) {
            this.chart.deSelectAll();
            this.chart.selectNodes(nodeIds)
            this.chart.setNeedLayoutNodes(nodeIds)
            this.chart.selectLinks(linkIds)
            innerLinks = this.chart.getInnerLinks(
                this.chart.getSelectedNodes()
            )
        }
        this.chart.triggerEvent('multiSelect', {
            nodeIds: this.chart.selectedNodeIds,
            linkIds: this.chart.selectedLinkIds.length === 0
                ? innerLinks.map(l => l.id)
                : this.chart.selectedLinkIds
        });
    }
    /**
     * Mouse Events Handler
     */
    // 鼠标事件包括mousedown, mousemove, mouseup以及mousewheel
    // 鼠标事件最终可能会触发以下一系列的事件:
    // select: 选中一个或者多个元素
    // pan: 拖动画布
    // zoom: 缩放画布
    // contextmenu: 右键单击画布/画布上的元素
    // contextmenuDismiss: 左键mousedown时触发, 用于关闭contextmenu
    // pan: mousedown于空白处 -> mousemove
    // zoom: mousewheel
    // contextmenu: mousedown -> mouseup (右键down+时间间隔小于100ms+位置偏移小于50)
    // contextmenuDismiss: mousedown
    // drag: mousedown于node上 -> mousemove
    // select: 点击, mousedown -> mouseup (左键down+时间间隔小于100ms+位置偏移小于50+在点上)
    // select: shift+点击
    // 框选: ctrl + mousedown + mousemove
    // Wheel:                Zoom
    // MouseDown:            ContextMenuDismiss
    // MouseDown, MouseMove: Pan, Drag, SelectionBox
    // MouseDown, MouseUp:   ContextMenu, Select, MultiSelect
    listenMouseEvents() {
        const canvas = this.chart.getContainer();
        this.mouseListenerArr = [
            [
                'resize',
                window,
                this.chart.triggerEvent.bind(this.chart, 'update-viewport'),
            ],
            ['mousemove', window, this.mouseMoveListener.bind(this)],
            ['mouseup', window, this.mouseUpListener.bind(this)],
            ['mousedown', canvas, this.mouseDownListener.bind(this)],
            ['mousewheel', canvas, this.mouseWheelListener.bind(this)],
            ['dblclick', canvas, this.mouseDbClickListener.bind(this)],
        ];
        this.mouseListenerArr.forEach((entry) => {
            entry[1].addEventListener(entry[0], entry[2]);
        });
    }
    removeMouseEvents() {
        this.mouseListenerArr.forEach((entry) => {
            entry[1].removeEventListener(entry[0], entry[2]);
        });
    }
    mouseWheelListener(e) {
        e.stopPropagation();
        this.handleZoom(e.x, e.y, e.deltaY)
    }
    handleZoom(x, y, deltaY){
        if(this.chart.animationCollection.isPlaying())
            return
        //获取当前鼠标在Canvas上的屏幕坐标点，缩放画布时以鼠标pos为不动点
        const pos = [x - this.chart.renderer.offsetLeft, y - this.chart.renderer.offsetTop]
        // const pos = [this.chart.width() / 2, this.chart.height() / 2];
        let scale = deltaY > 0 ? this.sensitivity : 1 / this.sensitivity;
        if(this.speedUpZoom){
            if(scale  > 1)
                scale *= 3
            else
                scale /= 3
        }
        const nextZoom = this.zoom * scale
        this.pan.x += pos[0] / this.zoom - pos[0] / nextZoom;
        this.pan.y += pos[1] / this.zoom - pos[1] / nextZoom;
        this.zoom = nextZoom;
        this.chart.triggerEvent('zoom', this.zoom);
    }

    handleZoomByExtTrigger(deltaY){
        const pos = [
            this.chart.renderer.width / 2,
            this.chart.renderer.height / 2
        ]
        let scale = deltaY > 0 ? this.sensitivity * 2 : 1 / this.sensitivity / 2;
        const nextZoom = this.zoom * scale
        this.pan.x += pos[0] / this.zoom - pos[0] / nextZoom;
        this.pan.y += pos[1] / this.zoom - pos[1] / nextZoom;
        this.zoom = nextZoom;
        this.chart.triggerEvent('zoom', this.zoom);
    }

    mouseDbClickListener(e) {
        e.stopPropagation();
        this.mdOnNode = collideCheck.findNodeUnderPos(this.chart, this.mdX, this.mdY);
        // if(!this.mdOnNode){
        //     this.handleZoom(e.x, e.y, 1)
        // }
        this.chart.triggerEvent('dbclick', this.mdOnNode ? this.mdOnNode.id : null);
    }
    mouseDownListener(e) {
        e.stopPropagation();
        if(this.chart.animationCollection.isPlaying())
            return
        this.mouseOnCanvas = true;
        this.chart.triggerEvent('contextMenuDismiss', e.x, e.y);
        this.mdRClick = e.which === 3 ? true : false;
        this.mdTimer = new Date();
        // 鼠标在canvas中渲染的位置
        this.mdClientX = e.x;
        this.mdClientY = e.y;
        const pos = this.projectPosInView(e.x - this.chart.renderer.offsetLeft, e.y - this.chart.renderer.offsetTop);
        // 鼠标在view中位置, 会因为pan, zoom改变而改变
        this.mdX = pos[0];
        this.mdY = pos[1];
        this.mdSelectBoxEnabled = this.selectBoxEnabled;
        this.mmClientX = null;
        this.mmClientY = null;
        this.mdOnNode = collideCheck.findNodeUnderPos(this.chart, this.mdX, this.mdY);
        this.mdOnLink = collideCheck.findLinkUnderPos(this.chart, this.mdX, this.mdY)
    }
    mouseMoveListener(e) {
        if (!this.mouseOnCanvas) {
            const preMdOnNode = this.mdOnNode;
            // 暂时不需要hover交互，为了节省性能，关闭hover事件
            const pos = this.projectPosInView(e.x - this.chart.renderer.offsetLeft, e.y - this.chart.renderer.offsetTop);
            this.mdOnNode = collideCheck.findNodeUnderPos(this.chart, pos[0], pos[1]);
            if (this.mdOnNode && !preMdOnNode) {
                this.chart.triggerEvent('hover', this.mdOnNode);
            }
            else if (!this.mdOnNode && preMdOnNode) {
                this.chart.triggerEvent('hover', null, preMdOnNode);
            }
        }
        else {
            // 按住鼠标拖拽
            if (this.mdSelectBoxEnabled) {
                this.setupSelectionBox(e);
            }
            else if (this.mdOnNode && !this.mdOnNode.selected) {
                this.dragNode(e, [this.mdOnNode]);
            }
            else if (this.mdOnNode) {
                if(!this.multiSelectEnabled)
                    this.dragNode(e, this.chart.getSelectedNodes());
                else
                    this.dragNode(e, this.chart.getVisibleNodes().filter(n => n.selected || n.connToSelected))
            }
            else {
                this.panView(e);
            }
        }
    }
    mouseUpListener(e) {
        if (!this.mouseOnCanvas) {
            return;
        }
        this.mouseOnCanvas = false;
        e.preventDefault();
        const checkRes = this.selectionCheck(e);
        if (this.mdRClick) {
            const nodeSelection = this.chart
                .getAllNodes()
                .filter((n) => n.selected)
                .map((n) => n.id);

            const linkSelection = this.chart
                .getAllLinks()
                .filter((l) => l.selected)
                .map((l) => l.id);

            if(checkRes){
                if(checkRes.nodeId){
                    const node = this.chart.getNode(checkRes.nodeId)
                    this.chart.triggerEvent(
                        'contextMenu',
                        {
                            x: e.x - this.chart.renderer.offsetLeft,
                            y: e.y - this.chart.renderer.offsetTop,
                            nodeId: node.id,
                            nodeIds: node.selected ? nodeSelection : [node.id],
                            linkIds: node.selected ? linkSelection : []
                        });
                } else {
                    const link = this.chart.getLink(checkRes.linkId)
                    this.chart.triggerEvent(
                        'contextMenu',
                        {
                            x: e.x - this.chart.renderer.offsetLeft,
                            y: e.y - this.chart.renderer.offsetTop,
                            linkId: link.id,
                            nodeIds: link.selected ? nodeSelection : [],
                            linkIds: link.selected ? linkSelection : [link.id]
                        });
                }
            } else{
                this.chart.triggerEvent('contextMenu', {
                    x: e.x - this.chart.renderer.offsetLeft,
                    y: e.y - this.chart.renderer.offsetTop,
                    nodeIds: [],
                    linkIds: []
                });
            }
        }
        this.mdOnNode = null;
        this.mdOnLink = null
        this.selectBox = null;
    }
    selectionCheck(e) {
        const time = new Date();
        const clientX = e.x;
        const clientY = e.y;
        const isClick = testClick(this.mdClientX, this.mdClientY, this.mdTimer.getTime(), clientX, clientY, time.getTime());
        if (this.mdSelectBoxEnabled) {
            // 框选
            const nodeSelection = this.chart
                .getAllNodes()
                .filter((n) => n.selected)
                .map((n) => n.id);
            const nodes = collideCheck.findNodesInArea(this.chart, this.selectBox);
            const selection = nodes.map((n) => n.id);
            this.handleMultiSelect({nodeIds: [...nodeSelection, ...selection]});
            return
        }
        if ((this.mdOnNode || this.mdOnLink) && isClick && this.multiSelectEnabled) {
            // 多选
            const nodeSelection = this.chart
                .getAllNodes()
                .filter((n) => n.selected)
                .map((n) => n.id);
            const linkSelection = this.chart
                .getAllLinks()
                .filter(l => l.selected)
                .map(l => l.id)
            if(this.mdOnNode) {
                const nodeIndex = nodeSelection.indexOf(this.mdOnNode.id);
                if (nodeIndex === -1) {
                    nodeSelection.push(this.mdOnNode.id);
                }
                else {
                    nodeSelection.splice(nodeIndex, 1);
                }
            }
            if(this.mdOnLink){
                const linkIndex = linkSelection.indexOf(this.mdOnLink.id)
                if(linkIndex === -1){
                    linkSelection.push(this.mdOnLink.id)
                } else {
                    linkSelection.splice(linkIndex, 1)
                }
            }
            this.handleMultiSelect({nodeIds: nodeSelection, linkIds: linkSelection});
            return
        }
        if((this.mdOnNode || this.mdOnLink) && this.mdRClick && isClick){
            if(this.mdOnNode) {
                const nodeSelection = this.chart.selectedNodeIds
                if(nodeSelection.find(nid => nid === this.mdOnNode.id)){
                    return null
                }
            } else {
                const linkSelection = this.chart.selectedLinkIds
                if(linkSelection.find(lid => lid === this.mdOnLink.id)){
                    return null
                }
            }
        }
        if(this.mdOnNode && isClick){
            //右键点击时不触发选中事件
            this.handleSelect(this.mdOnNode.id);
            return {nodeId: this.mdOnNode.id}
        }
        else if (this.mdOnLink && isClick) {
            //右键点击时不触发选中事件
            this.handleSelect(this.mdOnLink.id);
            return {linkId: this.mdOnLink.id}
        }
        else if (isClick && !this.multiSelectEnabled) { //多选时点击空白区域不取消已选择的元素
            // 空选
            this.handleSelect(null);
            return null
        }
    }
    setupSelectionBox(e) {
        const pos = this.projectPosInView(e.x - this.chart.renderer.offsetLeft, e.y - this.chart.renderer.offsetTop);
        this.selectBox = [this.mdX, this.mdY, pos[0], pos[1]];
    }
    dragNode(e, nodes) {
        const self = this;
        if (this.mmClientX && this.mmClientY) {
            nodes.forEach((node) => {
                node.x = node.x - (self.mmClientX - e.x) / self.zoom;
                node.y = node.y - (self.mmClientY - e.y) / self.zoom;
            });
            this.chart.triggerEvent('drag', nodes.map((n) => n.id));
            this.chart.onSave()
        }
        this.mmClientX = e.x;
        this.mmClientY = e.y;
    }
    panView(e) {
        if (this.mmClientX && this.mmClientY) {
            this.pan.x = this.pan.x + (this.mmClientX - e.x) / this.zoom;
            this.pan.y = this.pan.y + (this.mmClientY - e.y) / this.zoom;
        }
        this.mmClientX = e.x;
        this.mmClientY = e.y;
        this.chart.triggerEvent('pan', this.pan.x, this.pan.y);
    }
    projectPosInView(x, y) {
        return [x / this.zoom + this.pan.x, y / this.zoom + this.pan.y];
    }

    /**
     * 画布坐标到屏幕坐标的映射方法
     */
    projectCanvasPosToScreen(x, y){
        return [(x - this.pan.x) * this.zoom, (y - this.pan.y) * this.zoom]
    }
    /**
     * Keyboard Events Handler
     */
    listenKeyboardEvents() {
        this.keyboardListenerArr = [
            ['visibilitychange', document, this.windowBlur.bind(this)],
            ['keydown', document, this.keyDownListener.bind(this)],
            ['keyup', document, this.keyUpListener.bind(this)],
        ];
        this.keyboardListenerArr.forEach((entry) => {
            entry[1].addEventListener(entry[0], entry[2]);
        });
    }
    removeKeyboardEvents() {
        this.keyboardListenerArr.forEach((entry) => {
            entry[1].removeEventListener(entry[0], entry[2]);
        });
    }
    keyDownListener(event) {
        this.keyMap[event.keyCode] = true;
        this.selectBoxEnabled = this.keyMap[this.chart.option.selectBoxActivateKey || 16];
        this.speedUpZoom = this.keyMap[16]
        this.multiSelectEnabled = this.keyMap[this.chart.option.multiSelectActivateKey || 17];

        if(event.code == 'KeyA' && event.ctrlKey){
            event.preventDefault()
            //节点全选
            this.handleMultiSelect({
                nodeIds: this.chart.getAllNodes().map(n => n.id),
                linkIds: this.chart.getAllLinks().map(l => l.id)
            })
        }
    }
    keyUpListener(event) {
        this.keyMap[event.keyCode] = false;
        this.selectBoxEnabled = this.keyMap[this.chart.option.selectBoxActivateKey || 16];
        this.speedUpZoom = this.keyMap[16]
        this.multiSelectEnabled = this.keyMap[this.chart.option.multiSelectActivateKey || 17];
    }
    windowBlur() {
        this.keyMap = {};
        this.selectBoxEnabled = false;
        this.speedUpZoom = false
        this.multiSelectEnabled = false;
    }
    enableBoxSelect(){
        this.selectBoxEnabled = true
        const handleMouseup = () => {
            this.selectBoxEnabled = false
            window.removeEventListener('mouseup', handleMouseup)
        }
        window.addEventListener('mouseup', handleMouseup)
    }
}
const testClick = (px, py, pt, x, y, t) => {
    return t - pt < 250 && Math.abs(x - px) < 30 && Math.abs(y - py) < 30;
};
export default Interactor;
