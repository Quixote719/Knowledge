const collideCheck = {
    findLinkUnderPos: (chart, x, y) => {
        const node = collideCheck.findNodeUnderPos(chart, x, y)
        if(node) return node
        const links = chart.getVisibleLinks()
        const linksUnderPos = []
        for(const link of links){
            const res = link.mouseInLink(x, y) //res: null | 'label' | 'line'
            if(res){
                linksUnderPos.push({
                    link,
                    collideType: res
                })
            }
        }
        if(linksUnderPos.length > 0){
            const selectedLink = linksUnderPos.find(l => l.link.selected)
            const labelSelectedLink = linksUnderPos.find(l => l.collideType === 'label')
            if(selectedLink) {
                if(linksUnderPos.length > 1)
                    return linksUnderPos.find(l => l !== selectedLink).link
                return selectedLink.link
            }
            if(labelSelectedLink)
                return labelSelectedLink.link
            return linksUnderPos[0].link
        }
        return null

    },
    findNodeUnderPos: (chart, x, y) => {
        const nodes = chart.getVisibleNodes();
        const nodesUnderPos = [];
        for (const node of nodes) {
            if (node.mouseInNode(x, y)) {
                nodesUnderPos.push(node);
            }
        }
        if (nodesUnderPos.length > 0) {
            nodesUnderPos.sort((a, b) => {
                if (a.r < b.r) {
                    return -1;
                }
                else if (a.r === b.r) {
                    return 0;
                }
                else {
                    return 1;
                }
            });
            // 总是返回所有区域内面积最小的点
            return nodesUnderPos[0];
        }
        else {
            return null;
        }
    },
    findNodesInArea: (chart, selectBox) => {
        if (!Array.isArray(selectBox) || selectBox.length !== 4) {
            return [];
        }
        const sx = Math.min(selectBox[0], selectBox[2]);
        const sy = Math.min(selectBox[1], selectBox[3]);
        const ex = Math.max(selectBox[0], selectBox[2]);
        const ey = Math.max(selectBox[1], selectBox[3]);
        const res = [];
        const nodes = chart.getVisibleNodes();
        for (const node of nodes) {
            if (node.nodeInRectangle(sx, sy, ex, ey)) {
                res.push(node);
            }
        }
        return res;
    },
};
export default collideCheck;
