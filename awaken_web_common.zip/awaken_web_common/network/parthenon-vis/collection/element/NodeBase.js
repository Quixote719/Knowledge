import util from '../../util';
import is from '../../is';
import Element from './element';
const supportAttributes = [
    'visible',
    'selected',
    'connToSelected',
    't',
    'type',
    'd',
    'x',
    'y',
    'r',
    'alpha',
    'imgp',
    'id',
    'animAlpha',
    'tScale',
];
const DEFAULT_SELECTED_IMG = `${window.basename}/img/network/default_selected.svg`
const DEFAULT_UNSELECTED_IMG = `${window.basename}/img/network/default_unselected.svg`
const DEFAULT_CONNTOSELECTED_IMG = `${window.basename}/img/network/default_connToSelected.svg`
const DEFAULT_DEFAULT_IMG = `${window.basename}/img/network/default_default.svg`
class NodeBase extends Element {
    constructor(chart, data) {
        super(chart);
        this.links = [];
        this.imgp = DEFAULT_UNSELECTED_IMG
        this.visible = true;
        this.selected = false;
        this.connToSelected = false;
        this.textWidth = null;
        this.needLayout = true; //是否需要进行布局
        this.d = {
            imgp: DEFAULT_UNSELECTED_IMG,
            selectedImgp: DEFAULT_SELECTED_IMG,
            defaultImgp: DEFAULT_DEFAULT_IMG,
            connToSelectedImgp: DEFAULT_CONNTOSELECTED_IMG
        };
        this.tScale = 1;
        this.r = 20;
        this.addLink = (link) => {
            this.links.push(link);
        };
        this.removeLink = (link) => {
            for (let i = this.links.length - 1; i >= 0; i--) {
                if (this.links[i].id === link.id) {
                    this.links.splice(i, 1);
                }
            }
        };
        this.edgesWith = (v) => {
            const res = [];
            for (const link of this.links) {
                if (link.id1 === v.id || link.id2 === v.id) {
                    res.push(link);
                }
            }
            return res;
        };
        this.neighborhoodLinks = () => {
            const res = [];
            let node = null;
            for (const link of this.links) {
                if (link.id1 === this.id) {
                    node = this.chart.getNode(link.id2);
                }
                else if (link.id2 === this.id) {
                    node = this.chart.getNode(link.id1);
                }
                if (!node || node.id === this.id) {
                    continue;
                }
                res.push(link);
            }
            return res;
        };
        this.neighborhood = () => {
            const res = [];
            let node = null;
            for (const link of this.links) {
                if (link.id1 === this.id) {
                    node = this.chart.getNode(link.id2);
                }
                else if (link.id2 === this.id) {
                    node = this.chart.getNode(link.id1);
                }
                if (!node || node.id === this.id) {
                    continue;
                }
                res.push(node);
            }
            return res;
        };
        /**
         * 布局时点的邻居.
         */
        this.layoutNeighborHood = () => {
            const res = [];
            for (const link of this.links) {
                if (link.id1 === this.id) {
                    const target = this.chart.getNode(link.id2);
                    if (target && target.visible) {
                        res.push(target);
                    }
                }
                else if (link.id2 === this.id) {
                    const target = this.chart.getNode(link.id1);
                    if (target && target.visible) {
                        res.push(target);
                    }
                }
            }
            return res;
        };
        // Calculates and returns node dimensions { x, y } based on options given
        this.layoutDimensions = (options = {}) => {
            options = util.assign({
                nodeDimensionsIncludeLabels: true,
            }, options);
            if (options.nodeDimensionsIncludeLabels) {
                const bbDim = this.boundingBox();
                return {
                    h: bbDim.h,
                    w: bbDim.w,
                };
            }
            else {
                return {
                    h: this.outerHeight(),
                    w: this.outerWidth(),
                };
            }
        };
        this.mouseInNode = (mx, my) => {
            for (const key in this.chart.renderer.nodeTheme.renderUnitMap) {
                if (this.chart.renderer.nodeTheme.renderUnitMap[key].mouseInNode(this, mx, my)) {
                    return true;
                }
            }
            return false;
        };
        this.nodeInRectangle = (sx, sy, ex, ey) => {
            for (const key in this.chart.renderer.nodeTheme.renderUnitMap) {
                if (this.chart.renderer.nodeTheme.renderUnitMap[key].nodeInRectangle(this, sx, sy, ex, ey)) {
                    return true;
                }
            }
            return false;
        };
        this.id = data.id;
        this.updateData(data);
    }

    getType(){
        return this.type
    }

    get data() {
        const res = {};
        for (const key in this.d) {
            res[key] = this.d[key];
        }
        for (const key of supportAttributes) {
            if (this[key] !== undefined) {
                res[key] = this[key];
            }
        }
        return res;
    }
    get posInitialised() {
        return (this.x !== undefined &&
            this.x !== null &&
            this.y !== undefined &&
            this.y !== null &&
            this.r !== undefined &&
            this.r !== null);
    }
    updateData(data = {}, opts = {}) {
        for (const key in data) {
            if (supportAttributes.includes(key) && key !== 'd') {
                if(key === 't')
                    this.textWidth = null
                if(
                    opts.posFixed &&
                    (key === 'x' || key === 'y')
                )
                    continue
                this[key] = data[key];
            }
            else if (key === 'd' && typeof data[key] === 'object') {
                Object.assign(this.d, data.d);
            }
            else if (key !== 'd') {
                this.d[key] = data[key];
            }
        }
    }
    dumpData(){
        const res = {}
        for(let k of supportAttributes)
            res[k] = this[k]
        return res
    }
    destroy() {
        // this.links.forEach(l => l.destroy())
        // this.links.forEach((l) => {
        //     if (l.source === this) {
        //         l.removeSource();
        //         l.attachAddNodeListener(this.id, 'source');
        //     }
        //     else if (l.target === this) {
        //         l.removeTarget();
        //         l.attachAddNodeListener(this.id, 'target');
        //     }
        // });
    }
    removed() {
        return false;
    }
    displayAlpha() {
        if (is.number(this.alpha)) {
            return this.animAlpha ? this.animAlpha * this.alpha : this.alpha;
        }
        else {
            return this.animAlpha ? this.animAlpha : 1;
        }
    }
    degree() {
        let degree = 0;
        const connectedEdges = this.links;
        for (const edge of connectedEdges) {
            if (edge.source === edge.target) {
                degree += 2;
            }
            else {
                degree += 1;
            }
        }
        return degree;
    }
    indegree() {
        const degree = 0;
        const connectedEdges = this.links;
        for (const edge of connectedEdges) {
            if (edge.target === this) {
                return 1;
            }
            else {
                return 0;
            }
        }
        return degree;
    }
    outdegree() {
        let degree = 0;
        const connectedEdges = this.links;
        for (const edge of connectedEdges) {
            if (edge.source === this) {
                degree += 1;
            }
            else {
                degree += 0;
            }
        }
        return degree;
    }
    getInitialSize() {
        return 20;
    }
    boundingBox() {
        return {
            h: this.r * 2 || 40,
            w: this.r * 2 || 40,
        };
    }
    outerWidth() {
        return this.r * 2 || 40;
    }
    outerHeight() {
        return this.r * 2 || 40;
    }
    clonePos() {
        // 主要是保留点的位置信息
        return {
            r: this.r,
            x: this.x,
            y: this.y,
        };
    }
}
export default NodeBase;
