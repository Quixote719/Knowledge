class Element {
    constructor(chart) {
        this.chart = chart;
    }
}
export default Element;
