import Element from './element';
const supportAttributes = [ 'selected', 't', 'dashed', 'arrow', 'c', 'w', 'd'];
class Link extends Element {
    constructor(chart, data) {
        super(chart);
        this.selected = false;
        this.dashed = false;
        this.arrow = false;
        this.isCurve = false
        this.d = {}
        this.tScale = 1
        this.maxFontSize = 28
        this.labelContainer = null
        this.removeSource = () => {
            if (this.source) {
                this.removeAddNodeListener(this.id1);
                this.source.removeLink(this);
                this.source = null;
            }
        };
        this.removeTarget = () => {
            if (this.target) {
                this.removeAddNodeListener(this.id2);
                this.target.removeLink(this);
                this.target = null;
            }
        };
        this.removeAddNodeListener = (id) => {
            this.chart.removeListener('addNode', this.addNodeListeners[id]);
            delete this.addNodeListeners[id];
        };
        this.addNodeListeners = {};
        this.id = data.id;
        this.id1 = data.id1;
        this.id2 = data.id2;
        this.addLinksInNode(data.id1, 'source');
        this.addLinksInNode(data.id2, 'target');
        this.updateLink(data);
    }
    get connToSelected(){
        const {source, target} = this
        return (source && source.selected) || (target && target.selected)
    }
    get data() {
        const res = {};
        for (const key in this.d) {
            res[key] = this.d[key];
        }
        for (const key of supportAttributes) {
            if (this[key] !== undefined) {
                res[key] = this[key];
            }
        }
        return res;
    }

    mouseInLink(mx, my){
        const {target, source, labelContainer} = this
        //先判断点击是否在labelContainer上
        if(labelContainer) {
            const {x, y, w, h} = labelContainer
            const dx = mx - x
            const dy = my - y
            if (dx < w && dx > 0 && dy > 0 && dy < h)
                return 'label'
        }

        if(!this.isCurve)
            return this.isPointInLine(mx, my, target, source)
        else
            return this.isPointInCurve(mx, my)
    }

    isPointInCurve(mx, my){
        const {cx, cy, r, angle1, angle2, clockWise} = this.curve
        const sAngle = (angle1 + Math.PI * 2) % (Math.PI * 2)
        const eAngle = (angle2 + Math.PI * 2) % (Math.PI * 2)
        const dx = mx - cx
        const dy = my - cy
        const distance = Math.pow(dx**2 + dy**2, .5)
        if(Math.abs(distance - r) > 2)
            return null
        let angle = Math.asin(dy / r)
        if(angle > 0 && dx < 0)
            angle = Math.PI - angle
        else if(angle < 0 && dx < 0)
            angle = -Math.PI - angle
        angle = (angle + Math.PI * 2) % (Math.PI * 2)
        return clockWise
            ? (angle > eAngle && angle < sAngle)
            : (angle < eAngle && angle > sAngle)
    }

    isPointInLine(mx, my, target, source){
        const xt = target.x
        const yt = target.y
        const xs = source.x
        const ys = source.y

        if(xt === xs && yt === ys)
            return null
        if(xt === xs)
            return Math.abs(mx - xt) <= 1 && ((my - yt) * (my - ys)) < 0 ? 'line' : null
        if(yt === ys)
            return Math.abs(my - yt) <= 1 && ((mx - xt) * (mx - xs)) < 0 ? 'line' : null

        //判断鼠标点是否在target和source两点构成的矩形之外
        //如果是，则返回false
        const sx = Math.min(xt, xs) - 1
        const sy = Math.min(yt, ys) - 1
        const w = Math.abs(xt - xs) + 1
        const h = Math.abs(yt - ys) + 1
        const dx = mx - sx
        const dy = my - sy
        if (dx > w || dx < 0 || dy < 0 || dy > h)
            return null

        //假设线段的直线公式为 Ax + By + C = 0, 根据公式 |A*mx + B*my + C| / Math.pow(A**2 + B**2, 0.5)
        //求鼠标点距离直线的距离
        const A = (ys - yt)
        const B = (xs - xt)
        const res = Math.abs(
                (ys - yt) *(mx - xt) - (xs - xt) *(my - yt)
            ) / Math.pow(A**2 + B**2, 0.5)

        return res <= 2 ? 'line' : null
    }

    updateLink(data) {
        for (const key in data) {
            if (supportAttributes.includes(key) && key !== 'd') {
                this[key] = data[key];
            }
            else if (key === 'd' && typeof data[key] === 'object') {
                Object.assign(this.d, data.d);
            }
            else if (key !== 'd') {
                this.d[key] = data[key];
            }
        }
        if (data.id1 !== this.id1) {
            this.removeSource();
            this.id1 = data.id1;
            this.addLinksInNode(data.id1, 'source');
        }
        if (data.id2 !== this.id2) {
            this.removeTarget();
            this.id2 = data.id2;
            this.addLinksInNode(data.id2, 'target');
        }
    }
    /**
     * 若存在节点，则直接添加
     * 否则则在添加节点时使用回调函数更新该节点的links。
     */
    addLinksInNode(nid, type) {
        const node = this.chart.getNode(nid);
        if (!node) {
            this.attachAddNodeListener(nid, type);
        }
        else {
            node.addLink(this);
            if (type === 'source') {
                this.source = node;
            }
            if (type === 'target') {
                this.target = node;
            }
        }
    }
    attachAddNodeListener(nid, type) {
        const cb = (node) => {
            if (type === 'source') {
                this.source = node;
            }
            if (type === 'target') {
                this.target = node;
            }
        };
        const listener = (node) => {
            // 添加连接时，其连接的点尚未添加。此时设置回调函数，当新增此点时，在link中更新source和target。
            // 更新节点后，移除此回调函数
            if (node.id === nid) {
                node.addLink(this);
                cb(node);
                this.removeAddNodeListener(nid);
            }
        };
        this.addNodeListeners[nid] = listener;
        this.chart.bind('addNode', listener);
    }
    dumpData(){
        const res = {id: this.id, id1: this.id1, id2: this.id2}
        for(let k of supportAttributes)
            res[k] = this[k]
        return res
    }
    destroy() {
        this.removeSource();
        this.removeTarget();
    }
}
export default Link;
