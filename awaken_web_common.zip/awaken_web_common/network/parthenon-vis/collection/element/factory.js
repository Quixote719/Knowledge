import Link from './Link';
import NodeBase from './NodeBase';
const fns = {
    createNode(chart, data) {
        if (!data || !data.hasOwnProperty('id')) {
            console.error('异常数据，期待含有id的数据，实际数据为', data);
        }
        data.d = data.d || {};
        /**
         * 这里感觉有些奇怪
         * RectNode和RoundNode主要是渲染上的区别，用渲染方法描述就可以区分开。
         * 因此不应该创建两种点。
         * 当初创建两种点主要是因为方形点捕获鼠标事件，以及布局都和圆形略不同。
         * 不过如何避免让用户声明两次呢？（一次渲染声明，一次点的类型声明)
         */
        return new NodeBase(chart, data);
    },
    createLink(chart, data) {
        if (!data ||
            !data.hasOwnProperty('id') ||
            !data.hasOwnProperty('id1') ||
            !data.hasOwnProperty('id2')) {
            console.error('异常数据，期待含有id, id1, id2的数据，实际数据为', data);
        }
        data.d = data.d || {};
        return new Link(chart, data);
    },
};
export default fns;
