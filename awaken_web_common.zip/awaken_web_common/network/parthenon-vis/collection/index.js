import is from '../is';
import ElementFactory from './element/factory';
class Collection {
    /**
     * @brief 管理点和线实例化的结果以及他们的原始数据
     *        提供数据增, 删, 改, 查的能力
     *
     *        初版计划提供两个数据, 一是idsSet, 用于查询某个点/线是否存在, 二是map, 用于存放点和线.
     *
     * @param chart
     * @param data
     */
    constructor(chart) {
        this.chart = chart;
        this.nodeMap = new Map();
        this.linkMap = new Map();
    }
    removeData({ nodeIdArr, linkIdArr, }) {
        nodeIdArr = nodeIdArr || [];
        linkIdArr = linkIdArr || [];
        nodeIdArr.forEach((nid) => {
            const node = this.nodeMap.get(nid)
            const connectedLinkIds = node.links.map(l => l.id)
            connectedLinkIds.forEach(lid => this.removeLink(lid))
            this.removeNode(nid)
        });
        linkIdArr.forEach((lid) => this.removeLink(lid));
        this.updateLinkAwareness();
        this.chart.triggerEvent('dataDidChange');
        this.chart.getNeedRenderedNodes()
        this.chart.getNeedRenderedLinks()
    }
    resetData() {
        this.nodeMap = new Map();
        this.linkMap = new Map();
    }
    upsertData(data, needPartialLayout) {
        const self = this;
        if (Array.isArray(data.nodeArray)) {
            const needLayoutNodeIds = []
            data.nodeArray.forEach((item) => {
                const ele = ElementFactory.createNode( self.chart, item );
                if (!self.nodeMap.has(ele.id)) {
                    if(needPartialLayout)
                        needLayoutNodeIds.push(ele.id)
                    self.nodeMap.set(ele.id, ele);
                    this.chart.triggerEvent('addNode', ele);
                }
                else {
                    // 更新节点数据
                    self.nodeMap.get(ele.id).updateData(item, {posFixed: true});
                }
            });
            if(needPartialLayout){
                this.chart.selectNodes(data.nodeArray.map(n => n.id), false)
                this.chart.setNeedLayoutNodes(needLayoutNodeIds)
                this.chart.triggerEvent('multiSelect', {
                    nodeIds: this.chart.selectedNodeIds,
                    nodes: this.chart.getSelectedNodes(),
                    linkIds: []
                });
            } else {
                this.chart.setNeedLayoutNodes()
            }
        }
        if (Array.isArray(data.linkArray)) {
            data.linkArray.forEach((item) => {
                const ele = ElementFactory.createLink(self.chart, item);
                if (!is.node(ele) && !self.linkMap.has(ele.id)) {
                    self.linkMap.set(ele.id, ele);
                }
                else {
                    self.linkMap.get(ele.id).updateLink(item);
                }
            });
        }
        this.updateLinkAwareness();
        this.chart.triggerEvent('dataDidChange');
    }
    isVisible(node) {
        if (!node) {
            return false;
        }
        if (!node.visible) {
            return false;
        }
        return true;
    }
    getAllNodes() {
        const res = [];
        for (const entry of this.nodeMap.entries()) {
            res.push(entry[1]);
        }
        return res;
    }
    getAllLinks() {
        const res = [];
        for (const entry of this.linkMap.entries()) {
            const link = entry[1];
            res.push(link);
        }
        return res;
    }
    /**
     * 可见的点
     */
    getVisibleNodes() {
        const res = [];
        for (const entry of this.nodeMap.entries()) {
            const node = entry[1];
            if (this.isVisible(node)) {
                res.push(node);
            }
        }
        return res;
    }
    /**
     * 可见的连接
     */
    getVisibleLinks() {
        const res = [];
        for (const entry of this.linkMap.entries()) {
            const link = entry[1];
            const source = this.nodeMap.get(link.id1);
            const target = this.nodeMap.get(link.id2);
            if (this.isVisible(source) && this.isVisible(target)) {
                res.push(link);
            }
        }
        return res;
    }
    /**
     * 直接用于布局的点
     */
    getLayoutNodes() {
        const res = [];
        for (const entry of this.nodeMap.entries()) {
            const node = entry[1];
            if (node.visible) {
                res.push(node);
            }
        }
        return res;
    }
    getLayoutLinks(nodeIds) {
        const res = [];
        for (const entry of this.linkMap.entries()) {
            const link = entry[1];
            const source = this.nodeMap.get(link.id1);
            const target = this.nodeMap.get(link.id2);
            const nodeInRange = nodeIds
                ? nodeIds.includes(link.id1) && nodeIds.includes(link.id2)
                : true;
            if (source.visible && target.visible && nodeInRange) {
                res.push(link);
            }
        }
        return res;
    }
    getNodes(nodeIds = []) {
        const res = [];
        nodeIds.forEach((id) => res.push(this.nodeMap.get(id)));
        return res;
    }
    getNeedLayoutNodes(){
        return this.getVisibleNodes().filter(n => n.needLayout)
    }
    getSelectedNodes() {
        return this.getVisibleNodes().filter((n) => n.selected);
    }
    getSelectedLinks(){
        return this.getVisibleLinks().filter(l => l.selected)
    }
    getLinks(linkIds) {
        const res = [];
        linkIds.forEach((id) => res.push(this.linkMap.get(id)));
        return res;
    }
    getNode(id) {
        return this.nodeMap.get(id);
    }
    getLink(id) {
        return this.linkMap.get(id);
    }

    //获取目标节点之间的连线
    getInnerLinks(nodes = []){
        const nodeIds = {}
        const links = this.getAllLinks()
        const res = []

        for(let n of nodes){
            nodeIds[n.id] = true
        }
        for(let l of links){
            if(nodeIds.hasOwnProperty(l.id1) && nodeIds.hasOwnProperty(l.id2))
                res.push(l)
        }

        return res
    }

    getBoundingBox(nodes) {
        nodes = nodes ? nodes : this.getVisibleNodes();
        let sx = Infinity;
        let sy = Infinity;
        let ex = -Infinity;
        let ey = -Infinity;
        for (const node of nodes) {
            const nodeBBox = node.boundingBox();
            if (node.x !== undefined && node.y !== undefined) {
                sx = Math.min(sx, node.x - nodeBBox.w);
                sy = Math.min(sy, node.y - nodeBBox.h);
                ex = Math.max(ex, node.x + nodeBBox.w);
                ey = Math.max(ey, node.y + nodeBBox.h);
            }
        }
        return {
            sx,
            sy,
            w: ex - sx,
            h: ey - sy,
        };
    }
    /**
     * 更新线段的位置
     * 首先判断同样的起点和终点有没有大于一条线段. 有的话将这些线段错开
     */
    updateLinkAwareness() {
        const linkStatMap = this.buildLinkStatMap();
        for (const key in linkStatMap) {
            if (linkStatMap[key].length > 1) {
                this.reorderLines(linkStatMap[key]);
                const len = linkStatMap[key].length;
                linkStatMap[key].forEach((l, index) => {
                    l.dupTotal = len;
                    l.dupIndex = index + 1;
                });
            }
            else {
                const l = linkStatMap[key][0];
                l.dupTotal = 1;
                l.dupIndex = 1;
            }
        }
    }
    reorderLines(lines) {
        // 首先将同一方向的线段排在一块
        lines.sort((l1, l2) => {
            if (l1.id1 > l2.id1) {
                return 1;
            }
            else if (l1.id1 === l2.id1) {
                return 0;
            }
            else {
                return -1;
            }
        });
    }
    buildLinkStatMap() {
        const res = {};
        for (const entry of this.linkMap.entries()) {
            const line = entry[1];
            const sid = line.id1;
            const tid = line.id2;
            const uid = sid > tid ? `${sid}----${tid}` : `${tid}----${sid}`;
            res[uid] = res[uid] || [];
            res[uid].push(line);
        }
        return res;
    }
    removeNode(nid) {
        if (this.nodeMap.has(nid)) {
            this.nodeMap.get(nid).destroy();
            this.nodeMap.delete(nid);
        }
    }
    removeLink(lid) {
        if (this.linkMap.has(lid)) {
            this.linkMap.get(lid).destroy();
            this.linkMap.delete(lid);
        }
    }
}
export default Collection;
