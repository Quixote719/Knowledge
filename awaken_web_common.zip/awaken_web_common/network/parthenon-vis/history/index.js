/**
 * 历史记录
 * 
 */
class History{
    constructor(param){
        /* param 结构
        {
            max:10,
            onStateChange,
        }
        */
        this.param = param
        this.historyArr = new Array()
        //指针，默认没有数据-1
        this.pointer = -1
        //最大数
        this.max = param.max
        //初始化时重设一下
        this.setBtnStatus()
    }
    /**
     * 更新历史，当前指针后面的全部覆盖掉，且重新生成一个新的在数组里
     */
    updateHistory = (obj)=>{
        const {nodes, links} = obj.data
        if(
            nodes.length === 0 &&
            links.length === 0
        ){
            const currHis = this.getCurrent()
            if(
                currHis &&
                currHis.data.nodes.length === 0 &&
                currHis.data.links.length === 0
            )
                return
        }
        //1.删除指针后面的全部数据 2.添加数据 3.判断长度是否过长 4.指针赋值至当前数组最后一个即当前添加的这一项
        if(this.historyArr.length-1 > this.pointer){
            this.historyArr.splice(this.pointer + 1,this.historyArr.length - 1 - this.pointer)
        }
        this.historyArr.push(obj)
        if(this.historyArr.length === this.max){
            //移除第一项
            this.historyArr.shift()
        }
        this.pointer = this.historyArr.length - 1
        this.setBtnStatus()
    }
    /**
     * 替换历史，当前指针后面的全部覆盖掉，且替换当前的历史
     */
    replaceHistory = (obj) => {
        if(this.historyArr.length == 0){
            return false
        }
        //1.删除指针后面的全部数据 2.替换数据 3.判断长度是否过长 4.指针赋值至当前数组最后一个即当前添加的这一项
        if(this.historyArr.length-1 > this.pointer){
            this.historyArr.splice(this.pointer + 1,this.historyArr.length - 1 - this.pointer)
        }
        this.historyArr[this.historyArr.length - 1] = obj
        this.pointer = this.historyArr.length - 1
        this.setBtnStatus()
    }
    getPrevious = () => {
        if(this.pointer > 0)
            return this.historyArr[this.pointer - 1]
        return null
    }
    /**
     * 获得当前下标的数据
     */
    getCurrent = () => {
        if(this.pointer !== -1){
            return this.historyArr[this.pointer]
        }
        return null
    }
    /**
     * 获得上一步的历史，指针跳动到对应位置，如果有updateHistory动作将删除数组的后面内容
     *
     */
    undo = () => {
        if(this.historyArr.length == 0 || this.pointer === 0){
            return false
        }
        this.pointer -= 1
        //获得指针上的位置
        let his = this.historyArr[this.pointer]
        this.setBtnStatus()
        return his
    }
    /**
     * 获得指针上的下一步的历史
     *
     */
    redo = () => {
        if(this.historyArr.length == 0 || this.pointer > this.historyArr.length - 2){
            return false
        }
        this.pointer += 1
        //获得指针上的位置
        let his = this.historyArr[this.pointer]
        this.setBtnStatus()
        return his
    }
    /**
     * 清空历史
     * 场景：切换掉当前画布时
     */
    clearHistory = () => {
        this.historyArr = []
        this.pointer = -1
        this.setBtnStatus()
    }
    /**
     * 根据当前历史数组和指针位置，判断是否可用的
     */
    setBtnStatus = () => {
        let isUndo = false
        let isRedo = false
        if(this.pointer < 1){
            isUndo = false
        }else{
            isUndo = true
        }
        if(this.pointer > (this.historyArr.length - 2)){
            isRedo = false
        }else{
            isRedo = true
        }
        this.param.onStateChange({
            isUndo,
            isRedo
        })
    }
}
export default History
