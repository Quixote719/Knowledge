const getWindow = typeof window === 'undefined' ? null : window; // tslint-disable-line no-undef
export default getWindow;
