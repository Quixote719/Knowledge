import window from './window';
const navigator = window ? window.navigator : null;
const document = window ? window.document : null;
const typeofstr = typeof '';
const typeofobj = typeof {};
const emptyFn = () => {
    // Empty Function
};
const typeoffn = typeof emptyFn;
const typeofhtmlele = typeof HTMLElement;
const instanceStr = (obj) => {
    return obj && obj.instanceString && is.fn(obj.instanceString)
        ? obj.instanceString()
        : null;
};
const is = {
    defined(obj) {
        return obj != null; // not undefined or null
    },
    string(obj) {
        return obj != null && typeof obj === typeofstr;
    },
    fn(obj) {
        return obj != null && typeof obj === typeoffn;
    },
    array(obj) {
        return Array.isArray
            ? Array.isArray(obj)
            : obj != null && obj instanceof Array;
    },
    plainObject(obj) {
        return (obj != null &&
            typeof obj === typeofobj &&
            !is.array(obj) &&
            obj.constructor === Object);
    },
    object(obj) {
        return obj != null && typeof obj === typeofobj;
    },
    number(obj) {
        return obj != null && typeof obj === typeof 1 && !isNaN(obj);
    },
    integer(obj) {
        return is.number(obj) && Math.floor(obj) === obj;
    },
    bool(obj) {
        return obj != null && typeof obj === typeof true;
    },
    htmlElement(obj) {
        if ('undefined' === typeofhtmlele) {
            return undefined;
        }
        else {
            return null != obj && obj instanceof HTMLElement;
        }
    },
    elementOrCollection(obj) {
        return is.element(obj) || is.collection(obj);
    },
    element(obj) {
        return instanceStr(obj) === 'collection' && obj._private.single;
    },
    collection(obj) {
        return instanceStr(obj) === 'collection' && !obj._private.single;
    },
    chart(obj) {
        return instanceStr(obj) === 'chart';
    },
    node(obj) {
        return instanceStr(obj) === 'node';
    },
    core(obj) {
        return instanceStr(obj) === 'core';
    },
    style(obj) {
        return instanceStr(obj) === 'style';
    },
    stylesheet(obj) {
        return instanceStr(obj) === 'stylesheet';
    },
    event(obj) {
        return instanceStr(obj) === 'event';
    },
    thread(obj) {
        return instanceStr(obj) === 'thread';
    },
    fabric(obj) {
        return instanceStr(obj) === 'fabric';
    },
    emptyString(obj) {
        if (obj === undefined || obj === null) {
            // null is empty
            return true;
        }
        else if (obj === '' || obj.match(/^\s+$/)) {
            return true; // empty string is empty
        }
        return false; // otherwise, we don't know what we've got
    },
    nonemptyString(obj) {
        if (obj && is.string(obj) && obj !== '' && !obj.match(/^\s+$/)) {
            return true;
        }
        return false;
    },
    domElement(obj) {
        if (typeof HTMLElement === 'undefined') {
            return false; // we're not in a browser so it doesn't matter
        }
        else {
            return obj instanceof HTMLElement;
        }
    },
    boundingBox(obj) {
        return (is.plainObject(obj) &&
            is.number(obj.x1) &&
            is.number(obj.x2) &&
            is.number(obj.y1) &&
            is.number(obj.y2));
    },
    promise(obj) {
        return is.object(obj) && is.fn(obj.then);
    },
    webkit() {
        return (window &&
            (typeof webkitURL !== 'undefined' ||
                'WebkitAppearance' in document.documentElement.style));
    },
    khtml() {
        return navigator && navigator.vendor.match(/kde/i); // probably a better way to detect this...
    },
    ms() {
        return navigator && navigator.userAgent.match(/msie|trident|edge/i); // probably a better way to detect this...
    },
    windows() {
        return navigator && navigator.appVersion.match(/Win/i);
    },
    mac() {
        return navigator && navigator.appVersion.match(/Mac/i);
    },
    linux() {
        return navigator && navigator.appVersion.match(/Linux/i);
    },
    unix() {
        return navigator && navigator.appVersion.match(/X11/i);
    },
};
export default is;
