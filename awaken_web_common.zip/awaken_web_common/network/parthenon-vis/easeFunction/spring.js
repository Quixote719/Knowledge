/*! Runge-Kutta spring physics function generator. Adapted from Framer.js,
 * copyright Koen Bok. MIT License: http://en.wikipedia.org/wiki/MIT_License
 *
 * Given a tension, friction, and duration, a simulation at 60FPS will first run without a
 * defined duration in order to calculate the full path. A second pass
 * then adjusts the time delta -- using the relation between actual time and duration --
 * to calculate the path for the duration-constrained animation
 */
const generateSpringRK4 = (() => {
    const springAccelerationForState = (state) => {
        return -state.tension * state.x - state.friction * state.v;
    };
    const springEvaluateStateWithDerivative = (initialState, dt, derivative) => {
        const state = {
            friction: initialState.friction,
            tension: initialState.tension,
            v: initialState.v + derivative.dv * dt,
            x: initialState.x + derivative.dx * dt,
        };
        return { dx: state.v, dv: springAccelerationForState(state) };
    };
    const springIntegrateState = (state, dt) => {
        const a = {
            dv: springAccelerationForState(state),
            dx: state.v,
        };
        const b = springEvaluateStateWithDerivative(state, dt * 0.5, a);
        const c = springEvaluateStateWithDerivative(state, dt * 0.5, b);
        const d = springEvaluateStateWithDerivative(state, dt, c);
        const dxdt = (1.0 / 6.0) * (a.dx + 2.0 * (b.dx + c.dx) + d.dx);
        const dvdt = (1.0 / 6.0) * (a.dv + 2.0 * (b.dv + c.dv) + d.dv);
        state.x = state.x + dxdt * dt;
        state.v = state.v + dvdt * dt;
        return state;
    };
    const springRK4Factory = (tension, friction, duration) => {
        const initState = {
            friction: null,
            tension: null,
            v: 0,
            x: -1,
        };
        const path = [0];
        let timeLapsed = 0;
        const tolerance = 1 / 10000;
        const DT = 16 / 1000;
        let haveDuration;
        let dt;
        let lastState;
        tension = parseFloat(tension) || 500;
        friction = parseFloat(friction) || 20;
        duration = duration || null;
        initState.tension = tension;
        initState.friction = friction;
        haveDuration = duration !== null;
        /* Calculate the actual time it takes for this animation to complete with the provided conditions. */
        if (haveDuration) {
            /* Run the simulation without a duration. */
            timeLapsed = springRK4Factory(tension, friction);
            /* Compute the adjusted time delta. */
            dt = (timeLapsed / duration) * DT;
        }
        else {
            dt = DT;
        }
        for (;;) {
            /* Next/step function .*/
            lastState = springIntegrateState(lastState || initState, dt);
            /* Store the position. */
            path.push(1 + lastState.x);
            timeLapsed += 16;
            /* If the change threshold is reached, break. */
            if (!(Math.abs(lastState.x) > tolerance &&
                Math.abs(lastState.v) > tolerance)) {
                break;
            }
        }
        /**
         * If duration is not defined, return the actual time required for completing this animation.
         * Otherwise, return a closure that holds the computed path
         * and returns a snapshot of the position according to a given percentComplete.
         */
        return !haveDuration
            ? timeLapsed
            : (percentComplete) => {
                return path[(percentComplete * (path.length - 1)) | 0];
            };
    };
    return springRK4Factory;
})();
export default generateSpringRK4;
