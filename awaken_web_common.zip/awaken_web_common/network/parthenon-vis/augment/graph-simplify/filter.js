/**
 * 过滤接口
 */
/**
 * filterFn decides which nodes to filter in and which to filter out
 * opts: whether animation or not
 * cb: called when animation is done
 */
// const defaultOpts = {
//     animate: false,
//     scope: 'visible',
// };
const filter = (chart, filterFn, amongVisible = false) => {
    // let options = Object.assign({}, defaultOpts, opts);
    const nodes = amongVisible ? chart.getVisibleNodes() : chart.getAllNodes();
    // 找到所有不显示的点
    const hiddenToVisible = [];
    const visibleToHidden = [];
    for (const node of nodes) {
        if (node.visible === false && filterFn(node)) {
            hiddenToVisible.push(node);
        }
        else if (node.visible === true && !filterFn(node)) {
            visibleToHidden.push(node);
        }
    }
    return changeGraphAndCallback({
        hiddenToVisible,
        visibleToHidden,
    });
};
const changeGraphAndCallback = (changes) => {
    const { hiddenToVisible, visibleToHidden } = changes;
    const nodes = [];
    const visibles = [];
    // 设置变化或者动画
    if (hiddenToVisible && hiddenToVisible.length > 0) {
        for (const nodeToDisplay of hiddenToVisible) {
            nodes.push(nodeToDisplay);
            visibles.push({ visible: true });
        }
    }
    if (visibleToHidden && visibleToHidden.length > 0) {
        for (const ndoeToHide of visibleToHidden) {
            nodes.push(ndoeToHide);
            visibles.push({ visible: false });
        }
    }
    return {
        nodes,
        visibles,
    };
};
export { filter };
