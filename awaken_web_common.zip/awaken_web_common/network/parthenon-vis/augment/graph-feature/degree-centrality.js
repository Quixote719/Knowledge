import util from '../../util';
import is from '../../is';
function degreeCentralityNormalized(chart, options) {
    options = options || {};
    const directed = options.directed ? options.directed : false;
    const nodes = chart.getVisibleNodes();
    const numNodes = nodes.length;
    if (!directed) {
        const degrees = {};
        let maxDegree = 0;
        let minDegree = Infinity;
        for (let i = 0; i < numNodes; i++) {
            const node = nodes[i];
            // add current node to the current options object and call degreeCentrality
            const currDegree = degreeCentrality(util.extend({}, options, { root: node }));
            if (maxDegree < currDegree.degree) {
                maxDegree = currDegree.degree;
            }
            minDegree = Math.min(minDegree, currDegree.degree);
            degrees[node.id] = currDegree.degree;
        }
        return {
            degree(node) {
                return maxDegree === 0 ? 0 : degrees[node.id] / maxDegree;
            },
            maxDegree,
            minDegree,
        };
    }
    else {
        const inDegrees = {};
        const outDegrees = {};
        let maxInDegree = 0;
        let maxOutDegree = 0;
        for (let i = 0; i < numNodes; i++) {
            const node = nodes[i];
            // add current node to the current options object and call degreeCentrality
            const currDegree = degreeCentrality(util.extend({}, options, { root: node }));
            maxInDegree = Math.max(maxInDegree, currDegree.indegree);
            maxOutDegree = Math.max(maxOutDegree, currDegree.outdegree);
            inDegrees[node.id] = currDegree.indegree;
            outDegrees[node.id] = currDegree.outdegree;
        }
        return {
            indegree(node) {
                return maxInDegree === 0
                    ? maxInDegree
                    : inDegrees[node.id] / maxInDegree;
            },
            outdegree(node) {
                return maxOutDegree === 0
                    ? maxOutDegree
                    : outDegrees[node.id] / maxOutDegree;
            },
        };
    }
}
// Implemented from the algorithm in Opsahl's paper
// "Node centrality in weighted networks: Generalizing degree and shortest paths"
// check the heading 2 "Degree"
function degreeCentrality(options) {
    options = options || {};
    const root = options.root;
    if (!root) {
        console.warn('第一个参数应该包括root, 即度中心度的对象');
        return undefined;
    }
    let weightFn;
    // weight - optional
    if (options.weight !== null && is.fn(options.weight)) {
        weightFn = options.weight;
    }
    else {
        // If not specified, assume each edge has equal weight (1)
        weightFn = () => {
            return 1;
        };
    }
    const directed = options.directed ? options.directed : false;
    const alpha = options.alpha && is.number(options.alpha) ? options.alpha : 0;
    if (!directed) {
        const connEdges = root.links;
        const k = connEdges.length;
        let s = 0;
        // Now, sum edge weights
        for (const edge of connEdges) {
            s += weightFn(edge);
        }
        return {
            degree: Math.pow(k, 1 - alpha) * Math.pow(s, alpha),
        };
    }
    else {
        const incoming = root.links;
        const outgoing = root.links;
        const kIn = incoming.length;
        const kOut = outgoing.length;
        let sIn = 0;
        let sOut = 0;
        // Now, sum incoming edge weights
        for (const edge of incoming) {
            sIn += weightFn(edge);
        }
        // Now, sum outgoing edge weights
        for (const edge of outgoing) {
            sOut += weightFn(edge);
        }
        return {
            indegree: Math.pow(kIn, 1 - alpha) * Math.pow(sIn, alpha),
            outdegree: Math.pow(kOut, 1 - alpha) * Math.pow(sOut, alpha),
        };
    }
} // degreeCentrality
export { degreeCentrality, degreeCentralityNormalized };
