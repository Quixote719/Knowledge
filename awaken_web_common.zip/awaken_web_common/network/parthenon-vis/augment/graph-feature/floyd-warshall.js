import { getWeightFn } from './util';
// Implemented from pseudocode from wikipedia
const floydWarshall = (chart, options) => {
    options = options || {};
    const weightFn = getWeightFn(options);
    const directed = options.directed ? options.directed : false;
    const edges = chart.getVisibleLinks();
    const nodes = chart.getVisibleNodes();
    const numNodes = nodes.length;
    // mapping: node id -> position in nodes array
    const id2position = {};
    for (let i = 0; i < numNodes; i++) {
        id2position[nodes[i].id] = i;
    }
    // Initialize distance matrix
    // Initialize matrix used for path reconstruction
    // Initialize distance matrix
    const dist = [];
    initMatrix(dist, numNodes, 0, Infinity);
    // Process edges
    for (const edge of edges) {
        const sourceIndex = id2position[edge.id1];
        const targetIndex = id2position[edge.id2];
        const weight = weightFn(edge);
        // Check if already process another edge between same 2 nodes
        if (dist[sourceIndex][targetIndex] > weight) {
            dist[sourceIndex][targetIndex] = weight;
        }
    }
    // If undirected graph, process 'reversed' edges
    if (!directed) {
        for (const edge of edges) {
            const sourceIndex = id2position[edge.id2];
            const targetIndex = id2position[edge.id1];
            const weight = weightFn(edge);
            // Check if already process another edge between same 2 nodes
            if (dist[sourceIndex][targetIndex] > weight) {
                dist[sourceIndex][targetIndex] = weight;
            }
        }
    }
    // Main loop
    for (let k = 0; k < numNodes; k++) {
        for (let i = 0; i < numNodes; i++) {
            for (let j = 0; j < numNodes; j++) {
                if (dist[i][k] + dist[k][j] < dist[i][j]) {
                    dist[i][j] = dist[i][k] + dist[k][j];
                }
            }
        }
    }
    // Build result object
    const position2id = [];
    for (let i = 0; i < numNodes; i++) {
        position2id.push(nodes[i].id);
    }
    return {
        distance(from, to) {
            return dist[id2position[from.id]][id2position[to.id]];
        },
    };
}; // floydWarshall
const initMatrix = (next, rowLen, diaVal, otherVal) => {
    for (let i = 0; i < rowLen; i++) {
        const newRow = new Array(rowLen);
        for (let j = 0; j < rowLen; j++) {
            if (i === j) {
                newRow[j] = diaVal;
            }
            else {
                newRow[j] = otherVal;
            }
        }
        next.push(newRow);
    }
};
export default floydWarshall;
