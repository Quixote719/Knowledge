import Heap from 'heap';
export default (chart, options) => {
    const root = options.root;
    const weightFn = options.weight ||
        (() => {
            return 1;
        });
    const source = root;
    const dist = {};
    const prev = {};
    const knownDist = {};
    const nodes = chart.getVisibleNodes();
    const getDist = (node) => {
        return dist[node.id];
    };
    const setDist = (node, d) => {
        dist[node.id] = d;
        Q.updateItem(node);
    };
    const Q = new Heap((a, b) => {
        return getDist(a) - getDist(b);
    });
    for (const node of nodes) {
        dist[node.id] = node.id === source.id ? 0 : Infinity;
        Q.push(node);
    }
    const distBetween = (u, v) => {
        // let uvs = ( directed ? u.edgesTo(v) : u.edgesWith(v) ).intersect(edges)
        const uvs = u.edgesWith(v);
        let smallestDistance = Infinity;
        let smallestEdge;
        for (const edge of uvs) {
            const weight = weightFn(edge);
            if (weight < smallestDistance || !smallestEdge) {
                smallestDistance = weight;
                smallestEdge = edge;
            }
        }
        return {
            dist: smallestDistance,
            edge: smallestEdge,
        };
    };
    while (Q.size() > 0) {
        const u = Q.pop();
        const smalletsDist = getDist(u);
        const uid = u.id;
        knownDist[uid] = smalletsDist;
        if (smalletsDist === Infinity) {
            continue;
        }
        const neighbors = u.neighborhood();
        for (const v of neighbors) {
            const vid = v.id;
            const vDist = distBetween(u, v);
            const alt = smalletsDist + vDist.dist;
            if (alt < getDist(v)) {
                setDist(v, alt);
                prev[vid] = {
                    edge: vDist.edge,
                    node: u,
                    id: u.id,
                };
            }
        } // for
    } // while
    return {
        distanceTo(node) {
            return knownDist[node.id];
        },
        pathTo(nid) {
            const nodeIds = [];
            const linkIds = [];
            nodeIds.push(nid);
            let linkNode = prev[nid];
            if (!linkNode) {
                return null;
            }
            else {
                while (linkNode) {
                    nodeIds.push(linkNode.node.id);
                    linkIds.push(linkNode.edge.id);
                    linkNode = prev[linkNode.id];
                }
                return { linkIds, nodeIds };
            }
        },
    };
};
