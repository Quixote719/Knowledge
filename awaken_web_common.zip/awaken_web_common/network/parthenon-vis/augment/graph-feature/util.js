import is from '../../is';
export const getWeightFn = (options) => {
    // Weight function - optional
    if (options.weight != null && is.fn(options.weight)) {
        return options.weight;
    }
    else {
        // If not specified, assume each edge has equal weight (1)
        return () => {
            return 1;
        };
    }
};
