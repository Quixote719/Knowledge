import dijkstraPkg from './dijkstra';
import floydWarshall from './floyd-warshall';
function closenessCentralityNormalized(chart, options) {
    options = options || {};
    const harmonic = options.harmonic ? options.harmonic : true;
    const closenesses = {};
    let maxCloseness = 0;
    let minCloseness = Infinity;
    const nodes = chart.getVisibleNodes();
    const fw = floydWarshall(chart, {
        directed: options.directed,
        weight: options.weight,
    });
    // Compute closeness for every node and find the maximum closeness
    for (let i = 0; i < nodes.length; i++) {
        let currCloseness = 0;
        for (let j = 0; j < nodes.length; j++) {
            if (i !== j) {
                const d = fw.distance(nodes[i], nodes[j]);
                currCloseness = harmonic
                    ? currCloseness + 1 / d
                    : currCloseness + d;
            }
        }
        if (!harmonic) {
            currCloseness = 1 / currCloseness;
        }
        maxCloseness = Math.max(maxCloseness, currCloseness);
        minCloseness = Math.min(minCloseness, currCloseness);
        closenesses[nodes[i].id] = currCloseness;
    }
    return {
        closeness(node) {
            return maxCloseness === 0 ? 0 : closenesses[node.id] / maxCloseness;
        },
        maxCloseness,
        minCloseness,
    };
}
// Implemented from pseudocode from wikipedia
function closenessCentrality(chart, options) {
    options = options || {};
    if (!options.root) {
        return undefined;
    }
    const root = options.root;
    const harmonic = options.harmonic ? options.harmonic : true;
    // we need distance from the node to every other node
    const dijkstra = dijkstraPkg(chart, {
        root,
    });
    let totalDistance = 0;
    const nodes = chart.getVisibleNodes();
    for (const node of nodes) {
        if (node.id !== root.id) {
            const d = dijkstra.distanceTo(node);
            if (harmonic) {
                totalDistance += 1 / d;
            }
            else {
                totalDistance += d;
            }
        }
    }
    return harmonic ? totalDistance : 1 / totalDistance;
} // closenessCentrality
export { closenessCentrality, closenessCentralityNormalized };
