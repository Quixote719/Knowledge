import { getColorWithAlpha } from './color';
import object from 'lodash/fp/object';
const extendFn = Object.assign != null
    ? Object.assign.bind(Object)
    : (...rest) => {
        const tgt = rest[0];
        const args = rest;
        for (let i = 1; i < args.length; i++) {
            const obj = args[i];
            if (obj == null) {
                continue;
            }
            const keys = Object.keys(obj);
            for (const key of keys) {
                tgt[key] = obj[key];
            }
        }
        return tgt;
    };

/**
 * 若文字超长则删去部分文字并加上...
 * @param {string} text
 * @param {number} maxOnOneLine
 * @returns {string}
 */
const trancateText = (text, maxOnOneLine) => {
    if (text.length > maxOnOneLine) {
        return text.slice(0, maxOnOneLine - 1) + '...';
    } else {
        return text;
    }
};

const debounce = (func, delay = 100) => {
    let timer = null;
    return function(...args) {
        if(timer){
            clearTimeout(timer);
        }
        timer = setTimeout(() => {
            func(...args);
            timer = null;
        }, delay);
    };
};

/**
 * 深度覆盖 获得原始对象没有的内容，并替换原始对象里面没有的
 * original 原始对象
 * substitute 代替对象 
 */
const deepCover = (original, substitute) => {
    //使用lodash扩展
    return object.defaultsDeep(original,substitute)
};

const sum = (arr) => {
    let res = 0
    for(let n of arr){
        if(typeof n === 'number')
            res += n
    }
    return res
}

const util = {
    sum,
    assign: extendFn,
    extend: extendFn,
    deepCover,
    trancateText,
    getColorWithAlpha,
    debounce,
    /**
     * 在obj上设置getter及setter, 使得getter和setter能够直接从obj.property获取数据
     */
    defineAccessor(obj, property, key) {
        Object.defineProperty(obj, key, {
            get() {
                return this[property][key];
            },
            set(val) {
                return (this[property][key] = val);
            },
        });
    },
};

export default util;
