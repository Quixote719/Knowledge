export const getColorWithAlpha = (color, alpha) => {
    let obj = null;
    if (color.includes('rgb')) {
        obj = getRGBFromRGBStr(color);
    }
    else {
        obj = hexToRgb(color);
    }
    return `rgba(${obj.r}, ${obj.g}, ${obj.b}, ${obj.alpha * alpha})`;
};
const getRGBFromRGBStr = (rgb) => {
    const arr = rgb.replace(/[^\d,.]/g, '').split(',');
    return {
        alpha: arr.length === 4 ? parseFloat(arr[3]) : 1,
        b: parseInt(arr[2], 10),
        g: parseInt(arr[1], 10),
        r: parseInt(arr[0], 10),
    };
};
const hexToRgb = (hex) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result
        ? {
            alpha: 1,
            b: parseInt(result[3], 16),
            g: parseInt(result[2], 16),
            r: parseInt(result[1], 16),
        }
        : {
            alpha: 1,
            b: 0,
            g: 0,
            r: 0,
        };
};
