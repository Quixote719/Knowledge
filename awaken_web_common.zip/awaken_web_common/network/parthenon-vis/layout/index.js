import CircleLayout from './CircleLayout';
import ForceLayout from './force';
import GridLayout from './GridLayout';
import HierarchyLayout from './HierarchyLayout';
import { AsyncSubtreeLayoutWrapper, SyncSubtreeLayoutWrapper, } from './subtree-layout';
import { updateNodesPosition } from './updateNodesPosition';
const syncLayoutWrapper = (Layout) => {
    return (chart, layoutOpts, animOpts, cb) => {
        const opts = {fit: true}
        if(layoutOpts.nodeIds && layoutOpts.nodeIds.length > 0){
            const bb = chart.getBoundingBox(
                chart.getNodes(layoutOpts.nodeIds)
            )
            opts.fitCenter = [
                bb.sx + bb.w / 2,
                bb.sy + bb.h / 2
            ]
        }
        const res = Layout(chart, opts);
        if (res.chartPos) {
            if(!res.isGlobalLayout) {
                const opts = {
                    duration: 1500,
                    fitWhileAnimation: false
                }
                chart.animate(
                    res.nodes.concat([chart]),
                    res.posArr.concat([res.chartPos]),
                    opts,
                    cb
                );
            }
            else
                chart.animate(
                    res.nodes.concat([chart]),
                    res.posArr.concat([res.chartPos]),
                    animOpts,
                    cb
                );
        }
        else {
            let opts = null
            if(res.boundingBox || animOpts){
                opts = Object.assign({}, {boundingBox: res.boundingBox})
                if(animOpts)
                    opts = Object.assign(opts, animOpts)
            }
            chart.animate(
                res.nodes,
                res.posArr,
                opts,
                cb
            );
        }
    };
};
const asyncLayoutWrapper = (Layout) => {
    return (chart, layoutOpts, animOpts, cb) => {
        if(layoutOpts.nodeIds && layoutOpts.nodeIds.length > 0){
            const bb = chart.getBoundingBox(
                chart.getNodes(layoutOpts.nodeIds)
            )
            layoutOpts.fitCenter = [
                bb.sx + bb.w / 2,
                bb.sy + bb.h / 2
            ]
        }
        const temp = Layout(chart, layoutOpts);
        return chart.animateAsync(temp.step, animOpts, () => {
            if (typeof temp.cb === 'function') {
                temp.cb(cb);
            }
        });
    };
};
class LayoutController {
    constructor(chart) {
        this.isGlobalLayout = true
        this.registerSyncLayout = (name, layout) => {
            this.layouts = this.layouts || {};
            this.layouts[name] = syncLayoutWrapper(SyncSubtreeLayoutWrapper(layout));
        };
        this.registerAsyncLayout = (name, layout) => {
            this.layouts = this.layouts || {};
            this.layouts[name] = asyncLayoutWrapper(AsyncSubtreeLayoutWrapper(layout));
        };
        this.run = (name, layoutOpts, animOpts, cb) => {
            if (this.layouts.hasOwnProperty(name)) {
                const nodes = chart.getNeedLayoutNodes();
                const visibleNodes = chart.getVisibleNodes()
                const isGlobalLayout = nodes.length === visibleNodes.length
                this.isGlobalLayout = isGlobalLayout
                return this.layouts[name](this.chart, layoutOpts, animOpts, cb);
            }
            else {
                console.warn(`抱歉，并没有注册名字为${name}的布局`);
            }
        };
        /**
         * 给所有可见但是没有坐标的点赋予坐标位置
         * 先将这些点连接的点全部找到, 然后将其放置到其中间. 若找不到, 则放置到屏幕左上角.
         * 然后围绕着这个点找空地.
         * 然后将这些点矩阵布局放置到空地上. 所有点从屏幕中央上方开始移动.
         */
        this.updatePosition = (opts, animOpts, cb) => {
            opts = opts || {};
            const chart = this.chart;
            const { nodes, posArr } = updateNodesPosition(chart);
            const bb = chart.getBoundingBox();
            const angle = Math.random() * Math.PI * 2;
            let fisrtLayerShift = 0;
            let secondLayerShift = 0;
            const destArr = [];
            const nodesArr = [];
            nodes.forEach((n) => {
                if (opts.root && n.neighborhood().includes(opts.root)) {
                    // 第一层连接内
                    // n.x = opts.root.x
                    // n.y = opts.root.y
                    const linkLen = opts.layout === 'force' ? 200 + opts.root.r * 3 : 0;
                    fisrtLayerShift =
                        fisrtLayerShift >= 0
                            ? -fisrtLayerShift - Math.PI / 18
                            : -fisrtLayerShift;
                    destArr.push({
                        x: opts.root.x +
                            Math.cos(angle + fisrtLayerShift) * linkLen,
                        y: opts.root.y +
                            Math.sin(angle + fisrtLayerShift) * linkLen,
                    });
                    n.x = opts.root.x;
                    n.y = opts.root.y;
                    nodesArr.push(n);
                }
                else if (opts.root) {
                    // 不在第一层连接, 给予其一个初始的随机位置, 这样力导向时分离的更好
                    const linkLen = opts.layout === 'force' ? 400 + opts.root.r * 3 : 0;
                    secondLayerShift =
                        secondLayerShift >= 0
                            ? -secondLayerShift - Math.PI / 18
                            : -secondLayerShift;
                    destArr.push({
                        x: opts.root.x +
                            Math.cos(angle + secondLayerShift) * linkLen,
                        y: opts.root.y +
                            Math.sin(angle + secondLayerShift) * linkLen,
                    });
                    n.x = opts.root.x;
                    n.y = opts.root.y;
                    nodesArr.push(n);
                }
                else if (n.neighborhood().length > 0) {
                    let xSum = 0, ySum = 0, xCount = 0, yCount = 0;
                    n.neighborhood().forEach((neighbor) => {
                        if (neighbor.x !== undefined && neighbor.x !== null) {
                            xSum += neighbor.x;
                            xCount++;
                        }
                        if (neighbor.y !== undefined && neighbor.y !== null) {
                            ySum += neighbor.y;
                            yCount++;
                        }
                    });
                    if (xCount > 0 && yCount > 0) {
                        n.x = xSum / xCount;
                        n.y = ySum / yCount;
                    }
                }
                if (n.x === undefined || n.x === null) {
                    n.y = bb.sy;
                }
                if (n.y === undefined || n.y === null) {
                    n.y = bb.sy;
                }
                if (!n.r) {
                    n.r = 20;
                }
            });
            const _animOpts = Object.assign({}, { fitWhileAnimation: true }, animOpts);
            if (destArr.length > 0) {
                chart.animate(nodesArr, destArr);
            }
            if (opts.layout) {
                return chart.layout(opts.layout, opts.layoutOpts, _animOpts, cb);
            }
            else {
                return chart.animate(nodes, posArr, _animOpts, cb);
            }
        };
        this.chart = chart;
        this.registerSyncLayout('circle', new CircleLayout());
        this.registerSyncLayout('grid', new GridLayout());
        this.registerSyncLayout('hierarchy', new HierarchyLayout());
        this.registerAsyncLayout('force', new ForceLayout());
    }
}
export default LayoutController;
