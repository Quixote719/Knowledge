import util from '../util';
import math from '../math';
import SyncLayout from './SyncLayout';
import { wrapPosArrayBySort } from './util';
const defaultOptions = {
    fit: false,
};
class GridLayout extends SyncLayout {
    constructor() {
        super(...arguments);
        this.run = (chart, options) => {
            options = util.extend({}, defaultOptions, options);
            const nodes = options.nodes ? options.nodes : chart.getLayoutNodes();
            const cells = nodes.length;
            if(!options.boundingBox)
                options.boundingBox = {}
            const bb = math.makeBoundingBox(Object.assign({
                x1: 0,
                y1: 0,
                w: Math.ceil(Math.sqrt(cells)) * 60,
                h: Math.ceil(Math.sqrt(cells)) * 60,
            }, options.boundingBox));
            // width/height * splits^2 = cells
            // splits 是分的行数 === row splits
            /**
             * row split * column split = cells
             * row split / column split = height / width
             * =>>> width / height * Math.pow(row split, 2) = cells
             */
            const splits = Math.sqrt((cells * bb.h) / bb.w);
            let rows = Math.round(splits);
            let cols = Math.round((bb.w / bb.h) * splits);
            const oRows = options.rows;
            const oCols = options.columns;
            const small = (val) => {
                if (val === undefined) {
                    return Math.min(rows, cols);
                }
                else {
                    const min = Math.min(rows, cols);
                    if (min === rows) {
                        rows = val;
                    }
                    else {
                        cols = val;
                    }
                }
            };
            const large = (val) => {
                if (val === undefined) {
                    return Math.max(rows, cols);
                }
                else {
                    const max = Math.max(rows, cols);
                    if (max === rows) {
                        rows = val;
                    }
                    else {
                        cols = val;
                    }
                }
            };
            // if rows or columns were set in options, use those values
            if (oRows !== undefined && oCols !== undefined) {
                rows = oRows;
                cols = oCols;
            }
            else if (oRows !== undefined && oCols === undefined) {
                rows = oRows;
                cols = Math.ceil(cells / rows);
            }
            else if (oRows === undefined && oCols !== undefined) {
                cols = oCols;
                rows = Math.ceil(cells / cols);
            }
            else if (cols * rows > cells) {
                const sm = small();
                const lg = large();
                /**
                 * 如果cols * rows要大于cells，尝试松弛一边，使最终的结果更紧凑
                 */
                if ((sm - 1) * lg >= cells) {
                    small(sm - 1);
                }
                else if ((lg - 1) * sm >= cells) {
                    large(lg - 1);
                }
            }
            else {
                /**
                 * rows或者cols不够大，尝试增大rows或者cols
                 */
                while (cols * rows < cells) {
                    const sm = small();
                    const lg = large();
                    // try to add to larger side first (adds less in multiplication)
                    if ((lg + 1) * sm >= cells) {
                        large(lg + 1);
                    }
                    else {
                        small(sm + 1);
                    }
                }
            }
            const cellWidth = bb.w / cols;
            const cellHeight = bb.h / rows;
            // to keep track of current cell position
            let row = 0;
            let col = 0;
            const moveToNextCell = () => {
                col++;
                if (col >= cols) {
                    col = 0;
                    row++;
                }
            };
            // get a cache of all the manual positions
            const getPos = () => {
                let x, y;
                x = col * cellWidth + cellWidth / 2 + bb.x1;
                y = row * cellHeight + cellHeight / 2 + bb.y1;
                moveToNextCell();
                return { x, y };
            };
            let res = [];
            nodes.forEach(() => {
                const pos = getPos();
                res.push({
                    x: pos.x,
                    y: pos.y,
                });
            });
            if (options.sort) {
                res = wrapPosArrayBySort(res, nodes, options.sort);
            }
            return {
                posArr: res,
            };
        };
    }
}
export default GridLayout;
