import AsyncLayout from '../AsyncLayout';
import ForceSimulation from './ForceSimulation';
class ForceLayout extends AsyncLayout {
    constructor() {
        super(...arguments);
        this.init = (chart, opts = {}) => {
            return new ForceSimulation().init(chart, opts);
        };
    }
}
export default ForceLayout;
