/**
 * 是ForceSimulation的原始文件。拷贝自d3
 */

import LinkForce from './link';
import ManyBodyForce from './manybody';
import CollideForce from './collide';
// import CenterForce from './center';

export function x(d) {
    return d.x;
}

export function y(d) {
    return d.y;
}

var initialRadius = 10,
    initialAngle = Math.PI * (3 - Math.sqrt(5));
const MAX_INTERVAL = 2000;

export default function(chart, opts = {}) {
    let start = null;
    let nodes = opts.nodes ? opts.nodes : chart.getLayoutNodes();
    setFixedNodes(opts);
    const links = chart.getLayoutLinks(nodes.map(n => n.id));
    var simulation,
        alpha = 1,
        alphaMin = 0.001,
        alphaDecay = 1 - Math.pow(alphaMin, 1 / 300),
        alphaTarget = 0,
        velocityDecay = 0.6,
        velocityStopCount = 0,
        forces = new Map();

    forces.set(
        'link',
        new LinkForce(links)
            .strength(1)
            .iterations(10)
            .distance(l => {
                const res =
                    chart.getNode(l.id1).r * 5 + chart.getNode(l.id2).r * 5;
                return Math.min(200 + Math.pow(res, 0.75), res);
            })
    );
    forces.set(
        'collide',
        new CollideForce().radius(n => {
            const res = 1.5 * n.r;
            return res;
        })
    );
    //forces.set('manybody', new ManyBodyForce.strength(node) => Math.min(-2000, -1000 + node.links.length * 100))
    forces.set('manybody', new ManyBodyForce().strength(() => -600));
    // forces.set('center', new CenterForce().x(chart.width()/2).y(chart.height()/2))
    //forces.set('replusion', new ManyBodyForce().strength(() => -100))
    //forces.set('gravity', new ManyBodyForce().strength(() => 20))
    initializeForce(forces.get('link'));
    initializeForce(forces.get('collide'));
    initializeForce(forces.get('manybody'));
    //initializeForce(forces.get('gravity'))
    // initializeForce(forces.get('center'))

    if (nodes == null) nodes = [];

    function setFixedNodes(opts) {
        resetFixedNodes();
        if (opts.fixedNodeIds) {
            let _nodes = chart.getNodes(opts.fixedNodeIds);
            _nodes.forEach(n => {
                n.fx = n.x;
                n.fy = n.y;
            });
        }
    }

    function resetFixedNodes() {
        let _nodes = chart.getLayoutNodes();
        _nodes.forEach(n => {
            n.fx = null;
            n.fy = null;
        });
    }

    function step() {
        if (!start) start = performance.now();
        tick();
        if (alpha < alphaMin) {
            return true;
        } else {
            return false;
        }
    }

    function tick() {
        var i,
            n = nodes.length,
            node;

        alpha += (alphaTarget - alpha) * alphaDecay;

        forces.forEach(function(force) {
            force(alpha);
        });

        let velocityTotal = 0;
        for (i = 0; i < n; ++i) {
            node = nodes[i];
            const maxSpeed = 20;
            if (
                Math.abs(node.vx) > Math.abs(node.vy) &&
                Math.abs(node.vx) > maxSpeed
            ) {
                const temp = Math.abs(node.vx);
                node.vy = (node.vy * maxSpeed) / temp;
                node.vx = (node.vx * maxSpeed) / temp;
            } else if (
                Math.abs(node.vy) > Math.abs(node.vx) &&
                Math.abs(node.vy) > maxSpeed
            ) {
                const temp = Math.abs(node.vy);
                node.vx = (node.vx * maxSpeed) / temp;
                node.vy = (node.vy * maxSpeed) / temp;
            }

            velocityTotal = Math.abs(node.vx) + Math.abs(node.vy);

            if (node.fx == null) node.x += node.vx *= velocityDecay;
            else (node.x = node.fx), (node.vx = 0);
            if (node.fy == null) node.y += node.vy *= velocityDecay;
            else (node.y = node.fy), (node.vy = 0);
        }

        if (performance.now() - start > MAX_INTERVAL) alpha = 0;
        if (velocityTotal / n < 0.02) velocityStopCount++;
        else velocityStopCount = 0;

        if (velocityStopCount > 20) alpha = 0;
    }

    function initializeNodes() {
        for (var i = 0, n = nodes.length, node; i < n; ++i) {
            (node = nodes[i]), (node.index = i);
            if (isNaN(node.x) || isNaN(node.y)) {
                var radius = initialRadius * Math.sqrt(i),
                    angle = i * initialAngle;
                node.x = radius * Math.cos(angle);
                node.y = radius * Math.sin(angle);
            }
            if (isNaN(node.vx) || isNaN(node.vy)) {
                node.vx = node.vy = 0;
            }
        }
    }

    function initializeForce(force) {
        if (force.initialize) force.initialize(nodes);
        return force;
    }

    initializeNodes();

    return (simulation = {
        step: step,

        nodes: function(_) {
            return arguments.length
                ? ((nodes = _),
                initializeNodes(),
                forces.forEach(initializeForce),
                simulation)
                : nodes;
        },

        alpha: function(_) {
            return arguments.length ? ((alpha = +_), simulation) : alpha;
        },

        alphaMin: function(_) {
            return arguments.length ? ((alphaMin = +_), simulation) : alphaMin;
        },

        alphaDecay: function(_) {
            return arguments.length
                ? ((alphaDecay = +_), simulation)
                : +alphaDecay;
        },

        alphaTarget: function(_) {
            return arguments.length
                ? ((alphaTarget = +_), simulation)
                : alphaTarget;
        },

        velocityDecay: function(_) {
            return arguments.length
                ? ((velocityDecay = 1 - _), simulation)
                : 1 - velocityDecay;
        },

        force: function(name, _) {
            return arguments.length > 1
                ? (_ == null
                    ? forces.delete(name)
                    : forces.set(name, initializeForce(_)),
                simulation)
                : forces.get(name);
        },

        find: function(x, y, radius) {
            var i = 0,
                n = nodes.length,
                dx,
                dy,
                d2,
                node,
                closest;

            if (radius == null) radius = Infinity;
            else radius *= radius;

            for (i = 0; i < n; ++i) {
                node = nodes[i];
                dx = x - node.x;
                dy = y - node.y;
                d2 = dx * dx + dy * dy;
                if (d2 < radius) (closest = node), (radius = d2);
            }

            return closest;
        },
    });
}
