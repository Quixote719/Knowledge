import util from '../../util';
import _ from 'lodash'
import CollideForce from './collide';
import LinkForce from './link';
import ManyBodyForce from './manybody';
import CenterForce from './center';
import BoundingForce from './boxBounding'
const defaultOpts = {
    link: {
        strength: 1,
        iteration: 5,
        distance: 300,
        adjCoef: 1
    },
    bounding: {
        width: null,
        height: null,
        sx: 0,
        sy: 0
    },
    collide: {
        radius: (n) => {
            const res = 1.5 * n.r;
            return res;
        },
    },
    manybody: {
        strength: -1000,
    },
    center: {
        x: chart => chart.width() / 2,
        y: chart => chart.height() / 2
    }
};
const INIT_RADIUS = 20;
const INIT_ANGLE = Math.PI * (3 - Math.sqrt(5));
// const MAX_INTERVAL = 6000;
class ForceSimulation {
    constructor() {
        this.alpha = 1;
        // this.alphaMin = 0.036;
        this.alphaMin = 0.0001;
        this.start = null;
        this.nodes = [];
        this.links = [];
        this.alphaDecay = 1 - Math.pow(this.alphaMin, 1 / 300);
        this.alphaTarget = 0;
        this.velocityDecay = 1;
        // this.velocityStopCount = 0;
        this.init = (chart, opts = {}) => {
            opts = util.extend(
                {},
                _.cloneDeep(defaultOpts),
                opts
            );
            this.chart = chart;
            this.nodes = opts.nodes ? opts.nodes : chart.getLayoutNodes();
            this.links = chart.getLayoutLinks(this.nodes.map((n) => n.id));

            this.setFixedNodes(opts);
            if(this.nodes.length > 50)
                this.adjustNodesPos()

            if(this.nodes.length > 2000) {
                // this.velocityDecay = 3
                opts.manybody.strength /= 5
                opts.link.adjCoef = 3
                // opts.link.distance = 100
            } else if(this.nodes.length > 1000){
                opts.link.adjCoef = 3
            }
            else if(this.nodes.length > 100){
                opts.link.adjCoef = 2
            }
            // if(this.nodes.length > 1000) {
            //     opts.link.strength = 2
            // }
            // if(this.nodes.length > 2000) {
            //     opts.link.strength = 1
            // }
            if(this.nodes.length < 50){
                opts.link.distance = 120
                opts.link.adjCoef = 1
            }
            // console.log('links length', this.links.length)
            // console.log('nodes length', this.nodes.length)
            if(this.links.length / this.nodes.length > 3.5){
                opts.link.strength = .5
                // opts.link.distance = 300
                opts.link.adjCoef = 1
            }

            this.count = Date.now()
            if(!opts.isGlobalLayout){
                // opts.bounding.width = opts.bounding.width ||  chart.width()
                // opts.bounding.height = opts.bounding.height || chart.height()
                opts.center.x = opts.bounding.sx + opts.bounding.width / 2
                opts.center.y = opts.bounding.sy + opts.bounding.height / 2
                // opts.link.distance = 40
                opts.manybody.strength = -3000
                if(this.nodes.length < 75)
                    this.alphaDecay = 1 - Math.pow(this.alphaMin, 1 / 50);
            }
            this.forces = new Map();
            this.forces.set('link', new LinkForce(this.links)
                .strength(opts.link.strength)
                .iterations(opts.link.iteration)
                .distance(opts.link.distance)
                .adjCoef(opts.link.adjCoef));

            this.forces.set('manybody', new ManyBodyForce().strength(opts.manybody.strength))
            this.forces.set('center', new CenterForce()
                .x(typeof opts.center.x === 'function' ? opts.center.x(chart) : opts.center.x)
                .y(typeof opts.center.y === 'function' ? opts.center.y(chart) : opts.center.y)
            )

            this.forces.set('collide', new CollideForce().radius(opts.collide.radius));
            this.initializeForce(this.forces.get('collide'));

            this.initializeForce(this.forces.get('link'));
            this.initializeForce(this.forces.get('center'))
            this.initializeForce(this.forces.get('manybody'));
            if (this.nodes === null) {
                this.nodes = [];
            }
            this.initializeNodes(opts.bounding);
            return this.step;
        };
        this.adjustNodesPos = () => {
            const {nodes, links} = this
            const centerNodes = []

            // const nodeMap = {}
            // nodes.forEach(n => nodeMap[n.id] = n)
            for(let n of nodes.filter(n => !n.fx && !n.fy)){
                if(n.links.length > links.length / 9)
                    centerNodes.push(n)
            }

            if(centerNodes.length > 0) {
                const {sx, sy, w, h} = this.chart.getBoundingBox(nodes)
                let colNum = Math.floor(Math.sqrt(centerNodes.length))
                if (colNum * colNum < centerNodes.length)
                    colNum++
                const rowNum = Math.ceil(centerNodes.length / colNum)
                const gapH = w / (colNum + 1)
                const gapV = h / (rowNum + 1)

                for(let i = 0; i < centerNodes.length; ++i){
                    const m = Math.floor(i / colNum)
                    const n = i % colNum
                    const node = centerNodes[i]
                    if(w > h){
                        node.x = sx +  (n + 1) * gapH
                        node.y = sy + (m + 1) * gapV
                    } else {
                        node.x = sx + (m + 1) * gapV
                        node.y = sy + (n + 1) * gapH
                    }
                }
            }
        }
        this.setFixedNodes = (opts) => {
            this.resetFixedNodes();
            if (opts.fixedNodeIds) {
                const _nodes = this.chart.getNodes(opts.fixedNodeIds);
                _nodes.forEach((n) => {
                    n.fx = n.x;
                    n.fy = n.y;
                });
            }
        };
        this.resetFixedNodes = () => {
            const _nodes = this.chart.getLayoutNodes();
            _nodes.forEach((n) => {
                n.fx = null;
                n.fy = null;
            });
        };
        this.step = () => {
            if (!this.start) {
                this.start = performance.now();
            }
            this.tick();
            if (this.alpha < this.alphaMin) {
                console.log(Date.now() - this.count)
                return true;
            }
            else {
                return false;
            }
        };
        this.count = 0
        this.tick = () => {
            let i;
            const n = this.nodes.length;
            let node;
            this.alpha += (this.alphaTarget - this.alpha) * this.alphaDecay;
            this.forces.forEach((force) => {
                force(this.alpha);
            });
            // let velocityTotal = 0;
            for (i = 0; i < n; ++i) {
                node = this.nodes[i];
                const maxSpeed = 20;
                if (Math.abs(node.vx) > Math.abs(node.vy) &&
                    Math.abs(node.vx) > maxSpeed) {
                    const temp = Math.abs(node.vx);
                    node.vy = (node.vy * maxSpeed) / temp;
                    node.vx = (node.vx * maxSpeed) / temp;
                }
                else if (Math.abs(node.vy) > Math.abs(node.vx) &&
                    Math.abs(node.vy) > maxSpeed) {
                    const temp = Math.abs(node.vy);
                    node.vx = (node.vx * maxSpeed) / temp;
                    node.vy = (node.vy * maxSpeed) / temp;
                }
                // velocityTotal = Math.abs(node.vx) + Math.abs(node.vy);
                if (node.fx == null) {
                    node.vx *= this.velocityDecay;
                    node.x += node.vx;
                }
                else {
                    node.x = node.fx;
                    node.vx = 0;
                }
                if (node.fy == null) {
                    node.vy *= this.velocityDecay;
                    node.y += node.vy;
                }
                else {
                    node.y = node.fy;
                    node.vy = 0;
                }
            }
        };
        this.initializeNodes = (opts) => {
            for (let i = 0, n = this.nodes.length, node; i < n; ++i) {
                (node = this.nodes[i]), (node.index = i);
                if (isNaN(node.x) || isNaN(node.y)) {
                    const radius = INIT_RADIUS * Math.sqrt(i);
                    const angle = i * INIT_ANGLE;
                    node.x = radius * Math.cos(angle) + opts.sx;
                    node.y = radius * Math.sin(angle) + opts.sy;
                }
                if (isNaN(node.vx) || isNaN(node.vy)) {
                    node.vx = node.vy = 0;
                }
            }
        };
        this.initializeForce = (force) => {
            if (force.initialize) {
                force.initialize(this.nodes);
            }
            return force;
        };
    }
}
export default ForceSimulation;
