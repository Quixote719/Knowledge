import constant from './constant';
import jiggle from './jiggle';

export default function(links) {
    var id = d => d.id,
        strength = defaultStrength,
        strengths,
        distance = constant(30),
        distances,
        nodes,
        count,
        bias,
        adjCoef = 1,
        iterations = 1;

    if (links == null) links = [];

    function defaultStrength(link) {
        return 1 / Math.min(count[link.id1], count[link.id2]);
    }

    function force(alpha) {
        for (var k = 0, n = links.length; k < iterations; ++k) {
            for (var i = 0, link, source, target, x, y, l, b; i < n; ++i) {
                (link = links[i]),
                (source = link.source),
                (target = link.target);
                if(!source || !target)
                    return
                x = target.x + target.vx - source.x - source.vx || jiggle();
                y = target.y + target.vy - source.y - source.vy || jiggle();
                l = Math.sqrt(x * x + y * y); //target 到 source 的距离
                //距离大于 distance 时，l 为正，小于时为负
                l = ((l - distances[i]) / l) * alpha * strengths[i];
                if(l > 0){
                    //l为正时，代表需要缩短link的长度，
                    //为了让力导向布局整体更加紧凑，
                    //在此处给l乘以一个大于1的系数
                    // l *= adjCoef;
                }

                (x *= l), (y *= l);
                //如果 l 为正，则拉拢 target 和 source，为负则弹开 target 和 source
                const b = bias[i]
                // target.vx -= x * b * ((l > 0 && b > .5) ? adjCoef : 1);
                // target.vy -= y * b * ((l > 0 && b > .5) ? adjCoef : 1);
                // source.vx += x * (1 - b) * ((l > 0 && b < .5) ? adjCoef : 1);
                // source.vy += y * (1 - b) * ((l > 0 && b < .5) ? adjCoef : 1);
                target.vx -= x * b * ((b > .5) ? adjCoef : 1);
                target.vy -= y * b * ((b > .5) ? adjCoef : 1);
                source.vx += x * (1 - b) * ((b < .5) ? adjCoef : 1);
                source.vy += y * (1 - b) * ((b < .5) ? adjCoef : 1);
                // console.log(target.vx)
                // console.log(target.vy)
                // console.log(source.vx)
                // console.log(source.vy)
            }
        }
    }

    function initialize() {
        if (!nodes) return;

        var i,
            n = nodes.length,
            m = links.length,
            link,
            nodeById = new Map();

        nodes.forEach(node => nodeById.set(node.id, node));

        for (i = 0, count = new Array(n); i < m; ++i) {
            link = links[i];
            count[link.id1] = (count[link.id1] || 0) + 1;
            count[link.id2] = (count[link.id2] || 0) + 1;
        }

        for (i = 0, bias = new Array(m); i < m; ++i) {
            (link = links[i]),
            (bias[i] =
                    count[link.id1] / (count[link.id1] + count[link.id2]));
        }

        (strengths = new Array(m)), initializeStrength();
        (distances = new Array(m)), initializeDistance();
    }

    function initializeStrength() {
        if (!nodes) return;

        for (var i = 0, n = links.length; i < n; ++i) {
            strengths[i] = +strength(links[i], i, links);
        }
    }

    function initializeDistance() {
        if (!nodes) return;

        for (var i = 0, n = links.length; i < n; ++i) {
            distances[i] = +distance(links[i], i, links)
        }
    }

    force.initialize = function(_) {
        nodes = _;
        initialize();
    };

    force.links = function(_) {
        return arguments.length ? ((links = _), initialize(), force) : links;
    };

    force.id = function(_) {
        return arguments.length ? ((id = _), force) : id;
    };

    force.iterations = function(_) {
        return arguments.length ? ((iterations = +_), force) : iterations;
    };

    force.strength = function(_) {
        return arguments.length
            ? ((strength = typeof _ === 'function' ? _ : constant(+_)),
            initializeStrength(),
            force)
            : strength;
    };

    force.distance = function(_) {
        return arguments.length
            ? ((distance = typeof _ === 'function' ? _ : constant(+_)),
            initializeDistance(),
            force)
            : distance;
    };
    force.adjCoef = function(_){
        adjCoef = _
        return force
    }

    return force;
}
