/**
 * Created by yaojia7 on 2020/5/14.
 */
export default function(){
    let nodes = []
    let width = 500
    let height = 400
    let sx = 0
    let sy = 0
    let gradientArr = [ .2, .3, .4, 0.5, 0.65, 0.8, 0.95]

    function force(){
        const ratio = width / height
        for(let node of nodes){
            for(let g of gradientArr) {
                const top = height * (.5 - g / 2)
                const right = width * (.5 + g / 2)
                const bottom = height * (.5 + g / 2)
                const left = height * (.5 - g / 2)
                const x = node.x - sx
                const y = node.y - sy
                const overflowHorizontal = x - node.r < left || x + node.r > right
                const overflowVertical = y - node.r < top || y + node.r > bottom
                if (overflowHorizontal || overflowVertical){
                    if(overflowHorizontal)
                        node.vx *= (g * (g > .5 ? 0.75 : .5))
                    if (overflowVertical)
                        node.vy *= (g * (g > .5 ? 0.75 : .5) / ratio)
                    break
                }
            }
            // node.x = Math.max(node.r, Math.min(width - node.r, node.x))
            // console.log(node.vx, node.vy)
            // node.y = Math.max(node.r, Math.min(height - node.r, node.y))
        }
    }

    force.initialize = function(_nodes){
        nodes  = _nodes
    }

    force.width = function(_){
        return arguments.length
            ? ((width = _), force)
            : width;
    }

    force.height = function(_){
        return arguments.length
            ? ((height = _), force)
            : height;
    }

    force.sx = function(_){
        return arguments.length
            ? ((sx = _), force)
            : sx;
    }

    force.sy = function(_){
        return arguments.length
            ? ((sy = _), force)
            : sy;
    }

    return force
}
