import util from '../util';
import SyncLayout from './SyncLayout';
const defaultOpts = {
    fit: true,
    horizontalGap: 40,
    verticalGap: 140,
};
class HierarchyLayout extends SyncLayout {
    constructor() {
        super(...arguments);
        this.run = (chart, options) => {
            options = util.extend({}, defaultOpts, options);
            const nodes = options.nodes ? options.nodes : chart.getLayoutNodes();
            const links = options.links ? options.links : chart.getLayoutLinks();
            const allNodeIds = nodes.map((n) => n.id);
            const res = [];
            /**
             * 先计算出有几个相互连接的簇。然后计算这些簇占据的位置。
             * 再计算所有簇的中心几点， 然后计算每个簇中点在层级布局后的位置
             * 没有连接的点进行矩阵布局
             */
            const nodesInEachLevel = putNodesByHierarchy(nodes, links, allNodeIds, options.root);
            const tempRes = calcHierarchyPos(nodesInEachLevel, options);
            nodes.forEach((n) => {
                if (tempRes.hasOwnProperty(n.id)) {
                    res.push(tempRes[n.id]);
                }
                else {
                    res.push({
                        x: n.x,
                        y: n.y,
                    });
                }
            });
            return {
                posArr: res,
            };
        };
    }
}
/**
 * 计算层次布局中每个点的位置
 * 已知计算结果的中心位置cx, cy
 * 计算结果的horizonSize:{width, height}
 * 多个层级的簇, 每个簇中包含多行, 每行有多个点
 * clusterSizeArr是每个簇的大小
 * @param {Object} props
 */
const calcHierarchyPos = (cluster, options) => {
    const res = {};
    const sx = 0;
    const sy = 0;
    let tempY = sy;
    // 每个簇的起始位置
    let tempX = sx;
    let maxLevelWidth = -Infinity;
    cluster.forEach((nodeInOneLevel) => {
        maxLevelWidth = Math.max(maxLevelWidth, widthOfLevel(nodeInOneLevel, options));
    });
    cluster.forEach((nodeInOneLevel) => {
        const levelWidth = widthOfLevel(nodeInOneLevel, options);
        const levelHeight = heightOfLevel(nodeInOneLevel);
        // 每一行的起始位置 = 行中点- 行宽/2
        tempX += maxLevelWidth / 2 - levelWidth / 2;
        nodeInOneLevel.forEach((n) => {
            res[n.id] = {
                x: tempX + n.r,
                y: tempY + (levelHeight - 12) / 2,
            };
            tempX += n.r * 2 + options.horizontalGap;
        });
        tempX = sx;
        tempY += levelHeight + options.verticalGap;
    });
    return res;
};
/**
 * 计算某一层点的宽度
 * @param {Object} nodes
 * @param {Array} nodeIds
 * @returns {number}
 */
const widthOfLevel = (nodes, options) => {
    let width = -options.horizontalGap;
    nodes.forEach((n) => {
        width += options.horizontalGap + n.r * 2;
    });
    return width;
};
const heightOfLevel = (nodes) => {
    let height = 0;
    nodes.forEach((n) => {
        height = Math.max(height, n.r * 2);
    });
    return height;
};
/**
 * 将给定的点放到几层中, 其中第一层的点是拥有最多连接的点
 * @returns {Array}
 */
const putNodesByHierarchy = (nodes, links, allNodeIds, root) => {
    const nodeToLinkMap = getNodeToLinkMap(links);
    const res = [];
    let nodesAdded = [];
    let nodesInOneLevel;
    if (root) {
        nodesInOneLevel = [root];
    }
    else {
        nodesInOneLevel = getNodesWithMostLinks(nodes, nodeToLinkMap);
    }
    nodesInOneLevel.push(...nodes.filter(n => !nodeToLinkMap[n.id]))
    while (nodesInOneLevel.length > 0) {
        res.push(nodesInOneLevel);
        nodesAdded = nodesAdded.concat(nodesInOneLevel.map((n) => n.id));
        nodesInOneLevel = getNextLevelNodes(nodesInOneLevel, nodeToLinkMap, nodesAdded, allNodeIds);
    }
    return res;
};
/**
 * 找到下一层级的数据,
 * 先找到所有被本层级连接的点, 再剔除掉已经被添加的点
 * @param {Array} nodeIdsInOneLevel
 * @param {Object} nodeToLinkMap
 * @param {Array} nodeIdsAdded
 * @param {Object} allNodeIds 被选中的所有点
 * @returns {Array}
 */
const getNextLevelNodes = (nodesInOneLevel, nodeToLinkMap, nodesAdded, allNodeIds) => {
    const res = [];
    nodesInOneLevel.forEach((n) => {
        const links = nodeToLinkMap[n.id];
        if (!links) {
            return;
        }
        links.forEach((link) => {
            if (link.source &&
                !nodesAdded.includes(link.source.id) &&
                allNodeIds.includes(link.source.id) &&
                !res.includes(link.source)) {
                res.push(link.source);
            }
            if (link.target &&
                !nodesAdded.includes(link.target.id) &&
                allNodeIds.includes(link.target.id) &&
                !res.includes(link.target)) {
                res.push(link.target);
            }
        });
    });
    return res;
};
/**
 * 获得拥有最多连接的点作为首层的点
 * @param {Object} nodes
 * @param {Object} nodeToLinkMap
 * @returns {Array}
 */
const getNodesWithMostLinks = (nodes, nodeToLinkMap) => {
    let maxLinkCount = 0;
    let res = [];
    for (const node of nodes) {
        const id = node.id;
        const linkLen = nodeToLinkMap[id] ? nodeToLinkMap[id].length : 0;
        if (maxLinkCount < linkLen) {
            maxLinkCount = linkLen;
            res = [node];
        }
        else if (maxLinkCount === linkLen) {
            res.push(node);
        }
    }
    return res;
};
/**
 * 返回一个点到其连接的所有边的map
 * @param {Object} nodes
 * @param {Object} links
 * @returns {Object}
 */
const getNodeToLinkMap = (links) => {
    const nodeLinkMap = {};
    for (const key in links) {
        const link = links[key];
        buildNodeLinkMap(nodeLinkMap, link.id1, link);
        buildNodeLinkMap(nodeLinkMap, link.id2, link);
    }
    return nodeLinkMap;
};
/**
 * 创建node到link的map, 用于计算每个node有多少个连接
 * @param {Object} map
 * @param {string} key
 * @param {Object} link
 * @param {Object} nodes
 */
const buildNodeLinkMap = (map, key, link) => {
    if (!map.hasOwnProperty(key)) {
        map[key] = [link];
    }
    else {
        map[key].push(link);
    }
};
export default HierarchyLayout;
