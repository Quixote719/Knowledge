class AsyncLayout {
}
export default AsyncLayout;
