/**
 * 如果传入了排序函数，则需要调整节点的顺序。
 */
import {quadtree} from 'd3-quadtree'
export const wrapPosArrayBySort = (posArr, nodeArr, sort) => {
    if (nodeArr.length !== posArr.length) {
        throw new Error(`posArr和nodeArr长度应该相等, 实际长度分别为${nodeArr.length}, ${posArr.length}`);
    }
    else {
        const idToPosMap = {};
        nodeArr.forEach((n, index) => {
            idToPosMap[n.id] = posArr[index];
        });
        /**
         * 浅拷贝nodeArr数组并排序
         */
        const nodeArrCopy = nodeArr.slice();
        nodeArrCopy.sort(sort);
        const res = [];
        nodeArrCopy.forEach((n) => {
            res.push(idToPosMap[n.id]);
        });
        return res;
    }
};

function x(d){
    return d.x
}

function y(d){
    return d.y
}

/**
 * 寻找局部布局最适区域时，最适区域内未参与局部布局节点的个数上限
 */
const MAX_OVERLAY_NODE_NUM = 0
/**
 * 最适区域在单个节点周围的寻找方向
 */
const directArray = [
    [0, 0],
    [-1, 0],
    [0, -1],
    [-1, -1],
]
/**
 * 最适区域与其它节点直接的间隔距离
 * @type {number}
 */
const gap = 50

/**
 * 在画布中寻找一块区域放置 grid circle 和 hierarchy 等局部布局后的节点
 * 规则是：
 * 1. 计算所有参与局部布局的节点 nodes，布局变换之前的中心位置 originalCenter
 * 2. 按照距离 originalCenter 由近到远的顺序依次遍历所有未参与局部布局的节点 fixedNodes
 * 3. 根据 fixedNodes 建立四叉树
 * 4. 遍历 fixedNodes 时，根据每个 fixedNode 的位置以及最适矩形区域的 w 和 h，构建一个矩形区域。
 *    根据四叉树获取该矩形区域所覆盖的 fixedNodes 个数
 * 5. 如果步骤4结果满足小于 MAX_OVERLAY_NODE_NUM 的条件，则退出 fixedNodes 的遍历，并返回结果
 * 6. 完成遍历后，返回 null
 * @param chart 画布实例
 * @param nodes 参与局部布局的节点，此时节点的位置还未改变
 * @param w 局部布局之后，所有参与局部布局节点形成的矩形宽度
 * @param h 局部布局之后，所有参与局部布局节点形成的矩形高度
 * @returns {sx: number, sy: number} 局部布局最适矩形区域左上角的坐标
 */
export const findMostSuitablePosToPlaceNodes = (chart, nodes, w, h, fitCenter) => {
    const tmp = chart.getBoundingBox(nodes)
    const originalCenter = fitCenter || [tmp.sx + w / 2, tmp.sy + h / 2]
    const nodeIds = new Set(nodes.map(n => n.id))
    const fixedNodes = chart
        .getVisibleNodes()
        .filter(n => !nodeIds.has(n.id))
        .sort((n1, n2) => {
            const dist1 = Math.pow( n1.x - originalCenter[0], 2) + Math.pow(n1.y - originalCenter[1], 2 )
            const dist2 = Math.pow( n2.x - originalCenter[0], 2) + Math.pow(n2.y - originalCenter[1], 2 )
            if(dist1 > dist2)
                return 1
            return -1
        })
    const tree = quadtree().x(x).y(y).addAll(fixedNodes)

    for(let fn of fixedNodes){
        for(let i of directArray) {
            const x = fn.x + i[0] * w + (i[0] + 0.5) / 0.5 * gap
            const y = fn.y + i[1] * h + (i[1] + 0.5) / 0.5 * gap
            // if(x < tree._x0 || y < tree._y0)
            //     continue
            const count = search(tree, x, y, x + w, y + h)
            if (count <= MAX_OVERLAY_NODE_NUM) {
                return {sx: x, sy: y}
            }
        }
    }
    return null
}

const search = (tree, x0, y0, x3, y3) => {
    let includeNodesCount = 0
    tree.visit((node, x1, y1, x2, y2) => {
        if(!node.length){
            const d = node.data
            if(d.x >= x0 && d.x < x3 && d.y >= y0 && d.y < y3)
                includeNodesCount++
            while(node.next){
                const d = node.data
                if(d.x >= x0 && d.x < x3 && d.y >= y0 && d.y < y3)
                    includeNodesCount++
                node = node.next
            }
        }
        return x1 >= x3 || y1 >= y3 || x2 < x0 || y2 < y0
    })
    return includeNodesCount
}


const LAYOUT_GAP = 60
export const findPosToPlaceForceLayoutNodes = (chart, nodes, fixedNodes) => {
    try {
        const leftBB = chart.getBoundingBox(fixedNodes)
        return {sx: leftBB.sx + leftBB.w + LAYOUT_GAP, sy: leftBB.sy, width: leftBB.w, height: leftBB.h}
    }catch (e){
        console.log(e)
        return {sx: 0, sy: 0, width: chart.width(), height: chart.height()}
    }
}