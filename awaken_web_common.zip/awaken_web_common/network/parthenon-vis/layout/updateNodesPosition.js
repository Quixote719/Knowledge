import GridLayout from './GridLayout';
export const updateNodesPosition = (chart) => {
    const nodes = chart.getVisibleNodes();
    const newNodes = nodes.filter((n) => n.x === undefined ||
        n.x === null ||
        n.y === undefined ||
        n.y === null);
    const [cx, cy] = findCenterOfAllLinkedNode(newNodes, nodes, chart);
    const [layoutSx, layoutSy] = findMostSuitablePosToPlaceNodes(newNodes, nodes, cx, cy, chart);
    const boundingBox = getSizeOfNodesInGrid(newNodes);
    const { posArr } = new GridLayout().run(chart, {
        nodes: newNodes,
        boundingBox: {
            x1: layoutSx,
            y1: layoutSy,
            w: boundingBox.w,
            h: boundingBox.h,
        },
    });
    return {
        nodes: newNodes,
        posArr,
    };
};
/**
 * 找到离cx, cy最接近的能够放置新的点的一个区域.
 */
export const findMostSuitablePosToPlaceNodes = (newNodes, allNodes, cx, cy, chart) => {
    const layout = getSizeOfNodesInGrid(newNodes);
    const allValidX = getAllValidX(allNodes);
    const allValidY = getAllValidY(allNodes);
    const { cxIndex, cyIndex } = getCenterPointInSlicedNet(cx, cy, allValidX, allValidY);
    let minNodesInArea = allNodes.length;
    let minX = chart.getPan().x;
    let minY = chart.getPan().y;
    let found = false;
    const vxLength = allValidX.length;
    const vyLength = allValidY.length;
    const vlMax = Math.max(vxLength, vyLength);
    if (vlMax === 0) {
        return [minX, minY];
    }
    else {
        /**
         * 将layout在screen范围内移动, 计算出layout范围内含有最少点的区域
         * layout围绕着cIndex移动, 从左上角开始, 移动至右上角, 右下角, 左下角, 然后回到左上角
         * layout移动外围是根据已有点的位置, 即在allValidX, allValidY划割的矩阵位置移动
         * 第二个规则是若划割矩阵过大, 则根据layout的大小平移, 这是为了防止没有充分利用点与点之间的空间
         */
        for (let dist = 0; dist < vlMax; dist++) {
            let xIndex, yIndex;
            xIndex = cxIndex - dist;
            yIndex = cyIndex - dist;
            for (let i = 0; i < 2 * dist; i++) {
                if (indexWithinSliceNet(xIndex, yIndex, allValidX, allValidY)) {
                    [found, minX, minY, minNodesInArea] = searchInOneCeil(minNodesInArea, allNodes, layout, minX, minY, allValidX[xIndex], allValidY[yIndex], allValidX[xIndex + 1], allValidY[yIndex + 1]);
                    if (found) {
                        return [minX, minY];
                    }
                }
                xIndex++;
            }
            for (let i = 0; i < 2 * dist; i++) {
                if (indexWithinSliceNet(xIndex, yIndex, allValidX, allValidY)) {
                    [found, minX, minY, minNodesInArea] = searchInOneCeil(minNodesInArea, allNodes, layout, minX, minY, allValidX[xIndex], allValidY[yIndex], allValidX[xIndex + 1], allValidY[yIndex + 1]);
                    if (found) {
                        return [minX, minY];
                    }
                }
                yIndex++;
            }
            for (let i = 0; i < 2 * dist; i++) {
                if (indexWithinSliceNet(xIndex, yIndex, allValidX, allValidY)) {
                    [found, minX, minY, minNodesInArea] = searchInOneCeil(minNodesInArea, allNodes, layout, minX, minY, allValidX[xIndex], allValidY[yIndex], allValidX[xIndex + 1], allValidY[yIndex + 1]);
                    if (found) {
                        return [minX, minY];
                    }
                }
                xIndex--;
            }
            for (let i = 0; i < 2 * dist; i++) {
                if (indexWithinSliceNet(xIndex, yIndex, allValidX, allValidY)) {
                    [found, minX, minY, minNodesInArea] = searchInOneCeil(minNodesInArea, allNodes, layout, minX, minY, allValidX[xIndex], allValidY[yIndex], allValidX[xIndex + 1], allValidY[yIndex + 1]);
                    if (found) {
                        return [minX, minY];
                    }
                }
                yIndex--;
            }
        }
    }
    return [minX, minY];
};
const getSizeOfNodesInGrid = (nodes) => {
    const cells = nodes.length;
    return {
        w: Math.ceil(Math.sqrt(cells)) * 60,
        h: Math.ceil(Math.sqrt(cells)) * 60,
    };
};
const getAllValidX = (nodes) => {
    const res = [];
    for (const node of nodes) {
        if (node.x && !res.includes(node.x - node.r)) {
            res.push(node.x - node.r);
        }
        if (node.x && !res.includes(node.x + node.r)) {
            res.push(node.x + node.r);
        }
    }
    res.sort(integerSort);
    return res;
};
const getAllValidY = (nodes) => {
    const res = [];
    for (const key in nodes) {
        const node = nodes[key];
        if (node.y && !res.includes(node.y - node.r)) {
            res.push(node.y - node.r);
        }
        if (node.cy && !res.includes(node.y + node.r)) {
            res.push(node.y + node.r);
        }
    }
    res.sort(integerSort);
    return res;
};
const integerSort = (a, b) => {
    if (a > b) {
        return 1;
    }
    else if (a === b) {
        return 0;
    }
    else {
        return -1;
    }
};
/**
 * 计算出cx,cy在allValidX, allValidY组成的矩阵的哪个小矩形里. 若不在这个大矩阵里, 则返回0, 0
 */
const getCenterPointInSlicedNet = (cx, cy, allValidX, allValidY) => {
    if (cx < allValidX[0] ||
        cx > allValidX[allValidX.length - 1] ||
        cy < allValidY[0] ||
        cy > allValidY[allValidY.length - 1]) {
        return { cxIndex: 0, cyIndex: 0 };
    }
    else {
        let cxIndex = 0, cyIndex = 0;
        for (let i = 1; i < allValidX.length; i++) {
            if (allValidX[i] > cx) {
                cxIndex = i - 1;
                break;
            }
        }
        for (let k = 0; k < allValidY.length; k++) {
            if (allValidY[k] > cy) {
                cyIndex = k - 1;
                break;
            }
        }
        return { cxIndex, cyIndex };
    }
};
const indexWithinSliceNet = (xIndex, yIndex, allValidX, allValidY) => {
    return (xIndex >= 0 &&
        yIndex >= 0 &&
        xIndex < allValidX.length - 1 &&
        yIndex < allValidY.length - 1);
};
const searchInOneCeil = (minNodesInArea, allNodes, layout, minX, minY, ceilX, ceilY, nextCeilX, nextCeilY) => {
    let currY = ceilY;
    while (currY < nextCeilY) {
        let currX = ceilX; // 每次遍历x轴时重设currX
        while (currX < nextCeilX) {
            // 若60%范围内数据无法被放在屏幕内, 则改为遍历y轴
            const nodesInArea = getNodesNumInArea(allNodes, currX, currY, layout.w, layout.h, minNodesInArea);
            if (nodesInArea < minNodesInArea) {
                minNodesInArea = nodesInArea;
                // 移除一个点的距离
                minX = currX;
                minY = currY;
            }
            if (minNodesInArea === 0) {
                return [true, minX, minY, minNodesInArea];
            }
            if (layout.w > 0) {
                currX += layout.w;
            }
            else {
                break;
            }
        }
        if (layout.h > 0) {
            currY += layout.h;
        }
        else {
            break;
        }
    }
    return [false, minX, minY, minNodesInArea];
};
const getNodesNumInArea = (allNodes, x, y, width, height, currMin) => {
    let count = 0;
    for (const node of allNodes) {
        if (count >= currMin) {
            break;
        }
        if (node.x + node.r > x &&
            node.x - node.r < x + width &&
            node.y + node.r > y &&
            node.y - node.r < y + height) {
            count++;
        }
    }
    return count;
};
const findCenterOfAllLinkedNode = (newNodes, allNodes, chart) => {
    const connNodes = []; // 和新点连接的旧点
    for (const n of newNodes) {
        for (const link of n.links) {
            if (link.source &&
                link.source.id !== n.id &&
                link.source.posInitialised) {
                connNodes.push(link.source);
            }
            else if (link.target &&
                link.target.id !== n.id &&
                link.target.posInitialised) {
                connNodes.push(link.target);
            }
        }
    }
    if (connNodes.length === 0) {
        return findLeftTopOfGraph(allNodes, chart);
    }
    else {
        let xTotal = 0, yTotal = 0;
        connNodes.forEach((n) => {
            xTotal += n.x;
            yTotal += n.y;
        });
        return [xTotal / connNodes.length, yTotal / connNodes.length];
    }
};
/**
 * 找到最左上角的点的位置
 * 若没有点, 或者所有点都没有坐标, 则使用现在chart最左上角的坐标
 */
const findLeftTopOfGraph = (allNodes, chart) => {
    let leftMost = Infinity;
    let topMost = Infinity;
    let hasNode = false;
    for (const n of allNodes) {
        if (n.posInitialised) {
            hasNode = true;
            leftMost = Math.min(leftMost, n.x);
            topMost = Math.min(topMost, n.y);
        }
    }
    if (hasNode) {
        return [leftMost, topMost];
    }
    else {
        return [chart.getPan().x, chart.getPan().y];
    }
};
