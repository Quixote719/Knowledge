class Packer {
    sortBySize(blocks) {
        blocks.sort((b1, b2) => {
            if (b1.w * b1.h > b2.w * b2.h) {
                return -1;
            }
            else if (b1.w * b1.h === b2.w * b2.h) {
                return 0;
            }
            else {
                return 1;
            }
        });
    }
    fit(blocks, ratio) {
        let n;
        let node;
        let block;
        const len = blocks.length;
        const w = len > 0 ? blocks[0].w : 0;
        const h = len > 0 ? blocks[0].h : 0;
        this.root = { x: 0, y: 0, w, h };
        for (n = 0; n < len; n++) {
            block = blocks[n];
            node = this.findNode(this.root, block.w, block.h);
            if (node) {
                block.fit = this.splitNode(node, block.w, block.h);
            }
            else {
                block.fit = this.growNode(block.w, block.h, ratio);
            }
        }
    }
    // 从root中找到宽高大于w，h的未用区域
    findNode(root, w, h) {
        if (root.used) {
            return (this.findNode(root.right, w, h) ||
                this.findNode(root.down, w, h));
        }
        else if (w <= root.w && h <= root.h) {
            return root;
        }
        else {
            return null;
        }
    }
    // 从node中分割出宽高为w，h的区域
    splitNode(node, w, h) {
        node.used = true;
        node.right = {
            x: node.x + w,
            y: node.y,
            w: node.w - w,
            h,
        };
        node.down = {
            x: node.x,
            y: node.y + h,
            w,
            h: node.h - h,
        };
        return node;
    }
    // 增长w，h
    growNode(w, h, whRatio) {
        const canGrowDown = w <= this.root.w;
        const canGrowRight = h <= this.root.h;
        let shouldGrowRight = false, shouldGrowDown = false;
        let growRightOffset, growDownOffset;
        if (canGrowRight) {
            const newRatio = (this.root.w + w) / this.root.h;
            if (newRatio < whRatio) {
                shouldGrowRight = true;
            }
            else {
                growRightOffset = newRatio / whRatio;
            }
        }
        if (canGrowDown) {
            const newRatio = this.root.w / this.root.h + h;
            if (newRatio > whRatio) {
                shouldGrowDown = true;
            }
            else {
                growDownOffset = whRatio / newRatio;
            }
        }
        if (!shouldGrowDown &&
            !shouldGrowRight &&
            canGrowDown &&
            canGrowRight) {
            shouldGrowRight = growRightOffset < growDownOffset;
            shouldGrowDown = growDownOffset < growRightOffset;
        }
        if (shouldGrowRight) {
            return this.growRight(w, h);
        }
        else if (shouldGrowDown) {
            return this.growDown(w, h);
        }
        else if (canGrowRight) {
            return this.growRight(w, h);
        }
        else if (canGrowDown) {
            return this.growDown(w, h);
        }
        else {
            return null;
        } // need to ensure sensible root starting size to avoid this happening
    }
    // 使root往右侧增长
    growRight(w, h) {
        this.root = {
            used: true,
            x: 0,
            y: 0,
            w: this.root.w + w,
            h: this.root.h,
            down: this.root,
            right: { x: this.root.w, y: 0, w, h: this.root.h },
        };
        const node = this.findNode(this.root, w, h);
        if (node) {
            return this.splitNode(node, w, h);
        }
        else {
            return null;
        }
    }
    // 使root往下方增长
    growDown(w, h) {
        this.root = {
            used: true,
            x: 0,
            y: 0,
            w: this.root.w,
            h: this.root.h + h,
            down: { x: 0, y: this.root.h, w: this.root.w, h },
            right: this.root,
        };
        const node = this.findNode(this.root, w, h);
        if (node) {
            return this.splitNode(node, w, h);
        }
        else {
            return null;
        }
    }
}
export default Packer;
