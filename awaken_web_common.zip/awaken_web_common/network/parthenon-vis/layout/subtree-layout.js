import AsyncAnimation from '../animation/AsyncAnimation';
import Packer from './bin-packing';
import HierarchyLayout from './HierarchyLayout'
import ForceLayout from './force'
import { getBoundingBox, getFitAnimParams } from './fit';
import {findMostSuitablePosToPlaceNodes} from './util'
/**
 * 考虑将节点分为多个子树来进行布局
 * 1. 将输入节点分为1-N个子树
 * 2. 在子树内进行同步或者异步的布局
 * 3. 布局结束后生成若干个矩阵区域
 * 4. 将矩阵区域进行拼接
 */
const packer = new Packer();
/**
 * 在同步布局过程中添加将子树分离的过程
 * 返回值是函数。该函数接受chart，opts为参数，返回动画终点位置
 * 利用动画终点位置可以创建同步动画
 */
function SyncSubtreeLayoutWrapper(layout) {
    return (chart, opts) => {
        return syncLayout(layout, chart, opts);
    };
}
/**
 * 在异步过程中添加将子树分离的过程
 * 返回值是函数。该函数接受chart，opts为参数，返回一个step函数。
 * 利用step函数可以创建异步动画
 */
function AsyncSubtreeLayoutWrapper(layout) {
    return (chart, opts) => {
        return asyncLayout(layout, chart, opts);
    };
}
function getSubtrees(chart, nodes, layout) {
    const isHierarchyLayout = layout instanceof HierarchyLayout
    const isForceLayout = layout instanceof ForceLayout
    const subtrees = [];
    const unclassifiedSet = new Set();
    nodes.forEach((node) => unclassifiedSet.add(node.id));
    while (unclassifiedSet.size > 0) {
        const subtree = new Set();
        const greyNodeSet = new Set(); // 属于subtree, 但是其连接点未加入subtrees
        const traversedSet = new Set();
        const nodeId = unclassifiedSet.values().next().value;
        unclassifiedSet.delete(nodeId);
        const node = chart.getNode(nodeId);
        subtree.add(node.id);
        greyNodeSet.add(node.id);
        while (greyNodeSet.size > 0) {
            const greyNodeId = greyNodeSet.values().next().value;
            greyNodeSet.delete(greyNodeId);
            const greyNode = chart.getNode(greyNodeId);
            let neighborhood = greyNode.layoutNeighborHood();
            if(isHierarchyLayout || isForceLayout)
                neighborhood = neighborhood.filter(n => nodes.find(nn => nn.id === n.id))
            neighborhood.forEach((n) => {
                if (!subtree.has(n.id) && !traversedSet.has(n.id)) {
                    traversedSet.add(n.id)
                    if (unclassifiedSet.has(n.id))
                        subtree.add(n.id);
                    unclassifiedSet.delete(n.id);
                    if (!greyNodeSet.has(n.id)) {
                        greyNodeSet.add(n.id);
                    }
                }
            });
            greyNodeSet.delete(greyNode.id);
        }
        subtrees.push(subtree);
    }
    return {
        subtrees: subtrees.map((subtreeIds) => chart.getNodes(subtreeIds)),
    };
}
function syncLayout(layout, chart, opts = {}) {
    let nodes = chart.getNeedLayoutNodes();
    const visibleNodes = chart.getVisibleNodes()
    let sx = 0
    let sy = 0
    const isGlobalLayout = nodes.length === visibleNodes.length
    if(!isGlobalLayout){
        const chartBoundBox = chart.getBoundingBox(visibleNodes)
        sx = chartBoundBox.sx + chartBoundBox.w
        opts.boundingBox = {
            x1: sx,
            y1: sy
        }
    }
    const subtreesObj = getSubtrees(chart, nodes, layout);
    const subtrees = subtreesObj.subtrees.sort((s1, s2) => s1.length < s2.length ? 1 : -1);
    const subtreeBoundBox = [];
    const res = {
        nodes: [],
        posArr: [],
    };
    // 依次对每个subtree计算布局
    for (const tree of subtrees) {
        opts.nodes = tree;
        if(!isGlobalLayout)
            opts.links = chart.getLayoutLinks(opts.nodes.map(n => n.id))
        const temp = layout.run(chart, opts);
        res.nodes = res.nodes.concat(tree);
        res.posArr = res.posArr.concat(temp.posArr);
        subtreeBoundBox.push(getBoundingBox(tree, temp.posArr));
    }
    subtreeBoundBox.forEach((bb, i) => (bb.index = i));
    // method 1. Pack from small objects
    // subtreeBoundBox = layoutBoundBox(subtreeBoundBox, chart.width()/chart.height())
    // method 2. Pack from large objects
    packer.sortBySize(subtreeBoundBox);
    packer.fit(subtreeBoundBox, chart.width() / chart.height());
    subtreeBoundBox.sort((bb1, bb2) => {
        if (bb1.index > bb2.index) {
            return 1;
        }
        else {
            return -1;
        }
    });
    let posIndex = -1;
    // 设置偏移量

    if(!isGlobalLayout) {
        const w = subtreeBoundBox.reduce((value, bb) => bb.w + value, 0)
        const h = subtreeBoundBox.reduce((value, bb) => bb.h + value, 0)
        const tmp = findMostSuitablePosToPlaceNodes(chart, nodes, w, h, opts.fitCenter)
        if(tmp) {
            sx = tmp.sx
            sy = tmp.sy
        }
    }

    for (let i = 0; i < subtrees.length; i++) {
        const tree = subtrees[i];
        tree.forEach(() => {
            posIndex++;
            if (subtreeBoundBox[i].fit) {
                res.posArr[posIndex].x +=
                    subtreeBoundBox[i].fit.x - subtreeBoundBox[i].sx + sx;
                res.posArr[posIndex].y +=
                    subtreeBoundBox[i].fit.y - subtreeBoundBox[i].sy + sy;
            }
        });
    }

    if (opts.fit) {
        const bb = getBoundingBox(res.nodes, res.posArr)
        const factor = 3
        bb.sx -= (factor - 1) * bb.w / 2
        bb.sy -= (factor - 1) * bb.h / 2
        bb.w *= factor
        bb.h *= factor
        const chartPos = getFitAnimParams(chart, bb, opts);
        return {
            posArr: res.posArr,
            nodes: res.nodes,
            chartPos,
            isGlobalLayout: isGlobalLayout
        };
    }
    else {
        return res;
    }
}

function asyncLayout(layout, chart, opts = {}) {
    let nodes = chart.getNeedLayoutNodes();
    const visibleNodes = chart.getVisibleNodes()
    const isGlobalLayout = nodes.length === visibleNodes.length
    chart.getNeedRenderedNodes(true)
    chart.getNeedRenderedLinks(true)
    const subtreesObj = getSubtrees(chart, nodes, layout);
    const subtrees = subtreesObj.subtrees.sort((s1, s2) => s1.length < s2.length ? 1 : -1);
    const animator = {
        animatorArr: [],
        step() {
            let ended = true;
            animator.animatorArr.forEach((_ani) => {
                ended = _ani.step() && ended;
            });
                nodes = chart.getVisibleNodes();
                const _tempBB = chart.getBoundingBox(nodes);
                const _params = getFitAnimParams(chart, _tempBB);
                chart.setZoom(_params.zoom);
                chart.setPanX(_params.panX);
                chart.setPanY(_params.panY);
            return ended;
        },
        finish(cb) {
            seperateSubtrees(chart, subtrees, isGlobalLayout, opts.fitCenter, cb);
        },
        add(_ani) {
            animator.animatorArr.push(_ani);
        },
    };
    opts.fitWhileAnimation = opts.isGlobalLayout = isGlobalLayout
    if(!isGlobalLayout){
        // const fixedNodes = visibleNodes.filter(n => !n.needLayout)
        // const {sx, sy, width, height} = findPosToPlaceForceLayoutNodes(chart, nodes, fixedNodes)
        const {sx, sy, w, h} = chart.getBoundingBox()
        opts.bounding = {sx, sy, width: w, height: h}
        for(let n of nodes){
            n.x = NaN
            n.y = NaN
        }
    }
    for (const tree of subtrees) {
        opts.nodes = tree;
        const subtreeAnimator = new AsyncAnimation(layout.init(chart, opts));
        animator.add(subtreeAnimator);
    }
    return {
        step: animator.step,
        cb: animator.finish,
    };
}
function seperateSubtrees(chart, subtrees, isGlobalLayout, fitCenter, cb) {
    const subtreeBoundBox = [];
    for (const tree of subtrees) {
        subtreeBoundBox.push(chart.getBoundingBox(tree));
    }
    subtreeBoundBox.forEach((bb, i) => (bb.index = i));
    // method 1. Pack small objects first
    // subtreeBoundBox = layoutBoundBox(subtreeBoundBox, chart.width() / chart.height())
    // method 2. Pack large objects first
    packer.sortBySize(subtreeBoundBox);
    packer.fit(subtreeBoundBox, chart.width() / chart.height());
    subtreeBoundBox.sort((bb1, bb2) => {
        if (bb1.index > bb2.index) {
            return 1;
        }
        else {
            return -1;
        }
    });
    const posArr = [];
    const nodeArr = [];
    for (let i = 0; i < subtrees.length; i++) {
        const subtree = subtrees[i];
        for (const block of subtree) {
            nodeArr.push(block);
            posArr.push({
                x: block.x + subtreeBoundBox[i].fit.x - subtreeBoundBox[i].sx,
                y: block.y + subtreeBoundBox[i].fit.y - subtreeBoundBox[i].sy,
            });
        }
    }
    //如果是局部布局，在计算完各个subtree的最终位置后，
    //需要找到整个局部布局的最适位置
    if(!isGlobalLayout){
        const prevPosArr = nodeArr.map(n => ({x: n.x, y: n.y}))
        nodeArr.forEach((n, i) => {
            n.x = posArr[i].x
            n.y = posArr[i].y
        })
        const {w, h} = chart.getBoundingBox(nodeArr)
        nodeArr.forEach((n, i) => {
            n.x = prevPosArr[i].x
            n.y = prevPosArr[i].y
        })
        const tmp = findMostSuitablePosToPlaceNodes(chart, nodeArr, w, h, fitCenter)
        let sx = 0
        let sy = 0
        if(tmp) {
            sx = tmp.sx
            sy = tmp.sy
        }
        posArr.forEach(p => {
            p.x += sx
            p.y += sy
        })
    }
    chart.prependAnimate(nodeArr, posArr, {}, cb);
}
export { SyncSubtreeLayoutWrapper, AsyncSubtreeLayoutWrapper };
