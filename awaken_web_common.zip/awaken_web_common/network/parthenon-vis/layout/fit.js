const MAX_RATIO = 0.14;
export const getBoundingBox = (nodes, posArr) => {
    let sx = Infinity, sy = Infinity, ex = -Infinity, ey = -Infinity;
    for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i];
        const pos = posArr[i];
        const nodeBBox = node.boundingBox();
        sx = Math.min(sx, pos.x - nodeBBox.w);
        sy = Math.min(sy, pos.y - nodeBBox.h);
        ex = Math.max(ex, pos.x + nodeBBox.w);
        ey = Math.max(ey, pos.y + nodeBBox.h);
    }
    return {
        sx,
        sy,
        w: ex - sx,
        h: ey - sy,
    };
};
export const getFitAnimParams = (chart, bbox, opts = {}) => {
    const ratio = getSmallestNodeRatio(chart, bbox);
    if (ratio > MAX_RATIO) {
        const scale = ratio / MAX_RATIO;
        const nw = bbox.w * scale;
        const nh = bbox.h * scale;
        bbox.sx = bbox.sx + bbox.w / 2 - nw / 2;
        bbox.sy = bbox.sy + bbox.h / 2 - nh / 2;
        bbox.w = nw;
        bbox.h = nh;
    }
    const paddingX = opts.paddingX || opts.padding || 5, paddingY = opts.paddingY || opts.padding || 5;
    const w = chart.width();
    const h = chart.height();
    const wp = w - paddingX * 2;
    const hp = h - paddingY * 2;
    const factorByWidth = bbox.w / wp > bbox.h / hp; // 是否根据宽度计算缩放比例
    const factor = factorByWidth ? wp / bbox.w : hp / bbox.h;
    const sx = factorByWidth ? paddingX : (w - bbox.w * factor) / 2;
    const sy = factorByWidth ? (h - bbox.h * factor) / 2 : paddingY;

    const bbCenterCoord = [ bbox.sx + bbox.w / 2, bbox.sy + bbox.h / 2 ]
    const bbCenter = chart.interactor.projectCanvasPosToScreen(bbCenterCoord[0], bbCenterCoord[1])

    return {
        zoom: Math.min(factor, 1.7),
        // zoom: factor,
        panX: bbox.sx - sx / factor,
        panY: bbox.sy - sy / factor,
        bbCenter,
        // deltaToCenter: [bbCenter[0] - w / 2, bbCenter[1] - h / 2],
        // originZoom: chart.getZoom()
    };
};
/**
 * 获取最小的点在chart中所占的比例. 用于判断点是否过大
 */
const getSmallestNodeRatio = (chart, bbox) => {
    const visibleNodes = chart.getVisibleNodes();
    const smallerSide = Math.min(bbox.w, bbox.h);
    let biggestRatio = 0;
    visibleNodes.forEach((n) => {
        biggestRatio = Math.max(biggestRatio, n.r / smallerSide);
    });
    return biggestRatio;
};
