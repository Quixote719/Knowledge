class SyncLayout {
}
export default SyncLayout;
