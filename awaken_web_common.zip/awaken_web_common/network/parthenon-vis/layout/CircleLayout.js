import util from '../util';
import is from '../is';
import math from '../math';
import SyncLayout from './SyncLayout';
import { wrapPosArrayBySort } from './util';
const defaultOpts = {
    fit: true,
    startAngle: (3 / 2) * Math.PI,
    sweep: Math.PI * 2,
    clockwise: true,
};
class CircleLayout extends SyncLayout {
    constructor() {
        super(...arguments);
        this.run = (chart, options) => {
            options = util.extend({}, defaultOpts, options);
            const nodes = options.nodes ? options.nodes : chart.getLayoutNodes();
            let res = [];
            if(!options.boundingBox)
                options.boundingBox = {}
            const bb = math.makeBoundingBox(
                Object.assign({
                    x1: 0,
                    y1: 0,
                    w: chart.width(),
                    h: chart.height(),
                }, options.boundingBox));
            const center = {
                x: bb.x1 + bb.w / 2,
                y: bb.y1 + bb.h / 2,
            };
            const dTheta = options.sweep / Math.max(1, nodes.length);
            let r;
            let minDistance = 0;
            for (const n of nodes) {
                const nbb = n.layoutDimensions(options);
                const w = nbb.w;
                const h = nbb.h;
                minDistance = Math.max(minDistance, w, h);
            }
            if (is.number(options.radius)) {
                r = options.radius;
            }
            else if (nodes.length <= 1) {
                r = 0;
            }
            else {
                r = Math.max(nodes.length * 10, 30);
                // r = Math.min( bb.h, bb.w ) / 2 - minDistance;
            }
            /**
             * 根据boundingBox的大小计算最终的半径
             */
            if (nodes.length > 1) {
                // but only if more than one node (can't overlap)
                minDistance *= 1.75; // just to have some nice spacing
                const dcos = Math.cos(dTheta) - Math.cos(0);
                const dsin = Math.sin(dTheta) - Math.sin(0);
                const rMin = Math.sqrt((minDistance * minDistance) / (dcos * dcos + dsin * dsin)); // s.t. no nodes overlapping
                r = Math.max(rMin, r);
            }
            const getPos = (_, i) => {
                const theta = options.startAngle + i * dTheta * (options.clockwise ? 1 : -1);
                const rx = r * Math.cos(theta);
                const ry = r * Math.sin(theta);
                const pos = {
                    x: center.x + rx,
                    y: center.y + ry,
                };
                return pos;
            };
            for (let i = 0; i < nodes.length; i++) {
                const node = nodes[i];
                const pos = getPos(node, i);
                res.push({
                    x: pos.x,
                    y: pos.y,
                });
            }
            if (options.sort) {
                res = wrapPosArrayBySort(res, nodes, options.sort);
            }
            return {
                posArr: res,
            };
        };
    }
}
export default CircleLayout;
