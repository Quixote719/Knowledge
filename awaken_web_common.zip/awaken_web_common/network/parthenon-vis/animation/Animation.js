let uid = 0;
class Animation {
    constructor() {
        this.uid = uid++;
        this._started = false;
        this._progress = 0;
        this._opts = {};
    }
    progress() {
        return this._progress;
    }
    /**
     * 动画是否启动
     */
    started() {
        return this._started;
    }
    /**
     * 结束动画。结束后开启回调函数
     */
    finish() {
        if (this._cb && typeof this._cb === 'function') {
            this._cb();
        }
    }
    /**
     * 动画持续时间
     */
    duration() {
        if (this._opts && this._opts.duration) {
            return this._opts.duration;
        }
        else {
            return 1000;
        }
    }
    delay() {
        if (this._opts && this._opts.delay) {
            return this._opts.delay;
        }
        else {
            return 0;
        }
    }
    /**
     * 是否应该在动画过程中保持可视点在屏幕中，并撑满屏幕空间
     */
    shouldFitWhileAnimation() {
        return this._opts.fitWhileAnimation;
    }
}
export default Animation;
