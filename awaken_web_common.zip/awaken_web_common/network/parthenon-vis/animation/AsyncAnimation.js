import Animation from './Animation';
class AsyncAnimation extends Animation {
    constructor(step, animOpts = {}, cb) {
        super();
        this._opts = animOpts;
        this._stepFn = step;
        this._cb = cb;
    }
    step() {
        return this._stepFn();
    }
    run() {
        // empty
    }
    /**
     * 动画持续时间
     * 默认没有限制。
     */
    duration() {
        if (this._opts && this._opts.duration) {
            return this._opts.duration;
        }
        else {
            return 1000000;
        }
    }
}
export default AsyncAnimation;
