import Animation from './Animation';
class WrappedAnimation extends Animation {
    constructor(startFn) {
        super();
        this._startFn = startFn;
    }
    /**
     * 运行
     */
    run() {
        this._started = true;
        this._startFn();
    }
}
export default WrappedAnimation;
