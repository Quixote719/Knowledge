import Animation from './Animation';
const defaultOpts = {
    delay: 0,
    duration: 500,
    fitWhileAnimation: true,
    fitBoundingBox: null
};
/**
 * 线性动画变换
 */
class PlainAnimation extends Animation {
    constructor(animationCollection, eles, dest, opts, cb) {
        super();
        this.animationCollection = animationCollection;
        this.elements = eles;
        this._cb = cb;
        this.destBeforePrepare = dest;
        Object.assign(this._opts, defaultOpts, opts);
        if (dest.hasOwnProperty('fit') &&
            dest.fit === true) {
            this._opts.fitWhileAnimation = false;
        }
    }
    /**
     * 运行动画
     */
    run() {
        this._started = true;
        this.copyDestAttrToSrc();
    }
    /**
     * 动画持续时间
     */
    duration() {
        return this._opts.duration;
    }
    /**
     * 获取第[index]元素的动画初始属性
     */
    getSource(index) {
        return this.source[index];
    }
    /**
     * 获取第[index]元素的动画结束属性
     */
    getDestination(index) {
        return this.destAfterPrepare[index];
    }
    /**
     * 设置动画进度
     */
    setProgress(val) {
        // javascript 数字溢出
        if (val < -0.01 || val > 1.01) {
            return console.warn('无法设置progress为(0,1)之外的值', val);
        }
        else {
            this._progress = val;
        }
    }
    /**
     * 获取当前进度
     */
    progress() {
        return this._progress;
    }
    /**
     * 将出现在destination中的属性拷贝到source中.
     * 若动画初始位置和此刻相同, 则无需传递source.
     * 为了方便计算, 我们保留一份初始时刻元素状态的信息.
     */
    copyDestAttrToSrc() {
        if (this._opts.source && !Array.isArray(this._opts.source)) {
            this.source = new Array(this.elements.length).fill(this._opts.source);
        }
        else {
            this.source = this.animationCollection.prepareSource(this.elements, this.destBeforePrepare);
            this.destAfterPrepare = this.animationCollection.prepareDest(this.elements, this.destBeforePrepare);
        }
    }
}
export default PlainAnimation;
