import NodeBase from '../collection/element/NodeBase';
import is from '../is';
import Transformer from './Transformer';
/**
 * 若最终为可见, 则在动画过程中将visible设置为true, 这样动画时才能看见
 * 动画结束时设置元素visible状态. alpha只是用于动画, 因此设置为1
 */
const processVisible = (ele, progress, dest) => {
    if (dest.visible) {
        ele.visible = true;
    }
    if (progress === 1) {
        /**
         * 处理非连续变化的属性
         */
        if (dest.hasOwnProperty('visible')) {
            ele.visible = dest.visible;
            ele.animAlpha = 1;
        }
    }
};
class NodeTransformer extends Transformer {
    filter(node) {
        return node instanceof NodeBase;
    }
    prepareSource(node, destination) {
        const res = {
            animAlpha: node.visible ? 1 : 0,
            r: node.posInitialised ? node.r : destination.r,
            x: node.posInitialised ? node.x : destination.x,
            y: node.posInitialised ? node.y : destination.y,
        };
        return res;
    }
    prepareDest(node, dest) {
        let animAlpha;
        if (dest.hasOwnProperty('visible')) {
            animAlpha = dest.visible ? 1 : 0;
        }
        else {
            animAlpha = node.visible ? 1 : 0;
        }
        const res = Object.assign({}, dest, { animAlpha });
        return res;
    }
    /**
     * 1. 计算动画进度progress (0 -> 1)
     * 2. 设置元素的位置
     * 返回值：动画是否结束
     */
    transformer(progress, element, src, dest) {
        /**
         * 处理数值连续变化的属性
         */
        for (const key in dest) {
            if (is.number(dest[key]) && is.number(src[key])) {
                element[key] = (dest[key] - src[key]) * progress + src[key];
            }
        }
        processVisible(element, progress, dest);
        return progress === 1 ? true : false;
    }
}
const nodeTransformer = new NodeTransformer();
export default nodeTransformer;
