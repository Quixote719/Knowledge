import Chart from '../chart';
import is from '../is';
// import easings from './../../easeFunction/easing'
import { getFitAnimParams } from '../layout/fit';
import Transformer from './Transformer';
const getVal = (src, dest, progress, key) => {
    // if(key === 'zoom')
    //     return easings['ease-in'](src[key], dest[key], progress)
    // return easings['ease-out'](src[key], dest[key], progress)
    return (dest[key] - src[key]) * progress + src[key];
};
class ChartTransformer extends Transformer {
    filter(chart) {
        return chart instanceof Chart;
    }
    /**
     * 记录动画初始时的位置.
     */
    prepareSource(chart, dest) {
        const pan = chart.getPan();
        const zoom = chart.getZoom();
        return {
            panX: is.number(pan.x) ? pan.x : dest.panX,
            panY: is.number(pan.y) ? pan.y : dest.panY,
            zoom: is.number(zoom) ? zoom : dest.zoom,
        };
    }
    prepareDest(chart, dest) {
        if (dest.fit) {
            if (dest.hasOwnProperty('panX') ||
                dest.hasOwnProperty('panY') ||
                dest.hasOwnProperty('zoom')) {
                console.warn('animation: 若设置fit: true, 则panX, panY, zoom属性无效');
            }
            const bbox = chart.getBoundingBox();
            return getFitAnimParams(chart, bbox);
        }
        else {
            return dest;
        }
    }
    /**
     * 1. 计算动画进度progress (0 -> 1)
     * 2. 设置元素的位置
     * @returns {boolean} 动画是否已经结束
     */
    prevProgress = 0
    transformer(progress, chart, src, dest) {
        const hasZoom = dest.hasOwnProperty('zoom')
        const hasPanX = dest.hasOwnProperty('panX')
        const hasPanY = dest.hasOwnProperty('panY')
        const chartCenter = [chart.width() / 2, chart.height() / 2]
        if (hasZoom) {
            const prevZoom = chart.getZoom()
            const destZoom = dest.zoom
            const {x, y} = chart.getPan()
            const zoom = getVal(src, dest, progress, 'zoom')
            const pos = dest.bbCenter
                ? [dest.bbCenter[0], dest.bbCenter[1]]
                : chartCenter
            chart.setZoom(zoom);
            chart.setPanX(x + pos[0] / prevZoom - pos[0] / zoom + (pos[0] - chartCenter[0]) * (progress - this.prevProgress) / destZoom)
            chart.setPanY(y + pos[1] / prevZoom - pos[1] / zoom + (pos[1] - chartCenter[1]) * (progress - this.prevProgress) / destZoom)
            this.prevProgress = progress
        } else {
            if (hasPanX) {
                const panX = getVal(src, dest, progress, 'panX')
                chart.setPanX(panX);
            }
            if (hasPanY) {
                const panY = getVal(src, dest, progress, 'panY')
                chart.setPanY(panY);
            }
        }
        if (progress === 1) {
            this.prevProgress = 0
            return true;
        }
        else {
            return false;
        }
    }
}
// TODO: 1. 将规则细化至每一条的处理方案
// TODO: 2. 后期加入速率函数(现阶段不需要)
const chartTransformer = new ChartTransformer();
export default chartTransformer;
