import { getFitAnimParams } from '../layout/fit';
import AsyncAnimation from './AsyncAnimation';
import ChartTransformer from './chartTransformer';
import NodeTransformer from './nodeTransformer';
import PlainAnimation from './PlainAnimation';
import WrappedAnimation from './WrappedAnimation';
/**
 * 每个AnimationCollection可以串多个动画并行.
 * i.e. AnimationCollection.animate().animate().delay().animate()
 */
class AnimationCollection {
    constructor(chart) {
        /**
         * 转换规则。定义了元素哪些属性可以变化，以及如何变化
         */
        this.transformRule = [];
        /**
         * 动画队列
         */
        this._animQueue = [];
        this._isPlaying = false;
        /**
         * 当前正在运行的动画
         */
        this._currAnim = null;
        /**
         * 当前正在运行动画的开始时间
         */
        this._currAnimStartTime = null;
        /**
         * 添加转换规则
         */
        this.registerTransformRule = (transformRule) => {
            this.transformRule.push(transformRule);
        };
        /**
         * 添加延时动画
         */
        this.delay = (ms = 2000) => {
            const anim = this.createAnim([], [], { duration: ms });
            this.addAnimation(anim);
            this.play();
            return this._chart;
        };
        /**
         * 首先创建动画. 然后将其加入到animCollection中串行运行
         */
        this.animate = (eles, dest, opts, cb) => {
            const anim = this.createAnim(eles, dest, opts, cb);
            this.addAnimation(anim);
            this.play();
            return this._chart;
        };
        /**
         * 创建动画，并插入到动画队列头部
         */
        this.prependAnimate = (eles, dest, opts, cb) => {
            const anim = this.createAnim(eles, dest, opts, cb);
            this.prependAnimation(anim);
            this.play();
            return this._chart;
        };
        /**
         * 创建异步动画，并插入到动画队列尾部
         */
        this.animateAsync = (step, animOpts, cb) => {
            const anim = new AsyncAnimation(step, animOpts, cb);
            this.addAnimation(anim);
            this.play();
            return this._chart;
        };
        /**
         * 创建Wrapped动画，该动画会在上一个动画结束时，启动传入的函数，并由此决定动画的结束位置是什么。
         */
        this.animateByFn = (fn) => {
            const anim = new WrappedAnimation(fn);
            this.addAnimation(anim);
            this.play();
            return this._chart;
        };
        /**
         * 是否在运行动画
         */
        this.isPlaying = () => {
            return this._isPlaying;
        };
        /**
         * 获取当前动画
         */
        this.getCurrentAnim = () => {
            return this._currAnim;
        };
        /**
         * 获取当前动画开始时间
         */
        this.getCurrentAnimStartTime = () => {
            return this._currAnimStartTime;
        };
        /**
         * 停止动画，并清空动画队列
         */
        this.stop = () => {
            this._animQueue = [];
            this._currAnim = null;
            this._isPlaying = false;
            return this._chart;
        };
        /**
         * 结束当前动画，并开始下一动画
         */
        this.playNext = () => {
            this._currAnim.finish();
            if (this._animQueue.length < 1) {
                this.stop();
            }
            else {
                this._currAnimStartTime = performance.now();
                this._currAnim = this._animQueue.shift();
                this._currAnim.run();
            }
        };
        /**
         * 暂停当前动画
         */
        this.pause = () => {
            this._isPlaying = false;
            return this._chart;
        };
        /**
         * 开始动画
         */
        this.play = () => {
            if (!this._currAnim.started()) {
                const temp = this._currAnim;
                this._currAnim.run();
                if (temp === this._currAnim &&
                    this._currAnim instanceof WrappedAnimation) {
                    // 未改变_currAnim, 可能是animationFn没有调用任何的animate
                    this.playNext();
                }
                if (!this._currAnim) {
                    console.warn('Oops, 出错了. 你可能忘记了在wrapped animation中返回了一个可以做动画的格式.');
                }
                else {
                    // 此时wrapped_animation已经被替换为其他的animation
                    this._currAnimStartTime =
                        performance.now() -
                            this._currAnim.duration() * this._currAnim.progress();
                }
            }
            this._isPlaying = true;
            return this._chart;
        };
        /**
         * 准备动画的开始状态
         */
        this.prepareSource = (elements, destination) => {
            const rules = this.transformRule;
            const res = [];
            for (let k = 0; k < elements.length; k++) {
                const element = elements[k];
                for (const rule of rules) {
                    if (rule.filter(element)) {
                        res.push(rule.prepareSource(element, destination[k]));
                        break;
                    }
                }
            }
            return res;
        };
        /**
         * 计算动画终止位置
         */
        this.prepareDest = (elements, destArr) => {
            const rules = this.transformRule;
            const res = [];
            for (let k = 0; k < elements.length; k++) {
                const element = elements[k];
                for (const rule of rules) {
                    if (rule.filter(element)) {
                        res.push(rule.prepareDest(element, destArr[k]));
                        break;
                    }
                }
            }
            return res;
        };
        /**
         * 添加动画。
         * 若当前存在动画，则插入到动画队列末尾
         */
        this.addAnimation = (anim) => {
            if (this._currAnim === null) {
                this._currAnim = anim;
            }
            else if (this._currAnim instanceof WrappedAnimation) {
                this._currAnim = anim;
            }
            else {
                this._animQueue.push(anim);
            }
            return this._chart;
        };
        /**
         * 将动画插入到队列头
         */
        this.prependAnimation = (anim) => {
            this._animQueue.unshift(anim);
            return this._chart;
        };
        /**
         * 开始动画循环
         */
        this.startAnimationLoop = (now = 0) => {
            if (this.isPlaying()) {
                this.oneStep(now);
            }
            requestAnimationFrame(this.startAnimationLoop);
        };
        /**
         * 下一帧
         * collection中动画结束时, 要切换到下一个anim
         * @param now
         * @param animation
         */
        this.oneStep = (now) => {
            const animation = this.getCurrentAnim();
            const chart = this._chart;
            if (!animation || animation instanceof WrappedAnimation) {
                return;
            }
            const delay = animation.delay();
            const delta = now - this.getCurrentAnimStartTime() - delay;
            if (delta < 0) {
                // 用户设置了延迟
                return;
            }
            const progress = Math.max(0, Math.min(delta / animation.duration(), 1));
            if (animation instanceof PlainAnimation) {
                animation.setProgress(progress);
                const rules = this.transformRule;
                for (let i = 0; i < animation.elements.length; i++) {
                    const element = animation.elements[i];
                    for (const rule of rules) {
                        if (rule.filter(element)) {
                            rule.transformer(progress, element, animation.getSource(i), animation.getDestination(i));
                            break;
                        }
                    }
                }
                if (animation.shouldFitWhileAnimation()) {
                    const _tempBB = chart.getBoundingBox(chart.getVisibleNodes());
                    const _params = getFitAnimParams(chart, _tempBB);
                    chart.setZoom(_params.zoom);
                    chart.setPanX(_params.panX);
                    chart.setPanY(_params.panY);
                }
            }
            else if (animation instanceof AsyncAnimation) {
                const ended = animation.step();
                if (ended) {
                    return this.playNext();
                }
            }
            /**
             * 到达了duration规定的时间
             */
            if (progress === 1) {
                return this.playNext();
            }
            this._chart.getNeedRenderedNodes()
            this._chart.getNeedRenderedLinks()
        };
        this._chart = chart;
        /**
         * 注册画布的转换规则
         */
        this.registerTransformRule(ChartTransformer);
        /**
         * 注册点的转换规则
         */
        this.registerTransformRule(NodeTransformer);
        /**
         * 开始动画的事件循环
         */
        this.startAnimationLoop();
    }
    /**
     * 创建动画
     * @param eles
     * @param dest
     * @param opts
     * @param cb
     */
    createAnim(eles, dest, opts, cb) {
        if (eles.length !== dest.length) {
            throw new Error('第二个参数应该为对象或者和第一个参数数组长度一致');
        }
        return new PlainAnimation(this, eles, dest, opts, cb);
    }
}
export default AnimationCollection;
