/**
 * Created by yaojia7 on 2020/5/21.
 */
import {drawLinkCurve, setLinkStyles} from './link'

const defaultOpts = {
    maxNodeNumToShowLine: 300
}
export default class {
    constructor(chart, canvas, opts = {}){
        this.chart = chart
        this.canvas = canvas
        this.running = true
        this.opts = Object.assign({}, defaultOpts, opts)
        if(!chart || !canvas){
            throw('chart or canvas is undefined')
        }

        this.ctx = canvas.getContext('2d')
        this.width = canvas.clientWidth
        this.height = canvas.clientHeight
        this.bb = null

        this.startRenderLoop()
    }

    startRenderLoop = (time) => {
        if(this.running)
            this.render(time);
        requestAnimationFrame(this.startRenderLoop);
    };

    hide(){
        this.running = false
        this.ctx.clearRect(0, 0, this.width, this.height);
    }

    show(){
        this.running = true
    }

    render(){
        const {chart, ctx, width, height} = this
        if(chart && ctx){
            ctx.clearRect(0, 0, width, height);
            const nodes = chart.getVisibleNodes()
            if(nodes.length < 50)
                this.r = 3
            else if(nodes.length < 150)
                this.r = 2
            else
                this.r = 1
            this.bb = chart.getBoundingBox()
            const {w, h} = this.bb
            this.bb.scale = width / height > w / h ? this.height / h : this.width / w
            //计算中心偏移
            let wScale = w * this.bb.scale
            let hScale = h * this.bb.scale
            let wCenterScale = wScale/2
            let hCenterScale = hScale/2
            this.panX = (width/2 - wCenterScale)
            this.panY = (height/2 - hCenterScale)
            //在鹰眼框中的实际坐标范围
            this.nodesExtent = {
                minX:this.panX,
                minY:this.panY,
                maxX:this.panX + wScale,
                maxY:this.panY + hScale
            }
            //在大画布中当前实际的位置
            this.fullStart = this.leftRight2Canvas(0,0,chart.getPan().x,chart.getPan().y,chart.getZoom())
            this.fullEnd = this.leftRight2Canvas(chart.width(),chart.height(),chart.getPan().x,chart.getPan().y,chart.getZoom())

            for(let node of nodes){
                this.drawNode(ctx, node)
            }

            if(nodes.length < this.opts.maxNodeNumToShowLine){
                const links = chart.getVisibleLinks()
                for(let l of links){
                    this.drawLink(ctx, chart, l)
                }
            }
        }
    }

    r = 2
    drawNode = (ctx, node) => {
        ctx.save()
        const {x, y} = this.transform(node.x, node.y)
        ctx.beginPath()
        ctx.arc(x, y, this.r, 0, Math.PI * 2)
        if(node.selected || node.connToSelected)
            ctx.fillStyle =  '#eee'
        else
            ctx.fillStyle = '#75cbc788'
        ctx.fill()
        ctx.restore()
    }

    drawLink = (ctx, chart, l) => {
        const s = chart.getNode(l.id1)
        const t = chart.getNode(l.id2)
        const sPos = this.transform(s.x, s.y)
        const tPos = this.transform(t.x, t.y)
        ctx.save();
        ctx.globalAlpha = Math.min(s.displayAlpha(), t.displayAlpha());
        if(l.selected || l.connToSelected)
            setLinkStyles({lineColor: '#eee'})
        else
            setLinkStyles({lineColor: chart.renderer.linkTheme.lineColor})
        drawLinkCurve(
            ctx,
            Object.assign({}, s, sPos, {r: this.r + 1}),
            Object.assign({}, t, tPos, {r: this.r + 1}),
            l,
            true
        )
        ctx.restore();
    }
    /**
     * 中心点转换
     */
    transform = (x, y) => {
        if(this.bb){
            const {sx, sy, scale} = this.bb
            return {
                x: (x - sx) * scale + this.panX,
                y: (y - sy) * scale - this.panY
            }
        }
    }
    /**
     * 画布左上角坐标转换至画布的内部坐标
     * @param {*} x 画布相对左上角的坐标
     * @param {*} y 画布相对左上角的坐标
     * @param {*} panX 当前画布的偏移量
     * @param {*} panY 当前画布的偏移量
     * @param {*} zoom 
     */
    leftRight2Canvas = (x,y,panX,panY,zoom) => {
        return {
            x:x/zoom + panX ,
            y:y/zoom + panY
        }
    }
}
