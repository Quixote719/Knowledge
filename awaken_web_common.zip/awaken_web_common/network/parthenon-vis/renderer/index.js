import BorderRenderer from './BorderRenderer';
import ImageRenderer from './ImageRenderer';
import linkRenderer from './link';
import TextRenderer from './TextRenderer';
import LoadingRenderer from './LoadingRenderer'
import { drawTextArr } from './util-text';
import patternImg from './pattern.png'
class Renderer {
    constructor(chart) {
        this.registerEventListener = () => {
            this.chart.bind('update-viewport', this.updateViewport);
        };
        this.updateViewport = () => {
            this.canvas.width = this.canvas.clientWidth;
            this.canvas.height = this.canvas.clientHeight;
            this.textCanvas.width = this.canvas.clientWidth;
            this.textCanvas.height = this.canvas.clientHeight;
            const dim = this.container.getBoundingClientRect();
            this.offsetLeft = dim.left;
            this.offsetTop = dim.top;
        };
        this.startRenderLoop = (time) => {
            this.render(time);
            requestAnimationFrame(this.startRenderLoop);
        };
        this.drawNode = (ctx, textCtx, node, zoom) => {
            let textDesc = null;
            if (!node.visible) {
                return { textDesc };
            }
            ctx.save();
            const alphaDiscount = this.getAlphaDiscount(node);
            ctx.globalAlpha = node.displayAlpha() * alphaDiscount;
            textCtx.globalAlpha = node.displayAlpha() * alphaDiscount;
            for (const key in this.nodeTheme.renderUnitMap) {
                const renderer = this.nodeTheme.renderUnitMap[key];
                if (renderer instanceof TextRenderer) {
                    textDesc = renderer.render(textCtx, node, zoom);
                }
                else {
                    renderer.render(ctx, node);
                }
            }
            ctx.restore();
            return { textDesc };
        };
        this.drawLink = (ctx, s, t, l) => {
            let textDesc = null;
            let res;
            if ( !s || !s.visible || !t || !t.visible) {
                return { textDesc };
            }
            ctx.save();
            ctx.globalAlpha = Math.min(s.displayAlpha(), t.displayAlpha());
            res = linkRenderer(this, ctx, s, t, l, this.chart.getZoom());
            if (res && res.textDesc) {
                textDesc = res.textDesc;
            }
            ctx.restore();
            return { textDesc };
        };
        this.render = (time) => {
            if(!this.chart.running)
                return
            this.updateViewport();
            const interactor = this.chart.interactor;
            const textDescArr = [];
            const eleDescArr = [];
            this.ctx.setTransform(1, 0, 0, 1, 0, 0);
            this.ctx.clearRect(0, 0, this.width, this.height);
            this.ctx.fillStyle = '#00000000';
            this.ctx.fillRect(0, 0, this.width, this.height);

            this.ctx.scale(interactor.zoom, interactor.zoom);
            this.ctx.translate(-interactor.pan.x, -interactor.pan.y);
            this.textCtx.setTransform(1, 0, 0, 1, 0, 0);
            this.textCtx.clearRect(0, 0, this.width, this.height);

            //draw loading information
            LoadingRenderer(this.textCanvas, this.textCtx, this.chart, time)

            this.textCtx.scale(interactor.zoom, interactor.zoom);
            this.textCtx.translate(-interactor.pan.x, -interactor.pan.y);
            const needRenderedNodeIds = new Set()
            const isPlaying = this.chart.animationCollection &&
                this.chart.animationCollection.isPlaying()
            if(isPlaying){
                for(let n of this.chart.getNeedLayoutNodes()){
                    needRenderedNodeIds.add(n.id)
                }
            }
            this.chart.needRenderedLinks.forEach((l) => {
                if(isPlaying){
                    //如果在布局计算过程中的话，
                    //不渲染未布局节点和布局节点之间的连线
                    const hasId1 = needRenderedNodeIds.has(l.id1)
                    const hasId2 = needRenderedNodeIds.has(l.id2)
                    if(hasId1 && !hasId2 || !hasId1 && hasId2)
                        return
                }
                const s = this.chart.getNode(l.id1);
                const t = this.chart.getNode(l.id2);
                if (!s || !t) {
                    console.log('l == ', l)
                    console.warn('link找不到起点或者终点', l.id1, l.id2);
                }
                const { textDesc } = this.drawLink(this.ctx, s, t, l);
                if (textDesc) {
                    textDescArr.push(textDesc);
                }
            });
            this.chart.needRenderedNodes.forEach((n) => {
                const { textDesc } = this.drawNode(this.ctx, this.textCtx, n, this.chart.getZoom());
                if (textDesc) {
                    textDescArr.push(textDesc);
                }
                const bbox = n.boundingBox();
                eleDescArr.push({
                    id: n.id,
                    sx: n.x - bbox.w / 2,
                    ex: n.x + bbox.w / 2,
                    sy: n.y - bbox.h / 2,
                    ey: n.y + bbox.h / 2,
                    selected: n.selected
                });
            });
            drawTextArr(this.ctx, textDescArr, eleDescArr);
            if (interactor.selectBox && interactor.selectBox.length === 4) {
                const box = interactor.selectBox;
                this.ctx.fillStyle = this.theme.selectBoxColor;
                this.ctx.fillRect(box[0], box[1], box[2] - box[0], box[3] - box[1]);
            }

        };
        this.BorderRenderer = BorderRenderer;
        this.TextRenderer = TextRenderer;
        this.ImageRenderer = ImageRenderer;
        const container = chart.getContainer();
        const canvasContainer = document.createElement('div');
        const canvas = document.createElement('canvas');
        const textCanvas = document.createElement('canvas');

        canvasContainer.setAttribute('style', `position: relative; width: 100%; height: 100%;z-index:3; background: url(${patternImg}) repeat; background-color: #201d28 `);
        canvas.setAttribute('style', 'position: absolute; top: 0; bottom: 0; left: 0; right: 0; width: 100%; height: 100%;z-index:3');
        textCanvas.setAttribute('style', 'position: absolute; top: 0; bottom: 0; left: 0; right: 0; width: 100%; height: 100%;z-index:3');
        this.container = canvasContainer;
        container.appendChild(canvasContainer);
        canvasContainer.appendChild(canvas);
        canvasContainer.appendChild(textCanvas);
        this.container.addEventListener('contextmenu', e => {
            e.preventDefault()  //禁止浏览器默认的右键菜单栏事件
            return false
        })
        setTimeout(() => {
            this.updateViewport();
            chart.triggerEvent('canvasReady');
        }, 0);
        this.ctx = canvas.getContext('2d');
        this.textCtx = textCanvas.getContext('2d');
        this.canvas = canvas;
        this.textCanvas = textCanvas;
        this.chart = chart;
        this.theme = {
            backgroundColor: 'white',
            selectBoxColor: 'rgba(0, 0, 0, .2)',
        };
        this.linkTheme = {
            lineColor: 'black',
            textColor: 'black',
            textBgColor: 'rgba(255, 255, 255, .0)',
            linkWidth: 1,
            selected: {
                linkWidth: 2,
                lineColor: '#71a200',
                textColor: 'white',
                textBgColor: '#71a200',
            },
        };
        this.nodeTheme = {
            global: {
                alpha: 0.5,
                selected: {
                    alpha: 1,
                },
                connToSelected: {
                    alpha: 1,
                },
            },
            renderUnitMap: {
                border: new BorderRenderer(this, {
                    defaultAttribute: {
                        // 是否渲染边框
                        visible: true,
                        w: 1,
                        // 选中时渲染边框，边框宽度为4
                        selected: {
                            visible: true,
                            w: 4,
                        },
                    },
                    defaultStyle: {
                        color: 'black',
                    },
                }),
                text: new TextRenderer(this),
                image: new ImageRenderer(this),
            },
        };
        this.registerEventListener();
        this.startRenderLoop();
    }
    show() {
        this.container.style.visibility = 'visible';
    }
    hide() {
        this.container.style.visibility = 'hidden';
    }
    getContainer() {
        return this.container;
    }
    get width() {
        return this.canvas.width;
    }
    get height() {
        return this.canvas.height;
    }
    /**
     * 根据点的状态返回最终的扁平化的样式。
     * 若点处于选中状态，则优先返回选中的样式，若没有则返回原样式
     * 若点处于connToSelected状态，则优先返回connToSelected样式，没有则返回原样式
     */
    getResultByNodeState(node, object) {
        const res = {};
        const {hoverNodeId} = this.chart

        if(object.customNodeStyle){
            const customStyle = object.customNodeStyle
            if(customStyle[node.getType()]){
                object = customStyle[node.getType()]
            }
        }
        for (const key in object) {
            if (key !== 'selected' && key !== 'connToSelected' && key !== 'hover') {
                res[key] = object[key]
            }
        }
        if (node.connToSelected && object.connToSelected) {
            for (const key in object.connToSelected) {
                res[key] = object.connToSelected[key]
            }
        }
        if(hoverNodeId && node.id === hoverNodeId){
            for(const key in object.hover){
                res[key] = object.hover[key]
            }
        }
        if (node.selected && object.selected) {
            for (const key in object.selected) {
                res[key] = object.selected[key]
            }
        }
        for (const key in res) {
            if (typeof res[key] === 'function') {
                res[key] = res[key](node);
            }
        }
        return res;
    }
    /**
     * 获取线的样式
     */
    getLinkStyles(source, target, link) {
        const selected = link.selected || link.connToSelected;
        const res = {};
        /**
         * 首先获取默认情况下的样式
         */
        for (const key in this.linkTheme) {
            if (key !== 'selected') {
                res[key] = this.linkTheme[key];
            }
        }
        /**
         * 获取选中情况时的样式，并覆盖默认样式
         */
        if (selected && this.linkTheme.selected) {
            for (const key in this.linkTheme.selected) {
                res[key] = this.linkTheme.selected[key];
            }
        }
        for (const key in res) {
            if (typeof res[key] === 'function') {
                res[key] = res[key](link);
            }
        }
        return res;
    }
    getAlphaDiscount(node) {
        if (this.nodeTheme && this.nodeTheme.global) {
            if (node.connToSelected &&
                this.nodeTheme.global.connToSelected &&
                typeof this.nodeTheme.global.connToSelected.alpha === 'number') {
                return this.nodeTheme.global.connToSelected.alpha;
            }
            else if (node.selected &&
                this.nodeTheme.global.selected &&
                typeof this.nodeTheme.global.selected.alpha === 'number') {
                return this.nodeTheme.global.selected.alpha;
            }
            else if (typeof this.nodeTheme.global.alpha === 'number') {
                return this.nodeTheme.global.alpha;
            }
            else {
                return 1;
            }
        }
        else {
            return 1;
        }
    }
}
export default Renderer;
