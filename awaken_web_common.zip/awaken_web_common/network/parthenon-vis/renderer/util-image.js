const ImageMap = {};
const ProcessedMap = {}; // 已经开始下载的图片库
export const drawCircleImage = (ctx, x, y, r, imageSrc) => {
    if (imgLoaded(imageSrc)) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(x, y, r, 0, 2 * Math.PI, false);
        ctx.clip();
        ctx.drawImage(ImageMap[imageSrc], x - r, y - r, r * 2, r * 2);
        ctx.closePath();
        ctx.restore();
    }
    else {
        loadImg(imageSrc);
    }
};
export const drawSquareImage = (ctx, x, y, w, h, imageSrc) => {
    if (imgLoaded(imageSrc)) {
        ctx.save();
        ctx.beginPath();
        ctx.rect(x - w / 2, y - h / 2, w, h);
        ctx.clip();
        ctx.drawImage(ImageMap[imageSrc], x - w / 2, y - h / 2, w, h);
        ctx.closePath();
        ctx.restore();
    }
    else {
        loadImg(imageSrc);
    }
};
const imgLoaded = (imgp) => {
    if (!imgp) {
        // console.warn(
        //     '你的node设置shape为circle-image或者image, 但是没有提供图片地址'
        // )
        return false;
    }
    else {
        return ImageMap.hasOwnProperty(imgp);
    }
};
const loadImg = (imgp) => {
    if (!ProcessedMap.hasOwnProperty(imgp)) {
        const img = new Image();
        img.src = imgp;
        ProcessedMap[imgp] = true;
        img.onload = () => {
            ImageMap[imgp] = img;
        };
    }
};
