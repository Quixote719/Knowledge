import { drawLabelOnLink } from './util-text';
const BASE_ARROW_SIZE = 1 / 4;
let linkStyles = {};

export const setLinkStyles = (value = {}) => {
    linkStyles = Object.assign({}, linkStyles, value)
}

const drawLink = (renderer, ctx, source, target, link, zoom = 1) => {
    linkStyles = renderer.getLinkStyles(source, target, link);
    const res = drawLinkCurve(ctx, source, target, link);
    if (res) {
        const textDesc = drawLabelOnLink({
            ctx,
            link,
            source,
            target,
            cx: res.x,
            cy: res.y,
            textColor: linkStyles.textColor,
            textBgColor: linkStyles.textBgColor,
            zoom,
        });
        return { textDesc };
    }
    else {
        return { textDesc: null };
    }
};
/**
 * 箭头分为以下几种情况:
 * 1. 有无虚线
 * 2. 是否指向自己
 * 3. 是否有箭头: 线段终止于箭头末端. 否则会在箭头头部看到线段
 * 4. 是否有弧形: 线段起始和终止位置不在点的圆心相连的线上.
 */
export const drawLinkCurve = (ctx, source, target, link, inEagleEye = false) => {
    if (link.dupIndex === undefined || link.dupTotal === undefined) {
        throw new Error('没有dupIndex或者dupTotal, 请在创建link后计算这些值');
    }
    if (link.dashed) {
        ctx.setLineDash([5, 3]);
    }
    if (source === target) {
        return drawSelfLink(ctx, link, source, inEagleEye);
    }
    const arrowSize = BASE_ARROW_SIZE * target.r;
    // 计算线段弧度时, 我们希望不管线段是从A -> B, 还是 B -> A, 计算弧度时总是从一个方向计算.
    // 因此若source id小于target id时, 我们交换起点和终点的顺序.
    let lineInfo;
    if (source.id > target.id) {
        const [sx, sy, tx, ty] = getLinkTwoEnds(source.x, source.y, target.x, target.y, source.r, target.r, link.dupIndex, link.dupTotal);
        lineInfo = drawLine(ctx, link, sx, sy, tx, ty, false, arrowSize, link.arrow, inEagleEye);
    }
    else {
        const [sx, sy, tx, ty] = getLinkTwoEnds(target.x, target.y, source.x, source.y, target.r, source.r, link.dupIndex, link.dupTotal);
        lineInfo = drawLine(ctx, link, sx, sy, tx, ty, true, arrowSize, link.arrow, inEagleEye);
    }
    if (link.arrow && source !== target) {
        drawArrow(ctx, lineInfo.x, lineInfo.y, lineInfo.angle, arrowSize);
    }
    return {
        x: lineInfo.textX,
        y: lineInfo.textY,
    };
};
const drawSelfLink = (ctx, link, node, inEagleEye = false) => {
    const r = node.r;
    const arrowSize = r * BASE_ARROW_SIZE;
    // 起始和终止角度
    const sa = (Math.PI * 7) / 6 - (link.dupIndex * Math.PI) / 24;
    const ea = (Math.PI * 3) / 2 + (link.dupIndex * Math.PI) / 24;
    const sx = node.x + r * Math.cos(sa);
    const sy = node.y + r * Math.sin(sa);
    // 弧形终点
    const ex = node.x + (r + 0.9 * arrowSize) * Math.cos(ea);
    const ey = node.y + (r + 0.9 * arrowSize) * Math.sin(ea);
    // 弧线中间点
    const interPointR = r * 1.3 + ((link.dupIndex + 1) * r) / 3;
    const ix = node.x + interPointR * Math.cos(sa / 2 + ea / 2);
    const iy = node.y + interPointR * Math.sin(sa / 2 + ea / 2);
    renderCurve(ctx, link, sx, sy, ix, iy, ex, ey, true, inEagleEye);
    // 三个相交点求出(sx, sy, ex, ey, cx, cy)
    drawArrow(ctx, ex + 0.1 * arrowSize * Math.cos(ea), ey + 0.1 * arrowSize * Math.sin(ea), ea, arrowSize);
};
const drawLine = (ctx, link, sx, sy, tx, ty, swapped, arrowSize, shouldDrawArrow, inEagleEye = false) => {
    if (link.dupTotal === 1 || link.dupIndex === (link.dupTotal + 1) / 2) {
        const angle = swapped
            ? getLineAngle(sx, sy, tx, ty) + Math.PI
            : getLineAngle(sx, sy, tx, ty);
        if (swapped && shouldDrawArrow) {
            sx += arrowSize * Math.cos(angle);
            sy += arrowSize * Math.sin(angle);
        }
        else if (shouldDrawArrow) {
            tx += arrowSize * Math.cos(angle);
            ty += arrowSize * Math.sin(angle);
        }
        renderStraightLine(ctx, link, sx, sy, tx, ty);
        return {
            x: swapped ? sx : tx,
            y: swapped ? sy : ty,
            angle,
            textX: sx / 2 + tx / 2,
            textY: sy / 2 + ty / 2,
        };
    }
    else {
        const res = getControlPointOnCurve(sx, sy, tx, ty, link.dupIndex, link.dupTotal);
        let txEnd = tx;
        let tyEnd = ty;
        let sxEnd = sx;
        let syEnd = sy;
        if (swapped && shouldDrawArrow) {
            sxEnd += arrowSize * Math.cos(res.angle2);
            syEnd += arrowSize * Math.sin(res.angle2);
        }
        else if (shouldDrawArrow) {
            txEnd += arrowSize * Math.cos(res.angle1);
            tyEnd += arrowSize * Math.sin(res.angle1);
        }
        const [cx, cy] = renderCurve(ctx, link, sxEnd, syEnd, res.x, res.y, txEnd, tyEnd, false, inEagleEye);
        const x = swapped ? sxEnd : txEnd;
        const y = swapped ? syEnd : tyEnd;
        const temp = (swapped ? res.angle2 : res.angle1) % (Math.PI * 2);
        return {
            angle: getCircleTangentAngle(cx, cy, x, y, temp),
            x,
            y,
            textX: res.x,
            textY: res.y,
        };
    }
};
/**
 * 求圆心为cx, cy的圆上一点x, y的切线角度. 取靠近similarAngle这个方向的角度
 */
const getCircleTangentAngle = (cx, cy, x, y, similarAngle) => {
    const tempA1 = (Math.PI / 2 + getLineAngle(cx, cy, x, y)) % (Math.PI * 2);
    const tempA2 = ((Math.PI / 2) * 3 + getLineAngle(cx, cy, x, y)) % (Math.PI * 2);
    // 不确定是a1还是a2, 取离temp更接近的那个angle
    const temp1Dist = Math.min(Math.min(Math.abs(tempA1 - similarAngle), Math.abs(tempA1 + Math.PI * 2 - similarAngle)), Math.abs(tempA1 - Math.PI * 2 - similarAngle));
    const temp2Dist = Math.min(Math.min(Math.abs(tempA2 - similarAngle), Math.abs(tempA2 + Math.PI * 2 - similarAngle)), Math.abs(tempA2 - Math.PI * 2 - similarAngle));
    return temp1Dist > temp2Dist ? tempA2 : tempA1;
};
const renderStraightLine = (ctx, link, sx, sy, tx, ty) => {
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(tx, ty);
    ctx.strokeStyle = linkStyles.lineColor;
    ctx.lineWidth = linkStyles.lineWidth || ( link.w ? link.w : 1)
    ctx.stroke();
    ctx.closePath();
    link.isCurve = false
    link.curve = null
};
const renderCurve = (ctx, link, x1, y1, x2, y2, x3, y3, biggerSide, inEagleEye = false) => {
    let a, b, c, d, e, f, x, y, r;
    a = 2 * (x2 - x1);
    b = 2 * (y2 - y1);
    c = x2 * x2 + y2 * y2 - x1 * x1 - y1 * y1;
    d = 2 * (x3 - x2);
    e = 2 * (y3 - y2);
    f = x3 * x3 + y3 * y3 - x2 * x2 - y2 * y2;
    x = (b * f - e * c) / (b * d - e * a);
    y = (d * c - a * f) / (b * d - e * a);
    r = Math.sqrt((x - x1) * (x - x1) + (y - y1) * (y - y1));
    ctx.lineWidth = linkStyles.lineWidth || ( link.w ? link.w : 1)
    ctx.strokeStyle = linkStyles.lineColor;
    const angle1 = getLineAngle(x1, y1, x, y);
    const angle2 = getLineAngle(x3, y3, x, y);
    const diff = Math.abs(angle1 - angle2);
    let clockWise = (angle1 < angle2 && diff < Math.PI) ||
        (angle1 > angle2 && diff > Math.PI);
    clockWise = biggerSide ? clockWise : !clockWise
    ctx.beginPath();
    ctx.arc(x, y, r, angle1, angle2, clockWise);
    ctx.stroke();
    ctx.closePath();
    if(!inEagleEye) {
        link.isCurve = true
        link.curve = {
            cx: x,
            cy: y,
            r,
            angle1,
            angle2,
            clockWise
        }
    }
    return [x, y];
};
const drawArrow = (ctx, tx, ty, angle, arrowSize) => {
    tx -= arrowSize * Math.cos(angle);
    ty -= arrowSize * Math.sin(angle);
    const arrowAngleHalf = Math.PI / 8;
    ctx.beginPath();
    ctx.fillStyle = linkStyles.lineColor;
    ctx.beginPath();
    ctx.moveTo(tx, ty);
    ctx.lineTo(tx + arrowSize * Math.cos(angle + arrowAngleHalf), ty + arrowSize * Math.sin(angle + arrowAngleHalf));
    ctx.lineTo(tx + arrowSize * Math.cos(angle - arrowAngleHalf), ty + arrowSize * Math.sin(angle - arrowAngleHalf));
    ctx.fill();
    ctx.closePath();
};
const getLineAngle = (sx, sy, tx, ty) => {
    if (sx === tx && ty > sy) {
        return -Math.PI / 2;
    }
    else if (sx === tx && ty < sx) {
        return +Math.PI / 2;
    }
    else if (tx < sx) {
        return Math.atan((ty - sy) / (tx - sx));
    }
    else if (tx >= sx) {
        return Math.atan((ty - sy) / (tx - sx)) + Math.PI;
    }
};
/**
 * 获取连接线的起始位置和终止位置.
 * 已知起点/终点位置, 两点之间连线数量以及此连接是第几个连接
 */
const getLinkTwoEnds = (sx, sy, tx, ty, sr, tr, dupIndex, dupTotal) => {
    const SGirth = sr * Math.PI * 2;
    const TGirth = tr * Math.PI * 2;
    // 当dupTotal很小时, 优先选用一个小的常数, 避免线段间隔过大.
    // dupTotal很大时, 线段间隔和dupTotal呈反比
    const sLinkInterval = Math.min((SGirth / 4) * 0.2, ((SGirth / 2) * 0.6) / (dupTotal - 1));
    const tLinkInterval = Math.min((TGirth / 4) * 0.2, ((TGirth / 2) * 0.6) / (dupTotal - 1));
    // 设source和target连线的与source相交于A, 连接线在source上起始于B, sDistOnCurve是A, B在source上走得长度
    const sDistOnCurve = -sLinkInterval * (dupIndex - (dupTotal + 1) / 2);
    const tDistOnCurve = tLinkInterval * (dupIndex - (dupTotal + 1) / 2);
    const sToTAngle = getLineAngle(sx, sy, tx, ty) + Math.PI;
    const tToAngle = getLineAngle(tx, ty, sx, sy) + Math.PI;
    // source圆心到B的线段角度
    const sToDistAngle = sToTAngle + sDistOnCurve / sr;
    const tToDistAngle = tToAngle + tDistOnCurve / tr;
    // return [sx, sy, tx, ty]
    return [
        sx + sr * Math.cos(sToDistAngle),
        sy + sr * Math.sin(sToDistAngle),
        tx + tr * Math.cos(tToDistAngle),
        ty + tr * Math.sin(tToDistAngle),
    ];
};
/**
 * 给连接线加上一些弧度
 */
const getControlPointOnCurve = (x1, y1, x2, y2, dupIndex, dupTotal, curveUp = -Math.PI / 20) => {
    const dist = Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
    curveUp = dupIndex - (dupTotal + 1) / 2 < 0 ? curveUp : -curveUp;
    const distFromSourceToControlP = dist / 2 / Math.cos(curveUp);
    const curveAngle1 = getLineAngle(x1, y1, x2, y2) + curveUp;
    const curveAngle2 = Math.PI + getLineAngle(x1, y1, x2, y2) - curveUp;
    const res = {
        x: x2 + distFromSourceToControlP * Math.cos(curveAngle1),
        y: y2 + distFromSourceToControlP * Math.sin(curveAngle1),
        angle1: curveAngle1,
        angle2: curveAngle2,
    };
    return res;
};
export default drawLink;
