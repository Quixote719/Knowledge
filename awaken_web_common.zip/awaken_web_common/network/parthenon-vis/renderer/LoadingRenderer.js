/**
 * Created by yaojia7 on 2020/5/19.
 */

const dots = ['', '.', '..', '...']
const text = '布局计算中'
let textWidth = null
export default function(canvas, ctx, chart, time){
    if(
        chart.animationCollection &&
        chart.animationCollection.isPlaying()
    // chart.layoutController &&
    // !chart.layoutController.isGlobalLayout
    ) {
        const {clientWidth, clientHeight} = canvas
        const x = .5 + clientWidth / 2
        const y = .5 + clientHeight / 4
        const d = (((time || Date.now()) / 3) % 720)

        ctx.lineCap = 'round'
        ctx.lineWidth = 3
        ctx.font = `500 14px Roboto`
        ctx.textBaseline = 'middle'
        ctx.beginPath()
        if (d < 360) {
            ctx.arc(x, y, 75, 0, d * 0.0174532925)
        }
        else {
            ctx.arc(x, y, 75, (d - 360) * 0.0174532925, 0)
        }
        if(!textWidth)
            textWidth = ctx.measureText(text)
        ctx.strokeStyle = ctx.fillStyle = '#cecece'
        ctx.stroke()
        ctx.closePath()
        ctx.fillText(text + dots[Math.floor(d / 180)], x - textWidth.width / 2, y)
    }

}
