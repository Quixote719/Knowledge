import util from './../util'

const roundRect = (ctx, x, y, w, h, r) => {
    ctx.beginPath()
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h,  x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath()
};

export const drawLabelOnLink = ({ ctx, cx, cy, zoom, link, source, target, textColor, textBgColor, }) => {
    if (link.t) {
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        // let fontSize = 8 + Math.sqrt(source.r / 2 + target.r / 2) * 1.5;
        let fontSize = 12;
        ctx.font = `${fontSize}px sans-serif`;
        const text = util.trancateText(link.t, 4)
        const textScale = link.tScale ? link.tScale : 1;
        let scale = 1
        if (fontSize * zoom * textScale < 16) {
            return;
        }
        if(!link.textWidth)
            link.textWidth = ctx.measureText(text).width;
        let textWidth = link.textWidth * textScale;
        if(link.maxFontSize < fontSize * zoom){
            scale = link.maxFontSize / fontSize / zoom
            textWidth *= scale
            fontSize = link.maxFontSize / zoom
        }
        fontSize = fontSize * textScale;

        const w = 56 * scale
        const h = 16 * scale
        const x = cx - w/2
        const y = cy - h/2
        link.labelContainer = null
        return {
            id: `link-${link.id}`,
            fontSize,
            text,
            textColor,
            textBgColor,
            sx: cx - textWidth / 2,
            sy: cy - fontSize / 2,
            ex: cx + textWidth / 2,
            ey: cy + fontSize / 2,
            labelContainer: { x, y, w, h },
            selected: link.selected || link.connToSelected,
            link
        };
    }
};
export const drawTextArr = (ctx, textDescArr, eleDescArr) => {
    eleDescArr.forEach((eleDesc) => {
        for (let i = textDescArr.length - 1; i >= 0; i--) {
            const textDesc = textDescArr[i];
            if (textDesc.id !== eleDesc.id && collide(textDesc, eleDesc)) {
                // 与元素冲突的文字不绘制
                textDescArr.splice(i, 1);
            }
        }
    });
    sortTextBySize(textDescArr);
    while (textDescArr.length > 0) {
        const currTextDesc = textDescArr.shift();
        drawText(ctx, currTextDesc);
        for (let i = textDescArr.length - 1; i >= 0; i--) {
            if (collide(textDescArr[i], currTextDesc)) {
                // 目前最大的文字和遍历的文字有冲突, 将遍历的文字从文字列表中删除
                textDescArr.splice(i, 1);
            }
        }
    }
};
/**
 * 真正绘制字体
 * description: {
 *   sx, sy, ex, ey
 *   fontSize, text
 * }
 */
const drawText = (ctx, description) => {
    if(description.labelContainer){
        const {x, y, w, h} = description.labelContainer
        //绘制 label 的背景框
        roundRect(ctx, x, y, w, h, h/2)
        ctx.fillStyle = description.textBgColor
        ctx.fill()
        description.link.labelContainer = description.labelContainer
    }

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.font = `${description.fontSize}px sans-serif`;
    ctx.fillStyle = description.textBgColor
        ? description.textBgColor
        : 'rgba(255,255,255,.0)';
    const textWidth = description.ex - description.sx;
    const x = description.sx / 2 + description.ex / 2;
    const y = description.sy / 2 + description.ey / 2;
    // ctx.fillRect(description.sx, description.sy, textWidth, description.fontSize);
    ctx.fillStyle = description.textColor ? description.textColor : 'black';
    ctx.fillText(description.text, x, y, textWidth);
};
const sortTextBySize = (textDescArr) => {
    textDescArr.sort((td1, td2) => {
        if(td1.selected)
            return -1
        if(td2.selected)
            return 1
        if (td1.fontSize < td2.fontSize) {
            return 1;
        }
        else if (td1.fontSize === td2.fontSize) {
            return 0;
        }
        else {
            return -1;
        }
    });
};
// 长方形定义为rect(min,max)
// min和max是二维点（x，y）组成
//
// 两个长方形a（mina，maxa）和b（minb，maxb）的交集c（minc，   maxc）满足
// minc.x   =   max(mina.x,   minb.x)
// minc.y   =   max(mina.y,   minb.y)
// maxc.x   =   min(maxa.x,   maxb.x)
// maxc.y   =   min(maxa.y,   maxb.y)
//
// 如果minc.x <maxc.x   &&   minc.y <maxc.y，也就是c有效，则表示a和b相交，相交的结果就是c，否则a和b不相交
const collide = (d1, d2) => {
    if(d1.selected && !d2.selected)
        return false

    const sx1 = d1.labelContainer ? d1.labelContainer.x : d1.sx
    const sy1 = d1.labelContainer ? d1.labelContainer.y : d1.sy
    const ex1 = d1.labelContainer ? (d1.labelContainer.x + d1.labelContainer.w) : d1.ex
    const ey1 = d1.labelContainer ? (d1.labelContainer.y + d1.labelContainer.h) : d1.ey
    const sx2 = d2.labelContainer ? d2.labelContainer.x : d2.sx
    const sy2 = d2.labelContainer ? d2.labelContainer.y : d2.sy
    const ex2 = d2.labelContainer ? (d2.labelContainer.x + d2.labelContainer.w) : d2.ex
    const ey2 = d2.labelContainer ? (d2.labelContainer.y + d2.labelContainer.h) : d2.ey
    const res = {};

    res.sx = Math.max(sx1, sx2);
    res.sy = Math.max(sy1, sy2);
    res.ex = Math.min(ex1, ex2);
    res.ey = Math.min(ey1, ey2);
    return res.sx < res.ex && res.sy < res.ey;
};
