import RenderUnitBase from './RenderUnitBase';
class BorderRenderer extends RenderUnitBase {
    constructor() {
        super(...arguments);
        this.getStyle = (node) => {
            return this.renderer.getResultByNodeState(node, this.style);
        };
        this.getAttribute = (node) => {
            return this.renderer.getResultByNodeState(node, this.attribute);
        };
        this.getPosition = (node) => {
            return this.renderer.getResultByNodeState(node, this.position);
        };
    }
    render(ctx, node) {
        const style = this.getStyle(node);
        //如果color不存在或者透明并且fillColor不存在或者透明，则放弃渲染
        if(
            (!style.color || style.color.length === 9 && style.color.endsWith('00'))
            &&
            (!style.fillColor || style.fillColor.length === 9 && style.fillColor.endsWith('00'))
        )
            return

        const attribute = this.getAttribute(node);
        const position = this.getPosition(node);
        if (attribute.visible) {
            const x = position.x;
            const y = position.y;
            let borderGradient = null
            let fillGradient = null

            ctx.beginPath();
            const LINEWIDTH = attribute.w;
            ctx.lineWidth = LINEWIDTH;
            if (attribute.isCircle) {
                const r = position.r;
                ctx.arc(x, y, r + LINEWIDTH / 2, 0, Math.PI * 2, false);
                if(Array.isArray(style.color)){
                    borderGradient = ctx.createLinearGradient(
                        x - r - LINEWIDTH / 2,
                        y - r - LINEWIDTH / 2,
                        x + r + LINEWIDTH / 2,
                        y + r + LINEWIDTH / 2
                    )
                    for(let c of style.color){
                        borderGradient.addColorStop(c.position, c.color)
                    }
                }
            }
            else {
                const w = position.w;
                const h = position.h;
                ctx.rect(x - w / 2, y - h / 2, w, h);
            }
            if (style.fillColor) {
                if(attribute.isCircle && Array.isArray(style.fillColor)){
                    const r = position.r
                    fillGradient = ctx.createLinearGradient(
                        x - r - LINEWIDTH / 2,
                        y - r - LINEWIDTH / 2,
                        x + r + LINEWIDTH / 2,
                        y + r + LINEWIDTH / 2
                    )
                    for(let c of style.fillColor){
                        fillGradient.addColorStop(c.position, c.color)
                    }
                }
                ctx.fillStyle = fillGradient || style.fillColor;
                ctx.fill();
            }
            ctx.strokeStyle = borderGradient || style.color;
            ctx.stroke();
            ctx.closePath();
        }
    }
    mouseInNode(node, mx, my) {
        const attribute = this.getAttribute(node);
        const position = this.getPosition(node);
        if (!attribute.visible) {
            return false;
        }
        else if (attribute.isCircle) {
            const x = position.x;
            const y = position.y;
            const r = position.r;
            return mx < x + r && mx > x - r && my < y + r && my > y - r;
        }
        else {
            const x = position.x;
            const y = position.y;
            const w = position.w;
            const h = position.h;
            return (mx > x - w / 2 &&
                mx < x + w / 2 &&
                my > y - h / 2 &&
                my < y + h / 2);
        }
    }
    nodeInRectangle(node, sx, sy, ex, ey) {
        const attribute = this.getAttribute(node);
        const position = this.getPosition(node);
        if (!attribute.visible) {
            return false;
        }
        else if (attribute.isCircle) {
            const x = position.x;
            const y = position.y;
            const r = position.r;
            return x + r > sx && x - r < ex && y + r > sy && y - r < ey;
        }
        else {
            const x = position.x;
            const y = position.y;
            const w = position.w;
            const h = position.h;
            return (x + w / 2 > sx &&
                x - w / 2 < ex &&
                y + h / 2 > sy &&
                y - h / 2 < ey);
        }
    }
    defaultPosition() {
        return {
            x: (node) => node.x,
            y: (node) => node.y,
            r: (node) => node.r,
            w: (node) => node.r * 2,
            h: (node) => node.r * 2,
        };
    }
    defaultStyle() {
        return {
            color: 'black',
        };
    }
    defaultAttribute() {
        return {
            visible: true,
            isCircle: true,
            w: 1,
            selected: {
                w: 2,
            },
        };
    }
}
export default BorderRenderer;
