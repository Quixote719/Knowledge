import RenderUnitBase from './RenderUnitBase';
class TextRenderer extends RenderUnitBase {
    constructor() {
        super(...arguments);
        this.getStyle = (node) => {
            return this.renderer.getResultByNodeState(node, this.style);
        };
        this.getAttribute = (node) => {
            return this.renderer.getResultByNodeState(node, this.attribute);
        };
        this.getPosition = (node) => {
            return this.renderer.getResultByNodeState(node, this.position);
        };
    }
    render(ctx, node, zoom) {
        const style = this.getStyle(node);
        const attribute = this.getAttribute(node);
        const position = this.getPosition(node);
        if (attribute.visible) {
            const t = attribute.text;
            if (t) {
                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';
                let defaultFontSize = 14;
                // let defaultFontSize = 8 + Math.sqrt(node.r) * 1;
                ctx.font = `${defaultFontSize}px sans-serif`;
                let textScale = attribute.tScale;
                if (!attribute.minFontSize &&
                    defaultFontSize * zoom * textScale < 16) {
                    return;
                }
                if(!node.textWidth)
                    node.textWidth = ctx.measureText(t).width;

                let textWidth = node.textWidth
                // 若设置了最小的fontSize, 这个fontSize不应该因为zoom变小而变小. 通过设置textScale让其看上去
                // 和设置的fontSize一样大
                if (attribute.minFontSize > defaultFontSize * zoom) {
                    textWidth *= attribute.minFontSize / defaultFontSize / zoom;
                    defaultFontSize = attribute.minFontSize;
                    textScale *= 1 / zoom;
                }
                if(attribute.maxFontSize < defaultFontSize * zoom){
                    textWidth *= attribute.maxFontSize / defaultFontSize / zoom
                    defaultFontSize = attribute.maxFontSize
                    textScale *= 1 / zoom
                }
                const fontSize = defaultFontSize * textScale;
                return {
                    id: node.id,
                    fontSize,
                    text: t,
                    textColor: style.textColor,
                    textBgColor: style.textBgColor,
                    sx: position.cx - textWidth / 2,
                    sy: position.cy - fontSize / 2,
                    ex: position.cx + textWidth / 2,
                    ey: position.cy + fontSize / 2,
                    selected: node.selected || node.connToSelected
                };
            }
        }
    }
    mouseInNode() {
        return false;
    }
    nodeInRectangle() {
        return false;
    }
    defaultPosition() {
        return {
            cx: (node) => node.x,
            cy: (node) => node.y + node.r + 12,
        };
    }
    defaultStyle() {
        return {
            textColor: 'black',
            textBgColor: 'white',
        };
    }
    defaultAttribute() {
        return {
            visible: true,
            text: (node) => node.t,
            tScale: 1,
            maxFontSize: 28
        };
    }
}
export default TextRenderer;
