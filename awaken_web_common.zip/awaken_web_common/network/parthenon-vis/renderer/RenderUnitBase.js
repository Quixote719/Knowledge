class RenderUnitBase {
    constructor(renderer, { defaultStyle = {}, defaultAttribute = {}, defaultPosition = {}, } = {
        defaultStyle: {},
        defaultAttribute: {},
        defaultPosition: {},
    }) {
        this.getStyle = (node) => {
            return this.renderer.getResultByNodeState(node, this.style);
        };
        this.getAttribute = (node) => {
            return this.renderer.getResultByNodeState(node, this.attribute);
        };
        this.getPosition = (node) => {
            return this.renderer.getResultByNodeState(node, this.position);
        };
        this.renderer = renderer;
        this.style = {};
        Object.assign(this.style, this.defaultStyle(), defaultStyle || {});
        this.attribute = {};
        Object.assign(this.attribute, this.defaultAttribute(), defaultAttribute || {});
        this.position = {};
        Object.assign(this.position, this.defaultPosition(), defaultPosition || {});
    }
    updateStyle(style = {}) {
        Object.assign(this.style, style);
    }
    updatePosition(position = {}) {
        Object.assign(this.position, position);
    }
    updateAttribute(attribute = {}) {
        Object.assign(this.attribute, attribute);
    }
    replaceStyle(style = {}) {
        this.style = style;
    }
    replacePositon(position = {}) {
        this.position = position;
    }
    replaceAttribute(attribute = {}) {
        this.attribute = attribute;
    }
}
export default RenderUnitBase;
