import RenderUnitBase from './RenderUnitBase';
import { drawCircleImage, drawSquareImage } from './util-image';
class ImageRenderer extends RenderUnitBase {
    constructor() {
        super(...arguments);
        this.getStyle = (node) => {
            return this.renderer.getResultByNodeState(node, this.style);
        };
        this.getAttribute = (node) => {
            return this.renderer.getResultByNodeState(node, this.attribute);
        };
        this.getPosition = (node) => {
            return this.renderer.getResultByNodeState(node, this.position);
        };
    }
    render(ctx, node) {
        const attribute = this.getAttribute(node);
        const position = this.getPosition(node);
        if (attribute.visible) {
            const x = position.x;
            const y = position.y;
            if (attribute.isCircle) {
                const r = position.r * 0.6;
                drawCircleImage(ctx, x, y, r, attribute.imageSrc);
            }
            else if (!attribute.isCircle) {
                const w = position.w;
                const h = position.h;
                drawSquareImage(ctx, x, y, w, h, attribute.imageSrc);
            }
        }
    }
    mouseInNode(node, mx, my) {
        const attribute = this.getAttribute(node);
        const position = this.getPosition(node);
        if (!attribute.visible) {
            return false;
        }
        else if (attribute.isCircle) {
            const x = position.x;
            const y = position.y;
            const r = position.r;
            return mx < x + r && mx > x - r && my < y + r && my > y - r;
        }
        else {
            const x = position.x;
            const y = position.y;
            const w = position.w;
            const h = position.h;
            return (mx > x - w / 2 &&
                mx < x + w / 2 &&
                my > y - h / 2 &&
                my < y + h / 2);
        }
    }
    nodeInRectangle(node, sx, sy, ex, ey) {
        const attribute = this.getAttribute(node);
        const position = this.getPosition(node);
        if (!attribute.visible) {
            return false;
        }
        else if (attribute.isCircle) {
            const x = position.x;
            const y = position.y;
            const r = position.r;
            return x + r > sx && x - r < ex && y + r > sy && y - r < ey;
        }
        else {
            const x = position.x;
            const y = position.y;
            const w = position.w;
            const h = position.h;
            return (x + w / 2 > sx &&
                x - w / 2 < ex &&
                y + h / 2 > sy &&
                y - h / 2 < ey);
        }
    }
    defaultPosition() {
        return {
            x: (node) => node.x,
            y: (node) => node.y,
            r: (node) => node.r,
        };
    }
    defaultStyle() {
        return {};
    }
    defaultAttribute() {
        return {
            visible: true,
            isCircle: true,
            imageSrc: (node) => node.imgp,
        };
    }
}
export default ImageRenderer;
