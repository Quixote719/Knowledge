const math = {
    // makes a full bb (x1, y1, x2, y2, w, h) from implicit params
    makeBoundingBox(bb) {
        if (bb === null || bb === undefined) {
            return {
                h: 0,
                w: 0,
                x1: Infinity,
                x2: -Infinity,
                y1: Infinity,
                y2: -Infinity,
            };
        }
        else {
            if (bb.x2 !== undefined &&
                bb.y2 !== undefined &&
                bb.x2 >= bb.x1 &&
                bb.y2 >= bb.y1) {
                return {
                    h: bb.y2 - bb.y1,
                    w: bb.x2 - bb.x1,
                    x1: bb.x1,
                    x2: bb.x2,
                    y1: bb.y1,
                    y2: bb.y2,
                };
            }
            else if (bb.w !== undefined &&
                bb.h !== undefined &&
                bb.w >= 0 &&
                bb.h >= 0) {
                return {
                    h: bb.h,
                    w: bb.w,
                    x1: bb.x1,
                    x2: bb.x1 + bb.w,
                    y1: bb.y1,
                    y2: bb.y1 + bb.h,
                };
            }
        }
    },
};
export default math;
