//gulpfile.js
const gulp = require('gulp')
const shell = require('gulp-shell')

gulp.task(
    'git:diff',
    shell.task(
        'git diff --name-status --cached HEAD > script/git_diff.log && cat script/git_diff.log >> diff.log'
    )
)
