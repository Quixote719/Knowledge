/**
 * Created by yaojia7 on 2019/11/18.
 */
module.exports = {
    presets: [
        [
            '@babel/preset-env',
            {
                targets: {
                    chrome: '56',
                    ie: '9',
                    node: 'current'
                },
                useBuiltIns: 'entry',
                corejs: 2,
                modules: false,
                debug: false
            }
        ],
        '@babel/preset-react'
    ],
    plugins: [
        '@babel/plugin-proposal-export-default-from',
        ['@babel/plugin-proposal-decorators', { legacy: true }],
        ['@babel/plugin-proposal-class-properties', { loose: true }]
    ],
    env: {
        test: {
            presets: [
                [
                    '@babel/preset-env',
                    {
                        targets: {
                            chrome: '56',
                            ie: '9',
                            node: 'current'
                        },
                        useBuiltIns: 'entry',
                        corejs: 2,
                        modules: false,
                        debug: false
                    }
                ]
            ],
            plugins: ['transform-es2015-modules-commonjs']
        }
    }
}
