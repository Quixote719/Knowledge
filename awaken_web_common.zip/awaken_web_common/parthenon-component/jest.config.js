module.exports = {
    setupFiles: ['<rootDir>/jest.setup.js'],
    transform: {
        '^.+\\.(css|less)?$':
            '<rootDir>/node_modules/jest-css-modules-transform',
        '^.+\\.(js|jsx)?$': 'babel-jest'
    },
    testPathIgnorePatterns: ['<rootDir>/res', '<rootDir>/server'],
    moduleFileExtensions: ['tsx', 'ts', 'less', 'js', 'json', 'jsx'],
    moduleNameMapper: {
        '^three-examples(.*)$': '<rootDir>/../../node_modules/three/examples$1',
        '^parthenon-lib(.*)$': '<rootDir>/../parthenon-lib/index.js$1',
        '^parthenonComponentAlgo(.*)$':
            '<rootDir>/../parthenon-component/src/AlgoComponent$1',
        '^parthenonComponent(.*)$': '<rootDir>/../parthenon-component/src$1',
        '^multiLayerMap(.*)$': '<rootDir>/../Multi-layer-map/src/Map$1',
        '^flowchart(.*)$': '<rootDir>/../flowchart$1',
        '^Bdnet(.*)$': '<rootDir>/../bdnet/src/$1',
        '^@res(.*)$': '<rootDir>/res$1',
        '.*worker$': '<rootDir>/__mocks__/webWorker.js',
        '\\.(jpg|jpeg|png|gif)$': '<rootDir>/__mocks__/file.js'
    }
}
