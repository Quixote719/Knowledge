/**
 * Created by yaojia7 on 2019/12/9.
 */
const fs = require('fs')
const path = require('path')
const execa = require('execa')
const shelljs = require('shelljs')

const getFilesFromDiffLog = async diffLogPath => {
    try {
        const res = await execa.shell(
            `cat ${diffLogPath}/diff.log | grep -E '^(M|A)'`
        )
        const lineBreak = res.stdout.includes('\r\n') ? '\r\n' : '\n'

        return Array.from(
            new Set(
                res.stdout
                    .split(lineBreak)
                    .map(f => f.split('\t')[1])
                    .filter(f => f.startsWith('src'))
                    .map(f => path.resolve(diffLogPath, f))
            )
        )
    } catch (e) {
        return []
    }
}

const cleanDiffLog = async diffLogPath => {
    await execa.shell(`echo > ${diffLogPath}/diff.log`)
}

const func = async () => {
    try {
        const projectPath = path.resolve(__dirname, '../')

        const changedFiles = await getFilesFromDiffLog(projectPath)

        if (changedFiles.length === 0) {
            await cleanDiffLog(projectPath)
            process.exit(0)
        }

        let res = await execa.shell(
            `jest --listTests --findRelatedTests ${changedFiles.join(' ')}`
        )

        let testFiles = res.stdout.split('\n').filter(f => !!f)

        console.log('unit test files: ')
        console.log(testFiles)

        if (testFiles.length === 0) {
            await cleanDiffLog(projectPath)
            process.exit(0)
        }

        testFiles = testFiles
            .map(f => path.relative(process.cwd(), f))
            .join(' ')

        shelljs.exec(`cd ${process.cwd()}`)
        res = shelljs.exec(`npm test ${testFiles}`)

        if (res.code === 1) process.exit(1)

        //成功执行完改变文件的单元测试之后，清空diff.log
        await cleanDiffLog(projectPath)
        process.exit(0)
    } catch (e) {
        console.error(e)
        process.exit(1)
    }
}

func()
