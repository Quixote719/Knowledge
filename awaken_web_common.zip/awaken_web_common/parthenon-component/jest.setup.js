/**
 * Created by yaojia7 on 2019/11/18.
 */
import React from 'react'
import { configure } from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'

React.useLayoutEffect = React.useEffect

configure({
    adapter: new Adapter()
})
