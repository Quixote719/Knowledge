import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import * as CommonParam from '../CommonParam'
import { getEvaluationOptionsByType } from '../util'

export default class Regression extends React.Component {
    getNewDescription = description => {
        // 处理隐藏项
        const { parentComp, hiddenOptions } = this.props
        let newDescription = Object.assign({}, description)
        for (const key of hiddenOptions) {
            if (
                newDescription.hasOwnProperty(key) &&
                parentComp.instanceString() === '集成模型训练'
            ) {
                const prevOption = newDescription[key].option
                newDescription[key].option = {
                    hiddenInBagging: true,
                    ...prevOption
                }
            }
        }
        return newDescription
    }

    // 回归
    getParamRenderDescription() {
        const details = {
            labelCol: CommonParam.evaluationLabelCol(),
            predictCol: CommonParam.evaluationPredictCol,
            metricItems: {
                type: 'Select',
                param: {
                    label: '模型评估指标',
                    options: getEvaluationOptionsByType('Regression'),
                    mode: 'multiple'
                }
            }
        }
        return this.getNewDescription(details)
    }
    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
            />
        )
    }
}
