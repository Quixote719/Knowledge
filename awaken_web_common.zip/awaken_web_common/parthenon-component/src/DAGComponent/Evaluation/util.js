export const evaluationMap = {
    acc: '准确率（Accuracy）',
    precision: '精度（Precision）',
    recall: '召回率（Recall）',
    f1: 'F值（F1-scores）',
    auc: 'AUC',
    hitRatioK: 'HR@K',
    confusionMatrix: '混淆矩阵',
    prCurveJson: 'PR曲线',
    rocCurveJson: 'ROC曲线',
    totalSample: 'Total Samples',
    dbi: 'DBI指标',
    mae: '平均绝对误差（MAE）',
    mse: '平均平方误差（MSE）',
    rmse: '均方根误差（RMSE）',
    mape: '平均百分比误差（MAPE）',
    rs: '决定系数（R-Square）'
}

const getEvaluationOptions = values => {
    return values.map(v => {
        return {
            value: v,
            label: evaluationMap.hasOwnProperty(v) ? evaluationMap[v] : v
        }
    })
}

export const getEvaluationOptionsByType = evaluationType => {
    const eType = evaluationType ? evaluationType.toLowerCase() : evaluationType
    switch (eType) {
        case 'classification':
            return getEvaluationOptions([
                'acc',
                'precision',
                'recall',
                'f1',
                'auc',
                'hitRatioK',
                'confusionMatrix',
                'prCurveJson',
                'rocCurveJson',
                'totalSample'
            ])
        case 'abnormity':
            return getEvaluationOptions(['auc', 'hitRatioK', 'totalSample'])
        case 'clustering':
            return getEvaluationOptions(['dbi', 'totalSample'])
        case 'regression':
            return getEvaluationOptions([
                'mae',
                'mse',
                'rmse',
                'mape',
                'rs',
                'totalSample'
            ])
        case 'timeSeries':
            return getEvaluationOptions(['mae', 'mse', 'rmse', 'totalSample'])
        default:
            return []
    }
}
