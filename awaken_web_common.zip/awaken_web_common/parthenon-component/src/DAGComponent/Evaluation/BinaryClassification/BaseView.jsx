import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import { composeCompSaveState } from '../../../AlgoComponent/common'
import * as CommonParam from '../CommonParam'
import { getEvaluationOptionsByType } from '../util'

const METRIC_ITEM_DISABLED_OPTIONS = [
    'auc',
    'hitRatioK',
    'prCurveJson',
    'rocCurveJson'
]

export default class BinaryClassification extends React.Component {
    constructor(props) {
        super(props)
        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {}
            }
        }
    }

    getNewDescription = description => {
        // 处理隐藏项
        const { parentComp, hiddenOptions = [] } = this.props
        let newDescription = Object.assign({}, description)

        for (const key of hiddenOptions) {
            if (
                newDescription.hasOwnProperty(key) &&
                parentComp.instanceString() === '集成模型训练'
            ) {
                const prevOption = newDescription[key].option
                newDescription[key].option = {
                    hiddenInBagging: true,
                    ...prevOption
                }
            }
        }
        return newDescription
    }
    getMetricItemsOptions = () => {
        const { isSubComponent } = this.props
        let metricItemsOptions = getEvaluationOptionsByType('Classification')
        if (isSubComponent) {
            metricItemsOptions = metricItemsOptions.filter(
                opt => opt.value !== 'confusionMatrix'
            )
        }
        return metricItemsOptions
    }

    handlePredictProbabilityColChange = paramToSave => {
        const { instanceParams, onSave } = this.props
        const { metricItems = [] } = instanceParams
        const { predictProbabilityCol } = paramToSave
        // 预测概率列未选时，将评估指标中不允许选择却被选择的指标清空
        let newParamToSave = paramToSave
        if (
            (!predictProbabilityCol || predictProbabilityCol.length <= 0) &&
            metricItems.find(item =>
                METRIC_ITEM_DISABLED_OPTIONS.includes(item)
            )
        ) {
            newParamToSave.metricItems = metricItems.filter(
                item => !METRIC_ITEM_DISABLED_OPTIONS.includes(item)
            )
        }

        onSave(newParamToSave, this.saveCompState)
    }
    // 二分类
    getParamRenderDescription() {
        const { instanceParams } = this.props
        const description = {
            labelCol: CommonParam.evaluationLabelCol(),
            predictCol: CommonParam.evaluationPredictCol,
            predictProbabilityCol: CommonParam.evaluationRedictProbabilityCol({
                isRequired: false,
                paramState: this.state.params.state['predictProbabilityCol'],
                onSave: this.handlePredictProbabilityColChange
            }),
            positiveSampleValue: CommonParam.positiveSampleValue,
            kHitRadio: {
                type: 'Input',
                param: {
                    label: 'HR@K对应的k值',
                    isRequired: false,
                    isPositiveInteger: true,
                    min: {
                        value: 1,
                        include: true
                    },
                    max: {
                        value: 10000,
                        include: true
                    }
                }
            },
            metricItems: {
                type: 'Select',
                param: {
                    label: '模型评估指标',
                    options: this.getMetricItemsOptions(),
                    disabledOptions:
                        !instanceParams.predictProbabilityCol ||
                        instanceParams.predictProbabilityCol.length <= 0
                            ? METRIC_ITEM_DISABLED_OPTIONS
                            : [],
                    mode: 'multiple'
                }
            }
        }
        return this.getNewDescription(description)
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
            />
        )
    }
}
