import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import * as CommonParam from '../CommonParam'
import { getEvaluationOptionsByType } from '../util'

export default class TimeSeries extends React.Component {
    // 时序
    getParamRenderDescription() {
        return {
            labelCol: CommonParam.evaluationLabelCol(),
            predictCol: CommonParam.evaluationPredictCol,
            metricItems: {
                type: 'Select',
                param: {
                    label: '模型评估指标',
                    options: getEvaluationOptionsByType('TimeSeries'),
                    mode: 'multiple'
                }
            }
        }
    }
    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
            />
        )
    }
}
