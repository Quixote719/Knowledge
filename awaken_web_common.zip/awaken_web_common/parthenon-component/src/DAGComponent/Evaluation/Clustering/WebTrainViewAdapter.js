export default {
    renderProps: (props, instance) => {
        return {
            ...props,
            isFeatureMatch: instance.isFeatureMatch(),
            matchTable: instance.getMatchTable(),
        }
    },
}
