import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import * as CommonParam from '../CommonParam'
import { getEvaluationOptionsByType } from '../util'

export default class Abnormity extends React.Component {
    // 异常
    getParamRenderDescription() {
        return {
            labelCol: CommonParam.evaluationLabelCol(),
            predictCol: CommonParam.evaluationPredictCol,
            predictProbabilityCol: CommonParam.evaluationRedictProbabilityCol(),
            positiveSampleValue: CommonParam.positiveSampleValue,
            kHitRadio: {
                type: 'Input',
                param: {
                    label: 'HR@K对应的k值',
                    isRequired: false,
                    isPositiveInteger: true,
                    min: {
                        value: 1,
                        include: true
                    },
                    max: {
                        value: 10000,
                        include: true
                    }
                }
            },
            metricItems: {
                type: 'Select',
                param: {
                    label: '模型评估指标',
                    options: getEvaluationOptionsByType('Abnormity'),
                    mode: 'multiple'
                }
            }
        }
    }
    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
            />
        )
    }
}
