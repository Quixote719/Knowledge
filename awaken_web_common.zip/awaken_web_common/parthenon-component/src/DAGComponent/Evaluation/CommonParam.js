// 评估器标签列
export const evaluationLabelCol = (opts = {}) => {
    const { hiddenInBagging = true } = opts
    return {
        type: 'FieldSelect',
        param: {
            label: '原始标签列',
            isSelectMulti: false,
            allowedTypes: ['genericNumericCols', 'string'],
            portIndex: 1
        },
        option: {
            hiddenInBagging
        }
    }
}

// 评估器预测列
export const evaluationPredictCol = {
    type: 'FieldSelect',
    param: {
        label: '预测标签列',
        isSelectMulti: false,
        allowedTypes: ['genericNumericCols', 'string'],
        portIndex: 1
    }
}

// 评估器概率列
export const evaluationRedictProbabilityCol = (param = {}) => {
    return {
        type: 'FieldSelect',
        param: {
            label: '预测概率列',
            isSelectMulti: false,
            allowedTypes: ['genericNumericCols', 'string', 'vector'],
            portIndex: 1,
            ...param
        }
    }
}

// 评估器预测列
export const positiveSampleValue = {
    type: 'Input',
    param: {
        label: '正样本标签值',
        //isPositiveInteger: true,
        isNumber: true
    }
}
