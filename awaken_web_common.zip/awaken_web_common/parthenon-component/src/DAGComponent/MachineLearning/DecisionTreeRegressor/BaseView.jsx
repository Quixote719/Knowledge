import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import { getParamRenderDescription } from '../util'

export default class DecisionTreeRegressor extends React.Component {
    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={getParamRenderDescription(
                    'DecisionTreeRegressor'
                )}
            />
        )
    }
}
