import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import WrappedFieldSelection from '../../../AlgoComponent/wrappedBasicComponent/WrappedFieldSelection'
import { mapToTuple } from '../../../AlgoComponent/transformHelper'
import { getParamRenderDescription } from '../util'

export default class ARIMA extends React.Component {
    handleSelectOrderCol = selectedColumns => {
        const orderByCols = []
        const orderByASC = []
        selectedColumns = selectedColumns || []
        selectedColumns.forEach(col => {
            orderByCols.push(col.name)
            orderByASC.push(col.order)
        })
        return {
            orderByCols,
            orderByASC,
        }
    }

    renderOrderCols = () => {
        const { instanceParams, isLocked, inputSchema, onSave } = this.props
        const allColumns = inputSchema[0] || []
        const selectedColumns = mapToTuple({
            name: instanceParams.orderByCols,
            order: instanceParams.orderByASC,
        })

        return (
            <WrappedFieldSelection
                instanceParams={instanceParams}
                isLocked={isLocked}
                label="排序字段"
                attrName="orderByCols"
                isRequired={false}
                allColumns={allColumns}
                selectedColumns={selectedColumns}
                additionalParams={[
                    {
                        title: '排序',
                        paramName: 'order',
                        inputType: 'dropdown',
                        defaultValue: true,
                        options: [
                            { text: '升序', value: true },
                            { text: '降序', value: false },
                        ],
                    },
                ]}
                onSelectFields={this.handleSelectOrderCol}
                onSave={onSave}
            />
        )
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={getParamRenderDescription('ARIMA')}
                renderPieces={{
                    orderByCols: this.renderOrderCols(),
                }}
            />
        )
    }
}
