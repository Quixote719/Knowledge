import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import * as CommonParam from '../CommonParam'
import { getParamRenderDescription } from '../util'

export default class DecisionTreeClassifier extends React.Component {
    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={getParamRenderDescription(
                    'DecisionTreeClassifier'
                )}
            />
        )
    }
}
