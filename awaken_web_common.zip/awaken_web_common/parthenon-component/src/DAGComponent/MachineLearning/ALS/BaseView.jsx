import React from 'react'
import { Form, Input, Radio } from 'antd'
import ConfigComponent from '../../ConfigComponent'
import * as CommonParam from '../CommonParam'
import {
    getFormItemState,
    composeCompSaveState
} from '../../../AlgoComponent/common'
import {
    minValidator,
    maxValidator,
    IntegerValidator
} from '../../../AlgoComponent/inputValidator'

import { getParamRenderDescription } from '../util'
import styles from './BaseView.less'

const FormItem = Form.Item
const RadioGroup = Radio.Group

const CHECK_POINT_UNENABLE_VALUE = -1
const CHECK_POINT_ENABLE_DEFAULT_VALUE = 10

class ALS extends React.Component {
    constructor(props) {
        super(props)
        this.saveComponentState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {}
            }
        }
    }

    handleCheckPointEnableChange = e => {
        const { onSave, instanceParams, form } = this.props

        if (e.target.value === true) {
            const lastCheckPointInterval = instanceParams.checkpointInterval
            const currCheckPointInterval =
                lastCheckPointInterval === CHECK_POINT_UNENABLE_VALUE
                    ? CHECK_POINT_ENABLE_DEFAULT_VALUE
                    : lastCheckPointInterval

            form.setFieldsValue({ checkpointInterval: currCheckPointInterval })
            onSave(
                {
                    checkpointInterval: currCheckPointInterval
                },
                this.saveComponentState
            )
        } else {
            form.setFieldsValue({
                checkpointInterval: CHECK_POINT_UNENABLE_VALUE
            })
            onSave(
                {
                    checkpointInterval: CHECK_POINT_UNENABLE_VALUE
                },
                this.saveComponentState
            )
        }
    }

    handleCheckPointIntervalChange = () => {
        this.saveComponentState({ checkpointInterval: null }, 'init')
    }

    handleCheckPointIntervalSave = e => {
        const { form, onSave, instanceParams } = this.props
        const { validateFields } = form
        const value = e.target.value
        const attrName = 'checkpointInterval'

        validateFields(Object.keys({ [attrName]: value }), {}, err => {
            if (err) {
                form.setFieldsValue({
                    [attrName]: instanceParams[attrName]
                })
            } else {
                onSave(
                    {
                        [attrName]: Number(value)
                    },
                    this.saveComponentState
                )
            }
        })
    }

    renderCheckpointInterval() {
        const { instanceParams, isLocked } = this.props
        const checkpointEnabled =
            instanceParams.checkpointInterval !== CHECK_POINT_UNENABLE_VALUE
        const readOnly = !checkpointEnabled
        const { form } = this.props
        const { getFieldDecorator } = form
        return (
            <FormItem
                label="checkpoint间隔"
                required={false}
                {...getFormItemState(
                    this.state.params.state['checkpointInterval']
                )}
                className={styles.groupFormItem}>
                <RadioGroup
                    name="checkpointEnabled"
                    value={checkpointEnabled}
                    onChange={this.handleCheckPointEnableChange}
                    disabled={isLocked}>
                    <Radio key="open" value={true}>
                        开启
                    </Radio>
                    <Radio key="close" value={false}>
                        关闭
                    </Radio>
                </RadioGroup>
                {getFieldDecorator('checkpointInterval', {
                    initialValue: instanceParams.checkpointInterval,
                    rules: [
                        IntegerValidator({ message: '输入必须是整数' }),
                        minValidator({
                            message: '输入必须大于0',
                            min: 0,
                            include: false
                        }),
                        maxValidator({
                            message: '输入必须小于等于20',
                            max: 20,
                            include: true
                        })
                    ]
                })(
                    <Input
                        onChange={this.handleCheckPointIntervalChange}
                        onBlur={this.handleCheckPointIntervalSave}
                        onPressEnter={e => {
                            e.target.blur()
                        }}
                        disabled={isLocked || readOnly}
                    />
                )}
            </FormItem>
        )
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={getParamRenderDescription('ALS', this.props)}
                renderPieces={{
                    checkpointInterval: this.renderCheckpointInterval()
                }}
            />
        )
    }
}

export default Form.create()(ALS)
