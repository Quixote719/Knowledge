export const featuresCol = {
    type: 'FieldSelect',
    param: {
        label: '特征列选择',
        numericCols: true
    }
}

export const labelCol = {
    type: 'FieldSelect',
    param: {
        label: '标签列选择',
        isSelectMulti: false,
        numericCols: true
    },
    option: {
        hiddenInBagging: true
    }
}

export const maxDepth = (min, max) => {
    return {
        type: 'Input',
        param: {
            label: `单棵树最大深度 [${min},${max}]`,
            min: { value: min, include: true },
            max: { value: max, include: true },
            isInteger: true
        }
    }
}

export const minInstancesPerNode = () => {
    const min = { value: 1, include: true }
    const max = { value: 1000, include: true }

    return {
        type: 'Input',
        param: {
            label: `叶节点最少样本数 ${getRange(min, max)}`,
            min,
            max,
            isPositiveInteger: true
        }
    }
}

export const featureSubsetStrategy = {
    type: 'Select',
    param: {
        label: '训练特征数量选择',
        options: ['all', 'sqrt', 'log2']
    }
}

export const maxBins = (advancedOption = true) => {
    const min = { value: 2, include: true }
    const max = { value: 5000, include: true }

    return {
        type: 'Input',
        param: {
            label: `特征最大分裂数 ${getRange(min, max)}`,
            min,
            max,
            isPositiveInteger: true
        },
        option: {
            advancedOption
        }
    }
}

export const seed = (opts = {}) => {
    const { hidden = false, noRangeInGridSearch = true } = opts
    return {
        type: 'Input',
        param: {
            label: '随机种子',
            isRequired: false,
            isInteger: true
        },
        option: {
            hidden,
            noRangeInGridSearch
        }
    }
}

export const maxIter = (opts = {}) => {
    const { min, max, isRequired = true } = opts
    return {
        type: 'Input',
        param: {
            label: `最大迭代次数 ${getRange(min, max)}`,
            min,
            max,
            isInteger: true,
            isRequired
        }
    }
}

export const regParam = (opts = {}) => {
    const { min, precision, isRequired = true } = opts
    return {
        type: 'Input',
        param: {
            label: `正则化参数 ${getRange(min)}`,
            min,
            isRequired,
            precision
        }
    }
}

export const initMode = {
    type: 'Select',
    param: {
        options: ['random', 'k-means||']
    }
}

export const initSteps = (opts = {}) => {
    const { min, isRequired = true, advancedOption, hidden } = opts

    return {
        type: 'Input',
        param: {
            label: `k-means||模式的初始化步数 ${getRange(min)}`,
            min,
            isInteger: true,
            isRequired
        },
        option: {
            advancedOption,
            hidden
        }
    }
}

export const lossType = {
    type: 'Select',
    param: {
        label: '损失函数类型',
        options: ['logistic', 'exponential']
    }
}

export const tol = (opts = {}) => {
    const { advancedOption } = opts
    return {
        type: 'Input',
        param: {
            label: '收敛精度 (0,1]',
            min: { value: 0, include: false },
            max: { value: 1, include: true }
        },
        option: {
            advancedOption
        }
    }
}

export const getRange = (min, max) => {
    if (!min && !max) {
        return ''
    } else if (min && !max) {
        const minSymbol = min.include ? '>=' : '>'
        return minSymbol + min.value
    } else if (max && !min) {
        const maxSymbol = min.include ? '<=' : '<'
        return maxSymbol + max.value
    } else {
        const minSymbol = min.include ? '[' : '('
        const maxSymbol = max.include ? ']' : ')'
        return `${minSymbol}${min.value}, ${max.value}${maxSymbol}`
    }
}
