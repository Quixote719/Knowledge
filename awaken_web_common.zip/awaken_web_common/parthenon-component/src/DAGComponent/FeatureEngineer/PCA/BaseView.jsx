import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import {
    getFormItemState,
    composeCompSaveState,
} from '../../../AlgoComponent/common'
import { Form, Input, Tooltip, Icon } from 'antd'
import {
    minValidator,
    maxValidator,
    IntegerValidator,
} from '../../../AlgoComponent/inputValidator'
import { saveInput } from '../../util'

const FormItem = Form.Item

class PCA extends React.Component {
    constructor(props) {
        super(props)
        this.saveCompState = composeCompSaveState(this)
        this.saveInput = saveInput.bind(this)
        this.state = {
            params: {
                state: {},
            },
        }
    }

    getParamRenderDescription() {
        return {
            inputCol: {
                type: 'FieldSelect',
                param: {
                    label: '特征列字段',
                    numericCols: true,
                },
            },
            appendCols: {
                type: 'FieldSelect',
                param: {
                    label: '附加列字段',
                },
            },
            k: {
                option: {
                    byConcreteRenderer: true,
                },
            },
        }
    }

    handleKChange = () => {
        this.saveCompState({ k: null }, 'init')
    }

    handleKSave = e => {
        this.saveInput('k', e.target.value)
    }

    renderParamValidation = () => {
        const { instanceParams } = this.props
        const inputcolLength = instanceParams.inputCol
            ? instanceParams.inputCol.length
            : 0
        if (inputcolLength >= instanceParams.k) return null

        return (
            <Tooltip
                placement="right"
                title={`主成分个数应该小于或等于特征列长度: ${inputcolLength}`}
            >
                <div
                    style={{
                        position: 'relative',
                        top: -3,
                        display: 'inline-block',
                        verticalAlign: 'middle',
                    }}
                >
                    <Icon
                        type="exclamation-circle-o"
                        style={{
                            marginLeft: 10,
                            marginTop: 10,
                            color: '#fa4646',
                            transform: 'scale(1.2)',
                        }}
                    />
                </div>
            </Tooltip>
        )
    }

    renderPCANum = () => {
        const { form, instanceParams, isLocked } = this.props
        const { getFieldDecorator } = form
        const defaultValue = instanceParams.k
        const inputcolLength = instanceParams.inputCol
            ? instanceParams.inputCol.length
            : 0
        return (
            <FormItem
                label={
                    <span>
                        <span>{`主成分个数 <=特征列长度(${inputcolLength})`}</span>
                        {this.renderParamValidation()}
                    </span>
                }
                colon={false}
                required
                {...getFormItemState(this.state.params.state.k)}
            >
                {getFieldDecorator('k', {
                    initialValue: defaultValue,
                    rules: [
                        { message: '必填', required: true },
                        IntegerValidator({
                            message: '输入必须是整数',
                        }),
                        minValidator({
                            message: '输入必须大于0',
                            min: 0,
                            include: false,
                        }),
                        maxValidator({
                            message: `主成分个数必须小于等于特征列的长度(${inputcolLength})`,
                            max: inputcolLength,
                            include: true,
                        }),
                    ],
                })(
                    <Input
                        onChange={this.handleKChange}
                        onBlur={this.handleKSave}
                        onPressEnter={e => {
                            e.target.blur()
                        }}
                        disabled={isLocked}
                    />
                )}
            </FormItem>
        )
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
                renderPieces={{
                    k: this.renderPCANum(),
                }}
            />
        )
    }
}

export default Form.create()(PCA)
