import React from 'react'
import ConfigComponent from '../../ConfigComponent'

export default class FeatureDiscretizerTransformer extends React.Component {
    getParamRenderDescription() {
        return {
            featuresCol: {
                type: 'FieldSelect',
                param: {
                    label: '特征列选择',
                    genericNumericCols: true
                }
            },
            discretizerType: {
                type: 'Select',
                param: {
                    label: '离散方法',
                    options: [
                        { value: 'EqualWidth', label: '等宽' },
                        { value: 'EqualFrequency', label: '等频' }
                    ]
                }
            },
            discretizerNum: {
                type: 'Input',
                param: {
                    label: '离散区间数 [2, 100]',
                    min: { value: 2, include: true },
                    max: { value: 100, include: true },
                    isInteger: true
                }
            },
            keepColsBool: {
                type: 'Checkbox',
                param: {
                    label: <span>保留原始列 (衍生列以"discrete_字段"命名)</span>
                }
            }
        }
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
            />
        )
    }
}
