import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import { getSelectableColumns } from '../../util'

export default class FeatureSelectTransformer extends React.Component {
    getParamRenderDescription() {
        const { instanceParams, inputSchema } = this.props
        const oldInputSchema = inputSchema ? inputSchema[0] : []
        const selectedFeaturesCol = instanceParams.featuresCol
            ? instanceParams.featuresCol.slice()
            : []
        const selectedLabelCol = instanceParams.labelCol
            ? instanceParams.labelCol.slice()
            : []
        const selectedAdditionCol = instanceParams.additionCol
            ? instanceParams.additionCol.slice()
            : []

        return {
            featuresCol: {
                type: 'FieldSelect',
                param: {
                    label: '特征列选择',
                    genericNumericCols: true,
                    selectableColumns: getSelectableColumns(
                        oldInputSchema,
                        selectedLabelCol.concat(selectedAdditionCol)
                    )
                }
            },
            labelCol: {
                type: 'FieldSelect',
                param: {
                    label: '标签列选择',
                    isSelectMulti: false,
                    selectableColumns: getSelectableColumns(
                        oldInputSchema,
                        selectedFeaturesCol.concat(selectedAdditionCol)
                    )
                },
                option: {
                    hiddenInBagging: true
                }
            },
            additionCol: {
                type: 'FieldSelect',
                param: {
                    label: '附加列选择',
                    isRequired: false,
                    selectableColumns: getSelectableColumns(
                        oldInputSchema,
                        selectedFeaturesCol.concat(selectedLabelCol)
                    )
                }
            },
            option: {
                type: 'Select',
                param: {
                    label: '特征选择方法',
                    options: [{ value: 'variance', label: '方差' }]
                }
            },
            topN: {
                type: 'Input',
                param: {
                    label: 'topN >0',
                    min: { value: 0, include: false },
                    isInteger: true
                }
            }
        }
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
            />
        )
    }
}
