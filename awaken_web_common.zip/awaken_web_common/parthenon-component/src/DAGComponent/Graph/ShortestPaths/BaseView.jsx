import React from 'react'
import { Form } from 'antd'
import ConfigComponent from '../../ConfigComponent'
import * as CommonParam from '../CommonParam'
import WrappedInput from '../../../AlgoComponent/wrappedBasicComponent/WrappedInput'

class ShortestPaths extends React.Component {
    handleLandMarkSave = (values, saveCompState) => {
        const originalValue = values.landmarks || ''
        const { onSave } = this.props
        onSave(
            {
                landmarks: originalValue.split(','),
            },
            saveCompState
        )
    }

    handleEndMarkSave = (values, saveCompState) => {
        const originalValue = values.endmarks || ''
        const { onSave } = this.props
        onSave(
            {
                endmarks: originalValue.split(','),
            },
            saveCompState
        )
    }

    renderLandMarks = () => {
        const { instanceParams, isLocked, form } = this.props
        return (
            <WrappedInput
                isRequired
                form={form}
                instanceParams={instanceParams}
                isLocked={isLocked}
                form={this.props.form}
                label="查询终点ID 多ID间以逗号分隔"
                attrName="landmarks"
                onSave={this.handleLandMarkSave}
            />
        )
    }

    renderEndMarks = () => {
        const { instanceParams, isLocked, form } = this.props
        return (
            <WrappedInput
                form={form}
                instanceParams={instanceParams}
                isLocked={isLocked}
                form={this.props.form}
                label="查询起点ID 多ID间以逗号分隔"
                attrName="endmarks"
                onSave={this.handleEndMarkSave}
            />
        )
    }

    getParamRenderDescription() {
        return {
            srcIdCol: CommonParam.srcIdCol,
            dstIdCol: CommonParam.dstIdCol,
            edgeWeightCol: CommonParam.edgeWeightCol,
            vertexIdCol: CommonParam.vertexIdCol,
            landmarks: {
                option: {
                    byConcreteRenderer: true,
                },
            },
            endmarks: {
                option: {
                    byConcreteRenderer: true,
                },
            },
        }
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
                renderPieces={{
                    landmarks: this.renderLandMarks(),
                    endmarks: this.renderEndMarks(),
                }}
            />
        )
    }
}

export default Form.create()(ShortestPaths)
