import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import * as CommonParam from '../CommonParam'

export default class PageRank extends React.Component {
    getParamRenderDescription() {
        return {
            srcIdCol: CommonParam.srcIdCol,
            dstIdCol: CommonParam.dstIdCol,
            edgeWeightCol: CommonParam.edgeWeightCol,
            vertexIdCol: CommonParam.vertexIdCol,
            tol: CommonParam.tol,
            maxIter: CommonParam.maxIter(0, 200),
            resetPro: CommonParam.resetPro
        }
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
            />
        )
    }
}
