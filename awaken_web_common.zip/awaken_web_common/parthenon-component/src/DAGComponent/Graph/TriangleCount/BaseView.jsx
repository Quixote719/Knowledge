import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import * as CommonParam from '../CommonParam'

export default class TriangleCount extends React.Component {
    getParamRenderDescription() {
        return {
            srcIdCol: CommonParam.srcIdCol,
            dstIdCol: CommonParam.dstIdCol,
            vertexIdCol: CommonParam.vertexIdCol,
        }
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
            />
        )
    }
}
