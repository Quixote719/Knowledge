import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import * as CommonParam from '../CommonParam'

export default class ConnectedComponents extends React.Component {
    getParamRenderDescription() {
        return {
            srcIdCol: CommonParam.srcIdCol,
            dstIdCol: CommonParam.dstIdCol,
            vertexIdCol: CommonParam.vertexIdCol,
            maxIter: CommonParam.maxIter(0, 100),
        }
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
            />
        )
    }
}
