export const srcIdCol = {
    type: 'FieldSelect',
    param: {
        label: '边表：起点列',
        allowedTypes: ['String', 'Integer', 'Int', 'Bigint'],
        warnTips: [
            '“边表：起点列”、“边表：终点列”和“点表：节点列”三项类型需相同'
        ],
        isSelectMulti: false
    }
}

export const dstIdCol = {
    type: 'FieldSelect',
    param: {
        label: '边表：终点列',
        allowedTypes: ['String', 'Integer', 'Int', 'Bigint'],
        warnTips: [
            '“边表：起点列”、“边表：终点列”和“点表：节点列”三项类型需相同'
        ],
        isSelectMulti: false
    }
}

export const edgeWeightCol = {
    type: 'FieldSelect',
    param: {
        label: '边表：边权重列',
        isRequired: false,
        allowedTypes: ['Double'],
        isSelectMulti: false
    }
}

export const vertexIdCol = {
    type: 'FieldSelect',
    param: {
        label: '点表：节点列',
        portIndex: 1,
        isRequired: false,
        allowedTypes: ['String', 'Integer', 'Int', 'Bigint'],
        warnTips: [
            '“边表：起点列”、“边表：终点列”和“点表：节点列”三项类型需相同'
        ],
        isSelectMulti: false
    }
}

export const maxIter = (min, max, isRequired = true) => {
    return {
        type: 'Input',
        param: {
            label: `最大迭代次数 (${min}, ${max}]`,
            min: { value: min, include: false },
            max: { value: max, include: true },
            isInteger: true,
            isRequired
        }
    }
}

export const maxInnerIter = {
    type: 'Input',
    param: {
        label: '最大内迭代次数 (0, 100]',
        min: { value: 0, include: false },
        max: { value: 100, include: true },
        isInteger: true
    }
}

export const moduTol = {
    type: 'Input',
    param: {
        label: '模块度收敛阈值 [0, 1]',
        min: { value: 0, include: true },
        max: { value: 1, include: true }
    }
}

export const ratioTol = {
    type: 'Input',
    param: {
        label: '社区节点更改比例收敛阈值 [0, 1]',
        min: { value: 0, include: true },
        max: { value: 1, include: true }
    }
}

export const noProgressCounter = {
    type: 'Input',
    param: {
        label: '社区节点更改比例收敛阈值的轮次上限 (0, 100]',
        min: { value: 0, include: false },
        max: { value: 100, include: true },
        isInteger: true
    }
}

export const direction = {
    type: 'Select',
    param: {
        label: '方向',
        options: ['Both', 'In', 'Out'],
        mode: 'multiple'
    }
}

export const tol = {
    type: 'Input',
    param: {
        label: '收敛阈值 (0, 1)',
        min: { value: 0, include: false },
        max: { value: 1, include: false }
    }
}

export const resetPro = {
    type: 'Input',
    param: {
        label: '重置概率 (0, 1)',
        min: { value: 0, include: false },
        max: { value: 1, include: false }
    }
}
