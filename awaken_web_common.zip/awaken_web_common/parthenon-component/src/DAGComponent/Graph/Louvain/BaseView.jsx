import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import * as CommonParam from '../CommonParam'

export default class Louvain extends React.Component {
    getParamRenderDescription() {
        return {
            srcIdCol: CommonParam.srcIdCol,
            dstIdCol: CommonParam.dstIdCol,
            edgeWeightCol: CommonParam.edgeWeightCol,
            vertexIdCol: CommonParam.vertexIdCol,
            maxIter: CommonParam.maxIter(0, 100),
            maxInnerIter: CommonParam.maxInnerIter,
            moduTol: CommonParam.moduTol,
            ratioTol: CommonParam.ratioTol,
            noProgressCounter: CommonParam.noProgressCounter,
        }
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
            />
        )
    }
}
