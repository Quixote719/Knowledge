import React from 'react'
import { Form } from 'antd'
import ConfigComponent from '../../ConfigComponent'
import * as CommonParam from '../CommonParam'
import WrappedInput from '../../../AlgoComponent/wrappedBasicComponent/WrappedInput'
import {
    minValidator,
    maxValidator,
} from '../../../AlgoComponent/inputValidator'

class SVDPlusPlus extends React.Component {
    /**
     * 评分下限。小于评分上限
     */
    renderMinVal() {
        const { instanceParams, isLocked, form, onSave } = this.props
        return (
            <WrappedInput
                isRequired
                label="评分下限 >=0"
                isLocked={isLocked}
                form={form}
                attrName="minVal"
                isNumber
                onSave={onSave}
                instanceParams={instanceParams}
                rules={[
                    maxValidator({
                        message: '评分上限必须大于下限',
                        max: instanceParams.maxVal,
                        include: false,
                    }),
                    minValidator({
                        message: '评分下限必须大于等于0',
                        min: 0,
                        include: true,
                    }),
                ]}
            />
        )
    }

    /**
     * 评分上限。大于评分上限
     */
    renderMaxVal() {
        const { instanceParams, isLocked, form, onSave } = this.props
        return (
            <WrappedInput
                isRequired
                label="评分上限"
                isLocked={isLocked}
                form={form}
                onSave={onSave}
                attrName="maxVal"
                isNumber
                instanceParams={instanceParams}
                rules={[
                    minValidator({
                        message: '评分上限必须大于下限',
                        min: instanceParams.minVal,
                        include: false,
                    }),
                ]}
            />
        )
    }

    getParamRenderDescription() {
        return {
            srcIdCol: CommonParam.srcIdCol,
            dstIdCol: CommonParam.dstIdCol,
            edgeWeightCol: CommonParam.edgeWeightCol,
            vertexIdCol: CommonParam.vertexIdCol,
            rank: {
                type: 'Input',
                param: {
                    label: '向量维度 (0, 100]',
                    min: { value: 0, include: false },
                    max: { value: 100, include: true },
                    isInteger: true,
                },
            },
            maxIter: CommonParam.maxIter(0, 100),
            minVal: {
                option: {
                    byConcreteRenderer: true,
                },
            },
            maxVal: {
                option: {
                    byConcreteRenderer: true,
                },
            },
            gamma1: {
                type: 'Input',
                param: {
                    label: 'gamma1 (0,1) (b*梯度下降学习速率)',
                    min: { value: 0, include: false },
                    max: { value: 1, include: false },
                },
            },
            gamma2: {
                type: 'Input',
                param: {
                    label: 'gamma2 (0,1) (q,p,y梯度下降学习速率)',
                    min: { value: 0, include: false },
                    max: { value: 1, include: false },
                },
            },
            gamma6: {
                type: 'Input',
                param: {
                    label: 'gamma6 (0,1) (b*正则系数)',
                    min: { value: 0, include: false },
                    max: { value: 1, include: false },
                },
            },
            gamma7: {
                type: 'Input',
                param: {
                    label: 'gamma7 (0,1) (q,p,y正则系数)',
                    min: { value: 0, include: false },
                    max: { value: 1, include: false },
                },
            },
        }
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
                renderPieces={{
                    maxVal: this.renderMaxVal(),
                    minVal: this.renderMinVal(),
                }}
            />
        )
    }
}

export default Form.create()(SVDPlusPlus)
