import React from 'react'
import ConfigComponent from '../../ConfigComponent'

export default class DataNormalization extends React.Component {
    getParamRenderDescription() {
        const { instanceParams } = this.props

        const res = {
            inputCol: {
                type: 'FieldSelect',
                param: {
                    label: '选择字段',
                    allowedTypes: ['double', 'int', 'integer', 'decimal'],
                    portIndex: 0,
                },
            },
            standardMethod: {
                type: 'RadioGroup',
                param: {
                    label: '计算方式',
                    options: ['MaxMin', 'Zscore'],
                },
            },
        }

        if (instanceParams.standardMethod === 'MaxMin') {
            res.max = {
                type: 'Input',
                param: {
                    label: '最大值',
                    min: { value: instanceParams.min, include: false },
                },
            }
            res.min = {
                type: 'Input',
                param: {
                    label: '最小值',
                    max: { value: instanceParams.max, include: false },
                },
            }
        } else if (instanceParams.standardMethod === 'Zscore') {
            res.mean = {
                type: 'Input',
                param: {
                    label: '平均值',
                    isNumber: true,
                },
            }
            res.variance = {
                type: 'Input',
                param: {
                    label: '方差 >0',
                    min: { value: 0, include: false },
                },
            }
        }

        res.keepColsBool = {
            type: 'Checkbox',
            param: {
                label: <span>保留原列 (衍生列以"normalized_字段"命名)</span>,
            },
        }

        return res
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
            />
        )
    }
}
