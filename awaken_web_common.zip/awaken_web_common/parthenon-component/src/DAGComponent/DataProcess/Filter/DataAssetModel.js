export default {
    compType: '过滤筛选',

    initParams: () => {
        return {
            whereExpr: '',
            isDistinct: false,
            distinctColumns: [],
            distinctStrategy: 'KEEP_HEAD',
            isNeedStatistic: false,
            pickedColumns: [
                /**
                 * inputColumnName,
                 * ouptutColumnName
                 * columnType
                 * columnDesc
                 */
            ],
        }
    },
}
