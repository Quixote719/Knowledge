export default {
    viewDataToModelData: res => {
        if (res.hasOwnProperty('outputCols')) {
            res.outputCols = res.outputCols.map(col => col.name)
        }
        if (res.hasOwnProperty('filterCols')) {
            res.filterCols = res.filterCols.map(col => col.name)
        }
        return res
    },
}
