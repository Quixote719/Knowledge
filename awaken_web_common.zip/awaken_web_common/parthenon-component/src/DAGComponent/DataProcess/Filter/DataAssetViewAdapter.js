import React from 'react'
import { EditableCell } from './../../../DataAssetComponent/EditableCell'

export default {
    viewDataToModelData: (param, props) => {
        const { data, transformTypeInvert } = props
        const { inputList, params } = data
        const res = {}
        for (let key in param) {
            let value = param[key]
            switch (key) {
                case 'filterType': {
                    key = 'isDistinct'
                    value = value === 'dropDuplicates'
                    break
                }
                case 'filterStrategy': {
                    key = 'distinctStrategy'
                    break
                }
                case 'statement': {
                    key = 'whereExpr'
                    break
                }
                case 'filterCols': {
                    key = 'distinctColumns'
                    value = value.map(f => ({
                        inputColumnName: f.name,
                        outputColumnName: f.name,
                        columnType: f.type
                    }))
                    break
                }
                case 'outputCols': {
                    key = 'pickedColumns'
                    value = value.map(f => ({
                        inputColumnName: f.name,
                        outputColumnName: f.name,
                        columnType: transformTypeInvert(
                            inputList[0].fields.find(
                                field => field.fieldName === f.name
                            ).fieldType
                        ),
                        columnDesc: f.description
                    }))
                    break
                }
                default:
                    break
            }
            res[key] = value
            if (key == 'pickedColumns') {
                res['distinctColumns'] = params.distinctColumns.filter(df =>
                    value.find(f => f.outputColumnName == df.outputColumnName)
                )
            }
        }

        return res
    },

    modelDataToViewData: props => {
        const { data } = props
        const {
            distinctStrategy,
            distinctColumns,
            isDistinct,
            whereExpr,
            pickedColumns
        } = data.params
        return {
            filterType: isDistinct ? 'dropDuplicates' : 'no_dropDuplicates',
            filterStrategy: distinctStrategy,
            statement: whereExpr,
            outputCols: pickedColumns.map(c => ({
                name: c.outputColumnName,
                description: c.columnDesc
            })),
            filterCols: distinctColumns.map(c => c.outputColumnName)
        }
    },

    inputSchemaTransform: inputSchema => {
        const res = {}
        for (let k in inputSchema) {
            res[k] = inputSchema[k].map(f => ({
                name: f.fieldName,
                type: f.fieldType,
                description: f.fieldDesc
            }))
        }
        return res
    },

    renderProps: defaultProps => {
        return {
            ...defaultProps,
            autoFocus: false,
            groupByType: false,
            additionalParams: [
                {
                    title: '字段描述',
                    paramName: 'description',
                    inputType: 'textInput',
                    defaultValue: record => record.description,
                    isOutputCol: false,
                    Comp: ({ value, onSave }) => (
                        <EditableCell
                            value={value}
                            type="desc"
                            max="40"
                            onSave={onSave}
                        />
                    )
                }
            ]
        }
    }
}
