import React from 'react'
import { Form, Radio } from 'antd'
import PropTypes from 'prop-types'

import SelectFields from '../../../AlgoComponent/Shared/SelectFields'
import CodeEditor from '../../../AlgoComponent/Shared/CodeEditor'
import { mapToTuple } from '../../../AlgoComponent/transformHelper'
import {
    getFormItemState,
    validateThenSave
} from '../../../AlgoComponent/common'

import ParamSaveState from '../../../AlgoComponent/Shared/ParamSaveState'

import styles from './BaseView.less'

const FormItem = Form.Item
const RadioGroup = Radio.Group

class Filter extends React.Component {
    static defaultProps = {
        autoFocus: false,
        groupByType: true
    }

    static propTypes = {
        instanceParams: PropTypes.shape({
            filterType: PropTypes.string,
            filterStrategy: PropTypes.string,
            statement: PropTypes.string,
            filterCols: PropTypes.array,
            outputCols: PropTypes.array
        }),
        isLocked: PropTypes.bool,
        inputSchema: PropTypes.shape({
            0: PropTypes.array
        }),
        additionalParams: PropTypes.arrayOf(
            PropTypes.shape({
                title: PropTypes.string.isRequired,
                paramName: PropTypes.string.isRequired,
                inputType: PropTypes.string.isRequired, //textInput或者dropdown
                defaultValue: PropTypes.oneOfType([
                    PropTypes.string,
                    PropTypes.func
                ]).isRequired,
                isOutputCol: PropTypes.boolean,
                Comp: PropTypes.func, //用户自定义的渲染组件
                options: PropTypes.arrayOf({
                    value: PropTypes.string.isRequired,
                    text: PropTypes.string.isRequired
                })
            })
        ),
        udfList: PropTypes.arrayOf(PropTypes.string),
        groupByType: PropTypes.bool,
        onSave: PropTypes.func,
        autoFocus: PropTypes.bool
    }

    constructor(props) {
        super(props)
        this.getFormItemState = getFormItemState.bind(this)
        this.validateThenSave = validateThenSave.bind(this)
        this.editorSqlValue = this.props.instanceParams.statement
        this.focusChangeTime = +new Date() // 记录codeMirror聚焦的时间戳
        this.updateValueTimeout = null // 更新sql语句的定时器

        this.state = {
            params: {
                state: {}
            }
        }
    }

    handleSaveParams = params => {
        this.validateThenSave(params, this.props.onSave)
    }

    getEditorVal = () => {
        return this.refs['FilterCodeEditor'].CodeMirrorEditor.doc.getValue()
    }

    handleFocusChange = focused => {
        /**
         * 为解决：出现自动提示下拉菜单时，光标选择某一项提示，提示内容却不能显示在sql编辑框内
         * 原因：光标点击自动提示下拉菜单时，光标发生了变化，整个回调的过程是：focusChange(此时为focus值为false,因为它没有聚焦在编辑框中，而在下拉菜单中)→ focusChange（此时为focus值为true）→ valueChange
         *
         */
        const prevFocusTime = this.focusChangeTime
        const currFocusTime = +new Date()
        this.focusChangeTime = currFocusTime
        const time = 50
        // 短时间focus状态改变，我把它视为选择了自动提示下拉菜单的动作，此时不更新sql
        if (prevFocusTime && currFocusTime - prevFocusTime <= time) {
            clearTimeout(this.updateValueTimeout)
            return false
        }

        // 更新图标状态
        if (focused) {
            this.setState({
                params: {
                    state: {
                        ...this.state.params.state,
                        statement: 'init'
                    }
                }
            })
        }

        const EditorVal = this.getEditorVal()
        if (this.editorSqlValue !== EditorVal) {
            this.updateValueTimeout = setTimeout(() => {
                // 更新sql语句值
                this.editorSqlValue = EditorVal
                // 提交保存
                if (!focused) {
                    this.handleSaveParams({
                        statement: EditorVal
                    })
                }
            }, time)
        }
    }

    renderFilterStrategy = () => {
        const filterStrategy = this.props.instanceParams.filterStrategy
        return (
            <FormItem
                label="去重策略"
                required
                {...getFormItemState(this.state.params.state.filterStrategy)}>
                <RadioGroup
                    name="filterStrategy"
                    defaultValue={filterStrategy}
                    onChange={e => {
                        this.handleSaveParams({
                            filterStrategy: e.target.value
                        })
                    }}
                    disabled={this.props.isLocked}>
                    <Radio value={'first_keep'}>首行保留</Radio>
                    <Radio value={'last_keep'}>尾行保留</Radio>
                </RadioGroup>
            </FormItem>
        )
    }

    renderFilterType = () => {
        const filterType = this.props.instanceParams.filterType
        return (
            <FormItem
                label="是否去重"
                required
                {...getFormItemState(this.state.params.state.filterType)}>
                <RadioGroup
                    name="filterType"
                    defaultValue={filterType}
                    onChange={e => {
                        const value = e.target.value
                        const params = { filterType: value }
                        if (value == 'no_dropDuplicates') params.filterCols = []
                        this.handleSaveParams(params)
                    }}
                    disabled={this.props.isLocked}>
                    <Radio value={'no_dropDuplicates'}>不去重</Radio>
                    <Radio value={'dropDuplicates'}>去重</Radio>
                </RadioGroup>
            </FormItem>
        )
    }

    renderStatement = () => {
        const { udfList } = this.props

        const attrName = 'statement'
        const defaultValue = this.props.instanceParams[attrName]
        const autocompleteWords = {}

        const t0Schema = this.props.inputSchema[0]
        const t0Cols = t0Schema.map(col => {
            return {
                displayText: `${col.name}(${col.type})`,
                text: col.name
            }
        })
        if (t0Cols.length > 0) autocompleteWords['*'] = t0Cols

        if (udfList) {
            for (let udf of udfList.filter(u => u.length > 1))
                autocompleteWords[udf] = []
        }
        // console.log('isLocked:', this.props.isLocked);

        return (
            <FormItem label="过滤条件" className={styles.whereExprItem}>
                <ParamSaveState
                    {...getFormItemState(this.state.params.state[attrName])}
                />
                <p className={styles.editorHint}>1. 本组件不做语法校验</p>
                <p className={styles.editorHint}>
                    2. 请输入where后的过滤表达式
                </p>
                <p className={styles.editorHint}>3. 输入'*.'可以查看所有字段</p>
                <CodeEditor
                    ref={'FilterCodeEditor'}
                    autoFocus={this.props.autoFocus}
                    defaultTable={'*'}
                    disabled={this.props.isLocked}
                    autocompleteWords={autocompleteWords}
                    defaultSqlValue={defaultValue}
                    onChangeCallback={() => {}}
                    onFocusChange={this.handleFocusChange}
                />
            </FormItem>
        )
    }

    /**
     * 获取去重字段的所有输入字段。
     */
    getFilterColAllCols = () => {
        const { outputCols } = this.props.instanceParams
        const allCols = this.props.inputSchema[0]

        if (Array.isArray(outputCols) && typeof outputCols[0] === 'object') {
            const cols = []
            outputCols.forEach(f => {
                const col = allCols.find(ff => ff.name === f.name)
                if (col) {
                    cols.push({
                        ...f,
                        type: (col && col.type) || ''
                    })
                }
            })
            return cols

            // return outputCols.map(f => ({
            //     ...f,
            //     type: allCols.find(ff => ff.name === f.name).type || ''
            // }))
        } else if (Array.isArray(outputCols)) {
            return allCols.filter(f => outputCols.includes(f.name))
        } else {
            return []
        }
    }

    /**
     * 渲染去重标识字段。在选择去重后才会渲染该组件
     * 注意选择范围是保留字段中的字段
     */
    renderFilterCols = () => {
        const { filterCols } = this.props.instanceParams

        return (
            <FormItem
                label={'去重标识字段'}
                required
                {...getFormItemState(this.state.params.state.filterCols)}>
                <SelectFields
                    buttonText="选择"
                    onSelectFields={selectedColumns =>
                        this.handleSaveParams({
                            filterCols: selectedColumns
                        })
                    }
                    allColumns={this.getFilterColAllCols()}
                    selectedColumns={filterCols || []}
                    isSelectMulti={true}
                    groupByType={this.props.groupByType}
                    disabled={this.props.isLocked}
                />
            </FormItem>
        )
    }

    renderKeepCols = () => {
        const allColumns = this.props.inputSchema[0]
        const { outputCols } = this.props.instanceParams
        let selectedColumns
        if (Array.isArray(outputCols) && typeof outputCols[0] === 'string') {
            selectedColumns = mapToTuple({
                name: this.props.instanceParams.outputCols
            })
        } else if (
            Array.isArray(outputCols) &&
            typeof outputCols[0] === 'object'
        ) {
            selectedColumns = outputCols
        } else {
            selectedColumns = []
        }

        const additionalParams = this.props.additionalParams || []

        return (
            <FormItem
                label={'保留字段'}
                required
                {...getFormItemState(this.state.params.state.outputCols)}>
                <SelectFields
                    buttonText="选择"
                    onSelectFields={selectedColumns =>
                        this.handleSaveParams({
                            outputCols: selectedColumns
                        })
                    }
                    allColumns={allColumns}
                    selectedColumns={selectedColumns}
                    isSelectMulti={true}
                    disabled={this.props.isLocked}
                    groupByType={this.props.groupByType}
                    additionalParams={additionalParams}
                />
            </FormItem>
        )
    }

    render() {
        return (
            <div style={{ width: '100%' }}>
                {this.renderKeepCols()}
                {this.renderStatement()}
                {this.renderFilterType()}
                {this.props.instanceParams.filterType === 'dropDuplicates' &&
                    this.renderFilterCols()}
                {/* {this.instanceParams.filterType === 'dropDuplicates' &&
                    this.renderFilterStrategy()} */}
            </div>
        )
    }
}

export default Form.create()(Filter)
