/**
 * Created by yaojia7 on 2019/6/20.
 */
import React, { useState } from 'react'
import CodeEditor from '../../../AlgoComponent/Shared/CodeEditor'
import styles from './BaseView.less'

export default class extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            flag: false
        }
        this.focusChangeTime = +new Date() // 记录codeMirror聚焦的时间戳
        this.updateValueTimeout = null // 更新sql语句的定时器
    }

    getEditorVal = () => {
        return this.refs['FilterCodeEditor'].CodeMirrorEditor.doc.getValue()
    }

    handleFocusChange = focused => {
        const { onBlur, defaultValue } = this.props
        /**
         * 为解决：出现自动提示下拉菜单时，光标选择某一项提示，提示内容却不能显示在sql编辑框内
         * 原因：光标点击自动提示下拉菜单时，光标发生了变化，整个回调的过程是：focusChange(此时为focus值为false,因为它没有聚焦在编辑框中，而在下拉菜单中)→ focusChange（此时为focus值为true）→ valueChange
         *
         */
        const prevFocusTime = this.focusChangeTime
        const currFocusTime = +new Date()
        this.focusChangeTime = currFocusTime
        const time = 50
        // 短时间focus状态改变，我把它视为选择了自动提示下拉菜单的动作，此时不更新sql
        if (prevFocusTime && currFocusTime - prevFocusTime <= time) {
            clearTimeout(this.updateValueTimeout)
            return false
        }

        const EditorVal = this.getEditorVal()
        this.updateValueTimeout = setTimeout(() => {
            // 提交保存
            if (!focused) {
                onBlur(EditorVal.replace('*.', ''))
                this.setState({ flag: this.state.flag })
            }
        }, time)
    }

    render() {
        const { autocompleteWords, defaultValue, onBlur, isLocked } = this.props
        return (
            <div style={{ width: '100%' }}>
                <p className={styles.editorHint}>请输入where后的过滤表达式</p>
                <CodeEditor
                    ref={'FilterCodeEditor'}
                    autoFocus={false}
                    defaultTable={'*'}
                    disabled={isLocked}
                    autocompleteWords={autocompleteWords}
                    defaultSqlValue={defaultValue}
                    onChangeCallback={() => {}}
                    onFocusChange={this.handleFocusChange}
                />
            </div>
        )
    }
}
