/**
 * Created by yaojia7 on 2018/11/14.
 */
import React from 'react'
import memoize from 'memoize-one'
import { Menu, Modal, Table, Input, Icon, message } from 'antd'
import { deepCopy, addClass, delClass } from 'parthenon-lib'
import { EditableCell } from './../../../DataAssetComponent/EditableCell'
import InputFieldsTable from '../../../DataAssetComponent/FieldsTable'
import styles from './BaseView.less'
import {
    genFixedColumn,
    filterFieldList
} from '../../../DataAssetComponent/utils'

export default class extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            filterWords: '',
            targetTable: 'left', // 'left' | 'right' 当前设置的是左表还是右表
            leftOutputFields: [],
            rightOutputFields: [],
            lastLeftOutputFields: [],
            lastRightOutputFields: []
        }
        this.modified = false
        this.OUTPUT_COLUMNS = [
            {
                key: 'action',
                dataIndex: 'action',
                title: '',
                width: 32,
                render: (text, record, index) => {
                    return (
                        <Icon
                            type="delete"
                            onClick={() => {
                                const {
                                    targetTable,
                                    leftOutputFields,
                                    rightOutputFields
                                } = this.state
                                const outputFields =
                                    targetTable === 'left'
                                        ? leftOutputFields
                                        : rightOutputFields
                                if (outputFields[index]) {
                                    outputFields.splice(index, 1)
                                    if (targetTable === 'left')
                                        this.setState({
                                            leftOutputFields: [...outputFields]
                                        })
                                    else
                                        this.setState({
                                            rightOutputFields: [...outputFields]
                                        })
                                    this.modified = true
                                }
                            }}
                        />
                    )
                }
            },
            genFixedColumn('inputFieldName', 'inputFieldName', '字段名', 100),
            genFixedColumn('fieldType', 'fieldType', '字段类型', 100),
            {
                key: 'fieldName',
                dataIndex: 'fieldName',
                title: '输出名',
                width: 120,
                render: (text, record, index) => (
                    <EditableCell
                        value={text}
                        type="name"
                        max={40}
                        onSave={value => {
                            const {
                                targetTable,
                                leftOutputFields,
                                rightOutputFields
                            } = this.state
                            const outputFields =
                                targetTable === 'left'
                                    ? leftOutputFields
                                    : rightOutputFields

                            if (
                                outputFields.find(
                                    (f, i) =>
                                        i !== index &&
                                        f.fieldName.toLowerCase() ===
                                            value.toLowerCase()
                                )
                            ) {
                                message.error('输出字段名重复')
                                return
                            }
                            if (outputFields[index]) {
                                outputFields[index].fieldName = value
                                if (targetTable === 'left')
                                    this.setState({
                                        leftOutputFields: [...outputFields]
                                    })
                                else
                                    this.setState({
                                        rightOutputFields: [...outputFields]
                                    })
                                this.modified = true
                            }
                        }}
                    />
                )
            }
        ]
        if (this.props.enableDesc)
            this.OUTPUT_COLUMNS.push({
                key: 'fieldDesc',
                dataIndex: 'fieldDesc',
                title: '字段描述',
                width: 100,
                render: (text, record, index) => (
                    <EditableCell
                        value={text}
                        type="desc"
                        max={40}
                        onSave={value => {
                            const {
                                targetTable,
                                leftOutputFields,
                                rightOutputFields
                            } = this.state
                            const outputFields =
                                targetTable === 'left'
                                    ? leftOutputFields
                                    : rightOutputFields
                            if (outputFields[index]) {
                                outputFields[index].fieldDesc = value
                                if (targetTable === 'left')
                                    this.setState({
                                        leftOutputFields: [...outputFields]
                                    })
                                else
                                    this.setState({
                                        rightOutputFields: [...outputFields]
                                    })
                                this.modified = true
                            }
                        }}
                    />
                )
            })
        this.tableZoneDom = null
    }

    static getDerivedStateFromProps(props, state) {
        let nextState = null
        if (props.leftOutputFields !== state.lastLeftOutputFields) {
            if (!nextState) nextState = {}
            nextState.leftOutputFields = deepCopy(props.leftOutputFields)
            nextState.lastLeftOutputFields = props.leftOutputFields
        }
        if (props.rightOutputFields !== state.lastRightOutputFields) {
            if (!nextState) nextState = {}
            nextState.rightOutputFields = deepCopy(props.rightOutputFields)
            nextState.lastRightOutputFields = props.rightOutputFields
        }
        return nextState
    }

    // componentDidUpdate() {
    //     if (this.tableZoneDom) {
    //         const trList = this.tableZoneDom.querySelectorAll(
    //             `.${styles.tableRow}`
    //         )
    //         if (trList.length > 0) {
    //             const trParent = trList[0].parentElement
    //
    //             trParent.addEventListener(
    //                 'dragover',
    //                 this.handleDragOver,
    //                 false
    //             )
    //
    //             trParent.addEventListener(
    //                 'dragenter',
    //                 this.handleDragEnter,
    //                 false
    //             )
    //
    //             trParent.addEventListener(
    //                 'dragleave',
    //                 this.handleDragLeave,
    //                 false
    //             )
    //
    //             trParent.addEventListener('drop', this.handleDrop, false)
    //
    //             trList.forEach(dom => {
    //                 if (dom.getAttribute('draggable') !== 'true')
    //                     dom.setAttribute('draggable', 'true')
    //                 dom.removeEventListener(
    //                     'dragstart',
    //                     this.handleDragStart,
    //                     false
    //                 )
    //                 dom.addEventListener(
    //                     'dragstart',
    //                     this.handleDragStart,
    //                     false
    //                 )
    //             })
    //         }
    //     }
    // }

    //拖拽中释放鼠标时，先根据释放事件target所在tr的classList[1]即该行输入字段id获取字段的index，
    //然后与draggedFieldId字段的index进行互换
    handleDrop = e => {
        e.preventDefault()
        const trDom = e.target.parentElement
        const targetFieldId = trDom.classList[1]
        const { targetTable, leftOutputFields, rightOutputFields } = this.state

        const outputFields =
            targetTable === 'left'
                ? [...leftOutputFields]
                : [...rightOutputFields]
        const dragIndex = outputFields.findIndex(
            f => f.inputFieldName === this.draggedFieldId
        )
        const targetIndex = outputFields.findIndex(
            f => f.inputFieldName === targetFieldId
        )
        if (dragIndex > -1 && targetIndex > -1 && dragIndex !== targetIndex) {
            const draggedField = outputFields[dragIndex]
            outputFields.splice(dragIndex, 1)
            outputFields.splice(targetIndex, 0, draggedField)
            if (targetTable === 'left')
                this.setState({ leftOutputFields: outputFields })
            else this.setState({ rightOutputFields: outputFields })
            this.modified = true
        }

        this.tableZoneDom
            .querySelectorAll(`.${styles.hoverRow}`)
            .forEach(dom => delClass(dom, styles.hoverRow))
    }

    //table-body绑定dragEnter事件，触发时记录触发target tr字段的id
    handleDragEnter = e => {
        e.preventDefault()
        const trDom = e.target.parentElement
        addClass(trDom, styles.hoverRow)
    }

    handleDragLeave = e => {
        e.preventDefault()
        const trDom = e.target.parentElement
        delClass(trDom, styles.hoverRow)
    }

    handleDragOver = e => {
        e.preventDefault()
    }

    handleDragStart = e => {
        this.draggedFieldId = e.target.classList[1]
    }

    handleSave = () => {
        if (!this.props.disabled) {
            const { leftOutputFields, rightOutputFields } = this.state
            if (this.modified) {
                this.props.onSave(leftOutputFields, rightOutputFields)
            } else { // 未修改时也可能点击确认，此时只需关闭弹框即可
                this.handleCancel()
            }
            // this.modified &&
            //     this.props.onSave(leftOutputFields, rightOutputFields)
        }
    }

    handleCancel = () => {
        this.setState({
            leftFilterWords: '',
            rightFilterWords: ''
        })
        this.modified = false
        this.props.onCancel()
    }

    handleSearchLeft = e => {
        this.setState({
            leftFilterWords: e.target.value
        })
    }

    handleSearchRight = e => {
        this.setState({
            rightFilterWords: e.target.value
        })
    }

    handleTargetChange = item => {
        this.setState({
            targetTable: item.key
        })
    }

    genRowSelection = memoize((outputFields, targetTable) => ({
        selectedRowKeys: outputFields.map(i => i.inputFieldName),
        // selectedRowKeys: [],
        onChange: selectedKeys => {
            // 这里使用selectedKeys从原始fields里去取数据
            // (不用传入的selectedRows参数，否则会出现：当经过筛选后的输入列表无原已选字段时，此时去勾选会直接替换掉原来勾选的字段的问题)
            // 输出表的字段顺序按添加顺序排列而不是按其在原表的顺序排列
            const yetSelectedRows = []
            selectedKeys.forEach(name => {
                const existedRightField = outputFields.find(f => f.key === name)
                // 若存在已选择的字段则直接从outputFields里取值
                // 特殊场景：从其他地方复制的合并组件，原组件的输入字段和当前组件的输入字段可能有所不同存在异常，所以还需判断输出字段在当前输入字段列表中存在才可正常显示
                if (existedRightField && this.props[`${targetTable}Fields`].find(f=>f.fieldName === name)) {
                    yetSelectedRows.push(existedRightField)
                } else { // 若该字段是新选择的，则从原始字段列表中取值
                    this.props[`${targetTable}Fields`].filter(field => {
                        if (name === field.fieldName) {
                            yetSelectedRows.push(field)
                        }
                    })
                }
            })

            const newOutputFields = yetSelectedRows.map(f => ({
                // inputFieldName取值：有 f.inputFieldName 表示是原来已存在的字段，所以取值inputFieldName；未存在表示是新选择的字段则取值 fieldName
                inputFieldName: f.inputFieldName || f.fieldName,
                fieldName: f.fieldName,
                fieldType: f.fieldType,
                fieldDesc: f.fieldDesc
            }))

            this.setState({
                [`${targetTable}OutputFields`]: newOutputFields
            })
            this.modified = true
        }
    }))

    genInputFields = memoize(
        (leftFields, rightFields, targetTable, filterWords) => {
            let inputFields = targetTable === 'left' ? leftFields : rightFields
            return filterFieldList(inputFields, filterWords).map(f => ({
                ...f,
                key: f.fieldName
            }))
        }
    )

    genOutputFields = memoize(
        (leftOutputFields, rightOutputFields, targetTable, filterWords) => {
            let outputFields =
                targetTable === 'left' ? leftOutputFields : rightOutputFields

            return filterFieldList(outputFields, filterWords).map(f => ({
                ...f,
                key: f.inputFieldName
            }))
        }
    )

    render() {
        const { leftFields, rightFields, searchKeyMax } = this.props
        const {
            leftFilterWords,
            rightFilterWords,
            targetTable,
            leftOutputFields,
            rightOutputFields
        } = this.state
        const outputFields = this.genOutputFields(
            leftOutputFields,
            rightOutputFields,
            targetTable,
            rightFilterWords
        )
        const inputFields = this.genInputFields(
            leftFields,
            rightFields,
            targetTable,
            leftFilterWords
        )
        return (
            <Modal
                width={1100}
                title="选择字段"
                visible={true}
                maskClosable={false}
                className={styles.fieldSelector}
                okText="保存"
                cancelText="取消"
                onOk={this.handleSave}
                onCancel={this.handleCancel}
                style={{
                    top: 50,
                    paddingBottom: 0
                }}>
                <div
                    key="tableZone"
                    className={styles.tableZone + ' ' + styles.half}
                    style={{ marginRight: 20, paddingTop: 0 }}
                    ref={e => {
                        this.tableZoneDom = e
                    }}>
                    <div className={styles.searchZone} key="searchZone">
                        <Input.Search
                            onChange={this.handleSearchLeft}
                            maxLength={searchKeyMax}
                            placeholder="请输入字段名称\描述关键字(仅对输出)"
                        />
                    </div>
                    <Menu
                        mode="horizontal"
                        selectedKeys={[targetTable]}
                        onSelect={this.handleTargetChange}>
                        <Menu.Item key={'left'}>左表</Menu.Item>
                        <Menu.Item key={'right'}>右表</Menu.Item>
                    </Menu>
                    <InputFieldsTable
                        enableDesc={this.props.enableDesc}
                        dataSource={inputFields}
                        rowSelection={this.genRowSelection(
                            outputFields,
                            targetTable
                        )}
                    />
                </div>
                <div className={styles.half}>
                    <div className={styles.searchZone} key="searchZone">
                        <Input.Search
                            onChange={this.handleSearchRight}
                            maxLength={searchKeyMax}
                            placeholder="请输入字段名称\描述关键字(仅对输出)"
                        />
                    </div>
                    <Menu
                        mode="horizontal"
                        selectedKeys={[targetTable]}
                        onSelect={this.handleTargetChange}>
                        <Menu.Item key={'left'}>左表</Menu.Item>
                        <Menu.Item key={'right'}>右表</Menu.Item>
                    </Menu>
                    <Table
                        size="small"
                        bordered
                        columns={this.OUTPUT_COLUMNS}
                        dataSource={outputFields}
                        pagination={false}
                        placeholder={false}
                        scroll={{ x: 450, y: 500 }}
                        rowClassName={record =>
                            record.key + ' ' + styles.tableRow
                        }
                    />
                </div>
            </Modal>
        )
    }
}
