/**
 * Created by yaojia7 on 2019/2/22.
 */
import React from 'react'
import memoize from 'memoize-one'
import { Modal, Input } from 'antd'
import Table from '../../../DataAssetComponent/FieldsTable'
import { filterFieldList } from '../../../DataAssetComponent/utils'
import styles from './BaseView.less'

const initState = {
    keywords: '',
    distinctColumns: []
}

export default class extends React.Component {
    state = {
        ...initState,
        distinctColumns: this.props.distinctColumns.slice()
    }

    handleSave = () => {
        if (!this.props.disabled) {
            this.props.onSave(this.state.distinctColumns)
            this.handleCancel()
        }
    }

    handleCancel = () => {
        this.props.onCancel()
        this.setState({
            ...initState
        })
    }

    handleInput = e => {
        this.setState({
            keywords: e.target.value
        })
    }

    genInputFields = memoize((inputFields, keywords) => {
        return filterFieldList(inputFields, keywords).map(f => ({
            ...f,
            key: f.fieldName
        }))
    })

    genRowSelection = memoize(distinctColumns => ({
        selectedRowKeys: distinctColumns,
        onChange: selectedKeys => {
            this.setState({
                distinctColumns: selectedKeys
            })
        }
    }))

    render() {
        const { inputFields, searchKeyMax } = this.props
        const { keywords, distinctColumns } = this.state
        return (
            <Modal
                width={1000}
                title="选择去重字段"
                visible={true}
                maskClosable={false}
                okText="保存"
                cancelText="取消"
                onOk={this.handleSave}
                onCancel={this.handleCancel}>
                <div className={styles.searchZone} key="searchZone">
                    <Input.Search
                        value={keywords}
                        onChange={this.handleInput}
                        maxLength={searchKeyMax}
                        placeholder="请输入字段名称\描述关键字"
                    />
                </div>
                <div className={styles.tableZone} key="tableZone">
                    <Table
                        dataSource={this.genInputFields(inputFields, keywords)}
                        rowSelection={this.genRowSelection(distinctColumns)}
                    />
                </div>
            </Modal>
        )
    }
}
