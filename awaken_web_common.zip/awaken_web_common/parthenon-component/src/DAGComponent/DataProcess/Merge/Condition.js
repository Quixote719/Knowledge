/**
 * Created by yaojia7 on 2019/2/22.
 */
import React from 'react'
import { Select, Icon } from 'antd'
import { genOptionWithTooltip } from '../../../DataAssetComponent/utils'
import styles from './BaseView.less'

const Condition = ({
    leftValue = null,
    rightValue = null,
    leftList = [],
    rightList = [],
    lock = false,
    onAdd,
    onDel,
    onChange
}) => {
    return (
        <div className={styles.condition}>
            <Select
                size="small"
                value={leftValue}
                placeholder="左表字段"
                disabled={lock}
                onChange={onChange.bind(this, 'left')}>
                {leftList.map(f => genOptionWithTooltip({ value: f, text: f }))}
            </Select>
            <span>=</span>
            <Select
                size="small"
                value={rightValue}
                disabled={lock}
                placeholder="右表字段"
                onChange={onChange.bind(this, 'right')}>
                {rightList.map(f =>
                    genOptionWithTooltip({ value: f, text: f })
                )}
            </Select>
            {!lock && <Icon type="plus-circle-o" onClick={onAdd} />}
            {!lock && (
                <Icon
                    type="minus-circle-o"
                    onClick={onDel.bind(this, leftValue, rightValue)}
                />
            )}
        </div>
    )
}

export default Condition
