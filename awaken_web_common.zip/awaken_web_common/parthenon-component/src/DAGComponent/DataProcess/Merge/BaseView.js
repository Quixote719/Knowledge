/**
 * Created by yaojia7 on 2018/11/14.
 */
import React from 'react'
import PropTypes from 'prop-types'
import memoize from 'memoize-one'
import { Form, message, Radio, Tooltip, Select, Button } from 'antd'

import { validateThenSave } from './../../../AlgoComponent/common'
import Item from './../../../DataAssetComponent/Item'
import Filter from './Filter'
import FieldsTable from './../../../DataAssetComponent/FieldsTable'
import FieldSelector from './FieldSelector'
import UnionFieldSelector from './UnionFieldSelector'
import OutputFieldsTable from './../../../DataAssetComponent/FieldsTable'
import styles from './BaseView.less'

import { isSelectedColumnsValid } from '../../../AlgoComponent/Shared/util'

import { renderTip } from '../../util'

import {
    DATA_MERGE_TYPE,
    OUTPUT_COLUMNS
} from '../../../DataAssetComponent/utils'
import Condition from './Condition'
import DistinctFieldSelector from './DistinctFieldSelector'

const RadioGroup = Radio.Group
const Option = Select.Option
const REQUIRED_LIST = [
    'connectType',
    'outputFields',
    'distinctColumns',
    'joinType',
    'joinConditions'
]

class Merge extends React.Component {
    static defaultProps = {
        enableDistinctColumns: true,
        enableDescription: true
    }

    static propTypes = {
        instanceParams: PropTypes.shape({
            connectType: PropTypes.string, //'UNION', 'JOIN', 'INTERLEAVE'
            enableDeDup: PropTypes.bool, //是否去重
            distinctColumns: PropTypes.arrayOf(PropTypes.string), //去重字段的字段名列表
            outputFields: PropTypes.arrayOf(
                //输出字段列表，包括左表输出字段和右表输出字段
                PropTypes.shape({
                    inputFieldName: PropTypes.string, //输出字段对应的输入字段名称，
                    fromLeft: PropTypes.bool, //输出字段是左表输出字段还是右表输出字段
                    fieldName: PropTypes.string,
                    fieldType: PropTypes.string,
                    fieldDesc: PropTypes.string
                })
            ),
            //union连接参数
            leftTableFilterCondition: PropTypes.string, //union连接的左表过滤语句
            rightTableFilterCondition: PropTypes.string, //union连接的右表过滤语句
            //join连接参数
            joinType: PropTypes.string, // 'full', 'right', 'left', 'inner', 默认为inner
            joinConditions: PropTypes.arrayOf(
                PropTypes.shape({
                    leftField: PropTypes.string, //输入左表的字段名称
                    rightField: PropTypes.string //输入右表的字段名称
                })
            )
        }),
        inputSchema: PropTypes.shape({
            '0': PropTypes.arrayOf(
                PropTypes.shape({
                    fieldName: PropTypes.string,
                    fieldType: PropTypes.string,
                    fieldDesc: PropTypes.string
                })
            )
        }),
        isLocked: PropTypes.bool,
        enableDistinctColumns: PropTypes.bool,
        enableDescription: PropTypes.bool,
        onSave: PropTypes.func,
        searchKeyMax: PropTypes.oneOfType([
            //选择字段的搜索关键字最大限长
            PropTypes.string,
            PropTypes.number
        ])
    }

    constructor(props) {
        super(props)
        this.validateThenSave = validateThenSave.bind(this)

        this.state = {
            selectorVisible: false, //字段选择界面是否可见
            distinctColumnSelectorVisible: false, //去重字段选择界面是否可见
            params: {
                state: {
                    connectType: 'init',
                    leftTableFilterCondition: 'init',
                    rightTableFilterCondition: 'init',
                    enableDeDup: 'init',
                    joinType: 'init',
                    joinConditions: 'init',
                    distinctColumns: 'init',
                    outputFields: 'init'
                }
            }
        }
    }

    handleSaveParams = params => {
        this.validateThenSave(params, this.props.onSave)
    }

    handleDistinctColumnsChange = fieldNameList => {
        this.handleSaveParams({ distinctColumns: fieldNameList })
    }

    handleOutputChange = (leftOutputFields = [], rightOutputFields = []) => {
        const { inputSchema, instanceParams } = this.props

        const { connectType } = instanceParams
        let outputFields = []
        if (connectType === DATA_MERGE_TYPE.UNION) {
            try {
                if (leftOutputFields.length !== rightOutputFields.length)
                    throw '左右表列数不一致'
                for (let i = 0; i < leftOutputFields.length; ++i) {
                    let leftField = leftOutputFields[i]
                    let rightField = rightOutputFields[i]
                    if (leftField.fieldName !== rightField.fieldName)
                        throw `第${i + 1}个字段的左右表字段名称不一致`
                    if (leftField.leftType !== rightField.rightType)
                        throw `第${i + 1}个字段的左右表字段类型不一致`
                }
            } catch (e) {
                message.warning('左右表结构需保持一致，' + e)
                return
            }
        } else {
            for (let field of leftOutputFields) {
                if (
                    rightOutputFields.find(f => f.fieldName === field.fieldName)
                ) {
                    message.warning(`${field.fieldName}在左右表中重复出现`)
                    return
                }
            }
        }
        if (inputSchema[0] && inputSchema[0].length > 0 && leftOutputFields.length > 0) {
            outputFields = leftOutputFields.map(f => ({
                ...f,
                fromLeft: true
            }))
        }
        if (inputSchema[1] && inputSchema[1].length > 0 && rightOutputFields.length > 0) {
            outputFields = outputFields.concat(
                rightOutputFields.map(f => ({
                    ...f,
                    fromLeft: false
                }))
            )
        }

        this.handleSaveParams({ outputFields })

        this.setState({
            selectorVisible: false
        })
    }

    renderJoinConditions = conditions => {
        const { inputSchema } = this.props

        const leftFields = inputSchema[0] || []
        const rightFields = inputSchema[1] || []

        return (
            <div className={styles.conditionContainer}>
                {conditions.map((c, index) => {
                    return (
                        <Condition
                            key={index + ''}
                            lock={this.props.isLocked}
                            leftValue={c.leftField}
                            rightValue={c.rightField}
                            leftList={leftFields.map(f => f.fieldName)}
                            rightList={rightFields.map(f => f.fieldName)}
                            onAdd={() => {
                                const conds = [...conditions]
                                conds.splice(index + 1, 0, {
                                    leftField: null,
                                    rightField: null
                                })
                                this.handleSaveParams({
                                    joinConditions: [...conds]
                                })
                            }}
                            onDel={() => {
                                const conds = [...conditions]
                                if (conds.length === 1) {
                                    conds[0] = {
                                        leftField: null,
                                        rightField: null
                                    }
                                } else conds.splice(index, 1)
                                this.handleSaveParams({
                                    joinConditions: [...conds]
                                })
                            }}
                            onChange={(type, value) => {
                                c[`${type}Field`] = value
                                this.handleSaveParams({
                                    joinConditions: [...conditions]
                                })
                            }}
                        />
                    )
                })}
            </div>
        )
    }

    genOutputFields = memoize((outputFields, connectType) => {
        //对于Union连接类型的输出表单，因为左右表结构一致，只需要列出左表的字段
        return outputFields.filter(
            f => connectType !== DATA_MERGE_TYPE.UNION || f.fromLeft
        )
    })

    genOutputTableCols = memoize((columns, enableDescription) => {
        if (enableDescription) return columns
        return columns.slice(0, 2)
    })

    genParamState = memoize((params, instanceParams, inputSchema) => {
        const res = {}
        for (let k in params.state) {
            res[k] = {
                isRequired: REQUIRED_LIST.includes(k),
                tip: '',
                state: params.state[k]
            }
            const item = res[k]
            const value = instanceParams[k]
            switch (k) {
                case 'joinConditions': {
                    if (instanceParams['connectType'] == 'JOIN') {
                        const flag =
                            value.length === 0 ||
                            value.find(c => !c.leftField || !c.rightField)
                        if (flag) {
                            item.state = 'warning'
                            item.tip = '关联字段不能为空'
                        }
                    }
                    break
                }
                case 'distinctColumns': {
                    if (
                        this.props.enableDistinctColumns &&
                        instanceParams['connectType'] === 'UNION' &&
                        instanceParams['enableDeDup']
                    ) {
                        item.state = value.length === 0 ? 'warning' : 'init'
                        item.tip = value.length === 0 ? '去重字段不能为空' : ''
                    }
                    break
                }
                case 'outputFields': {
                    if (value.length === 0) {
                        item.state = 'warning'
                        item.tip = '输出字段不能为空'
                    } else {
                        // 判断字段是否失效
                        try {
                            const { outputFields } = instanceParams
                            const selectedList = {
                                left: [],
                                right: []
                            }
                            const allList = {
                                left: [],
                                right: []
                            }
                            // 因为来源有很多个，且名称可编辑，故用原始字段，且需要一一对应判断
                            outputFields.forEach(item => {
                                item.fromLeft &&
                                    selectedList.left.push({
                                        name: item.hasOwnProperty('leftInput')
                                            ? item.leftInput
                                            : item.inputFieldName // 融合平台用的前者，训练平台用的后者
                                    })
                                !item.fromLeft &&
                                    selectedList.right.push({
                                        name: item.hasOwnProperty('rightInput')
                                            ? item.rightInput
                                            : item.inputFieldName // 融合平台用的前者，训练平台用的后者
                                    })
                            })

                            for (const portPos in inputSchema) {
                                const item = inputSchema[portPos]
                                if (portPos === '0') {
                                    // left
                                    item.forEach(sf => {
                                        allList.left.push({
                                            name: sf.fieldName
                                        })
                                    })
                                } else if (portPos === '1') {
                                    // right
                                    item.forEach(sf => {
                                        allList.right.push({
                                            name: sf.fieldName
                                        })
                                    })
                                }
                            }

                            const keys = Object.keys(selectedList)
                            const isInvalid = keys.some(value => {
                                return (
                                    isSelectedColumnsValid(
                                        selectedList[value],
                                        allList[value]
                                    ) === false
                                )
                            })
                            if (isInvalid) {
                                item.state = 'invalid'
                                item.tip = '参数无效'
                            }
                        } catch (e) {
                            console.error(e)
                        }
                    }

                    break
                }
                default: {
                    break
                }
            }
        }

        return res
    })

    genLeftConditionAutocompleteWords = memoize(inputSchema => {
        const leftFields = inputSchema[0] || []
        const res = {}
        if (leftFields.length > 0) {
            res['*'] = leftFields.map(f => ({
                displayText: `${f.fieldName}(${f.fieldType})`,
                text: f.fieldName
            }))
        }
        return res
    })

    genRightConditionAutocompleteWords = memoize(inputSchema => {
        const rightFields = inputSchema[1] || []
        const res = {}
        if (rightFields.length > 0) {
            res['*'] = rightFields.map(f => ({
                displayText: `${f.fieldName}(${f.fieldType})`,
                text: f.fieldName
            }))
        }
        return res
    })

    render() {
        const {
            instanceParams,
            inputSchema,
            isLocked,
            searchKeyMax
        } = this.props
        const {
            connectType,
            leftTableFilterCondition,
            rightTableFilterCondition,
            enableDeDup,
            joinType,
            joinConditions,
            outputFields,
            distinctColumns
        } = instanceParams
        const { selectorVisible, params } = this.state

        const leftOutputFields = inputSchema[0]
            ? outputFields.filter(f => f.fromLeft)
            : []
        const rightOutputFields = inputSchema[1]
            ? outputFields.filter(f => !f.fromLeft)
            : []

        const statusMap = this.genParamState(
            params,
            instanceParams,
            inputSchema
        )
        const max = searchKeyMax === '0' || searchKeyMax ? searchKeyMax : ''

        return (
            <div className={styles.container}>
                <Item
                    k="mergeType"
                    title="连接类型"
                    status={statusMap.connectType}>
                    <RadioGroup
                        value={connectType}
                        disabled={isLocked}
                        onChange={e => {
                            const value = e.target.value
                            this.handleSaveParams({
                                connectType: value,
                                outputFields: []
                            })
                        }}>
                        <Radio value={DATA_MERGE_TYPE.UNION}>Union</Radio>
                        <Radio value={DATA_MERGE_TYPE.JOIN}>Join</Radio>
                        <Radio value={DATA_MERGE_TYPE.INTERLEAVE}>
                            交叉连接
                        </Radio>
                        {renderTip(statusMap.connectType)}
                    </RadioGroup>
                </Item>
                <Item
                    k="fieldSelector"
                    title="选择字段"
                    status={statusMap.outputFields}>
                    <Button
                        onClick={() => {
                            this.setState({ selectorVisible: true })
                        }}>
                        选择字段
                    </Button>
                    {renderTip(statusMap.outputFields)}
                </Item>
                {connectType === DATA_MERGE_TYPE.UNION && (
                    <Item
                        k="leftCondition"
                        title="左表过滤条件"
                        status={statusMap.leftTableFilterCondition}>
                        <Filter
                            autocompleteWords={this.genLeftConditionAutocompleteWords(
                                inputSchema
                            )}
                            defaultValue={leftTableFilterCondition}
                            onBlur={value =>
                                this.handleSaveParams({
                                    leftTableFilterCondition: value
                                })
                            }
                            isLocked={this.props.isLocked}
                        />
                        {renderTip(statusMap.leftTableFilterCondition)}
                    </Item>
                )}
                {connectType === DATA_MERGE_TYPE.UNION && (
                    <Item
                        k="rightCondition"
                        title="右表过滤条件"
                        status={statusMap.rightTableFilterCondition}>
                        <Filter
                            autocompleteWords={this.genRightConditionAutocompleteWords(
                                inputSchema
                            )}
                            defaultValue={rightTableFilterCondition}
                            onBlur={value =>
                                this.handleSaveParams({
                                    rightTableFilterCondition: value
                                })
                            }
                            isLocked={this.props.isLocked}
                        />
                        {renderTip(statusMap.rightTableFilterCondition)}
                    </Item>
                )}
                {connectType === DATA_MERGE_TYPE.UNION && (
                    <Item
                        k="deDup"
                        title="是否去重"
                        status={statusMap.enableDeDup}>
                        <RadioGroup
                            value={enableDeDup}
                            disabled={isLocked}
                            onChange={e => {
                                const value = e.target.value
                                this.handleSaveParams({
                                    enableDeDup: value,
                                    distinctColumns: []
                                })
                            }}>
                            <Radio value={false}>不去重</Radio>
                            <Radio value={true}>去重</Radio>
                            {renderTip(statusMap.enableDeDup)}
                        </RadioGroup>
                    </Item>
                )}
                {connectType === DATA_MERGE_TYPE.UNION &&
                    enableDeDup &&
                    this.props.enableDistinctColumns && (
                        <Item
                            k="distinctColumnsSelector"
                            title="去重标识字段"
                            status={statusMap.distinctColumns}>
                            <Tooltip
                                placement="left"
                                overlayClassName={styles.tooltip}
                                title={
                                    <FieldsTable
                                        dataSource={this.genOutputFields(
                                            outputFields,
                                            connectType
                                        ).filter(f =>
                                            distinctColumns.includes(
                                                f.fieldName
                                            )
                                        )}
                                    />
                                }>
                                <Button
                                    onClick={() => {
                                        this.setState({
                                            distinctColumnSelectorVisible: true
                                        })
                                    }}>
                                    选择字段
                                </Button>
                                {renderTip(statusMap.distinctColumns)}
                            </Tooltip>
                        </Item>
                    )}
                {connectType === DATA_MERGE_TYPE.JOIN && (
                    <Item
                        k="joinType"
                        title="Join类型"
                        status={statusMap.joinType}>
                        <Select
                            value={joinType}
                            disabled={isLocked}
                            onSelect={value => {
                                this.handleSaveParams({ joinType: value })
                            }}>
                            <Option key="full">全连接</Option>
                            <Option key="left">左连接</Option>
                            <Option key="right">右连接</Option>
                            <Option key="inner">内连接</Option>
                        </Select>
                        {renderTip(statusMap.joinType)}
                    </Item>
                )}
                {connectType === DATA_MERGE_TYPE.JOIN && (
                    <Item
                        k="joinCondition"
                        title="关联条件"
                        status={statusMap.joinConditions}>
                        {this.renderJoinConditions(joinConditions)}
                        {renderTip(statusMap.joinConditions)}
                    </Item>
                )}
                {this.genOutputFields(outputFields, connectType).length > 0 && (
                    <Item k="output" title="输出表单">
                        <OutputFieldsTable
                            dataSource={this.genOutputFields(
                                outputFields,
                                connectType
                            )}
                            columns={this.genOutputTableCols(
                                OUTPUT_COLUMNS,
                                this.props.enableDescription
                            )}
                            width={300}
                        />
                    </Item>
                )}
                {connectType !== DATA_MERGE_TYPE.UNION && selectorVisible && (
                    <FieldSelector
                        disabled={isLocked}
                        leftOutputFields={leftOutputFields}
                        rightOutputFields={rightOutputFields}
                        leftFields={inputSchema[0] || []}
                        rightFields={inputSchema[1] || []}
                        enableDesc={this.props.enableDescription}
                        onCancel={() => {
                            this.setState({ selectorVisible: false })
                        }}
                        onSave={this.handleOutputChange}
                        searchKeyMax={max}
                    />
                )}
                {connectType === DATA_MERGE_TYPE.UNION && selectorVisible && (
                    <UnionFieldSelector
                        disabled={isLocked}
                        outputFields={outputFields}
                        leftFields={inputSchema[0] || []}
                        rightFields={inputSchema[1] || []}
                        enableDesc={this.props.enableDescription}
                        onCancel={() => {
                            this.setState({ selectorVisible: false })
                        }}
                        onSave={this.handleOutputChange}
                        searchKeyMax={max}
                    />
                )}
                {this.state.distinctColumnSelectorVisible && (
                    <DistinctFieldSelector
                        disabled={isLocked}
                        inputFields={this.genOutputFields(
                            outputFields,
                            connectType
                        )}
                        distinctColumns={distinctColumns}
                        onSave={this.handleDistinctColumnsChange}
                        onCancel={() => {
                            this.setState({
                                distinctColumnSelectorVisible: false
                            })
                        }}
                        searchKeyMax={max}
                    />
                )}
            </div>
        )
    }
}

export default Form.create()(Merge)
