/**
 * Created by yaojia7 on 2018/11/14.
 */
import React from 'react'
import memoize from 'memoize-one'
import { message, Select, Menu, Modal, Table, Input, Icon } from 'antd'
import { addClass, delClass } from 'parthenon-lib'
import { EditableCell } from './../../../DataAssetComponent/EditableCell'
import InputFieldsTable from './../../../DataAssetComponent/FieldsTable'
import {
    genOptionWithTooltip,
    filterFieldList
} from '../../../DataAssetComponent/utils'
import styles from './BaseView.less'

export default class extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            leftFilterWords: '',
            rightFilterWords: '',
            targetTable: 'left', // 'left' | 'right' 当前设置的是左表还是右表
            outputFields: [
                /**
                 * fieldName: 输出字段名称
                 * fieldType: 输出字段类型
                 * fieldDesc: 输出字段描述
                 * leftInput: 左表输入字段名称
                 * leftType: 左表输入字段类型
                 * rightInput: 右表输入字段名称
                 * rightType: 右表输入字段类型
                 */
            ],
            lastOutputFields: null
        }
        this.modified = false
        this.OUTPUT_COLUMNS = [
            {
                key: 'action',
                dataIndex: 'action',
                title: '',
                width: 32,
                render: (text, record, index) => {
                    return (
                        <Icon
                            type="delete"
                            onClick={() => {
                                const { outputFields } = this.state
                                outputFields.splice(index, 1)
                                this.setState({
                                    outputFields: [...outputFields]
                                })
                                this.modified = true
                            }}
                        />
                    )
                }
            },
            {
                key: 'fieldName',
                dataIndex: 'fieldName',
                title: '字段名称',
                width: 120,
                render: (text, record, index) => (
                    <EditableCell
                        value={text}
                        type="name"
                        max={40}
                        onSave={value => {
                            const { outputFields } = this.state
                            if (
                                outputFields.find(
                                    (f, i) =>
                                        i !== index &&
                                        f.fieldName.toLowerCase() ===
                                            value.toLowerCase()
                                )
                            ) {
                                message.error('输出字段名重复')
                                return
                            }
                            if (outputFields[index]) {
                                outputFields[index].fieldName = value
                                this.setState({
                                    outputFields: [...outputFields]
                                })
                                this.modified = true
                            }
                        }}
                    />
                )
            },
            {
                key: 'fieldType',
                dataIndex: 'fieldType',
                title: '字段类型',
                width: 100
            }
        ]

        if (props.enableDesc)
            this.OUTPUT_COLUMNS.push({
                key: 'fieldDesc',
                dataIndex: 'fieldDesc',
                title: '字段描述',
                width: 120,
                render: (text, record, index) => (
                    <EditableCell
                        value={text}
                        type="desc"
                        max={40}
                        onSave={value => {
                            const { outputFields } = this.state
                            if (outputFields[index]) {
                                outputFields[index].fieldDesc = value
                                this.setState({
                                    outputFields: [...outputFields]
                                })
                                this.modified = true
                            }
                        }}
                    />
                )
            })

        this.OUTPUT_COLUMNS.push(
            ...['left', 'right'].map(flag => ({
                key: flag,
                dataIndex: flag,
                title: flag === 'left' ? '左表输入' : '右表输入',
                width: 150,
                render: (text, record) => {
                    return (
                        <Select
                            showSearch
                            size="small"
                            style={{ width: 130 }}
                            value={record[flag + 'Input']}
                            onChange={this.handleInputFieldChange.bind(
                                this,
                                flag,
                                record.fieldName
                            )}>
                            {this.props[flag + 'Fields'].map(f =>
                                genOptionWithTooltip({
                                    value: f.fieldName,
                                    tip: `${f.fieldName}: ${f.fieldDesc || ''}`
                                })
                            )}
                        </Select>
                    )
                }
            }))
        )

        this.tableZoneDom = null
    }

    static getDerivedStateFromProps(props, state) {
        const { outputFields } = props
        if (outputFields !== state.lastOutputFields) {
            const nextOutputFields = []
            for (let f of outputFields) {
                const existedField = nextOutputFields.find(
                    field => field.fieldName === f.fieldName
                )
                if (existedField) {
                    if (f.fromLeft) {
                        existedField.leftInput = f.inputFieldName
                        existedField.leftType = f.fieldType
                    } else {
                        existedField.rightInput = f.inputFieldName
                        existedField.rightType = f.fieldType
                    }
                } else {
                    const newField = {
                        fieldName: f.fieldName,
                        fieldType: f.fieldType,
                        fieldDesc: f.fieldDesc
                    }
                    if (f.fromLeft) {
                        newField.leftInput = f.inputFieldName
                        newField.leftType = f.fieldType
                    } else {
                        newField.rightInput = f.inputFieldName
                        newField.rightType = f.fieldType
                    }
                    nextOutputFields.push(newField)
                }
            }
            return {
                outputFields: nextOutputFields,
                lastOutputFields: outputFields
            }
        }
        return null
    }

    //处理输出表中左表输入和右表输入字段的切换
    handleInputFieldChange = (flag, outputFieldName, item) => {
        try {
            const { leftFields, rightFields } = this.props
            const { outputFields } = this.state
            const outputField = outputFields.find(
                f => f.fieldName === outputFieldName
            )
            if (flag === 'left') {
                outputField.leftInput = item
                outputField.leftType = leftFields.find(
                    f => f.fieldName === item
                ).fieldType
            } else {
                outputField.rightInput = item
                outputField.rightType = rightFields.find(
                    f => f.fieldName === item
                ).fieldType
            }
            this.setState({ outputFields: [...outputFields] })
            this.modified = true
        } catch (e) {
            message.error(e.toString())
        }
    }

    //拖拽中释放鼠标时，先根据释放事件target所在tr的classList[1]即该行输入字段id获取字段的index，
    //然后与draggedFieldId字段的index进行互换
    handleDrop = e => {
        e.preventDefault()
        const trDom = e.target.parentElement
        const targetFieldId = trDom.classList[1]
        const { outputFields } = this.state

        const dragIndex = outputFields.findIndex(
            f => f.inputFieldId === this.draggedFieldId
        )
        const targetIndex = outputFields.findIndex(
            f => f.inputFieldId === targetFieldId
        )
        if (dragIndex > -1 && targetIndex > -1 && dragIndex !== targetIndex) {
            const draggedField = outputFields[dragIndex]
            outputFields.splice(dragIndex, 1)
            outputFields.splice(targetIndex, 0, draggedField)
            this.setState({ outputFields: [...outputFields] })
            this.modified = true
        }
        this.tableZoneDom
            .querySelectorAll(`.${styles.hoverRow}`)
            .forEach(dom => delClass(dom, styles.hoverRow))
    }

    //table-body绑定dragEnter事件，触发时记录触发target tr字段的id
    handleDragEnter = e => {
        e.preventDefault()
        const trDom = e.target.parentElement
        addClass(trDom, styles.hoverRow)
    }

    handleDragLeave = e => {
        e.preventDefault()
        const trDom = e.target.parentElement
        delClass(trDom, styles.hoverRow)
    }

    handleDragOver = e => {
        e.preventDefault()
    }

    handleDragStart = e => {
        this.draggedFieldId = e.target.classList[1]
    }

    handleSave = () => {
        const { onSave, disabled } = this.props
        if (!disabled) {
            const { outputFields } = this.state
            const leftFields = []
            const rightFields = []
            for (let field of outputFields) {
                if (field.leftInput) {
                    leftFields.push({
                        ...field,
                        fieldType: field.leftType,
                        inputFieldName: field.leftInput
                    })
                }
                if (field.rightInput) {
                    rightFields.push({
                        ...field,
                        fieldType: field.rightType,
                        inputFieldName: field.rightInput
                    })
                }
            }
            // this.modified && onSave(leftFields, rightFields)
            // onSave(leftFields, rightFields)

            if (this.modified) {
                onSave(leftFields, rightFields)
            } else { // 未修改时也可能点击确认，此时只需关闭弹框即可
               this.handleCancel()
            }
        }
    }

    handleCancel = () => {
        this.setState({
            leftFilterWords: '',
            rightFilterWords: ''
        })
        this.modified = false
        this.props.onCancel()
    }

    handleSearchLeft = e => {
        this.setState({
            leftFilterWords: e.target.value
        })
    }

    handleSearchRight = e => {
        this.setState({
            rightFilterWords: e.target.value
        })
    }

    handleTargetChange = item => {
        this.setState({
            targetTable: item.key
        })
    }

    genOutputFields = memoize((outputFields, filterWords) => {
        return filterFieldList(outputFields, filterWords).map(f => ({
            ...f,
            key: f.fieldName
        }))
    })

    genInputFields = memoize(
        (leftFields, rightFields, targetTable, filterWords) => {
            let inputFields = targetTable === 'left' ? leftFields : rightFields
            return filterFieldList(inputFields, filterWords).map(f => ({
                ...f,
                key: f.fieldName
            }))
        }
    )

    genRowSelection = memoize((outputFields, targetTable) => {
        // 特殊场景：从其他地方复制的合并组件，原组件的输入字段和当前组件的输入字段可能有所不同存在异常，所以还需判断输出字段在当前输入字段列表中存在才可正常显示
        outputFields =  outputFields.filter(f => this.props.leftFields.find(lf=>lf.fieldName === f.leftInput) || this.props.rightFields.find(lr=>lr.fieldName === f.rightInput))

        return {
            selectedRowKeys: outputFields.map(i =>
                targetTable === 'left' ? i.leftInput : i.rightInput
            ),
            onSelect: (field, selected) => {
                if (selected)
                    this.addInputField(field, targetTable, outputFields)
                else this.delInputField(field, targetTable, outputFields)
                this.setState({
                    outputFields: [...outputFields]
                })
                this.modified = true
            },
            onSelectAll: selected => {
                const { leftFields, rightFields } = this.props
                if (selected) {
                    if (targetTable === 'left')
                        for (let field of leftFields)
                            this.addInputField(field, targetTable, outputFields)
                    else
                        for (let field of rightFields)
                            this.addInputField(field, targetTable, outputFields)
                } else {
                    if (targetTable === 'left')
                        for (let field of leftFields)
                            this.delInputField(field, targetTable, outputFields)
                    else
                        for (let field of rightFields)
                            this.delInputField(field, targetTable, outputFields)
                }
                this.setState({
                    outputFields: [...outputFields]
                })
                this.modified = true
            }
        }
    })

    addInputField = (field, targetTable, outputFields) => {
        if (
            outputFields.find(
                f =>
                    f[
                        `${targetTable === 'left' ? 'leftInput' : 'rightInput'}`
                    ] === field.fieldName
            )
        )
            return
        if (targetTable === 'left') {
            const existedRightField = outputFields.find(f => !f.leftInput)
            if (existedRightField) {
                existedRightField.leftInput = field.fieldName
                existedRightField.leftType = field.fieldType
            } else {
                outputFields.push({
                    fieldName: field.fieldName,
                    fieldType: field.fieldType,
                    fieldDesc: field.fieldDesc,
                    leftInput: field.fieldName,
                    leftType: field.fieldType,
                    rightType: '',
                    rightInput: ''
                })
            }
        } else {
            const existedLeftField = outputFields.find(f => !f.rightInput)
            if (existedLeftField) {
                existedLeftField.rightInput = field.fieldName
                existedLeftField.rightType = field.fieldType
            } else {
                outputFields.push({
                    fieldName: field.fieldName,
                    fieldType: field.fieldType,
                    fieldDesc: field.fieldDesc,
                    rightInput: field.fieldName,
                    rightType: field.fieldType,
                    leftType: '',
                    leftInput: ''
                })
            }
        }
    }

    delInputField = (field, targetTable, outputFields) => {
        let existedField = outputFields.find(
            f =>
                f[`${targetTable === 'left' ? 'leftInput' : 'rightInput'}`] ===
                field.fieldName
        )
        if (!existedField) return
        if (targetTable === 'left') {
            existedField.leftInput = ''
        } else {
            existedField.rightInput = ''
        }
        if (!existedField.rightInput && !existedField.leftInput) {
            outputFields.splice(outputFields.indexOf(existedField), 1)
        }
    }

    render() {
        const { leftFields, rightFields, searchKeyMax } = this.props
        const {
            leftFilterWords,
            rightFilterWords,
            targetTable,
            outputFields
        } = this.state
        const outputFieldList = this.genOutputFields(
            outputFields,
            rightFilterWords
        )
        const inputFieldList = this.genInputFields(
            leftFields,
            rightFields,
            targetTable,
            leftFilterWords
        )

        return (
            <Modal
                width={1300}
                visible={true}
                title="选择字段"
                maskClosable={false}
                className={styles.unionFieldSelector}
                okText="保存"
                cancelText="取消"
                onOk={this.handleSave}
                onCancel={this.handleCancel}
                style={{
                    top: 50,
                    paddingBottom: 0
                }}>
                <div className={styles.searchZone} key="searchZone">
                    <div>
                        <Input.Search
                            onChange={this.handleSearchLeft}
                            maxLength={searchKeyMax}
                            placeholder="请输入字段名称\描述关键字(仅对输入)"
                        />
                    </div>
                    <div>
                        <Input.Search
                            onChange={this.handleSearchRight}
                            maxLength={searchKeyMax}
                            placeholder="请输入字段名称\描述关键字(仅对输出)"
                        />
                    </div>
                </div>
                <Menu
                    mode="horizontal"
                    selectedKeys={[targetTable]}
                    onSelect={this.handleTargetChange}>
                    <Menu.Item key={'left'}>左表</Menu.Item>
                    <Menu.Item key={'right'}>右表</Menu.Item>
                </Menu>
                <div
                    key="tableZone"
                    className={styles.tableZone}
                    ref={e => {
                        this.tableZoneDom = e
                    }}>
                    <div
                        style={{
                            marginRight: 20,
                            width: 500
                        }}>
                        <InputFieldsTable
                            enableDesc={this.props.enableDesc}
                            dataSource={inputFieldList}
                            rowSelection={this.genRowSelection(
                                outputFieldList,
                                targetTable
                            )}
                        />
                    </div>
                    <Table
                        size="small"
                        bordered
                        columns={this.OUTPUT_COLUMNS}
                        dataSource={outputFieldList}
                        pagination={false}
                        scroll={{ y: 500 }}
                        rowClassName={record =>
                            record.key + ' ' + styles.tableRow
                        }
                    />
                </div>
            </Modal>
        )
    }
}
