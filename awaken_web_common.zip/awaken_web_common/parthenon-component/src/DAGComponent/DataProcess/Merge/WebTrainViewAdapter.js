const getConnectType = linkType => {
    if (linkType === 'join') return 'JOIN'
    if (linkType === 'union') return 'UNION'
    if (linkType === 'cartesian') return 'INTERLEAVE'
}

const getLinkType = connectType => {
    if (connectType === 'JOIN') return 'join'
    if (connectType === 'UNION') return 'union'
    if (connectType === 'INTERLEAVE') return 'cartesian'
}

const getJoinType = joinType => {
    if (joinType === 'inner') return 'inner'
    if (joinType === 'left_outer') return 'left'
    if (joinType === 'right_outer') return 'right'
    if (joinType === 'outer') return 'full'
}

const getJoinConditions = (leftJoinCols, rightJoinCols) => {
    if (!Array.isArray(leftJoinCols) || !Array.isArray(rightJoinCols)) {
        return [
            {
                leftField: null,
                rightField: null,
            },
        ]
    } else if (
        leftJoinCols.length !== rightJoinCols.length ||
        leftJoinCols.length === 0
    ) {
        return [
            {
                leftField: null,
                rightField: null,
            },
        ]
    } else {
        const res = []
        for (let i = 0; i < leftJoinCols.length; i++) {
            res.push({
                leftField: leftJoinCols[i],
                rightField: rightJoinCols[i],
            })
        }
        return res
    }
}

const getOutputFields = (inputCols, outputCols, sources, colTypes) => {
    if (
        !Array.isArray(inputCols) ||
        !Array.isArray(outputCols) ||
        !Array.isArray(sources) ||
        !Array.isArray(colTypes)
    ) {
        return []
    } else if (
        inputCols.length !== outputCols.length ||
        outputCols.length !== sources.length ||
        sources.length !== colTypes.length
    ) {
        return []
    } else {
        const res = []
        for (let i = 0; i < inputCols.length; i++) {
            res.push({
                inputFieldName: inputCols[i],
                fromLeft: sources[i] === 0,
                fieldName: outputCols[i],
                fieldType: colTypes[i],
                fieldDesc: '',
            })
        }
        return res
    }
}

export default {
    viewDataToModelData: res => {
        const newObj = {}
        if (res.hasOwnProperty('connectType')) {
            newObj.linkType = getLinkType(res.connectType)
        }

        if (res.hasOwnProperty('joinType')) {
            if (res.joinType === 'inner') newObj.joinType = 'inner'
            if (res.joinType === 'left') newObj.joinType = 'left_outer'
            if (res.joinType === 'right') newObj.joinType = 'right_outer'
            if (res.joinType === 'full') newObj.joinType = 'outer'
        }

        if (res.hasOwnProperty('joinConditions')) {
            newObj.leftJoinCols = []
            newObj.rightJoinCols = []
            if (Array.isArray(res.joinConditions)) {
                res.joinConditions.forEach(joinCondition => {
                    newObj.leftJoinCols.push(joinCondition.leftField)
                    newObj.rightJoinCols.push(joinCondition.rightField)
                })
            }
        }

        if (res.hasOwnProperty('leftTableFilterCondition')) {
            newObj.unionLeftStatement = res.leftTableFilterCondition
        }

        if (res.hasOwnProperty('rightTableFilterCondition')) {
            newObj.unionRightStatement = res.rightTableFilterCondition
        }

        if (res.hasOwnProperty('enableDeDup')) {
            newObj.unionFilterType = res.enableDeDup
                ? 'dropDuplicates'
                : 'no_dropDuplicates'
        }

        if (res.hasOwnProperty('distinctColumns')) {
            newObj.distinctColumns = res.distinctColumns
        }

        if (res.hasOwnProperty('outputFields')) {
            newObj.inputCols = []
            newObj.outputCols = []
            newObj.sources = []
            newObj.colTypes = []
            if (Array.isArray(res.outputFields)) {
                res.outputFields.forEach(outputField => {
                    newObj.inputCols.push(outputField.inputFieldName)
                    newObj.outputCols.push(outputField.fieldName)
                    newObj.colTypes.push(outputField.fieldType)
                    newObj.sources.push(outputField.fromLeft ? 0 : 1)
                })
            }
        }
        return newObj
    },
    modelDataToViewData: res => {
        const newObj = {}
        newObj.connectType = getConnectType(res.linkType)
        newObj.joinType = getJoinType(res.joinType)
        newObj.joinConditions = getJoinConditions(
            res.leftJoinCols,
            res.rightJoinCols
        )
        newObj.leftTableFilterCondition = res.unionLeftStatement
        newObj.rightTableFilterCondition = res.unionRightStatement
        newObj.enableDeDup = res.unionFilterType === 'dropDuplicates'
        newObj.distinctColumns = res.distinctColumns || []
        newObj.outputFields = getOutputFields(
            res.inputCols,
            res.outputCols,
            res.sources,
            res.colTypes
        )
        return newObj
    },
    inputSchemaTransform: inputSchema => {
        const res = {}
        for (let k in inputSchema) {
            res[k] = inputSchema[k].map(f => ({
                fieldName: f.name,
                fieldType: f.type,
                fieldDesc: '',
            }))
        }
        return res
    },
    renderProps: props => {
        return {
            ...props,
            enableDistinctColumns: true,
            enableDescription: false,
        }
    },
}
