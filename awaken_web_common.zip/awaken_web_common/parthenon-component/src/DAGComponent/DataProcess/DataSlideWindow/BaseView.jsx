import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import TimeSlide from '../../../AlgoComponent/Shared/TimeSlide'

import { composeCompSaveState } from '../../../AlgoComponent/common'

export default class DataSlideWindow extends React.Component {
    constructor(props) {
        super(props)
        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {},
            },
        }
    }
    getParamRenderDescription() {
        return {
            groupByCols: {
                type: 'FieldSelect',
                param: {
                    label: '分组字段',
                    isRequired: false,
                },
            },
            timeSlide: {
                option: {
                    byConcreteRenderer: true,
                },
            },
        }
    }

    handleChangeTimeParam = params => {
        const obj = this.state.params.state
        for (let key in params) {
            obj[key] = 'init'
        }
        this.setState({
            params: {
                state: obj,
            },
        })
    }

    hanldeSaveTimeParam = params => {
        const { onSave } = this.props
        onSave(params, this.saveCompState)
    }

    renderTimeSlide = () => {
        const { instanceParams, inputSchema, isLocked } = this.props
        return (
            <TimeSlide
                {...instanceParams}
                paramState={{ ...this.state.params.state }}
                onChangeInput={this.handleChangeTimeParam}
                allColumns={inputSchema[0] || []}
                onSave={this.hanldeSaveTimeParam}
                disabled={isLocked}
            />
        )
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
                renderPieces={{
                    timeSlide: this.renderTimeSlide(),
                }}
            />
        )
    }
}
