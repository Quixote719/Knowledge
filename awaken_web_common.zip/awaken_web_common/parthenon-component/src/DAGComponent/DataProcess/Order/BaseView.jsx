import React from 'react'
import WrappedFieldSelection from '../../../AlgoComponent/wrappedBasicComponent/WrappedFieldSelection'
import { mapToTuple } from '../../../AlgoComponent/transformHelper'

class Order extends React.Component {
    render() {
        const { inputSchema, instanceParams, onSave, isLocked } = this.props
        const allColumns = inputSchema['0']

        let selectedColumns = mapToTuple({
            name: instanceParams.sortCols || [],
            order: instanceParams.sortTypes || [],
        })

        const onSelectFields = selectedColumns => {
            return {
                sortCols: selectedColumns.map(col => col.name),
                sortTypes: selectedColumns.map(col => col.order),
            }
        }

        return (
            <WrappedFieldSelection
                label="排序字段"
                isRequired
                instanceParams={instanceParams}
                attrName="sortCols"
                allColumns={allColumns}
                selectedColumns={selectedColumns}
                isLocked={isLocked}
                onSelectFields={onSelectFields}
                onSave={onSave}
                additionalParams={[
                    {
                        title: '排序',
                        paramName: 'order',
                        inputType: 'dropdown',
                        defaultValue: 'asc',
                        options: [
                            { text: '升序', value: 'asc' },
                            { text: '降序', value: 'desc' },
                        ],
                    },
                ]}
            />
        )
    }
}

export default Order
