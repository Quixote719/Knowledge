import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import { Form, DatePicker } from 'antd'
import moment from 'moment'
import {
    composeCompSaveState,
    getFormItemState,
} from '../../../AlgoComponent/common'
const FormItem = Form.Item

const DATE_TARGET_FORMAT = 'YYYY-MM-DD HH:mm:ss'

class RandomDataTransformer extends React.Component {
    constructor(props) {
        super(props)
        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {},
            },
        }
    }

    getUnitCheck = () => {
        const { instanceParams } = this.props
        const { startTime, endTime, unit } = instanceParams
        let timePeriod
        const ST =
            startTime !== 'Invalid date'
                ? moment(startTime).format('x')
                : moment('2018-01-01').format('x')
        const ET =
            endTime !== 'Invalid date'
                ? moment(endTime).format('x')
                : moment().format('x')

        timePeriod =
            unit === 'hour'
                ? (ET - ST) / (3600 * 1000)
                : unit === 'minute'
                ? (ET - ST) / (60 * 1000)
                : unit === 'second'
                ? (ET - ST) / 1000
                : (ET - ST) / (24 * 3600 * 1000)
        return Math.floor(timePeriod)
    }

    getParamRenderDescription() {
        return {
            dataType: {
                type: 'Select',
                param: {
                    label: '数据类型',
                    options: [{ value: 'series', label: '序列型' }],
                },
            },
            seriesType: {
                type: 'Select',
                param: {
                    label: '时间序列',
                    options: [{ value: 'time_series', label: '时间序列' }],
                },
            },
            startTime: {
                // type: 'DatePicker',
                // param: {
                //     label: '序列开始时间',
                //     invalidDefault: new moment('2018-01-01', 'YYYY-MM-DD'),
                //     format: 'YYYY-MM-DD',
                //     showTime: false,
                // },
                option: {
                    byConcreteRenderer: true,
                },
            },
            endTime: {
                // type: 'DatePicker',
                // param: {
                //     label: '序列结束时间',
                //     invalidDefault: new moment('2018-01-01', 'YYYY-MM-DD'),
                //     format: 'YYYY-MM-DD',
                //     showTime: false,
                // },
                option: {
                    byConcreteRenderer: true,
                },
            },
            startEndComparison: {
                option: {
                    byConcreteRenderer: true,
                },
            },
            unit: {
                type: 'Select',
                param: {
                    label: '序列粒度',
                    options: [
                        { value: 'day', label: '天' },
                        { value: 'hour', label: '时' },
                        { value: 'minute', label: '分' },
                        { value: 'second', label: '秒' },
                    ],
                },
            },
            unitCheck: {
                option: {
                    byConcreteRenderer: true,
                },
            },
            interval: {
                type: 'Input',
                param: {
                    label: '序列间隔 >=1',
                    min: { value: 1, include: true },
                    max: {
                        value: Math.max(this.getUnitCheck(), 1),
                        include: true,
                    },
                    isInteger: true,
                },
            },
        }
    }

    renderStartEndComparison = () => {
        const { instanceParams } = this.props
        const startTime = instanceParams.startTime
        const endTime = instanceParams.endTime

        const ST =
            startTime !== 'Invalid date'
                ? Number(moment(startTime).format('x'))
                : Number(moment('2018-01-01').format('x'))
        const ET =
            endTime !== 'Invalid date'
                ? Number(moment(endTime).format('x'))
                : Number(moment().format('x'))
        if (ST <= ET) {
            return null
        } else {
            return (
                <div
                    style={{
                        color: 'red',
                        fontSize: '12px',
                        lineHeight: '20px',
                        position: 'relative',
                        top: -15,
                    }}
                >
                    序列结束时间不可在序列开始时间之前
                </div>
            )
        }
    }

    handleDateChange = (e, attrName) => {
        const value = moment(e).format(DATE_TARGET_FORMAT)
        this.setState({
            params: {
                state: {
                    [attrName]: 'init',
                },
            },
            [attrName]: value,
        })
    }

    handleOpenChange = (open, attrName) => {
        if (open) {
            return
        }

        const { form, instanceParams, isLocked, onSave } = this.props
        const value = this.state[attrName]
        if (value === 'Invalid date') {
            this.props.form.setFieldsValue({
                [attrName]: new moment(instanceParams[attrName]), // 还原上一次值
            })
            return
        }
        onSave(
            {
                [attrName]: value,
            },
            this.saveCompState
        )
    }

    renderStartTime = () => {
        const { form, instanceParams, isLocked, onSave } = this.props
        const { getFieldDecorator } = form
        const defaultValue = new moment(instanceParams.startTime)
        return (
            <FormItem
                label="序列开始时间"
                required={true}
                {...getFormItemState(this.state.params.state.startTime)}
            >
                {getFieldDecorator('startTime', {
                    initialValue: defaultValue,
                    rules: [
                        { type: 'object', required: true, message: '必填' },
                    ],
                })(
                    <DatePicker
                        // showTime={
                        //     instanceParams.transDateFormat !== 'yyyy-MM-dd'
                        // }
                        allowClear={false}
                        showTime
                        placeholder=""
                        disabledDate={this.disabledDate}
                        style={{ width: '100%' }}
                        onChange={e => this.handleDateChange(e, 'startTime')}
                        onOpenChange={open =>
                            this.handleOpenChange(open, 'startTime')
                        }
                        disabled={isLocked}
                        format={DATE_TARGET_FORMAT}
                    />
                )}
            </FormItem>
        )
    }

    renderEndTime = () => {
        const { form, instanceParams, isLocked, onSave } = this.props
        const { getFieldDecorator } = form
        const defaultValue = new moment(instanceParams.endTime)
        return (
            <FormItem
                label="序列结束时间"
                required={true}
                {...getFormItemState(this.state.params.state.endTime)}
            >
                {getFieldDecorator('endTime', {
                    initialValue: defaultValue,
                    rules: [
                        { type: 'object', required: true, message: '必填' },
                    ],
                })(
                    <DatePicker
                        // showTime={
                        //     instanceParams.transDateFormat !== 'yyyy-MM-dd'
                        // }
                        allowClear={false}
                        showTime
                        placeholder=""
                        disabledDate={this.disabledDate}
                        style={{ width: '100%' }}
                        onChange={e => this.handleDateChange(e, 'endTime')}
                        onOpenChange={open =>
                            this.handleOpenChange(open, 'endTime')
                        }
                        disabled={isLocked}
                        format={DATE_TARGET_FORMAT}
                    />
                )}
            </FormItem>
        )
    }

    disabledDate = current => {
        // 可选择的日期在1970开始，到现在时刻往后10年截止
        return (
            current < moment('1970-01-01') ||
            current > moment().add(10, 'years')
        )
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
                renderPieces={{
                    startEndComparison: this.renderStartEndComparison(),
                    startTime: this.renderStartTime(),
                    endTime: this.renderEndTime(),
                }}
            />
        )
    }
}

export default Form.create()(RandomDataTransformer)
