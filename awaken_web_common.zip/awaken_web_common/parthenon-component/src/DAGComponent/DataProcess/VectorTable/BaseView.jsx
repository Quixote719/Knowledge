import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import { createColNameValidator } from '../../../AlgoComponent/inputValidator'

export default class VectorTable extends React.Component {
    getTransformCols = transformType => {
        if (transformType === 'TABLETOVECTOR') {
            return {
                mergeCols: {
                    type: 'FieldSelect',
                    param: {
                        label: '选择字段',
                        colsRequired: 2,
                        allowedTypes: ['int', 'double'],
                        isSelectMulti: true,
                    },
                },
            }
        } else if (transformType === 'VECTORTOTABLE') {
            return {
                splitCol: {
                    type: 'FieldSelect',
                    param: {
                        label: '选择字段',
                        colsRequired: 1,
                        allowedTypes: ['vector'],
                        isSelectMulti: false,
                    },
                },
            }
        }
        return {}
    }
    getParamRenderDescription() {
        const { instanceParams } = this.props
        return {
            transformType: {
                type: 'Select',
                param: {
                    label: '转换方向',
                    options: [
                        { value: 'VECTORTOTABLE', label: 'Vector to Table' },
                        { value: 'TABLETOVECTOR', label: 'Table to Vector' },
                    ],
                },
            },
            ...this.getTransformCols(instanceParams.transformType),
            userDefinedName: {
                type: 'Input',
                param: {
                    label: '输出列名',
                    placeholder:
                        instanceParams.transformType === 'VECTORTOTABLE'
                            ? '默认使用 V2T_字段名称'
                            : '默认使用 T2V_所选字段总数_序号',
                    rules: createColNameValidator({
                        prefix: '自定义列名',
                        maxLength: 30,
                        allowUndefined: true,
                    }),
                    isRequired: false,
                },
            },
            isRetainTransCols: {
                type: 'Checkbox',
                param: {
                    label: (
                        <span>
                            保留原始列 <br />
                            {instanceParams.transformType === 'VECTORTOTABLE'
                                ? '输出多列增加，“_1、_2...”尾标'
                                : ''}
                        </span>
                    ),
                },
            },
        }
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
            />
        )
    }
}
