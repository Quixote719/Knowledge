import React from 'react'
import ConfigComponent from '../../ConfigComponent'

export default class DataCorCoeAnalyse extends React.Component {
    getParamRenderDescription() {
        return {
            inputCol: {
                type: 'FieldSelect',
                param: {
                    label: '选择字段 （至少选择2个字段)',
                    numericCols: true,
                    colsRequired: 2,
                },
            },
            corType: {
                type: 'RadioGroup',
                param: {
                    label: '相关性度量',
                    options: [
                        { value: 'pearson', label: 'Pearson系数' },
                        { value: 'spearman', label: 'Spearman系数' },
                    ],
                },
            },
        }
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
            />
        )
    }
}
