import React from 'react'
import { Form, Input, DatePicker } from 'antd'
import ConfigComponent from '../../ConfigComponent'
import { mapToTuple } from '../../../AlgoComponent/transformHelper'
import WrappedFieldSelection from '../../../AlgoComponent/wrappedBasicComponent/WrappedFieldSelection'
import {
    composeCompSaveState,
    getFormItemState
} from '../../../AlgoComponent/common'
import { getSelectableColumns, saveInput } from '../../util'
import {
    getMin,
    getMax,
    getInputRules
} from '../../../AlgoComponent/inputCommon'

const FormItem = Form.Item

const DATE_TARGET_FORMAT = 'YYYY-MM-DD HH:mm:ss'
const SPLIT_THRESHOLD_ATTRNAME = 'splitThreshold'
const ST_DATE_FORM_FIELD = SPLIT_THRESHOLD_ATTRNAME
const ST_NUMBER_FORM_FIELD = `${SPLIT_THRESHOLD_ATTRNAME}_number`

class DataSplit extends React.Component {
    constructor(props) {
        super(props)
        this.saveCompState = composeCompSaveState(this)
        this.saveInput = saveInput.bind(this)
        this.state = {
            params: {
                state: {}
            }
        }
        this.prevSplitType = this.props.instanceParams
            ? this.props.instanceParams.splitType
            : ''
        this.prevThresholdCol = this.props.instanceParams
            ? this.props.instanceParams.thresholdCol
            : ''
        this.prevThresholdColType = this.isSplitThresholdRenderDate()
    }
    componentDidMount() {
        const { instanceParams, form } = this.props
        if (
            instanceParams.hasOwnProperty('splitType') &&
            instanceParams.splitType === 'THRESHOLD' &&
            !instanceParams.hasOwnProperty('splitThreshold')
        ) {
            this.initSplitThreshold()
        }
    }

    initSplitThreshold = () => {
        const isDate = this.isSplitThresholdRenderDate()
        const { onSave, form } = this.props
        const attrName = SPLIT_THRESHOLD_ATTRNAME
        let value = 0
        let fiedName = ST_NUMBER_FORM_FIELD
        if (isDate) {
            value = +new Date()
            fiedName = ST_DATE_FORM_FIELD
            onSave(
                {
                    [attrName]: value
                },
                this.saveCompState
            )
            form.setFieldsValue({
                [attrName]: new moment(value)
            })
        } else {
            this.saveInput(attrName, value)
            form.setFieldsValue({
                [fiedName]: value
            })
        }
    }

    componentWillReceiveProps(nextProps) {
        const { instanceParams } = this.props
        // 拆分类型切换
        if (this.prevSplitType !== nextProps.instanceParams.splitType) {
            if (
                nextProps.instanceParams.splitType === 'THRESHOLD' &&
                !nextProps.instanceParams.hasOwnProperty('splitThreshold')
            ) {
                this.initSplitThreshold()
            }
        }
        // 阈值拆分下，字段类型切换
        if (
            nextProps.instanceParams.splitType === 'THRESHOLD' &&
            nextProps.instanceParams.thresholdCol !== this.prevThresholdCol
        ) {
            const currentThresholdColType = this.isSplitThresholdRenderDate()
            if (currentThresholdColType !== this.prevThresholdColType) {
                this.initSplitThreshold()
            }
        }
        this.prevThresholdColType = this.isSplitThresholdRenderDate()
        this.prevSplitType = nextProps.instanceParams.splitType
        this.prevThresholdCol = nextProps.instanceParams.thresholdCol
    }

    getParamRenderDescription() {
        const { instanceParams } = this.props
        let res = {
            splitType: {
                type: 'RadioGroup',
                param: {
                    label: '拆分类型',
                    options: [
                        { value: 'GROUP', label: '分组拆分' },
                        { value: 'RATIO', label: '比例拆分' },
                        { value: 'THRESHOLD', label: '阈值拆分' }
                    ]
                }
            }
        }

        if (instanceParams.splitType === 'GROUP') {
            res = this.getGroupSplitParams(res)
        } else if (instanceParams.splitType === 'RATIO') {
            res = this.getRatioSplitParam(res)
        } else {
            res = this.getThresholdSplitParam(res)
        }
        return res
    }

    getGroupSplitParams(res) {
        const { inputSchema, instanceParams, onSave, isLocked } = this.props
        const oldInputSchema = inputSchema ? inputSchema[0] : []
        const selectedSortCols = instanceParams.sortCols || []

        Object.assign(res, {
            groupCols: {
                type: 'FieldSelect',
                param: {
                    label: '分组字段',
                    selectableColumns: getSelectableColumns(
                        oldInputSchema,
                        selectedSortCols
                    )
                }
            },
            sortCols: {
                option: {
                    byConcreteRenderer: true
                }
            },
            isHead: {
                type: 'RadioGroup',
                param: {
                    label: '分组操作',
                    options: [
                        { value: true, label: '拆分每组前N条记录' },
                        { value: false, label: '拆分每组后N条记录' }
                    ]
                }
            },
            records: {
                type: 'Input',
                param: {
                    label: 'N: ',
                    isPositiveInteger: true
                }
            }
        })
        return res
    }

    getRatioSplitParam(res) {
        const { instanceParams } = this.props
        Object.assign(res, {
            ratio: {
                type: 'Input',
                param: {
                    label: '比例(0, 1)',
                    min: { value: 0, include: false },
                    max: { value: 1, include: false }
                }
            },
            splitStrategy: {
                type: 'RadioGroup',
                param: {
                    label: '拆分策略',
                    options: [
                        { value: 'RANDOM', label: '随机拆分' },
                        { value: 'SEQUENTIAL', label: '顺序拆分' }
                    ]
                }
            },
            seed: {
                type: 'Input',
                param: {
                    label: '随机种子',
                    isRequired: false,
                    isInteger: true
                },
                option: {
                    hidden: instanceParams.splitStrategy !== 'RANDOM'
                }
            }
        })
        return res
    }

    getThresholdSplitParam(res) {
        Object.assign(res, {
            thresholdCol: {
                type: 'FieldSelect',
                param: {
                    label: '选择字段',
                    isSelectMulti: false,
                    allowedTypes: [
                        'short',
                        'long',
                        'float',
                        'double',
                        'int',
                        'byte',
                        'fractional',
                        'integer',
                        'decimal',
                        'timestamp'
                    ] // 即数值型，加decimal,timestamp
                }
            },
            splitThreshold: {
                option: {
                    byConcreteRenderer: true
                }
                // type: 'Input',
                // param: {
                //     label: '阈值',
                //     isNumber: true,
                // },
            }
        })
        return res
    }

    handleNumberChange = () => {
        const attrName = SPLIT_THRESHOLD_ATTRNAME
        this.saveCompState({ [attrName]: null }, 'init')
    }

    handleNumberSave = e => {
        const { form, onSave, instanceParams } = this.props
        const { validateFields } = form
        const value = e.target.value
        const attrName = SPLIT_THRESHOLD_ATTRNAME
        const formFieldName = ST_NUMBER_FORM_FIELD

        validateFields(Object.keys({ [formFieldName]: value }), {}, err => {
            if (err) {
                form.setFieldsValue({
                    [formFieldName]: instanceParams[attrName]
                })
            } else {
                this.saveInput(attrName, Number(value))
            }
        })
    }

    handleDateChange = (e, attrName) => {
        const value = moment(e).valueOf()
        this.setState({
            params: {
                state: {
                    [attrName]: 'init'
                }
            },
            [attrName]: value
        })
    }

    handleOpenChange = (open, attrName) => {
        if (open) {
            return
        }

        const { form, instanceParams, isLocked, onSave } = this.props
        const value = this.state[attrName]
        if (value === 'Invalid date') {
            this.props.form.setFieldsValue({
                [attrName]: new moment(instanceParams[attrName]) // 还原上一次值
            })
            return
        }
        onSave(
            {
                [attrName]: value
            },
            this.saveCompState
        )
    }

    disabledDate = current => {
        // 可选择的日期在1970开始，到现在时刻往后10年截止
        return (
            current < moment('1970-01-01') ||
            current > moment().add(10, 'years')
        )
    }

    // 日期型阈值输入框
    renderDateSplitThreshold = () => {
        const { form, instanceParams, isLocked, onSave } = this.props
        const { getFieldDecorator } = form
        const attrName = SPLIT_THRESHOLD_ATTRNAME
        const defaultValue = new moment(instanceParams[attrName])
        return (
            <FormItem
                label="阈值"
                required={true}
                {...getFormItemState(this.state.params.state[attrName])}>
                {getFieldDecorator(ST_DATE_FORM_FIELD, {
                    initialValue: defaultValue,
                    rules: [{ type: 'object', required: true, message: '必填' }]
                })(
                    <DatePicker
                        // showTime={
                        //     instanceParams.transDateFormat !== 'yyyy-MM-dd'
                        // }
                        allowClear={false}
                        showTime
                        placeholder=""
                        disabledDate={this.disabledDate}
                        style={{ width: '100%' }}
                        onChange={e => this.handleDateChange(e, attrName)}
                        onOpenChange={open =>
                            this.handleOpenChange(open, attrName)
                        }
                        disabled={isLocked}
                        format={DATE_TARGET_FORMAT}
                    />
                )}
            </FormItem>
        )
    }

    getAllRules = () => {
        const props = { isRequired: true, isNumber: true }
        const min = getMin(props)
        const max = getMax(props)
        return getInputRules(min, max, props)
    }

    // 数值型阈值输入框
    renderNumberThreshold = () => {
        const { instanceParams, isLocked, form } = this.props
        const { getFieldDecorator } = form
        const attrName = SPLIT_THRESHOLD_ATTRNAME
        return (
            <FormItem
                label="阈值"
                required={true}
                {...getFormItemState(this.state.params.state[attrName])}>
                {getFieldDecorator(ST_NUMBER_FORM_FIELD, {
                    initialValue: instanceParams[attrName],
                    rules: this.getAllRules()
                })(
                    <Input
                        onChange={this.handleNumberChange}
                        onBlur={this.handleNumberSave}
                        onPressEnter={e => {
                            e.target.blur()
                        }}
                        disabled={isLocked}
                    />
                )}
            </FormItem>
        )
    }

    getThresholdColField = () => {
        const { instanceParams, inputSchema } = this.props
        const oldInputSchema = inputSchema ? inputSchema[0] : []
        const selectedFieldName = Array.isArray(instanceParams.thresholdCol)
            ? instanceParams.thresholdCol[0]
            : ''
        const field = oldInputSchema.find(
            field => field.name === selectedFieldName
        )
        return field
    }

    isSplitThresholdRenderDate = () => {
        const field = this.getThresholdColField()
        if (field) {
            return field.type === 'timestamp'
        } else {
            return this.prevThresholdColType
        }
    }

    renderSplitThreshold = () => {
        if (this.isSplitThresholdRenderDate()) {
            return this.renderDateSplitThreshold()
        } else {
            return this.renderNumberThreshold()
        }
    }

    renderGroupOrderingSelection = () => {
        const { inputSchema, instanceParams, onSave, isLocked } = this.props
        const oldInputSchema = inputSchema ? inputSchema[0] : []
        let allColumns = oldInputSchema

        let selectedColumns = mapToTuple({
            name: instanceParams.sortCols,
            order: instanceParams.sortTypes
        })

        const onSelectFields = selectedColumns => {
            return {
                sortCols: selectedColumns.map(col => col.name),
                sortTypes: selectedColumns.map(col => col.order)
            }
        }
        // 分组字段未选择，分组排序可选项为空；分组字段已选择字段，分组排序可选项将已选字段置灰
        let selectableColumns = []
        const selectedGroupCols = instanceParams.groupCols || []
        if (selectedGroupCols.length > 0) {
            selectableColumns = getSelectableColumns(
                allColumns,
                selectedGroupCols
            )
        } else {
            allColumns = []
            selectableColumns = []
        }

        return (
            <WrappedFieldSelection
                label="分组排序"
                isRequired
                instanceParams={instanceParams}
                attrName="sortCols"
                allColumns={allColumns}
                selectableColumns={selectableColumns}
                selectedColumns={selectedColumns}
                isLocked={isLocked}
                isSelectMulti={true}
                onSelectFields={onSelectFields}
                onSave={onSave}
                additionalParams={[
                    {
                        title: '排序',
                        paramName: 'order',
                        inputType: 'dropdown',
                        defaultValue: 'ASC',
                        options: [
                            { text: '升序', value: 'ASC' },
                            { text: '降序', value: 'DESC' }
                        ]
                    }
                ]}
            />
        )
    }

    render() {
        const { instanceParams } = this.props
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
                renderPieces={{
                    sortCols:
                        instanceParams.splitType == 'GROUP' &&
                        this.renderGroupOrderingSelection(),
                    splitThreshold: this.renderSplitThreshold()
                }}
            />
        )
    }
}

export default Form.create()(DataSplit)
