import React from 'react'
import { Form, DatePicker } from 'antd'
import ConfigComponent from '../../ConfigComponent'
import WrappedSelect from '../../../AlgoComponent/wrappedBasicComponent/WrappedSelect'
import {
    composeCompSaveState,
    getFormItemState
} from '../../../AlgoComponent/common'
import {
    IntegerWithAnomalylValidator,
    DoubleWithAnomalylValidator
} from '../../../AlgoComponent/inputValidator'

import moment from 'moment'

const FormItem = Form.Item

class DataTypeTransform extends React.Component {
    constructor(props) {
        super(props)
        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {}
            }
        }
    }

    getParamRenderDescription() {
        return {
            doubleCols: {
                type: 'FieldSelect',
                param: {
                    label: '转换为double类型的列(可选)',
                    isRequired: false
                }
            },
            doubleDefault: {
                type: 'Input',
                param: {
                    label: '转换为double异常默认值',
                    // isNumber: true,
                    customValidator: DoubleWithAnomalylValidator,
                    isRequired: false
                }
            },
            intCols: {
                type: 'FieldSelect',
                param: {
                    label: '转换为integer类型的列(可选)',
                    isRequired: false
                }
            },
            intDefault: {
                type: 'Input',
                param: {
                    label: '转换为integer异常默认值',
                    // isInteger: true,
                    customValidator: IntegerWithAnomalylValidator,
                    isRequired: false
                }
            },
            stringCols: {
                type: 'FieldSelect',
                param: {
                    label: '转换为string类型的列(可选)',
                    isRequired: false
                }
            },
            stringDefault: {
                type: 'Input',
                param: {
                    label: '转换为string异常默认值',
                    isRequired: false
                }
            },
            dateCols: {
                type: 'FieldSelect',
                param: {
                    label: '转换为date类型的列(可选)',
                    isRequired: false
                }
            },
            dateOriginFormat: {
                type: 'Select',
                param: {
                    label: '原始列格式',
                    options: ['yyyy-MM-dd HH:mm:ss', 'yyyy-MM-dd', 'TimeStamp'],
                    isRequired: false
                }
            },
            transDateFormat: {
                option: {
                    byConcreteRenderer: true
                }
            },
            dateDefault: {
                option: {
                    byConcreteRenderer: true
                }
            },
            keepColsBool: {
                type: 'Checkbox',
                param: {
                    label: <span>保留原列 (衍生列以"转换类型_字段"命名) </span>
                }
            }
        }
    }

    handleSaveTransDateFormat = param => {
        const { instanceParams, form, onSave } = this.props
        const value = param.transDateFormat

        let dateValue = instanceParams.dateDefault
        const mapFormat = {
            'yyyy-MM-dd HH:mm:ss': 'YYYY-MM-DD HH:mm:ss',
            'yyyy-MM-dd': 'YYYY-MM-DD',
            TimeStamp: 'x'
        }

        if (
            instanceParams.transDateFormat === 'yyyy-MM-dd' &&
            instanceParams.dateDefault === '1970-01-01'
        ) {
            dateValue = '1970-01-01 08:00:00'
        }

        const dateDefault =
            instanceParams.transDateFormat == 'TimeStamp'
                ? moment(new Date(Number(dateValue))).format(mapFormat[value])
                : moment(dateValue).format(mapFormat[value])

        form.setFieldsValue({
            dateDefault:
                instanceParams.transDateFormat === 'TimeStamp'
                    ? moment(
                          moment(new Date(Number(dateValue))).format(
                              'YYYY-MM-DD HH:mm:ss'
                          )
                      )
                    : moment(dateValue)
        })

        onSave(
            {
                transDateFormat: value,
                dateDefault: dateDefault
            },
            this.saveCompState
        )
    }

    disabledDate = current => {
        // 可选择的日期在1970开始，到现在时刻往后10年截止
        return (
            current < moment('1970-01-01') ||
            current > moment().add(10, 'years')
        )
    }

    renderTransDateFormat = () => {
        const { form, instanceParams, isLocked } = this.props
        return (
            <WrappedSelect
                form={form}
                instanceParams={instanceParams}
                isLocked={isLocked}
                paramState={this.state.params.state.transDateFormat}
                attrName="transDateFormat"
                label="转换为date类型的格式"
                defaultValue={
                    instanceParams.transDateFormat || 'yyyy-MM-dd HH:mm:ss'
                }
                options={['yyyy-MM-dd HH:mm:ss', 'yyyy-MM-dd', 'TimeStamp']}
                onSave={this.handleSaveTransDateFormat}
            />
        )
    }

    renderDateDefaultVal = () => {
        const { form, instanceParams, isLocked, onSave } = this.props
        const { getFieldDecorator } = form
        let defaultValue

        let DateTargetFormat = 'YYYY-MM-DD HH:mm:ss'
        if (instanceParams.transDateFormat == 'yyyy-MM-dd HH:mm:ss') {
            DateTargetFormat = 'YYYY-MM-DD HH:mm:ss'
        } else if (instanceParams.transDateFormat == 'yyyy-MM-dd') {
            DateTargetFormat = 'YYYY-MM-DD'
        } else if (instanceParams.transDateFormat == 'TimeStamp') {
            DateTargetFormat = 'x'
        }

        if (instanceParams.dateDefault === 'null') {
            defaultValue = ''
        } else {
            if (instanceParams.transDateFormat === 'TimeStamp') {
                defaultValue = new moment(Number(instanceParams.dateDefault))
            } else {
                defaultValue = new moment(instanceParams.dateDefault)
            }
        }

        return (
            <FormItem
                label="转换为date异常默认值"
                {...getFormItemState(this.state.params.state.dateDefault)}>
                {getFieldDecorator('dateDefault', {
                    initialValue: defaultValue
                })(
                    <DatePicker
                        showTime={
                            instanceParams.transDateFormat !== 'yyyy-MM-dd'
                        }
                        placeholder=""
                        disabledDate={this.disabledDate}
                        // disabledTime={this.disabledDateTime}
                        style={{ width: '100%' }}
                        onChange={e => {
                            onSave(
                                {
                                    dateDefault:
                                        e === null
                                            ? 'null'
                                            : moment(e).format(DateTargetFormat)
                                },
                                this.saveCompState
                            )
                        }}
                        disabled={isLocked}
                        format={DateTargetFormat}
                    />
                )}
            </FormItem>
        )
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
                renderPieces={{
                    transDateFormat: this.renderTransDateFormat(),
                    dateDefault: this.renderDateDefaultVal()
                }}
            />
        )
    }
}

export default Form.create()(DataTypeTransform)
