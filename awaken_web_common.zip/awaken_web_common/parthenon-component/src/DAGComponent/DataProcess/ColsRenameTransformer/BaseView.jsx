import React from 'react'
import WrappedFieldSelection from '../../../AlgoComponent/wrappedBasicComponent/WrappedFieldSelection'
import { mapToTuple } from '../../../AlgoComponent/transformHelper'

class ColsRenameTransformer extends React.Component {
    render() {
        const { inputSchema, instanceParams, onSave, isLocked } = this.props
        const allColumns = inputSchema['0']

        let selectedColumns = mapToTuple({
            name: instanceParams.origCols,
            outputName: instanceParams.renameCols,
        })

        const onSelectFields = selectedColumns => {
            return {
                origCols: selectedColumns.map(col => col.name),
                renameCols: selectedColumns.map(col => col.outputName),
            }
        }

        return (
            <WrappedFieldSelection
                label="重命名字段"
                isRequired
                instanceParams={instanceParams}
                attrName="origCols"
                allColumns={allColumns}
                selectedColumns={selectedColumns}
                isLocked={isLocked}
                onSelectFields={onSelectFields}
                onSave={onSave}
                additionalParams={[
                    {
                        title: '输出名',
                        paramName: 'outputName',
                        inputType: 'textInput',
                        defaultValue: record => record.name,
                        isOutputCol: true,
                    },
                ]}
            />
        )
    }
}

export default ColsRenameTransformer
