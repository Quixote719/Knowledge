import React from 'react'
import { Form } from 'antd'
import { composeCompSaveState } from '../../../AlgoComponent/common'
import ConfigComponent from '../../ConfigComponent'
import WrappedSelect from '../../../AlgoComponent/wrappedBasicComponent/WrappedSelect'
import WrappedInput from '../../../AlgoComponent/wrappedBasicComponent/WrappedInput'

class DataSampling extends React.Component {
    constructor(props) {
        super(props)

        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {},
            },
        }
    }

    handleSavePositiveSampleMode = params => {
        const { onSave, instanceParams } = this.props
        if (
            instanceParams.positiveParameter !== '' &&
            instanceParams.positiveParameter !== undefined
        ) {
            params.positiveParameter = ''
        }
        onSave(params, this.saveCompState)
    }

    handleSaveNegativeSampleMode = params => {
        const { onSave, instanceParams } = this.props
        if (
            instanceParams.negativeParameter !== '' &&
            instanceParams.negativeParameter !== undefined
        ) {
            params.negativeParameter = ''
        }
        onSave(params, this.saveCompState)
    }

    getParamRenderDescription() {
        const { instanceParams } = this.props

        let res = {
            sampleType: {
                type: 'Select',
                param: {
                    label: '抽样方式',
                    options: [
                        { value: 'RandomSampling', label: '随机抽样' },
                        { value: 'StratifiedSampling', label: '分层抽样' },
                        {
                            value: 'PositiveNegativeProportionSampling',
                            label: '正\\负样本比例抽样',
                        },
                    ],
                },
            },
        }

        if (
            instanceParams.sampleType !== 'PositiveNegativeProportionSampling'
        ) {
            res.sampleMode = {
                type: 'Select',
                param: {
                    label: '样本抽样方式',
                    options: [
                        { value: 'number_sample', label: '数量抽样' },
                        { value: 'percent_sample', label: '比例抽样' },
                    ],
                },
            }

            if (instanceParams.sampleMode === 'percent_sample') {
                res.percentSampleParameter = {
                    type: 'Input',
                    param: {
                        label: '样本抽样参数 (0,1]',
                        min: { value: 0, include: false },
                        max: { value: 1, include: true },
                    },
                }
            }

            if (
                instanceParams.sampleMode === 'number_sample' ||
                instanceParams.sampleMode === undefined
            ) {
                res.numberSampleParameter = {
                    type: 'Input',
                    param: {
                        label: '样本抽样参数 >=1',
                        min: { value: 1, include: true },
                        max: { value: 1000000000, include: true },
                        isInteger: true,
                    },
                }
            }
        }

        if (instanceParams.sampleType === 'StratifiedSampling') {
            res.stratifiedColumn = {
                type: 'FieldSelect',
                param: {
                    label: '分层列',
                    isSelectMulti: false,
                },
            }
        }

        if (
            instanceParams.sampleType === 'PositiveNegativeProportionSampling'
        ) {
            res.labelColumn = {
                type: 'FieldSelect',
                param: {
                    label: '标签列',
                    isSelectMulti: false,
                },
            }

            res.labelNum = {
                type: 'Input',
                param: {
                    label: '正样本标签值',
                    isNumber: true,
                },
            }

            res.positiveSampleMode = {
                option: {
                    byConcreteRenderer: true,
                },
            }

            res.positiveParameter = {
                option: {
                    byConcreteRenderer: true,
                },
            }

            res.negativeSampleMode = {
                option: {
                    byConcreteRenderer: true,
                },
            }

            res.negativeParameter = {
                option: {
                    byConcreteRenderer: true,
                },
            }
        }

        res.seeds = {
            type: 'Input',
            param: {
                label: '随机种子',
                isInteger: true,
                isRequired: false,
            },
        }

        res.withReplacement = {
            type: 'Checkbox',
            param: {
                label: '放回抽样',
            },
        }

        return res
    }

    renderPositiveSampleMode = () => {
        return this.renderPositiveNegativeSampleMode(
            'positiveSampleMode',
            'negativeSampleMode',
            this.handleSavePositiveSampleMode,
            '正样本中抽样模式'
        )
    }

    renderNegativeSampleMode = () => {
        return this.renderPositiveNegativeSampleMode(
            'negativeSampleMode',
            'positiveSampleMode',
            this.handleSaveNegativeSampleMode,
            '负样本中抽样模式'
        )
    }

    renderPositiveNegativeSampleMode = (
        sampleModeName,
        oppoSampleNodeName,
        onSave,
        label
    ) => {
        const { instanceParams, isLocked, form } = this.props

        const options = [
            { value: 'number_sample', label: '数量抽样' },
            { value: 'percent_sample', label: '比例抽样' },
        ]

        if (instanceParams[oppoSampleNodeName] !== 'positive_negative_sample') {
            options.push({
                value: 'positive_negative_sample',
                label: '正\\负样本比例抽样',
            })
        }

        return (
            <WrappedSelect
                label={label}
                paramState={this.state.params.state[sampleModeName]}
                form={form}
                isRequired
                instanceParams={instanceParams}
                attrName={sampleModeName}
                isLocked={isLocked}
                onSave={onSave}
                options={options}
            />
        )
    }

    renderPositiveParameter = () => {
        return this.renderPositiveNegativeParameter(
            'positiveParameter',
            'positiveSampleMode',
            '正样本中抽样参数'
        )
    }

    renderNegativeParameter = () => {
        return this.renderPositiveNegativeParameter(
            'negativeParameter',
            'negativeSampleMode',
            '负样本中抽样参数'
        )
    }

    renderPositiveNegativeParameter = (
        attrName,
        sampleModeName,
        labelPrefix
    ) => {
        const { instanceParams, isLocked, form, onSave } = this.props
        let props = {
            isRequired: true,
        }

        if (instanceParams[sampleModeName] === 'number_sample') {
            props.label = `${labelPrefix} >=1`
            props.min = { value: 1, include: true }
            props.max = { value: 1000000000, include: true }
            props.isInteger = true
        } else if (instanceParams[sampleModeName] === 'percent_sample') {
            props.label = `${labelPrefix} (0,1]`
            props.min = { value: 0, include: false }
            props.max = { value: 1, include: true }
        } else if (
            instanceParams[sampleModeName] === 'positive_negative_sample'
        ) {
            props.label = `${labelPrefix} >0`
            props.min = { value: 0, include: false }
            props.max = { value: 1000000000, include: true }
        } else {
            props.label = `${labelPrefix} >0`
            props.min = { value: 0, include: false }
            props.max = { value: 1000000000, include: true }
        }
        return (
            <WrappedInput
                paramState={this.state.params.state[attrName]}
                {...props}
                form={form}
                instanceParams={instanceParams}
                attrName={attrName}
                isLocked={isLocked}
                onSave={params => {
                    onSave(params, this.saveCompState)
                }}
            />
        )
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
                renderPieces={{
                    positiveSampleMode: this.renderPositiveSampleMode(),
                    positiveParameter: this.renderPositiveParameter(),
                    negativeSampleMode: this.renderNegativeSampleMode(),
                    negativeParameter: this.renderNegativeParameter(),
                }}
            />
        )
    }
}

export default Form.create()(DataSampling)
