export default {
    renderProps: (props, instance) => {
        return {
            ...props,
            isNoParamStyle: instance.isNoParamStyle(),
        }
    },
}
