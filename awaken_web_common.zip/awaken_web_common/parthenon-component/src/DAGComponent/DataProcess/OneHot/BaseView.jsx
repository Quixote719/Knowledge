import React from 'react'
import ConfigComponent from '../../ConfigComponent'
import styles from './BaseView.less'

export default class OneHot extends React.Component {
    getParamRenderDescription() {
        return {
            inputCols: {
                type: 'FieldSelect',
                param: {
                    label: '编码字段选择',
                    portIndex: 0,
                },
            },
            keepColsBool: {
                type: 'Checkbox',
                param: {
                    label: (
                        <span>
                            保留原列
                            <span className={styles.floatRight}>
                                (衍生列以"编码字段_Vec"命名)
                            </span>
                        </span>
                    ),
                },
            },
        }
    }

    renderCompLockedText = () => {
        const textStyle = {
            color: '#f5222d',
            margin: '20px 0 30px 0',
            fontSize: '14px',
        }
        return (
            <div style={textStyle}>不支持对接受参数列表的组件进行参数配置</div>
        )
    }

    render() {
        const { isNoParamStyle, isLocked } = this.props
        return (
            <div>
                {isNoParamStyle && this.renderCompLockedText()}
                <ConfigComponent
                    {...this.props}
                    paramsDescription={this.getParamRenderDescription()}
                    isLocked={isLocked || isNoParamStyle}
                />
            </div>
        )
    }
}
