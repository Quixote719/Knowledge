import React from 'react'
import { Form } from 'antd'
import ConfigComponent from '../../ConfigComponent'

import TimeSlide from '../../../AlgoComponent/Shared/TimeSlide'
import ComplexDropdownSelection from '../../../AlgoComponent/Shared/ComplexDropdownSelection'

import {
    composeCompSaveState,
    getFormItemState,
} from '../../../AlgoComponent/common'

import {
    isGeneralNumericType,
    isStringType,
    isDateType,
    isBooleanType,
} from '../../../AlgoComponent/typeHelper'

const FormItem = Form.Item

export default class SlideWindowAgg extends React.Component {
    constructor(props) {
        super(props)
        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {},
            },
        }
    }
    getParamRenderDescription() {
        return {
            groupByCols: {
                type: 'FieldSelect',
                param: {
                    label: '分组字段',
                    isRequired: false,
                },
            },
            timeSlide: {
                option: {
                    byConcreteRenderer: true,
                },
            },
            aggSetting: {
                option: {
                    byConcreteRenderer: true,
                },
            },
        }
    }

    handleChangeTimeParam = params => {
        const obj = this.state.params.state
        for (let key in params) {
            obj[key] = 'init'
        }
        this.setState({
            params: {
                state: obj,
            },
        })
    }

    hanldeSaveTimeParam = params => {
        const { onSave } = this.props
        onSave(params, this.saveCompState)
    }

    renderTimeSlide = () => {
        const { instanceParams, inputSchema, isLocked } = this.props
        return (
            <TimeSlide
                {...instanceParams}
                paramState={{ ...this.state.params.state }}
                onChangeInput={this.handleChangeTimeParam}
                allColumns={inputSchema[0] || []}
                onSave={this.hanldeSaveTimeParam}
                disabled={isLocked}
            />
        )
    }

    handleSaveAggSetting = selectedColumns => {
        const { onSave } = this.props
        let metricColTypes = []
        let metricCols = []
        let aggMethods = []
        let metricAlias = []
        for (let i = 0; i < selectedColumns.length; i++) {
            metricColTypes.push(selectedColumns[i].input1Type) // 存储input1字段类型，前端展示用
            metricCols.push(selectedColumns[i].input1)
            aggMethods.push(selectedColumns[i].input2)
            metricAlias.push(selectedColumns[i].outputName)
        }
        onSave(
            { metricColTypes, metricCols, aggMethods, metricAlias },
            this.saveCompState
        )
    }

    getAggsSelectedColumns = () => {
        const { instanceParams } = this.props
        const selectedColumns = []
        const metricColTypes = instanceParams.metricColTypes || []
        const metricCols = instanceParams.metricCols || []
        const aggMethods = instanceParams.aggMethods || []
        const metricAlias = instanceParams.metricAlias || []
        if (
            metricCols.length === aggMethods.length &&
            aggMethods.length === metricAlias.length
        ) {
            for (let i = 0; i < metricCols.length; i++) {
                selectedColumns.push({
                    input1Type: metricColTypes[i], // 存储input1字段类型，前端展示用
                    input1: metricCols[i],
                    input2: aggMethods[i],
                    outputName: metricAlias[i],
                })
            }
        }
        return selectedColumns
    }

    renderAggSetting = () => {
        const { inputSchema, isLocked } = this.props

        const input1 = (inputSchema[0] || [])
            .map(record => ({
                name: record.name,
                value: record.name,
                key: record.name,
                type: record.type,
            }))
            .filter(record => {
                return (
                    isGeneralNumericType(record.type) ||
                    isStringType(record.type) ||
                    isDateType(record.type) ||
                    isBooleanType(record.type)
                )
            })
        const input2 = ({ type }) => {
            if (isGeneralNumericType(type)) {
                return [
                    { name: '全组计数', value: 'count', key: 'count' },
                    { name: '最小值', value: 'min', key: 'min' },
                    { name: '最大值', value: 'max', key: 'max' },
                    { name: '均值', value: 'mean', key: 'mean' },
                    { name: '标准差', value: 'std', key: 'std' },
                    { name: '偏度', value: 'skewness', key: 'skewness' },
                    { name: '峰度', value: 'kurtosis', key: 'kurtosis' },
                    { name: '中位数', value: 'median', key: 'median' },
                    { name: '众数', value: 'mode', key: 'mode' },
                    { name: '求和', value: 'sum', key: 'sum' },
                ]
            } else if (isStringType(type) || isBooleanType(type)) {
                return [
                    { name: '全组计数', value: 'count', key: 'count' },
                    { name: '众数', value: 'mode', key: 'mode' },
                ]
            } else if (isDateType(type)) {
                return [
                    { name: '全组计数', value: 'count', key: 'count' },
                    { name: '最小值', value: 'min', key: 'min' },
                    { name: '最大值', value: 'max', key: 'max' },
                    { name: '众数', value: 'mode', key: 'mode' },
                ]
            }
        }
        const selectedColumns = this.getAggsSelectedColumns()

        return (
            <FormItem
                label={'全局统计'}
                {...getFormItemState(this.state.params.state.metricCols)}
            >
                <ComplexDropdownSelection
                    required={false}
                    buttonText="设置"
                    onSelectFields={this.handleSaveAggSetting}
                    input1={input1}
                    input2={input2}
                    input1Label={'字段选择'}
                    input2Label={'方法选择'}
                    outputLabel={'已选择字段'}
                    input1TableHead={'分析字段'}
                    input2TableHead={'分析指标'}
                    selectedColumns={selectedColumns}
                    isSelectMulti={true}
                    disabled={isLocked}
                    additionalParams={[
                        {
                            title: '输出字段',
                            paramName: 'outputName',
                            inputType: 'textInput',
                            defaultValue: record =>
                                `${record.input1}_${record.input2}`,
                            isOutputCol: true,
                        },
                    ]}
                />
            </FormItem>
        )
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
                renderPieces={{
                    timeSlide: this.renderTimeSlide(),
                    aggSetting: this.renderAggSetting(),
                }}
            />
        )
    }
}
