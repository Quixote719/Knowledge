import React from 'react'
import { Form, Input } from 'antd'

import FilePreview from '../../AlgoComponent/Shared/FilePreview'
import { createJsonValidator } from '../../AlgoComponent/inputValidator'
import {
    composeCompSaveState,
    getFormItemState,
} from '../../AlgoComponent/common'

const FormItem = Form.Item
const TextArea = Input.TextArea

class CustomComponent extends React.Component {
    constructor(props) {
        super(props)

        this.saveCompState = composeCompSaveState(this)
        this.state = {
            previewVisible: false,
            params: {
                state: {
                    k: 'init',
                    inputCol: 'init',
                },
            },
        }
    }

    handleOpenPreview = () => {
        this.setState({
            previewVisible: true,
        })
    }

    handleClosePreview = () => {
        this.setState({
            previewVisible: false,
        })
    }

    /**
     * 如果是合法的JSON则保存并美化其格式
     */
    handleCustomJSONSave = value => {
        const { onSave } = this.props
        const { setFieldsValue, validateFields } = this.props.form
        validateFields(['customParams'], {}, err => {
            if (!err) {
                let val = JSON.parse(value)
                let newVal = JSON.stringify(val, null, 2)
                onSave(
                    {
                        customParams: newVal,
                    },
                    this.saveCompState
                )
                setFieldsValue({
                    customParams: newVal,
                })
            }
        })
    }

    handleCustomJSONChange = () => {
        this.setState({
            params: {
                state: {
                    customParams: 'init',
                },
            },
        })
    }

    renderCustomJSON = () => {
        const { isLocked, instanceParams } = this.props
        const { getFieldDecorator } = this.props.form
        const attrName = 'customParams'
        return (
            <FormItem
                label="参数设置"
                required
                {...getFormItemState(this.state.params.state[attrName])}
            >
                {getFieldDecorator(attrName, {
                    initialValue: instanceParams[attrName],
                    rules: createJsonValidator(),
                })(
                    <TextArea
                        placeholder="请输入json格式参数列表"
                        onChange={this.handleCustomJSONChange}
                        onBlur={e => this.handleCustomJSONSave(e.target.value)}
                        disabled={isLocked}
                        autosize={{ minRows: 20, maxRows: 37 }}
                    />
                )}
            </FormItem>
        )
    }

    renderPreviewFile = () => {
        const { downloadPath, filePath, programmingLanguage } = this.props
        return (
            this.state.previewVisible && (
                <FilePreview
                    downloadPath={downloadPath}
                    programmingLanguage={programmingLanguage}
                    onClose={this.handleClosePreview}
                    filePath={filePath}
                    showError={false}
                />
            )
        )
    }

    render() {
        //const { filePath } = this.props
        return (
            <div>
                {/* filePath && <Button onClick={this.handleOpenPreview}>代码预览</Button> */}
                {this.renderPreviewFile()}
                {this.renderCustomJSON()}
            </div>
        )
    }
}

export default Form.create()(CustomComponent)
