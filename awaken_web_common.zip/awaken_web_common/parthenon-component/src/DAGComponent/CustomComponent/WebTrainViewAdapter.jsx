export default {
    renderProps: (props, instance) => {
        return {
            ...props,
            downloadPath: instance.downloadPath,
            filePath: instance.getFilePath(),
            programmingLanguage: instance.getProgrammingLanguage(),
        }
    },
}
