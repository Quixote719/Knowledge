import React from 'react'
import { Form, Input } from 'antd'
import ConfigComponent from '../../ConfigComponent'
import HourRangeSelect from '../../../AlgoComponent/Shared/HourRangeSelect'
import ParamSaveState from '../../../AlgoComponent/Shared/ParamSaveState'
import { createJsonValidator } from '../../../AlgoComponent/inputValidator'
import {
    getFormItemState,
    composeCompSaveState,
} from '../../../AlgoComponent/common'

const FormItem = Form.Item
const TextArea = Input.TextArea

class AccomFeatureExtractor extends React.Component {
    constructor(props) {
        super(props)

        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {},
            },
        }
    }

    getParamRenderDescription() {
        const { instanceParams } = this.props
        const res = {
            paramMode: {
                type: 'RadioGroup',
                param: {
                    label: '参数模式',
                    options: [
                        { value: 'normal', label: '普通模式' },
                        { value: 'custom', label: '高级模式' },
                    ],
                },
            },
        }

        if (instanceParams.paramMode === 'custom') {
            res.customJSON = {
                option: {
                    byConcreteRenderer: true,
                },
            }
        } else if (instanceParams.paramMode === 'normal') {
            (res.is_merge_record = {
                type: 'Checkbox',
                param: {
                    label: '是否合并住宿记录',
                },
            }),
            (res.mr_delta_time = {
                type: 'Input',
                param: {
                    label: '住宿记录合并时间区间(分钟) >=1',
                    min: { value: 1, include: true },
                    isInteger: true,
                },
            })
            res.sliding_days = {
                type: 'Input',
                param: {
                    label: '统计区间时间周期(天) >=1',
                    min: { value: 1, include: true },
                    isInteger: true,
                },
            }
            res.tolerance = {
                type: 'Input',
                param: {
                    label: '统计区间规则触发阈值(次) >=1',
                    min: { value: 1, include: true },
                    isInteger: true,
                },
            }
            res.checkInHourRangeSelect = {
                option: {
                    byConcreteRenderer: true,
                },
            }
            res.checkOutHourRangeSelect = {
                option: {
                    byConcreteRenderer: true,
                },
            }
            res.check_in_interval = {
                type: 'Input',
                param: {
                    label: '相邻住宿记录入住时间差阈值(时) >=1',
                    min: { value: 1, include: true },
                    isInteger: true,
                },
            }
            res.check_out_interval = {
                type: 'Input',
                param: {
                    label: '相邻住宿记录时间间隔阈值(时) >=1',
                    min: { value: 1, include: true },
                    isInteger: true,
                },
            }
        }

        return res
    }

    handleSaveCheckInRange = (start, end) => {
        const { onSave } = this.props
        onSave(
            {
                abnormal_begin_checkin: start,
                abnormal_end_checkin: end % 24,
            },
            this.saveCompState
        )
    }

    handleSaveCheckOutRange = (start, end) => {
        const { onSave } = this.props
        onSave(
            {
                abnormal_begin_checkout: start,
                abnormal_end_checkout: end % 24,
            },
            this.saveCompState
        )
    }

    renderCheckInHourRangeSelect = () => {
        const { instanceParams } = this.props
        return (
            <FormItem label="异常入住时间区间(点击进行编辑)" required>
                <ParamSaveState
                    {...getFormItemState(
                        this.state.params.state.abnormal_begin_checkin
                    )}
                />
                <HourRangeSelect
                    start={instanceParams.abnormal_begin_checkin}
                    end={instanceParams.abnormal_end_checkin}
                    onChange={this.handleSaveCheckInRange}
                />
            </FormItem>
        )
    }

    renderCheckOutHourRangeSelect = () => {
        const { instanceParams } = this.props
        return (
            <FormItem label="异常退房时间区间(点击进行编辑)" required>
                <ParamSaveState
                    {...getFormItemState(
                        this.state.params.state.abnormal_begin_checkout
                    )}
                />
                <HourRangeSelect
                    start={instanceParams.abnormal_begin_checkout}
                    end={instanceParams.abnormal_end_checkout}
                    onChange={this.handleSaveCheckOutRange}
                />
            </FormItem>
        )
    }

    handleChangeCustomJSON = () => {
        this.setState({
            params: {
                state: {
                    customJSON: 'init',
                },
            },
        })
    }

    handleSaveCustomJSON = value => {
        const { onSave } = this.props
        const { setFieldsValue, validateFields } = this.props.form
        validateFields(['customJSON'], {}, err => {
            if (!err) {
                let val = JSON.parse(value)
                let newVal = JSON.stringify(val, null, 2)
                onSave(
                    {
                        customJSON: newVal,
                    },
                    this.saveCompState
                )
                setFieldsValue({
                    customJSON: newVal,
                })
            }
        })
    }

    renderCustomJSON = () => {
        const { instanceParams } = this.props
        const { getFieldDecorator, isLocked } = this.props.form
        const attrName = 'customJSON'
        return (
            <FormItem
                label="参数设置"
                required
                {...getFormItemState(this.state.params.state[attrName])}
            >
                {getFieldDecorator(attrName, {
                    initialValue: instanceParams[attrName],
                    rules: createJsonValidator(),
                })(
                    <TextArea
                        placeholder="请输入json格式参数列表"
                        onChange={this.handleChangeCustomJSON}
                        onBlur={e => this.handleSaveCustomJSON(e.target.value)}
                        disabled={isLocked}
                        autosize={{ minRows: 20, maxRows: 37 }}
                    />
                )}
            </FormItem>
        )
    }

    render() {
        return (
            <ConfigComponent
                {...this.props}
                paramsDescription={this.getParamRenderDescription()}
                renderPieces={{
                    customJSON: this.renderCustomJSON(),
                    checkInHourRangeSelect: this.renderCheckInHourRangeSelect(),
                    checkOutHourRangeSelect: this.renderCheckOutHourRangeSelect(),
                }}
            />
        )
    }
}

export default Form.create()(AccomFeatureExtractor)
