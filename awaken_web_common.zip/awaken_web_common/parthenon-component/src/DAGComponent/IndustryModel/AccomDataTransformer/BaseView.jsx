import React from 'react'
import { Form, Button } from 'antd'
import moment from 'moment'

import SubConfig from '../../../AlgoComponent/Shared/SubConfig'
import TableWithPaginationArrow from '../../../AlgoComponent/Shared/TableWithPaginationArrow'
import { BUTTON_DEFAULT_WIDTH } from '../../../AlgoComponent/tableDesc'
import {
    composeCompSaveState,
    getFormItemState,
} from '../../../AlgoComponent/common'

import EditRuleModal from './EditRuleModal'

import styles from './BaseView.less'

const COL_DEFAULT_WIDTH = 210

const FormItem = Form.Item

class AccommodationDataTransformer extends React.Component {
    constructor(props) {
        super(props)

        this.saveCompState = composeCompSaveState(this)
        this.state = {
            editNewRuleVisible: false,
            strategyType: null,
            params: {
                state: {
                    checkinTimeRange: 'init',
                    checkoutTimeRange: 'init',
                    hotelDurationTimeRange: 'init',
                    detalTimeRange: 'init',
                    chooseLastData: 'init',
                },
            },
        }
        this.fieldFillingTable = [
            {
                title: '规则说明',
                dataIndex: 'RuleName',
                key: 'RuleName',
                width: COL_DEFAULT_WIDTH,
            },
            {
                title: '',
                dataIndex: 'Delete',
                key: 'Delete',
                render: (text, record) => {
                    return (
                        // this.deleteSelectedRule(record)
                        <div>
                            <span>
                                <a
                                    style={{ marginRight: 5 }}
                                    disabled={this.props.isLocked}
                                    onClick={() =>
                                        this.handleEditRuleClick(record)
                                    }
                                >
                                    设置
                                </a>
                                |
                                <a
                                    style={{ marginLeft: 5 }}
                                    disabled={this.props.isLocked}
                                    onClick={() =>
                                        this.deleteSelectedRule(record)
                                    }
                                >
                                    删除
                                </a>
                            </span>
                        </div>
                    )
                },
            },
        ]
        this.InputSchemaTable = [
            {
                title: '需覆盖字段',
                dataIndex: 'name',
                key: 'name',
            },
            {
                title: '字段类型',
                dataIndex: 'type',
                key: 'type',
            },
            {
                title: '是否覆盖',
                dataIndex: 'isValid',
                key: 'isValid',
            },
        ]
    }

    getInputColumns = () => {
        const { inputSchema } = this.props
        let id = 0
        const validSchema = [
            'ID',
            'CHECKIN_TIME',
            'CHECKOUT_TIME',
            'HOTEL_ID',
            'ROOM_ID',
        ]
        const SchemaFilteredArr = (inputSchema[0] || []).filter(
            item =>
                validSchema.includes((item.name || '').toUpperCase()) &&
                (item.type || '').toUpperCase() === 'STRING'
        )

        const resArr = validSchema.map(item => {
            let isColValid = SchemaFilteredArr.map(item =>
                item.name.toUpperCase()
            ).includes(item)
                ? '是'
                : '否'
            return {
                name: item,
                type: 'string',
                id: id++,
                isValid: isColValid,
            }
        })
        return resArr
    }

    getOutputColumns = () => {
        const { instanceParams } = this.props
        let id = 0
        const ruleArr = []
        if (instanceParams.checkinTimeRange !== undefined) {
            ruleArr.push({
                RuleName: `${moment(instanceParams.checkinTimeRange[0]).format(
                    'YYYY-MM-DD HH:mm:ss'
                )} <入住时间< ${moment(
                    instanceParams.checkinTimeRange[1]
                ).format('YYYY-MM-DD HH:mm:ss')}`,
                type: 'checkinTimeRange',
                id: id++,
            })
        }
        if (instanceParams.checkoutTimeRange !== undefined) {
            ruleArr.push({
                RuleName: `${moment(instanceParams.checkoutTimeRange[0]).format(
                    'YYYY-MM-DD HH:mm:ss'
                )} < 离店时间< ${moment(
                    instanceParams.checkoutTimeRange[1]
                ).format('YYYY-MM-DD HH:mm:ss')}`,
                type: 'checkoutTimeRange',
                id: id++,
            })
        }
        if (instanceParams.detalTimeRange !== undefined) {
            ruleArr.push({
                RuleName: `同一酒店间隔入住时长> ${(
                    instanceParams.detalTimeRange / 3600
                ).toFixed(2)}h`,
                type: 'detalTimeRange',
                chooseLastData: instanceParams.chooseLastData,
                id: id++,
            })
        }
        if (instanceParams.hotelDurationTimeRange !== undefined) {
            ruleArr.push({
                RuleName: `入住时长> ${(
                    instanceParams.hotelDurationTimeRange / 3600
                ).toFixed(2)}h`,
                type: 'hotelDurationTimeRange',
                id: id++,
            })
        }
        return ruleArr
    }

    handleAddNewClick = () => {
        this.setState({
            editNewRuleVisible: true,
            strategyType: null,
        })
    }

    handleEditRuleConfirm = val => {
        const { onSave } = this.props
        //updateState用于更新表单上面保存时的状态显示
        if (val.strategyType === 'checkinTimeRange') {
            onSave(
                {
                    updateState: null,
                    checkinTimeRange: [val.startTime, val.endTime],
                },
                this.saveCompState
            )
        } else if (val.strategyType === 'checkoutTimeRange') {
            onSave(
                {
                    updateState: null,
                    checkoutTimeRange: [val.startTime, val.endTime],
                },
                this.saveCompState
            )
        } else if (val.strategyType === 'hotelDurationTimeRange') {
            onSave(
                {
                    updateState: null,
                    hotelDurationTimeRange: Math.round(
                        val.timeThreshold * 3600
                    ),
                },
                this.saveCompState
            )
        } else if (val.strategyType === 'detalTimeRange') {
            onSave(
                {
                    updateState: null,
                    detalTimeRange: Math.round(val.timeThreshold * 3600),
                    chooseLastData: val.chooseLastData,
                },
                this.saveCompState
            )
        }
        this.setState({ editNewRuleVisible: false })
    }

    handleEditRuleCancel = () => {
        this.setState({ editNewRuleVisible: false })
    }

    handleEditRuleClick = record => {
        this.setState({ editNewRuleVisible: true, strategyType: record.type })
    }

    deleteSelectedRule = record => {
        const { onSave } = this.props
        if (record.type === 'checkinTimeRange') {
            onSave(
                {
                    checkinTimeRange: undefined,
                },
                this.saveCompState
            )
        } else if (record.type === 'checkoutTimeRange') {
            onSave(
                {
                    checkoutTimeRange: undefined,
                },
                this.saveCompState
            )
        } else if (record.type === 'hotelDurationTimeRange') {
            onSave(
                {
                    hotelDurationTimeRange: undefined,
                },
                this.saveCompState
            )
        } else if (record.type === 'detalTimeRange') {
            onSave(
                {
                    detalTimeRange: undefined,
                    chooseLastData: undefined,
                },
                this.saveCompState
            )
        }
    }

    renderAddColButton = () => {
        return (
            <FormItem
                label={'住宿数据规则设置'}
                isRequire={true}
                {...getFormItemState(this.state.params.state.updateState)}
            >
                <Button
                    disabled={this.props.isLocked}
                    onClick={this.handleAddNewClick}
                    style={{ width: BUTTON_DEFAULT_WIDTH }}
                    className={styles.button}
                >
                    添加
                </Button>
            </FormItem>
        )
    }

    renderEditRuleModal() {
        const { inputSchema, instanceParams } = this.props
        return (
            <EditRuleModal
                inputCols={inputSchema[0] || []}
                instanceParams={instanceParams}
                strategyType={this.state.strategyType}
                onConfirm={this.handleEditRuleConfirm}
                onCancel={this.handleEditRuleCancel}
                isLocked={this.props.isLocked}
            />
        )
    }

    renderinputSchemaTable = () => {
        let InputColumns = this.getInputColumns()
        return (
            <div>
                <SubConfig title="需覆盖字段表单">
                    <TableWithPaginationArrow
                        dataSource={InputColumns}
                        columns={this.InputSchemaTable}
                        pagination={InputColumns.length > 10}
                        bordered
                    />
                </SubConfig>
            </div>
        )
    }

    renderAccommodationRuleTable = () => {
        let OutputColumns = this.getOutputColumns()
        return (
            <SubConfig title="输出表单">
                <TableWithPaginationArrow
                    dataSource={OutputColumns}
                    columns={this.fieldFillingTable}
                    pagination={OutputColumns.length > 10}
                    bordered
                />
            </SubConfig>
        )
    }

    render() {
        return (
            <div>
                {this.renderinputSchemaTable()}
                {this.renderAddColButton()}
                {this.renderAccommodationRuleTable()}
                {this.state.editNewRuleVisible && this.renderEditRuleModal()}
            </div>
        )
    }
}

export default Form.create()(AccommodationDataTransformer)
