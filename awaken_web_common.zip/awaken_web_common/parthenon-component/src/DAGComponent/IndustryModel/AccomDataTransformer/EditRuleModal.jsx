import React from 'react'
import { Form, Select, DatePicker, Input, Radio, message } from 'antd'
import RightModal from '../../../AlgoComponent/Shared/RightModal'
import { minValidator } from '../../../AlgoComponent/inputValidator'
import moment from 'moment'
const FormItem = Form.Item
const Option = Select.Option
const TextArea = Input.TextArea
const RadioGroup = Radio.Group

class EditRuleModal extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            newRule: false,
            strategyType: this.props.strategyType || null,
            ruleDescription: null,
            startTime: null,
            endTime: null,
            hotelTimeThreshold: null,
            detalTimeThreshold: null,
            chooseLastData: null,
            formDirty: false,
        }
    }

    componentDidMount = () => {
        const { instanceParams } = this.props
        this.setState({
            startTime: Date.parse('2000-01-01 00:00:00'),
            endTime: Date.parse(moment()),
            chooseLastData: true,
        })
        if (this.state.strategyType === null) {
            this.setState({ newRule: true })
        }
        if (this.props.strategyType == 'checkinTimeRange') {
            this.setState({
                startTime: instanceParams.checkinTimeRange[0],
                endTime: instanceParams.checkinTimeRange[1],
            })
        } else if (this.props.strategyType == 'checkoutTimeRange') {
            this.setState({
                startTime: instanceParams.checkoutTimeRange[0],
                endTime: instanceParams.checkoutTimeRange[1],
            })
        } else if (this.props.strategyType === 'hotelDurationTimeRange') {
            this.setState({
                hotelTimeThreshold:
                    instanceParams.hotelDurationTimeRange / 3600,
            })
        } else if (this.props.strategyType == 'detalTimeRange') {
            this.setState({
                detalTimeThreshold: instanceParams.detalTimeRange / 3600,
                chooseLastData: instanceParams.chooseLastData,
            })
        }
    }

    checkFormValid = () => {
        if (
            (this.state.strategyType == 'checkinTimeRange' ||
                this.state.strategyType == 'checkoutTimeRange') &&
            (this.state.endTime < this.state.startTime ||
                !this.state.startTime ||
                !this.state.endTime)
        ) {
            message.error('无法保存: 终止时间必须在起始时间之后')
            return false
        } else if (
            this.state.strategyType == 'hotelDurationTimeRange' &&
            (String(this.state.hotelTimeThreshold).trim() === '' ||
                !(this.state.hotelTimeThreshold >= 0))
        ) {
            message.error('无法保存: 请设置合法的时长阈值')
            return false
        } else if (
            this.state.strategyType == 'detalTimeRange' &&
            (String(this.state.detalTimeThreshold).trim() === '' ||
                !(this.state.detalTimeThreshold >= 0))
        ) {
            message.error('无法保存: 请设置合法的时长阈值')
            return false
        } else {
            return true
        }
    }

    handleConfirm = () => {
        this.setState({ formDirty: true })
        let timeThreshold =
            this.state.strategyType === 'detalTimeRange'
                ? this.state.detalTimeThreshold
                : this.state.hotelTimeThreshold
        if (this.state.strategyType === null) {
            message.error('无法保存: 必须选择一条规则')
        } else if (this.state.strategyType !== null && this.checkFormValid()) {
            this.props.onConfirm({
                strategyType: this.state.strategyType,
                ruleDescription: this.state.ruleDescription,
                startTime: this.state.startTime,
                endTime: this.state.endTime,
                timeThreshold: timeThreshold,
                chooseLastData: this.state.chooseLastData,
            })
        }
    }

    renderAcRuleSelect = () => {
        let Rule = [
            'T1<入住时间<T2',
            'T1<离店时间<T2',
            '入住时长>T',
            '同一酒店间隔入住时长>T',
        ]
        return (
            <FormItem label={'规则选择'}>
                <Select
                    style={{ width: '100%' }}
                    value={this.state.strategyType}
                    onChange={val => this.setState({ strategyType: val })}
                >
                    <Option key="checkinTimeRange"> {Rule[0]} </Option>
                    <Option key="checkoutTimeRange"> {Rule[1]} </Option>
                    <Option key="hotelDurationTimeRange"> {Rule[2]} </Option>
                    <Option key="detalTimeRange"> {Rule[3]} </Option>
                </Select>
            </FormItem>
        )
    }

    renderAcRuleDescription = () => {
        const { form } = this.props
        const { getFieldDecorator } = form
        let defaultValue = ''
        if (this.state.strategyType == 'checkinTimeRange') {
            defaultValue =
                '酒店入住时间必须满足设定的时间区间内,过滤掉不满足区间条件的入住记录'
        } else if (this.state.strategyType == 'checkoutTimeRange') {
            defaultValue =
                '酒店离店时间必须满足设定的时间区间内,过滤掉不满足区间条件的入住记录'
        } else if (this.state.strategyType == 'hotelDurationTimeRange') {
            defaultValue =
                '酒店入住时长必须大于时长阈值,过滤掉不符合阈值条件的入住记录'
        } else if (this.state.strategyType == 'detalTimeRange') {
            defaultValue =
                '统计同一人员同一酒店间隔入住时间间隔,需满足间隔时间大于时长阈值,若不满足则只保留入住时间较近记录或者入住时间较远记录'
        }

        return (
            <FormItem label="规则说明">
                {getFieldDecorator('ruleDescription', {
                    initialValue: defaultValue,
                })(
                    <TextArea
                        placeholder=""
                        onChange={e =>
                            this.setState({ ruleDescription: e.target.value })
                        }
                        onBlur={e =>
                            this.setState({ ruleDescription: e.target.value })
                        }
                        onPressEnter={e => {
                            e.target.blur()
                        }}
                        autosize={true}
                        disabled={true}
                    />
                )}
            </FormItem>
        )
    }

    disabledDate = current => {
        // 可选择的日期在1970开始，到9999-12-31
        return current < moment('1970-01-01') || current > moment('9999-12-31')
    }

    renderAcStartTime = () => {
        const { form } = this.props
        const { getFieldDecorator } = form
        return (
            <FormItem label="起始时间">
                {getFieldDecorator('startTime', {
                    initialValue: moment(this.state.startTime),
                    rules: [{ message: '必填', required: true }],
                })(
                    <DatePicker
                        showTime
                        placeholder=""
                        onChange={e => {
                            this.setState({ startTime: Date.parse(e) })
                        }}
                        format={'YYYY-MM-DD HH:mm:ss'}
                        disabled={this.props.isLocked}
                        disabledDate={this.disabledDate}
                    />
                )}
            </FormItem>
        )
    }

    renderAcEndTime = () => {
        const { form } = this.props
        const { getFieldDecorator } = form
        return (
            <FormItem label="终止时间">
                {getFieldDecorator('endTime', {
                    initialValue: moment(this.state.endTime),
                    rules: [{ message: '必填', required: true }],
                })(
                    <DatePicker
                        showTime
                        placeholder=""
                        onChange={e => {
                            this.setState({ endTime: Date.parse(e) })
                        }}
                        format={'YYYY-MM-DD HH:mm:ss'}
                        disabled={this.props.isLocked}
                        disabledDate={this.disabledDate}
                    />
                )}
            </FormItem>
        )
    }

    renderHotelTimeThreshold = () => {
        const { form } = this.props
        const { getFieldDecorator } = form
        let defaultValue
        if (this.state.hotelTimeThreshold === null) {
            defaultValue = 0
            this.setState({ hotelTimeThreshold: defaultValue })
        } else {
            defaultValue = this.state.hotelTimeThreshold
        }
        return (
            <FormItem label="时长阈值(小时)">
                {getFieldDecorator('hotelTimeThreshold ', {
                    initialValue: defaultValue,
                    rules: [
                        { message: '必填', required: true },
                        minValidator({
                            message: '输入必须大于等于0',
                            min: 0,
                            include: true,
                        }),
                    ],
                })(
                    <Input
                        placeholder=""
                        onChange={e =>
                            this.setState({
                                hotelTimeThreshold: e.target.value,
                            })
                        }
                        onBlur={e =>
                            this.setState({
                                hotelTimeThreshold: e.target.value,
                            })
                        }
                        onPressEnter={e => {
                            e.target.blur()
                        }}
                        disabled={this.props.isLocked}
                    />
                )}
            </FormItem>
        )
    }

    renderDetalTimeThreshold = () => {
        const { form } = this.props
        const { getFieldDecorator } = form
        let defaultValue
        if (this.state.detalTimeThreshold === null) {
            defaultValue = 0.5
            this.setState({ detalTimeThreshold: defaultValue })
        } else {
            defaultValue = this.state.detalTimeThreshold
        }
        return (
            <FormItem label="时长阈值(小时)">
                {getFieldDecorator('detalTimeThreshold', {
                    initialValue: defaultValue,
                    rules: [
                        { message: '必填', required: true },
                        minValidator({
                            message: '输入必须大于等于0',
                            min: 0,
                            include: true,
                        }),
                    ],
                })(
                    <Input
                        placeholder=""
                        onChange={e =>
                            this.setState({
                                detalTimeThreshold: e.target.value,
                            })
                        }
                        onBlur={e =>
                            this.setState({
                                detalTimeThreshold: e.target.value,
                            })
                        }
                        onPressEnter={e => {
                            e.target.blur()
                        }}
                        disabled={this.props.isLocked}
                    />
                )}
            </FormItem>
        )
    }

    renderChooseLastData = () => {
        const { form } = this.props
        const { getFieldDecorator } = form
        const chooseLastData = this.state.chooseLastData

        return (
            <FormItem label="保留策略" isRequire={true}>
                {getFieldDecorator('chooseLastData', {
                    initialValue: chooseLastData,
                })(
                    <RadioGroup
                        name="type"
                        onChange={e =>
                            this.setState({ chooseLastData: e.target.value })
                        }
                        disabled={this.props.isLocked}
                    >
                        <Radio value={true}>最近入住记录</Radio>
                        <Radio value={false}>最远入住记录</Radio>
                    </RadioGroup>
                )}
            </FormItem>
        )
    }

    renderInvalidMessage = () => {
        if (
            this.state.endTime < this.state.startTime &&
            (this.state.strategyType === 'checkinTimeRange' ||
                this.state.strategyType === 'checkoutTimeRange')
        ) {
            return (
                <div style={{ color: '#F5222D' }}>
                    终止时间必须在起始时间之后
                </div>
            )
        }
    }

    renderDuplicateRuleCheck = () => {
        const { instanceParams } = this.props
        return (
            <div style={{ color: 'red', margin: '-10px 0 10px 0' }}>
                {instanceParams[this.state.strategyType] !== undefined &&
                    this.state.newRule &&
                    '已存在此类规则，重复设置将覆盖旧规则'}
            </div>
        )
    }

    errorMessage = () => {
        return (
            <div style={{ color: 'red' }}>
                {this.state.strategyType === null &&
                    this.state.formDirty &&
                    '请选择规则'}
            </div>
        )
    }

    render() {
        return (
            <div>
                <RightModal
                    onOk={this.handleConfirm}
                    onCancel={this.props.onCancel}
                >
                    {this.renderAcRuleSelect()}
                    {this.renderDuplicateRuleCheck()}
                    {this.renderAcRuleDescription()}
                    {(this.state.strategyType == 'checkinTimeRange' ||
                        this.state.strategyType == 'checkoutTimeRange') &&
                        this.renderAcStartTime()}
                    {(this.state.strategyType == 'checkinTimeRange' ||
                        this.state.strategyType == 'checkoutTimeRange') &&
                        this.renderAcEndTime()}
                    {(this.state.strategyType == 'checkinTimeRange' ||
                        this.state.strategyType == 'checkoutTimeRange') &&
                        this.renderInvalidMessage()}
                    {this.state.strategyType == 'hotelDurationTimeRange' &&
                        this.renderHotelTimeThreshold()}
                    {this.state.strategyType == 'detalTimeRange' &&
                        this.renderDetalTimeThreshold()}
                    {this.state.strategyType == 'detalTimeRange' &&
                        this.renderChooseLastData()}
                </RightModal>
            </div>
        )
    }
}

export default Form.create()(EditRuleModal)
