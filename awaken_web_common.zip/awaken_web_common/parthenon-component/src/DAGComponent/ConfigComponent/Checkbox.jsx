import React from 'react'
// import { observer } from 'mobx-react'
import WrappedCheckbox from '../../AlgoComponent/wrappedBasicComponent/WrappedCheckbox'

// @observer
class Checkbox extends React.Component {
    render() {
        const {
            form,
            paramDesc,
            attrName,
            instanceParams,
            isLocked
        } = this.props
        const { label, isRequired = true, paramState } = paramDesc.param || {}

        const propsSave = this.props.onSave
        const paramSave = (paramDesc.param || {}).onSave
        const onSave = paramSave || propsSave

        return (
            <WrappedCheckbox
                isRequired={isRequired}
                label={label}
                form={form}
                attrName={attrName}
                isLocked={isLocked}
                instanceParams={instanceParams}
                onSave={onSave}
                paramState={paramState}
            />
        )
    }
}

export default Checkbox
