//字段选择参数列表
import React from 'react'
// import { observer } from 'mobx-react'
import WrappedFieldSelection from '../../AlgoComponent/wrappedBasicComponent/WrappedFieldSelection'

// @observer
export default class extends React.Component {
    render() {
        const {
            isSubComponent,
            paramDesc,
            attrName,
            isLocked,
            instanceParams,
            inputSchema
        } = this.props
        let {
            isSelectMulti = true,
            isRequired = true,
            label,
            numericCols,
            genericNumericCols,
            stringTypeCols,
            hidePopupOutput = false,
            displayOutput = false,
            additionalParams = [],
            allowedTypes = [],
            warnTips = [],
            portIndex,
            allColumns,
            paramState,
            colsRequired,
            selectableColumns
        } = paramDesc.param || {}

        const { hiddenInBagging = false } = paramDesc.option || {}

        const propsSave = this.props.onSave
        const paramSave = (paramDesc.param || {}).onSave
        const onSave = paramSave || propsSave
        if (!allColumns && portIndex === undefined) {
            allColumns = inputSchema[0]
        } else if (!allColumns) {
            allColumns = inputSchema[portIndex]
        }

        if (!Array.isArray(allColumns)) allColumns = []

        if (hiddenInBagging && isSubComponent) {
            return null
        } else {
            return (
                <WrappedFieldSelection
                    allColumns={allColumns}
                    isRequired={isRequired}
                    label={label}
                    attrName={attrName}
                    isSelectMulti={isSelectMulti}
                    numericCols={numericCols}
                    genericNumericCols={genericNumericCols}
                    stringTypeCols={stringTypeCols}
                    hidePopupOutput={hidePopupOutput}
                    displayOutput={displayOutput}
                    additionalParams={additionalParams}
                    allowedTypes={allowedTypes}
                    warnTips={warnTips}
                    isLocked={isLocked}
                    instanceParams={instanceParams}
                    onSave={onSave}
                    paramState={paramState}
                    colsRequired={colsRequired}
                    selectableColumns={selectableColumns}
                />
            )
        }
    }
}
