import React from 'react'
// import { observer } from 'mobx-react'
import WrappedInput from '../../AlgoComponent/wrappedBasicComponent/WrappedInput'

// @observer
class TextInput extends React.Component {
    render() {
        const {
            form,
            paramDesc,
            attrName,
            isLocked,
            instanceParams
        } = this.props
        const {
            isRequired = true,
            label,
            rules,
            min,
            max,
            isPositiveInteger,
            isNumber,
            isInteger,
            placeholder,
            paramState,
            onChange,
            colon,
            readOnly,
            precision, // 数值精度
            customValidator // 使用自定义方法
        } = paramDesc.param || {}

        const propsSave = this.props.onSave
        const paramSave = (paramDesc.param || {}).onSave
        const onSave = paramSave || propsSave

        return (
            <WrappedInput
                isRequired={isRequired}
                label={label}
                form={form}
                attrName={attrName}
                rules={rules}
                min={min}
                max={max}
                isPositiveInteger={isPositiveInteger}
                isInteger={isInteger}
                isNumber={isNumber}
                customValidator={customValidator}
                placeholder={placeholder}
                isLocked={isLocked || readOnly}
                instanceParams={instanceParams}
                paramState={paramState}
                onSave={onSave}
                onChange={onChange}
                colon={colon}
                precision={precision}
            />
        )
    }
}

export default TextInput
