import React from 'react'
// import { observer } from 'mobx-react'
import WrappedSelect from '../../AlgoComponent/wrappedBasicComponent/WrappedSelect'

// @observer
class Select extends React.Component {
    render() {
        const {
            form,
            paramDesc,
            attrName,
            isLocked,
            instanceParams
        } = this.props

        const {
            isRequired = true,
            label,
            width = '100%',
            options = [],
            allowReset = false,
            mode,
            paramState,
            disabledOptions,
            colon
        } = paramDesc.param || {}

        const propsSave = this.props.onSave
        const paramSave = (paramDesc.param || {}).onSave
        const onSave = paramSave || propsSave

        return (
            <WrappedSelect
                isRequired={isRequired}
                label={label}
                form={form}
                attrName={attrName}
                width={width}
                options={options}
                allowReset={allowReset}
                mode={mode}
                isLocked={isLocked}
                instanceParams={instanceParams}
                paramState={paramState}
                onSave={onSave}
                disabledOptions={disabledOptions}
                colon={colon}
            />
        )
    }
}

export default Select
