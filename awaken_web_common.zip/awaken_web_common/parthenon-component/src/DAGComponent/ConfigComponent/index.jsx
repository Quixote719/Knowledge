import React from 'react'

import { Form } from 'antd'
import TextInput from './TextInput'
import FieldSelection from './FieldSelection'
import Select from './Select'
import RadioGroup from './RadioGroup'
import Checkbox from './Checkbox'
import DatePicker from './DatePicker'
import FeatureMatchDetect from './FeatureMatchDetect'
import AdvancedOption from '../../AlgoComponent/Shared/AdvancedOption'

class ConfigComponent extends React.Component {
    /**
     * 渲染参数.
     */
    renderParam(attrName, paramDesc) {
        const {
            form,
            renderPieces = {},
            instanceParams,
            onSave,
            isLocked,
            inputSchema,
            isSubComponent,
            isFeatureMatch,
            matchTable,
        } = this.props
        const renderPiece = renderPieces[attrName]
        let RenderComp = null

        if (paramDesc.option && paramDesc.option.hidden) return null
        if (
            paramDesc.option &&
            paramDesc.option.byConcreteRenderer &&
            renderPiece
        ) {
            return <span key={attrName}>{renderPiece}</span>
        }

        if (paramDesc.type === 'FieldSelect') {
            RenderComp = FieldSelection
        } else if (paramDesc.type === 'Input') {
            RenderComp = TextInput
        } else if (paramDesc.type === 'Select') {
            RenderComp = Select
        } else if (paramDesc.type === 'RadioGroup') {
            RenderComp = RadioGroup
        } else if (paramDesc.type === 'Checkbox') {
            RenderComp = Checkbox
        } else if (paramDesc.type === 'DatePicker') {
            RenderComp = DatePicker
        } else if (paramDesc.type === 'FeatureMatchDetect') {
            RenderComp = FeatureMatchDetect
        } else {
            console.warn(
                `抱歉, 找不到inputType为${paramDesc.inputType}的输入类型`
            )
            return null
        }

        return (
            <RenderComp
                key={attrName}
                attrName={attrName}
                paramDesc={paramDesc}
                form={form}
                instanceParams={instanceParams}
                isLocked={isLocked}
                onSave={onSave}
                inputSchema={inputSchema}
                isSubComponent={isSubComponent}
                isFeatureMatch={isFeatureMatch}
                matchTable={matchTable}
            />
        )
    }

    render() {
        const { paramsDescription, advOptShow, onAdvOptShowChange } = this.props

        const inputsArr = []

        let hiddenOptionRendered = false

        for (let key in paramsDescription) {
            if (
                paramsDescription[key].option &&
                paramsDescription[key].option.advancedOption
            ) {
                if (!hiddenOptionRendered) {
                    inputsArr.push(
                        <AdvancedOption
                            key="advancedOption"
                            visible={advOptShow}
                            onChange={onAdvOptShowChange}
                        />
                    )
                    hiddenOptionRendered = true
                }
                if (advOptShow) {
                    inputsArr.push(
                        this.renderParam(key, paramsDescription[key])
                    )
                }
            } else {
                inputsArr.push(this.renderParam(key, paramsDescription[key]))
            }
        }

        return <div>{inputsArr}</div>
    }
}

export default Form.create()(ConfigComponent)
