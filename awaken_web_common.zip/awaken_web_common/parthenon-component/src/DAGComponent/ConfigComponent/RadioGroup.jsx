import React from 'react'
// import { observer } from 'mobx-react'
import WrappedRadioGroup from '../../AlgoComponent/wrappedBasicComponent/WrappedRadioGroup'

// @observer
class RadioGroup extends React.Component {
    render() {
        const {
            form,
            paramDesc,
            attrName,
            isLocked,
            instanceParams
        } = this.props
        const { label, options = [], isRequired = true, paramState } =
            paramDesc.param || {}

        const propsSave = this.props.onSave
        const paramSave = (paramDesc.param || {}).onSave
        const onSave = paramSave || propsSave

        return (
            <WrappedRadioGroup
                isRequired={isRequired}
                label={label}
                form={form}
                attrName={attrName}
                options={options}
                isLocked={isLocked}
                instanceParams={instanceParams}
                onSave={onSave}
                paramState={paramState}
            />
        )
    }
}

export default RadioGroup
