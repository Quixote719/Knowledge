import React from 'react'
import { Tooltip, Table, Icon } from 'antd'
//import { COL_DEFAULT_WIDTH } from '../../AlgoComponent/tableDesc'

class FeatureMatchDetect extends React.Component {
    render() {
        const { isFeatureMatch, matchTable } = this.props
        return (
            <div>
                <div style={{ marginBottom: 10 }}>
                    <span style={{ display: 'inline-block', marginRight: 10 }}>
                        特征列匹配表
                    </span>
                    {!isFeatureMatch && (
                        <Tooltip
                            placement="top"
                            title="必须匹配所有特征列才能执行"
                        >
                            <span>
                                <Icon
                                    type="exclamation-circle-o"
                                    style={{
                                        marginLeft: 11,
                                        color: '#fa4646',
                                        transform: 'scale(1.3)',
                                    }}
                                />
                            </span>
                        </Tooltip>
                    )}
                </div>
                <Table
                    dataSource={(matchTable || []).map(row => {
                        return {
                            ...row,
                            foundMatch: row.foundMatch ? '是' : '否',
                        }
                    })}
                    columns={tableDesc}
                    pagination={false}
                    scroll={{ y: 650 }}
                    bordered
                />
            </div>
        )
    }
}

const COL_DEFAULT_WIDTH = 90
const tableDesc = [
    {
        title: '字段名',
        dataIndex: 'name',
        key: 'name',
        width: COL_DEFAULT_WIDTH,
    },
    {
        title: '字段类型',
        dataIndex: 'type',
        key: 'type',
        width: COL_DEFAULT_WIDTH,
    },
    {
        title: '存在匹配字段',
        dataIndex: 'foundMatch',
        key: 'foundMatch',
    },
]

export default FeatureMatchDetect
