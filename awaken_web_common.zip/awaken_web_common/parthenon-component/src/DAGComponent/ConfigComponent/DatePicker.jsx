import React from 'react'
// import { observer } from 'mobx-react'
import WrappedDatePicker from '../../AlgoComponent/wrappedBasicComponent/WrappedDatePicker'

// @observer
class DatePicker extends React.Component {
    render() {
        const {
            form,
            paramDesc,
            attrName,
            isLocked,
            instanceParams,
            onSave
        } = this.props
        const {
            isRequired = true,
            label,
            width = '100%',
            format,
            invalidDefault,
            showTime = true
        } = paramDesc.param || {}

        return (
            <WrappedDatePicker
                isRequired={isRequired}
                label={label}
                form={form}
                attrName={attrName}
                width={width}
                isLocked={isLocked}
                instanceParams={instanceParams}
                onSave={onSave}
                format={format}
                invalidDefault={invalidDefault}
                showTime={showTime}
            />
        )
    }
}

export default DatePicker
