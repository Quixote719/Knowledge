const typeCheckMap = {
    number: {
        exact: ['double'],
        include: ['int']
    },
    generalNumber: {
        exact: ['short', 'long', 'float', 'double'],
        include: ['decimal', 'int', 'byte', 'fractional', 'integer']
    },
    double: {
        exact: ['double']
    },
    string: {
        exact: ['string'],
        include: ['char']
    },
    date: {
        exact: ['date', 'timestamp'],
        include: ['calendar']
    },
    boolean: {
        exact: [],
        include: ['bool']
    },
    ALSGeneralNumber: {
        exact: ['short', 'long', 'float', 'double'],
        include: ['int', 'byte', 'integer']
    }
}

function typeCheck(type, expectedType) {
    if (!type) {
        return false
    }

    if (!typeCheckMap.hasOwnProperty(expectedType)) {
        throw new Error(`找不到${expectedType}对应的类型的描述`)
    }

    let { exact, include } = typeCheckMap[expectedType]
    const exactArray = exact || []
    const includeArray = include || []

    if (exactArray.includes(type.toLowerCase())) {
        return true
    }

    for (let i = 0; i < includeArray.length; i++) {
        if (type.toLowerCase().startsWith(includeArray[i])) {
            //type包括includeArray中某一个
            return true
        }
    }

    return false
}

export function isBooleanType(type) {
    return typeCheck(type, 'boolean')
}

export function isVectorType(type) {
    if (!type) {
        return false
    }

    if (type.toLowerCase().startsWith('vector')) {
        return true
    }

    return false
}

// 这个方法的修改要通知大家
export function isNumericType(type) {
    if (!type) {
        return false
    }

    if (
        ['double', 'int', 'integer', 'decimal', 'bigint', 'float'].includes(
            type.toLowerCase()
        )
    ) {
        // decimal也是数值型
        return true
    }

    if (type.toLowerCase().startsWith('vector')) {
        return true
    }

    return false
}

export function isDecimalType(type) {
    if (!type) {
        return false
    }

    if (type.toLowerCase().startsWith('decimal')) {
        return true
    }

    return false
}

export function isDoubleType(type) {
    return typeCheck(type, 'double')
}

export function isGeneralNumericType(type) {
    return typeCheck(type, 'generalNumber')
}

export function isStringType(type) {
    return typeCheck(type, 'string')
}

export function isDateType(type) {
    return typeCheck(type, 'date')
}

function filterValueOfType(val, filterFn) {
    let data = JSON.parse(JSON.stringify(val))
    if (Array.isArray(data)) {
        return data.filter(item => {
            if (!item) return false

            return filterFn(item.type)
        })
    } else {
        return []
    }
}

function filterCustomerTypeValue(val, expectedType) {
    return filterValueOfType(val, type => typeCheck(type, expectedType))
}

export function filterNumericalValue(val) {
    return filterValueOfType(val, isNumericType)
    // return filterTypes(val, ['double', 'int', 'integer'])
}

export function filterGenericNumericValue(val) {
    return filterValueOfType(val, isGeneralNumericType)
}

export function filterDoubleValue(val) {
    return filterValueOfType(val, isDoubleType)
}

export function filterStringTypeValue(val) {
    return filterValueOfType(val, isStringType)
}

export function filterTypes(val, allowedTypes) {
    val = val || []
    let data = JSON.parse(JSON.stringify(val))
    // 将类型全部转为小写
    allowedTypes = allowedTypes.map(item => {
        if (typeof item === 'object') {
            return {
                ...item,
                typeName: item.typeName.toLowerCase()
            }
        } else {
            return item.toLowerCase()
        }
    })
    if (Array.isArray(data)) {
        let selectableColumns = []
        // 处理 genericNumericCols、numericCols、doubleCols、stringTypeCols 又包含多个类型 的情况
        allowedTypes = allowedTypes.filter((item, idx) => {
            const t = typeof item === 'object' ? item.typeName : item

            if (typeof item === 'object') {
                // 处理自定义的情况
                selectableColumns = selectableColumns.concat(
                    filterCustomerTypeValue(val, item.expectedType)
                )
                return false
            }
            if (t === 'genericNumericCols'.toLowerCase()) {
                selectableColumns = selectableColumns.concat(
                    filterGenericNumericValue(val)
                )
                return false
            }
            if (t === 'numericCols'.toLowerCase()) {
                selectableColumns = selectableColumns.concat(
                    filterNumericalValue(val)
                )
                return false
            }
            if (t === 'doubleCols'.toLowerCase()) {
                selectableColumns = selectableColumns.concat(
                    filterDoubleValue(val)
                )
                return false
            }
            if (t === 'stringTypeCols'.toLowerCase()) {
                selectableColumns = selectableColumns.concat(
                    filterStringTypeValue(val)
                )
                return false
            }
            return true
        })
        // 处理 除以上四种大类 和 自定义 以外 的类型
        selectableColumns = selectableColumns.concat(
            data.filter(item => {
                if (!item) return false
                let itemType = item.type.toLowerCase()
                // 由于decimal字段类型，返回的是decimal(11,0)这种带精度的，所以直接截取前面的decimal， vector同理
                if (itemType.startsWith('decimal')) {
                    itemType = 'decimal'
                } else if (itemType.startsWith('vector')) {
                    itemType = 'vector'
                }
                return allowedTypes.includes(itemType)
            })
        )
        // 过滤相同元素
        let uniqueSelectableColumns = []
        selectableColumns.forEach(col => {
            if (
                !uniqueSelectableColumns.find(
                    uCol => JSON.stringify(uCol) === JSON.stringify(col)
                )
            ) {
                uniqueSelectableColumns.push(col)
            }
        })
        return uniqueSelectableColumns
    } else {
        return []
    }
}
