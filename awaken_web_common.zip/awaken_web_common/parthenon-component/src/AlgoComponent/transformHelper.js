/**
 * {
 *    key1: [],
 *    key2: [],
 *    key3: []
 * }
 * 转化为
 * [
 *    {key1, key2, key3},
 *    {key1, key2, key3}
 * ]
 *
 * 第二个参数可以转化map中的key名
 */
export function mapToTuple(obj, keyTrans = {}) {
    let keyArr = Object.keys(obj)
    let arrLen = null
    //先校验map里面是不是都是数组, 数组是不是一样长. 如果不一样则返回[]
    for (let i = 0; i < keyArr.length; i++) {
        const key = keyArr[i]
        if (!Array.isArray(obj[key])) {
            return []
        } else if (arrLen === null) {
            arrLen = obj[key].length
        } else if (arrLen !== obj[key].length) {
            return []
        }
    }

    const res = []
    for (let i = 0; i < obj[keyArr[0]].length; i++) {
        res[i] = {}
        for (let j = 0; j < keyArr.length; j++) {
            let newKey = keyTrans.hasOwnProperty(keyArr[j])
                ? keyTrans[keyArr[j]]
                : keyArr[j]
            res[i][newKey] = obj[keyArr[j]][i]
        }
    }
    return res
}
