/**
 * Created by linhanzi on 2019/6/11.
 */
import React from 'react'
import styles from './showModal.less'
import { Modal, Select, Popover, Button, Table, message } from 'antd'

const { Option } = Select

const detailsMap = {
    模型名称: 'modelName',
    模型类型: 'modelClass',
    算法名称: 'algName',
    模型日期: 'createTime',
}

export default class extends React.Component {
    constructor(props) {
        super(props)
    }
    getDetails = originalData => {
        let details = {}
        let eKey = '' // 英文
        let d = originalData
        for (const cKey in detailsMap) {
            eKey = detailsMap[cKey]
            // 取出submodelInfos里面的信息
            if (eKey.startsWith('modelParams')) {
                eKey = eKey.split('.')[1]
                d = originalData.modelParams ? originalData.modelParams : {}
            }
            // 赋值
            if (d.hasOwnProperty(eKey)) {
                let value = d[eKey]
                details[cKey] = value
            }
        }
        return details
    }

    renderDetails = () => {
        const { modelData } = this.props
        const details = this.getDetails(modelData) // 模型基本参数
        let dom = []
        for (const key in details) {
            const value = details[key]
            dom.push(
                <div className={styles.item} key={key}>
                    {key}：{value}
                </div>
            )
        }

        return <div className={styles.detailsWrap}>{dom}</div>
    }

    render() {
        const { onCancel, modelData } = this.props
        return (
            <Modal
                title={`${modelData.modelName} - 查看模型`}
                visible={true}
                onCancel={onCancel}
                width="1000px"
                footer={null}
                className={styles.resultModal}
                maskClosable={false}
            >
                <div className={styles.resultContent}>
                    {this.renderDetails()}
                </div>
            </Modal>
        )
    }
}
