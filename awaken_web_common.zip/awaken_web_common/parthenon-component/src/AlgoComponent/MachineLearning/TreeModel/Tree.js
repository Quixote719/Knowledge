/**
 * Created by linhanzi on 2019/6/12.
 */
import React from 'react'
import Chart from '../../Shared/Charts/Chart'
import styles from './showModal.less'

export default React.memo(({ data }) => {
    return (
        <Chart
            className={styles.histogramChart}
            style={{ width: '100%', height: '100%' }}
            option={{
                tooltip: {
                    trigger: 'item',
                    triggerOn: 'mousemove',
                },
                series: [
                    {
                        type: 'tree',

                        data: [data],

                        top: '2%',
                        left: '10%', // TODO: 只有一个节点时，文本内容不够放
                        bottom: '2%',
                        right: '2%',

                        itemStyle: {
                            borderColor: '#1890ff',
                        },

                        label: {
                            normal: {
                                position: 'left',
                                verticalAlign: 'middle',
                                align: 'left',
                                formatter: params => {
                                    if (params.value) {
                                        return `${params.value}`
                                    } else {
                                        const name = params.name.split('|')
                                        return name.length > 1
                                            ? `${name[0]}\n${name[1]}`
                                            : name[0]
                                    }
                                },
                            },
                        },

                        leaves: {
                            label: {
                                normal: {
                                    position: 'left',
                                    verticalAlign: 'middle',
                                    align: 'right',
                                },
                            },
                        },

                        tooltip: {
                            formatter: params => {
                                const name = params.name.split('|')
                                return name.length > 1
                                    ? `${name[0]}\n${name[1]}`
                                    : name[0]
                            },
                        },

                        expandAndCollapse: true,
                        initialTreeDepth: 2,

                        animationDurationUpdate: 750,
                    },
                ],
            }}
        />
    )
})
