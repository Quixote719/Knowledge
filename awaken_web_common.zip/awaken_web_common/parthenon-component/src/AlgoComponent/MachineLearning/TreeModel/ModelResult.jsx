/**
 * Created by linhanzi on 2019/6/11.
 */
import React from 'react'
import Tree from './Tree'
import styles from './showModal.less'
import { Modal, Select } from 'antd'

const { Option } = Select

const detailsMap = {
    模型名称: 'modelName',
    模型类型: 'modelClass',
    算法名称: 'algName',
    模型日期: 'createTime',
    训练特征数: 'submodelInfos.numFeatures',
    训练样本数: 'submodelInfos.numSamples',
    样本标签分布: 'submodelInfos.labelDistribution', // TODO: 确认数据格式
    树深度: 'submodelInfos.depth',
    树叶子节点数: 'submodelInfos.numNodes',
    模型迭代次数: 'submodelInfos.numIters',
}

export default class extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            subModelIndex: 0,
        }
        this.nodes = []
    }

    onChangeIndex = value => {
        if (value !== this.state.subModelIndex) {
            this.setState({ subModelIndex: value })
        }
    }

    modelNameFormatter = (name, index) => {
        const base = '000'.slice(0, -String(index).length) // 从001开始计数
        return `${name}—${base}${index}`
    }

    getDetails = originalData => {
        const submodelInfos = originalData.submodelInfos
        let details = {}
        let eKey = '' // 英文
        let d = originalData
        for (const cKey in detailsMap) {
            eKey = detailsMap[cKey]
            // 取出submodelInfos里面的信息
            if (eKey.startsWith('submodelInfos')) {
                eKey = eKey.split('.')[1]
                d =
                    submodelInfos && submodelInfos.length > 0
                        ? submodelInfos[this.state.subModelIndex]
                        : {}
            }
            // 赋值
            if (d.hasOwnProperty(eKey)) {
                let value = d[eKey]
                //  有多个子模型时，模型名称格式化处理
                if (
                    cKey === '模型名称' &&
                    submodelInfos &&
                    submodelInfos.length > 1
                ) {
                    value = this.modelNameFormatter(
                        value,
                        this.state.subModelIndex + 1
                    )
                }
                // TODO: 待确认样本标签分布值
                details[cKey] =
                    cKey === '样本标签分布' ? JSON.stringify(value) : value
            }
        }
        return details
    }

    getNode = (nodeId, nodes) => {
        return nodes.find(node => node.id === nodeId)
    }

    getName = node => {
        // 分类（且不为GBDT分类）与回归文本内容不同
        if (
            this.props.modelData.modelClass === '分类' &&
            this.props.modelData.algName !== 'GBDT分类'
        ) {
            return JSON.stringify(node.labelDistribution)
        }
        return `numSamples=${node.numSamples}|average=${node.average}`
    }

    getChildren = node => {
        let childrenIds = []
        let nodeLineInfos = []
        if (node.leftChild !== -1) {
            childrenIds.push(node.leftChild)
            nodeLineInfos.push(`${node.featureName} < ${node.threshold}`)
        }
        if (node.rightChild !== -1) {
            childrenIds.push(node.rightChild)
            nodeLineInfos.push(`${node.featureName} >= ${node.threshold}`)
        }
        return childrenIds.map((nodeId, index) => {
            const node = this.getNode(nodeId, this.nodes)
            const lineInfo = nodeLineInfos[index] // 两节点连接线上的信息 （由于echarts中lineStyle不能配置label内容，只能把连接线上的信息，作为一个节点来完成）
            return {
                name: this.getName(node),
                value: lineInfo,
                children: this.getChildren(node),
            }
        })
    }

    getNodeTree = nodes => {
        let data = {}
        const headNode = nodes[0]
        data.name = this.getName(headNode)
        data.children = this.getChildren(headNode)
        return data
    }

    render() {
        const { onCancel, modelData } = this.props
        const details = this.getDetails(modelData)
        const submodelInfos = modelData.submodelInfos || []
        const selectValue =
            submodelInfos.length > 0 ? this.state.subModelIndex : '无子模型'
        if (submodelInfos.length > 0) {
            this.nodes =
                modelData.submodelInfos[this.state.subModelIndex].nodeInfos
        }

        return (
            <Modal
                title={`${modelData.modelName} - 查看模型`}
                visible={true}
                onCancel={onCancel}
                width="1000px"
                footer={null}
                className={styles.resultModal}
                maskClosable={false}
            >
                <div className={styles.resultContent}>
                    <div className={styles.left}>
                        <div className={styles.selectWrap}>
                            <Select
                                value={selectValue}
                                style={{ width: '100%' }}
                                onChange={this.onChangeIndex}
                            >
                                {submodelInfos.length > 0 &&
                                    submodelInfos.map((info, index) => (
                                        <Option value={index} key={index}>
                                            子模型{index + 1}
                                        </Option>
                                    ))}
                            </Select>
                        </div>
                        <div className={styles.detailsWrap}>
                            {Object.keys(details).map(k => (
                                <div className={styles.item} key={k}>
                                    {k}：{details[k]}
                                </div>
                            ))}
                        </div>
                    </div>
                    <div className={styles.right}>
                        <div className={styles.chartWrap}>
                            {submodelInfos.length > 0 ? (
                                <Tree data={this.getNodeTree(this.nodes)} />
                            ) : (
                                '无图表数据'
                            )}
                        </div>
                    </div>
                </div>
            </Modal>
        )
    }
}
