/**
 * Created by linhanzi on 2019/6/11.
 */
import React from 'react'
import Radar from './Radar'
import styles from './showModal.less'
import { Modal, Select, Popover, Button, Table, message } from 'antd'

const { Option } = Select

const detailsMap = {
    模型名称: 'modelName',
    模型类型: 'modelClass',
    算法名称: 'algName',
    模型日期: 'createTime',
    特征列: 'featureSchema', // 特征列为数组
    初始质心选择模式: 'modelParams.initMode',
    期望聚类簇个数: 'modelParams.k',
    最大迭代次数: 'modelParams.maxIter',
    收敛精度: 'modelParams.tol',
}

const MAX_TAG_COUNT = 30 // 最多选择多少个标签

export default class extends React.Component {
    constructor(props) {
        super(props)
        this.state = {}
        this.initSelectParam(props)
    }
    /**
     * 初始化select组件需要的默认值
     * 初始化 selectedDimensions， selectedClusters
     * 默认选中全部，不超过定义的最大数量
     */
    initSelectParam = props => {
        const { dimensions, clusterCenterInfo } = props.modelData
        const clusters = clusterCenterInfo.map(c => c.clusterIndex)

        const selectedDimensions =
            dimensions.length > MAX_TAG_COUNT
                ? dimensions.slice(0, MAX_TAG_COUNT)
                : dimensions // 不超过定义的最大数量
        const selectedClusters =
            clusters.length > MAX_TAG_COUNT
                ? clusters.slice(0, MAX_TAG_COUNT)
                : clusters

        this.state.selectedDimensions = selectedDimensions // 下拉框中选中的特征列
        this.state.selectedClusters = selectedClusters // 下拉框中选中的聚类簇
    }

    getDetails = originalData => {
        let details = {}
        let eKey = '' // 英文
        let d = originalData
        for (const cKey in detailsMap) {
            eKey = detailsMap[cKey]
            // 取出submodelInfos里面的信息
            if (eKey.startsWith('modelParams')) {
                eKey = eKey.split('.')[1]
                d = originalData.modelParams ? originalData.modelParams : {}
            }
            // 赋值
            if (d.hasOwnProperty(eKey)) {
                let value = d[eKey]
                details[cKey] = value
            }
        }
        return details
    }

    handleChangeDimension = value => {
        if (value.length > MAX_TAG_COUNT) {
            message.warning(`最多不能超过${MAX_TAG_COUNT}个`)
            return
        }
        this.setState({ selectedDimensions: value })
    }

    handleChangeCluster = value => {
        if (value.length > MAX_TAG_COUNT) {
            message.warning(`最多不能超过${MAX_TAG_COUNT}个`)
            return
        }
        this.setState({ selectedClusters: value })
    }

    getRadarData = params => {
        const {
            dimensions,
            clusterCenterInfo,
            selectedDimensions,
            selectedClusters,
        } = params

        /**
         * 计算被选中的维度，在原数据中的索引
         */
        let selectDimensionsIndexs = []
        dimensions.forEach((d, idx) => {
            if (selectedDimensions.includes(d)) {
                selectDimensionsIndexs.push(idx)
            }
        })

        /**
         * 根据已选维度和已选聚类簇，计算当前聚类簇信息
         */
        const currClusterCenterInfo = clusterCenterInfo
            .filter(c => selectedClusters.includes(c.clusterIndex))
            .map(c => {
                const clusterVector = c.clusterVector.filter((cv, idx) =>
                    selectDimensionsIndexs.includes(idx)
                )
                return {
                    ...c,
                    clusterVector,
                }
            })

        /**
         * 当前聚类簇信息中，计算每个维度的最大值
         */
        let maxNumArr = [] // 存放每个维度的最大值
        let minNumArr = [] // 存放每个维度的最小值
        for (const c of currClusterCenterInfo) {
            c.clusterVector.forEach((cv, idx) => {
                maxNumArr[idx] = maxNumArr[idx] || 1 // 初始化时默认最大值为1
                minNumArr[idx] = minNumArr[idx] || 0 // 初始化时默认最小值为0
                if (cv >= 0) {
                    maxNumArr[idx] = cv > maxNumArr[idx] ? cv : maxNumArr[idx] // 若当前值大于原先的最大值，则替换为当前值，否则不改变
                } else {
                    minNumArr[idx] = cv < minNumArr[idx] ? cv : minNumArr[idx] // 若当前值小于原先的最小值，则替换为当前值，否则不改变
                }
            })
        }

        // indicator
        const indicator = selectedDimensions.map((dName, idx) => {
            return { name: dName, max: maxNumArr[idx], min: minNumArr[idx] }
        })
        // series data
        const data = currClusterCenterInfo.map(c => {
            return {
                value: c.clusterVector,
                name: `prediction=${c.clusterIndex}`,
                originalName: c.clusterIndex,
            }
        })
        // legengd data
        const legendData = data.map(d => d.name)

        return { indicator, data, legendData }
    }

    getOptions = items => {
        const options = []
        items.forEach(d => {
            options.push({
                label: d,
                value: d,
            })
        })
        return options
    }

    renderTable = tabledata => {
        const dataSource = tabledata.map((data, idx) => {
            return {
                key: idx,
                ...data,
            }
        })
        const columns = [
            {
                title: '字段名',
                dataIndex: 'name',
                key: 'name',
            },
            {
                title: '字段类型',
                dataIndex: 'type',
                key: 'type',
                width: 80,
            },
        ]

        return (
            <Table
                size="small"
                pagination={false}
                dataSource={dataSource}
                columns={columns}
                scroll={{ y: 150 }}
            />
        )
    }

    renderDetails = () => {
        const { modelData } = this.props
        const details = this.getDetails(modelData) // 模型基本参数
        let dom = []
        for (const key in details) {
            const value = details[key]
            if (Array.isArray(value) && key === '特征列') {
                // 特征列查看
                dom.push(
                    <div className={styles.item} key={key}>
                        {key}：
                        {
                            <Popover
                                placement="left"
                                content={this.renderTable(value)}
                                mouseEnterDelay={0.2}
                            >
                                <Button size="small" type="primary">
                                    查看
                                </Button>
                            </Popover>
                        }
                    </div>
                )
            } else {
                dom.push(
                    <div className={styles.item} key={key}>
                        {key}：{value}
                    </div>
                )
            }
        }

        return <div className={styles.detailsWrap}>{dom}</div>
    }

    render() {
        const { onCancel, modelData } = this.props
        const { dimensions, clusterCenterInfo } = modelData
        const clusters = clusterCenterInfo.map(c => c.clusterIndex)

        const dimensionOptions = this.getOptions(dimensions) // 特征列可选项
        const clusterOptions = this.getOptions(clusters) // 聚类簇prediction可选项

        const { selectedDimensions, selectedClusters } = this.state
        const { indicator, data, legendData } = this.getRadarData({
            dimensions,
            clusterCenterInfo,
            selectedDimensions,
            selectedClusters,
        }) // 雷达图数据

        return (
            <Modal
                title={`${modelData.modelName} - 查看模型`}
                visible={true}
                onCancel={onCancel}
                width="1000px"
                footer={null}
                className={styles.resultModal}
                maskClosable={false}
            >
                <div className={styles.resultContent}>
                    <div className={styles.left}>
                        <div className={styles.selectWrap}>
                            已选维度(特征列)
                            <Select
                                mode="multiple"
                                style={{ width: '100%' }}
                                placeholder="请选择维度(特征列)"
                                value={selectedDimensions}
                                onChange={this.handleChangeDimension}
                            >
                                {dimensionOptions.map(opt => (
                                    <Option key={opt.label} value={opt.value}>
                                        {opt.label}
                                    </Option>
                                ))}
                            </Select>
                        </div>
                        <div className={styles.selectWrap}>
                            已选聚类簇(prediction)
                            <Select
                                mode="multiple"
                                style={{ width: '100%' }}
                                placeholder="请选择聚类簇(prediction)"
                                value={selectedClusters}
                                onChange={this.handleChangeCluster}
                            >
                                {clusterOptions.map(opt => (
                                    <Option key={opt.label} value={opt.value}>
                                        {opt.label}
                                    </Option>
                                ))}
                            </Select>
                        </div>
                        {this.renderDetails()}
                    </div>
                    <div className={styles.right}>
                        <div className={styles.chartWrap}>
                            <Radar
                                indicator={indicator}
                                data={data}
                                legendData={legendData}
                            />
                        </div>
                    </div>
                </div>
            </Modal>
        )
    }
}
