/**
 * Created by linhanzi on 2019/6/12.
 */
import React from 'react'
import Chart from '../../Shared/Charts/Chart'
import styles from './showModal.less'

export default React.memo(({ indicator, data, legendData }) => {
    if (indicator.length <= 2) {
        return <div>最少选三个维度，图表更友好</div>
    }
    return (
        <Chart
            className={styles.histogramChart}
            style={{ width: '100%', height: '100%' }}
            option={{
                tooltip: {},
                legend: {
                    type: 'scroll',
                    data: legendData,
                },
                radar: {
                    name: {
                        textStyle: {
                            color: '#fff',
                            backgroundColor: '#999',
                            borderRadius: 3,
                            padding: [3, 5],
                        },
                    },
                    indicator: indicator,
                },
                series: [
                    {
                        type: 'radar',
                        data: data,
                    },
                ],
            }}
        />
    )
})
