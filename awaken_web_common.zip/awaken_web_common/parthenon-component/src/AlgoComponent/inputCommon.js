/**
 * 组件右侧配置栏wrappedInput 与 参数寻优默认值input 都是通过同一份配置项渲染的
 * 所以整理出公用方法这两处渲染使用，保证逻辑一致
 */

import {
    maxValidator,
    minValidator,
    IntegerValidator,
    positiveIntegerValidator,
    numberValidator,
    precisionValidator,
    IntegerWithAnomalylValidator
} from './inputValidator'

const MAX_NUMBER = 9e15 // js的number类型有个最大值（安全值）。即2的53次方，为9007199254740992。如果超过这个值，那么js会出现不精确的问题。9e15是为了取整
const MIN_NUMBER = -9e15 // 最小值同理

/**
 * 根据配置项判断input是否为数值型输入框
 * 配置项是指渲染wrappedInput的配置
 */
export const isNumberType = props => {
    const { min, max, isPositiveInteger, isNumber, isInteger } = props
    if (
        min !== undefined ||
        max !== undefined ||
        isPositiveInteger ||
        isNumber ||
        isInteger
    ) {
        return true
    } else {
        return false
    }
}

/**
 * 若为数值型输入框，且没有设置max，需要手动给定最大值
 */
export const getMax = props => {
    let max
    if (isNumberType(props)) {
        if (props.max !== undefined && props.max.value < MAX_NUMBER) {
            max = props.max
        } else {
            max = {
                include: true,
                value: MAX_NUMBER
            }
        }
    }
    return max
}

/**
 * 若为数值型输入框，且没有设置min，需要手动给定最小值
 */
export const getMin = props => {
    let min
    if (isNumberType(props)) {
        if (props.min !== undefined && props.min.value > MIN_NUMBER) {
            min = props.min
        } else {
            min = {
                include: true,
                value: MIN_NUMBER
            }
        }

        if (props.isPositiveInteger) {
            if (min.value < 1) {
                min = {
                    include: true,
                    value: 1
                }
            }
        }
    }
    return min
}

/**
 * 获取输入框的所有规则
 * 因为min 和 max 做过最大值最小值手动处理，在这里拎出来传，主要是想提示开发人员注意，不能直接传prop里的配置
 */
export const getInputRules = (min, max, props) => {
    const {
        rules,
        //min,
        //max,
        isPositiveInteger,
        isNumber,
        isInteger,
        precision,
        isRequired,
        customValidator
    } = props

    const res = (rules || []).slice()
    if (isRequired) {
        res.push({ message: '必填', required: true })
    }
    if (min !== undefined) {
        const { include = false, value } = min

        res.push(
            minValidator({
                message: include
                    ? `输入必须大于等于${value}`
                    : `输入必须大于${value}`,
                min: value,
                include
            })
        )
    }

    if (max !== undefined) {
        const { include = false, value } = max
        res.push(
            maxValidator({
                message: include
                    ? `输入必须小于等于${value}`
                    : `输入必须小于${value}`,
                max: value,
                include
            })
        )
    }

    if (isPositiveInteger) {
        res.push(positiveIntegerValidator({ message: '输入必须是正整数' }))
    } else if (isInteger) {
        res.push(IntegerValidator({ message: '输入必须是整数' }))
    } else if (isNumber) {
        res.push(numberValidator({ message: '输入必须是数值' }))
    }

    if (precision) {
        res.push(
            precisionValidator({
                precision,
                message: `输入的小数位不能超过${precision}`
            })
        )
    }
    if (customValidator && typeof customValidator === 'function') {
        res.push(...customValidator())
    }

    return res
}
