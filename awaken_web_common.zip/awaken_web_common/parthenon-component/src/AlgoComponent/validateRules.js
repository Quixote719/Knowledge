const CNPattern = new RegExp('[\u4E00-\u9FA5]+')
const CapitalENPattern = new RegExp('[A-Z]+')
// const ENPattern = new RegExp("[A-Za-z]+")
// const digitPattern = new RegExp("[0-9]+")

export function jsonValidate(value) {
    try {
        JSON.parse(value)
        return true
    } catch (err) {
        return false
    }
}

export function noUnderScoreHeadValidate(value) {
    if (value && value.length > 0 && value[0] === '_') {
        return false
    } else {
        return true
    }
}

export function noCapitalValidate(value) {
    if (CapitalENPattern.test(value)) {
        return false
    } else {
        return true
    }
}
export function asciiValidate(value){
    for(let i = 0; i < value.length; ++i){
        const code = value.charCodeAt(i)
        if(!isAscii(code))
            return false
    }
    return true
}

export function characterValidate(value, { whiteList, allowChinese = true }) {
    for (let i = 0; i < value.length; i++) {
        let code = value.charCodeAt(i)
        if (
            !isAlphaNumeric(code) &&
            !isUnderScore(code) &&
            !isInWhiteList(code, whiteList) &&
            code !== 32 &&
            !(allowChinese && CNPattern.test(value[i]))
        ) {
            return false
        }
    }
    return true
}

export function noSpaceValidate(value, { allowEmptySpace = false }) {
    if (!allowEmptySpace && value.includes(' ')) {
        return false
    } else {
        return true
    }
}

export function emptyValidate(value) {
    if (typeof value !== 'string' || !value.trim()) {
        return false
    } else {
        return true
    }
}
// 字母开头
export function startWithAlphabetValidate(value) {
    if (!value) return true
    if (!isAlphabet(value.charCodeAt(0))) {
        return false
    } else {
        return true
    }
}
export function isAscii(code){
    if(!(code >31 && code < 127)){ // ascii
        return false
    } else {
        return true
    }
}

export function minLenValidate(value, { minLength = 6 }) {
    if (!value) return true
    if (value.length < minLength) {
        return false
    } else {
        return true
    }
}

export function maxLenValidate(value, { maxLength = 30 }) {
    if (!value) return true
    if (value.length > maxLength) {
        return false
    } else {
        return true
    }
}

export function isInWhiteList(code, whiteList) {
    if (!whiteList) return false
    for (let i = 0; i < whiteList.length; i++) {
        if (whiteList.charCodeAt(i) === code) {
            return true
        }
    }
    return false
}

export function maxValidate(num, { max, include }) {
    if (!isNumeric(num)) return false
    num = Number(num)

    if (include && num > max) {
        return false
    } else if (!include && num >= max) {
        return false
    } else {
        return true
    }
}

export function minValidate(num, { min, include }) {
    if (!isNumeric(num)) return false
    num = Number(num)

    if (include && num < min) {
        return false
    } else if (!include && num <= min) {
        return false
    } else {
        return true
    }
}

export function isIntegerArray(str) {
    if (!str || typeof str !== 'string') {
        return false
    } else {
        const arr = str.split(',')
        for (let i = 0; i < arr.length; i++) {
            if (!isInteger(arr[i]) || !arr[i]) {
                return false
            }
        }
    }
    return true
}

export function isInteger(num) {
    if (!isNumeric(num)) {
        return false
    } else {
        num = Number(num)
        if (!Number.isInteger(num)) {
            return false
        }
    }
    return true
}

export function isConformPrecision(num, precision) {
    if (!isNumeric(num)) {
        return false
    } else {
        const x = String(num).indexOf('.') // 小数点的索引
        const y = String(num).length - (x + 1) // 小数的位数
        if (x > -1 && y > precision) {
            return false
        }
    }
    return true
}

export function isPositiveInteger(num) {
    if (!isNumeric(num)) {
        return false
    } else {
        num = Number(num)
        if (!Number.isInteger(num)) {
            return false
        } else if (num <= 0) {
            return false
        }
    }
    return true
}

export function isNumeric(num) {
    return !isNaN(num)
}

export function isAlphaNumeric(code) {
    if (
        !(code > 47 && code < 58) && // numeric (0-9)
        !(code > 64 && code < 91) && // upper alpha (A-Z)
        !(code > 96 && code < 123)
    ) {
        // lower alpha (a-z)
        return false
    } else {
        return true
    }
}

export function isAlphabet(code) {
    if (
        !(code > 64 && code < 91) && // upper alpha (A-Z)
        !(code > 96 && code < 123)
    ) {
        return false
    } else {
        return true
    }
}

export function isLowerCaseAlphaNumeric(code) {
    if (
        !(code > 47 && code < 58) && // numeric (0-9)
        !(code > 96 && code < 123)
    ) {
        // lower alpha (a-z)
        return false
    } else {
        return true
    }
}

export function isUnderScore(code) {
    return code === 95
}
