/**
 * Created by lizhoujie5 on 2018/1/4.
 */
import React from 'react'
import PropTypes from 'prop-types'
import memoize from 'memoize-one'
import styles from './showModal.less'
import { Modal, Tabs } from 'antd'
import LinePlot from './LinePlot'
import ConfusionMatrixChart from './ConfusionMatrixChart'

const { TabPane } = Tabs

export default class extends React.Component {
    static propTypes = {
        confusionMatrix: PropTypes.shape({
            tp: PropTypes.number.isRequired,
            fp: PropTypes.number.isRequired,
            tn: PropTypes.number.isRequired,
            fn: PropTypes.number.isRequired,
        }),
        prCurveData: PropTypes.array,
        rocCurveData: PropTypes.array,
    }

    constructor(props) {
        super(props)
    }

    getChartData = memoize(datas => {
        return datas.map(data => data[1])
    })

    getChartXData = memoize(datas => {
        return datas.map(data => data[0])
    })

    renderConfusionMatrixChart = () => {
        if (!this.props.confusionMatrix) {
            return '请在模型评估指标中选择混淆矩阵'
        }
        return <ConfusionMatrixChart data={this.props.confusionMatrix} />
    }

    renderPRChart = () => {
        if (!this.props.prCurveData) {
            return '请在模型评估指标中选择PR曲线'
        }
        return <LinePlot data={this.props.prCurveData} />
    }

    renderROCChart = () => {
        if (!this.props.rocCurveData) {
            return '请在模型评估指标中选择ROC曲线'
        }
        return <LinePlot data={this.props.rocCurveData} />
    }

    render() {
        const { onCancel } = this.props
        return (
            <Modal
                title="二分类评估 - 分析结果"
                visible={true}
                onCancel={onCancel}
                width={1200}
                footer={null}
                className={styles.resultModal}
                maskClosable={false}
            >
                <div className={styles.resultContent}>
                    <Tabs defaultActiveKey="1">
                        <TabPane tab="混淆矩阵" key="1">
                            {this.renderConfusionMatrixChart()}
                        </TabPane>
                        <TabPane tab="PR曲线" key="2">
                            {this.renderPRChart()}
                        </TabPane>
                        <TabPane tab="ROC曲线" key="3">
                            {this.renderROCChart()}
                        </TabPane>
                    </Tabs>
                </div>
            </Modal>
        )
    }
}
