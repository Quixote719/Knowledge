export const translateStringToArray = str => {
    let arr = str.replace(/\(/g, '[').replace(/\)/g, ']')
    return JSON.parse(arr)
}
