/**
 * Created by yaojia7 on 2019/3/20.
 */
import React, { useMemo } from 'react'
import BoxplotModal from './DataShowModal'

export default React.memo(function({ data, onCancel }) {
    const props = useMemo(() => {
        const { rowList } = data['0']
        const tableSource = []
        for (let i = 0; i < rowList.length; ++i) {
            const columnData = JSON.parse(rowList[i])

            //             lower_quartile: "249999.0"
            // max: "990001"
            // median_quartile: "499999.0"
            // min: "0"
            // upper_quartile: "749999.0"

            tableSource.push({
                number: i + 1,
                selectedColumn: columnData.column,
                statistic: Object.keys(columnData.metrics)
                    .map(key => {
                        return `${key}: ${columnData.metrics[key]}`
                    })
                    .join(', '),
            })
        }

        return {
            onCancel,
            tableSource,
        }
    }, [data, onCancel])
    return <BoxplotModal {...props} />
})
