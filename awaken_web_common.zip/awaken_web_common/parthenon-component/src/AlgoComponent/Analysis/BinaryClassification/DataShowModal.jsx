/**
 * Created by lizhoujie5 on 2018/1/4.
 */
import React from 'react'
import styles from './showModal.less'
import { Modal, Table, Tooltip } from 'antd'

const Pre = ({ text = '' }) => {
    return (
        <pre
            style={{
                fontSize: 12,
                whiteSpace: 'pre-wrap',
                marginBottom: '0.4em',
            }}
        >
            {text}
        </pre>
    )
}

//生成固定宽度的表格列
const genFixedColumn = (key, dataIndex, title, width, enableTooltip = true) => {
    return {
        key,
        dataIndex,
        title,
        width,
        render: text =>
            enableTooltip ? (
                <Tooltip
                    title={
                        key === 'statistic' ? (
                            <Pre text={text.split(', ').join(', \n')} />
                        ) : (
                            text
                        )
                    }
                >
                    <div
                        style={{
                            width: '100%',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                        }}
                    >
                        {text}
                    </div>
                </Tooltip>
            ) : (
                <div
                    style={{
                        width: '100%',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                    }}
                >
                    {text}
                </div>
            ),
    }
}

const TABLE_COLUMNS = [
    genFixedColumn('number', 'number', '序号', 50),
    genFixedColumn('selectedColumn', 'selectedColumn', '选择字段', 150),
    genFixedColumn('statistic', 'statistic', '数据统计结果', 500),
]

export default class extends React.Component {
    render() {
        const { onCancel, tableSource } = this.props
        const dataSource = tableSource.map((item, index) => {
            return {
                ...item,
                key: index,
            }
        })
        return (
            <Modal
                title="箱线图 - 查看数据"
                visible={true}
                onCancel={onCancel}
                width="800px"
                footer={null}
                className={styles.resultModal}
                maskClosable={false}
            >
                <div className={styles.resultContent}>
                    <Table
                        dataSource={dataSource}
                        columns={TABLE_COLUMNS}
                        pagination={false}
                        scroll={{ x: 700, y: 500 }}
                        bordered
                    />
                </div>
            </Modal>
        )
    }
}
