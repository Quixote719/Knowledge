/**
 * Created by yaojia7 on 2019/4/12.
 */
import React from 'react'
import Chart from '../../Shared/Charts/Chart'
import styles from './showModal.less'

export default React.memo(({ data }) => {
    // 单条数据格式： [[1,2]];多条数据格式： [{name: 'test', value: [1,2]}]
    const seriesOptionObj = {
        smooth: true,
        type: 'line',
        itemStyle: {
            borderColor: '#188df0',
        },
        symbolSize: 10,
    }
    let seriesOption = []
    let legendData = []

    if (data && data[0] && data[0].hasOwnProperty('name')) {
        seriesOption = data.map(d => {
            legendData.push(d.name)
            return {
                ...seriesOptionObj,
                name: d.name,
                data: d.value,
            }
        })
    } else {
        seriesOption = [
            {
                ...seriesOptionObj,
                data: data,
            },
        ]
    }
    //console.log('legendData==', legendData, seriesOption)

    return (
        <Chart
            className={styles.histogramChart}
            style={{ height: 600 }}
            option={{
                legend: {
                    show: true,
                    data: legendData,
                },
                tooltip: {
                    trigger: 'item',
                    formatter: function(params) {
                        const data = params.data
                        return data[0] + ', ' + data[1]
                    },
                },
                series: seriesOption,
                xAxis: {
                    splitArea: {
                        show: false,
                    },
                    splitLine: {
                        show: false,
                    },
                },
                yAxis: {
                    type: 'value',
                    splitArea: {
                        show: true,
                    },
                },
            }}
        />
    )
})
