/**
 * 直方图组件查看分析结果组件
 * Created by yaojia7 on 2019/3/18.
 */
import React, { useMemo } from 'react'
import BinaryModal from './BinaryResultModal'
import { translateStringToArray } from './util'

export default React.memo(function({ component, onCancel }) {
    const props = useMemo(() => {
        const { tp, fp, tn, fn, prCurveJson, rocCurveJson } = JSON.parse(
            component.analysisData
        )
        const confusionMatrix = tp === 'undefined' ? null : { tp, fp, tn, fn } // 混淆矩阵
        return {
            confusionMatrix,
            prCurveData: prCurveJson
                ? translateStringToArray(prCurveJson)
                : null, // pr曲线
            rocCurveData: rocCurveJson
                ? translateStringToArray(rocCurveJson)
                : null, // roc曲线
        }
    }, [component])

    return <BinaryModal {...props} onCancel={onCancel} />
})
