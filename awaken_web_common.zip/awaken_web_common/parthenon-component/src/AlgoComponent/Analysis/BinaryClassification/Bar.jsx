/**
 * Created by yaojia7 on 2019/4/12.
 */
import React from 'react'
import Chart from '../../Shared/Charts/Chart'
import styles from './showModal.less'

export default React.memo(({ data = [], axisLabel }) => {
    const xAxisData = data.map(d => d.name)
    const yAxisData = data.map(d => d.value)
    let xAxisOptions = {}
    if (axisLabel) {
        xAxisOptions.axisLabel = axisLabel // 自行处理文本过长的问题
    }
    return (
        <Chart
            className={styles.histogramChart}
            style={{ height: 600 }}
            option={{
                color: ['#40a9ff'],
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        // 坐标轴指示器，坐标轴触发有效
                        type: 'shadow' // 默认为直线，可选为：'line' | 'shadow'
                    }
                },
                series: [
                    {
                        data: yAxisData,
                        type: 'bar',
                        label: {
                            normal: {
                                show: true,
                                position: 'top'
                            }
                        }
                    }
                ],
                xAxis: {
                    type: 'category',
                    data: xAxisData,
                    ...xAxisOptions
                },
                yAxis: {
                    type: 'value'
                    // splitArea: {
                    //     show: true,
                    // },
                }
            }}
        />
    )
})
