/**
 * Created by yaojia7 on 2019/4/12.
 */
import React from 'react'
import styles from './showModal.less'

export default React.memo(({ data }) => {
    const { tp, fp, fn, tn } = data
    return (
        <table className={styles.confusionMatrixChart}>
            <tbody>
                <tr>
                    <th rowSpan={2}>真实情况</th>
                    <th colSpan={2}>预测结果</th>
                </tr>
                <tr>
                    <th>正例</th>
                    <th>反例</th>
                </tr>
                <tr>
                    <th>正例</th>
                    <td>{tp}</td>
                    <td>{fn}</td>
                </tr>
                <tr>
                    <th>反例</th>
                    <td>{fp}</td>
                    <td>{tn}</td>
                </tr>
            </tbody>
        </table>
    )
})
