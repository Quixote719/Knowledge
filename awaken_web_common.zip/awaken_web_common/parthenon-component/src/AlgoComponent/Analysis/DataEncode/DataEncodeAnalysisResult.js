/**
 * 标签编码组件查看分析结果组件
 * Created by yaojia7 on 2019/3/18.
 */
import React, { useMemo } from 'react'
import Modal from './resultModal'

export default React.memo(function({ component, onCancel }) {
    const props = useMemo(() => {
        const rowList = JSON.parse(component.analysisData)
        const fields = []
        const dataList = []

        for (let row of rowList) {
            const fieldData = JSON.parse(row.singleStatInfo['直方图'])
            const numeric = true
            let xData = JSON.parse(fieldData.key)
            let yData = JSON.parse(fieldData.value)

            fields.push({
                fieldName: row.columnName,
                fieldId: row.columnName,
            })

            dataList.push({
                xData,
                data: yData,
                numeric,
            })
        }

        return {
            fields,
            datas: dataList,
        }
    }, [component])

    return <Modal {...props} onCancel={onCancel} />
})
