/**
 * Created by yaojia7 on 2019/4/12.
 */
import React from 'react'
import Chart from '../../Shared/Charts/Chart'
import styles from './showModal.less'

const findMinData = data => {
    if (data) {
        let min = undefined
        data.forEach(d => {
            if (Array.isArray(d)) {
                min = findMinData(d)
            } else {
                const num = Number(d)
                min = min !== undefined ? (num < min ? num : min) : num
            }
        })
        return min
    }
    return 0
}

const findMaxData = data => {
    if (data) {
        let max = undefined
        data.forEach(d => {
            if (Array.isArray(d)) {
                max = findMaxData(d)
            } else {
                const num = Number(d)
                max = max !== undefined ? (num > max ? num : max) : num
            }
        })
        return max
    }
    return 0
}

export default React.memo(({ xData, yData, type = 'detailChart' }) => {
    const minY = findMinData(yData)
    const maxY = findMaxData(yData)

    if (type === 'thumbnail') {
        return (
            <Chart
                className={styles.histogramChart}
                style={{ height: 64 }}
                option={{
                    series: [
                        {
                            data: yData,
                            type: 'boxplot',
                            itemStyle: {
                                borderColor: '#188df0'
                            },
                            slient: true
                        }
                    ],
                    xAxis: {
                        show: false,
                        data: xData
                    },
                    yAxis: {
                        show: false,
                        min: minY
                    }
                }}
            />
        )
    } else if (type === 'detailChart') {
        return (
            <Chart
                className={styles.histogramChart}
                style={{ height: 600 }}
                option={{
                    tooltip: {
                        trigger: 'item',
                        axisPointer: {
                            type: 'shadow'
                        }
                    },
                    series: [
                        {
                            data: yData,
                            type: 'boxplot',
                            itemStyle: {
                                borderColor: '#188df0'
                            },
                            tooltip: {
                                formatter: function(param) {
                                    return [
                                        param.name + ': ',
                                        '最大值: ' + param.data[5],
                                        '上四分位数: ' + param.data[4],
                                        '中位数: ' + param.data[3],
                                        '下四分位数: ' + param.data[2],
                                        '最小值: ' + param.data[1]
                                    ].join('<br/>')
                                }
                            }
                        }
                    ],
                    xAxis: {
                        type: 'category',
                        data: xData,
                        splitArea: {
                            show: false
                        },
                        splitLine: {
                            show: false
                        }
                    },
                    yAxis: {
                        type: 'value',
                        min: minY,
                        splitArea: {
                            show: true
                        }
                    },
                    grid: {
                        left: 30 + String(maxY).length * 8
                    }
                }}
            />
        )
    } else {
        return null
    }
})
