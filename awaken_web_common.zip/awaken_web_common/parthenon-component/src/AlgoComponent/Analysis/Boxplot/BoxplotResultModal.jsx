/**
 * Created by lizhoujie5 on 2018/1/4.
 */
import React from 'react'
import PropTypes from 'prop-types'
import memoize from 'memoize-one'
import styles from './showModal.less'
import { Modal, Table } from 'antd'
import BoxPlot from './BoxPlot'

const InlineBarChart = ({ record }) => {
    const chartXData = record.xData
    const chartData = record.data
    return (
        <div className={styles.inlineBarChart}>
            <BoxPlot type="thumbnail" xData={chartXData} yData={chartData} />
        </div>
    )
}

export default class extends React.Component {
    static propTypes = {
        fields: PropTypes.array.isRequired,
        datas: PropTypes.arrayOf(
            PropTypes.shape({
                xData: PropTypes.array.isRequired,
                data: PropTypes.array.isRequired,
                numeric: PropTypes.bool.isRequired,
            })
        ).isRequired,
    }

    constructor(props) {
        super(props)
        const { fields } = this.props
        this.state = {
            currFieldId: fields && fields.length > 0 ? fields[0].fieldId : null,
        }
        this.tableColumns = [
            {
                title: '字段名',
                key: 'fieldName',
                dataIndex: 'fieldName',
                width: '40%',
            },
            {
                title: '预览',
                key: 'preview',
                width: '59%',
                render: (text, record) => <InlineBarChart record={record} />,
            },
        ]
    }

    //切换字段
    handleFieldSelect = fieldId => {
        this.setState({ currFieldId: fieldId })
    }

    getDataSource = memoize((fields, datas) => {
        return fields.map((f, i) => {
            return {
                ...datas[i],
                fieldName: f.fieldName,
                key: f.fieldId, //字段id
            }
        })
    })

    getChartData = memoize(currField => {
        return currField.data
    })

    getChartXData = memoize(currField => {
        return currField.xData
    })

    render() {
        const { onCancel, fields, datas } = this.props
        const { currFieldId } = this.state
        if (fields.length !== datas.length) {
            return null
        }
        const dataSource = this.getDataSource(fields, datas) //缩略图表的展示数据(原始数据)
        const currField = dataSource.find(f => f.key === currFieldId)

        const chartData = this.getChartData(currField)
        const chartXData = this.getChartXData(currField)

        return (
            <Modal
                title="箱线图 - 分析结果"
                visible={true}
                onCancel={onCancel}
                width={1200}
                footer={null}
                className={styles.resultModal}
                maskClosable={false}
            >
                <div className={styles.resultContent}>
                    <div className={styles.colChange}>
                        <header>切换字段</header>
                        <Table
                            dataSource={dataSource}
                            columns={this.tableColumns}
                            pagination={false}
                            scroll={{ y: 600 }}
                            bordered
                            rowClassName={record =>
                                record.key === currFieldId ? 'selectedRow' : ''
                            }
                            onRow={record => ({
                                onClick: () => {
                                    this.handleFieldSelect(record.key)
                                },
                            })}
                        />
                    </div>

                    <div className={styles.chartChange}>
                        {currField.numeric && (
                            <BoxPlot xData={chartXData} yData={chartData} />
                        )}
                    </div>
                </div>
            </Modal>
        )
    }
}
