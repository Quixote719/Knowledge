// 选择字段功能组件
import React from 'react'
import {Button} from 'antd'
import AnalysisResultModal from './AnalysisResultModal'


export default class extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            isResultShow: false, //模拟结果分析弹窗是否显示
        }
    }

    getResultDataSource = (value) => {
        ////获取新的表格数据
        console.log('value==',value)
    }



    render() {
        const { selectedColumns } = this.props
        return (
            <div>
                <Button type='primary' onClick={()=> {this.setState({isResultShow: !this.state.isResultShow})}}>数据质量分析结果弹窗</Button>
                {
                    this.state.isResultShow &&
                    <AnalysisResultModal
                        componentName='数据质量-组件名'
                        selectedCols={selectedColumns}
                        onCancel={()=> {this.setState({isResultShow: false})}}
                        getResultDataSource={this.getResultDataSource}
                        tableSource={TABLE_SOURCE}
                        tableColumns={TABLE_COLUMNS}
                    />
                }
            </div>
        )
    }
}

//模拟表格数据
const TABLE_SOURCE = [{
    name : 'name1',
    type: 'string',
    total: 1000000,
    nullTotal: 555,
    nanTotal: 333,
    mode: '女',
    modeTotal: 55,
    max: null,
    min: null,
    average: null,
    median: null,
    lowerQuartiles: null,
    upperQuartiles: null,
    variance: null,
    standardDeviation: null,
    skewness: null,
    kurtosis: null,
}]

//模拟列
const TABLE_COLUMNS = [{
    title: '字段名称',
    dataIndex: 'name',
    key: 'name',
}, {
    title: '字段类型',
    dataIndex: 'type',
    key: 'type',
}, {
    title: '数据总量',
    dataIndex: 'total',
    key: 'total',
}, {
    title: 'NULL值数',
    dataIndex: 'nullTotal',
    key: 'nullTotal',
}, {
    title: 'NAN值数',
    dataIndex: 'nanTotal',
    key: 'nanTotal',
}, {
    title: '众数',
    dataIndex: 'mode',
    key: 'mode',
}, {
    title: '众数频数',
    dataIndex: 'modeTotal',
    key: 'modeTotal',
}, {
    title: '最大数',
    dataIndex: 'max',
    key: 'max',
}, {
    title: '最小数',
    dataIndex: 'min',
    key: 'min',
}, {
    title: '平均值',
    dataIndex: 'average',
    key: 'average',
}, {
    title: '中位数',
    dataIndex: 'median',
    key: 'median',
}, {
    title: '下四分位数',
    dataIndex: 'lowerQuartiles',
    key: 'lowerQuartiles',
}, {
    title: '上四分位数',
    dataIndex: 'upperQuartiles',
    key: 'upperQuartiles',
}, {
    title: '方差',
    dataIndex: 'variance',
    key: 'variance',
}, {
    title: '标准差',
    dataIndex: 'standardDeviation',
    key: 'standardDeviation',
}, {
    title: '偏度',
    dataIndex: 'skewness',
    key: 'skewness',
}, {
    title: '峰度',
    dataIndex: 'kurtosis',
    key: 'kurtosis',
}]
