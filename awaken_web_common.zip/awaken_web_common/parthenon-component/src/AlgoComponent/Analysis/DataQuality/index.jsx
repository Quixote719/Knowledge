import React from 'react'
import { Form } from 'antd'
import PropTypes from 'prop-types'

import SelectFields from '../../Shared/SelectFields'
import { mapToTuple } from '../../transformHelper'
import { getFormItemState, validateThenSave } from '../../common'

const FormItem = Form.Item

class DataQuality extends React.Component {
    static propTypes = {
        instanceParams: PropTypes.shape({
            outputCols: PropTypes.array
        }),
        isLocked: PropTypes.bool,
        inputSchema: PropTypes.shape({
            0: PropTypes.array
        }),
        paramState: PropTypes.shape({
            outputCols: PropTypes.string
        }),
        onSave: PropTypes.func
    };

    constructor(props) {
        super(props)
        this.getFormItemState = getFormItemState.bind(this)
        this.validateThenSave = validateThenSave.bind(this)
    }

    handleSaveParams = params => {
        this.validateThenSave(params, this.props.onSave)
    };

    renderKeepCols = () => {
        const allColumns = this.props.inputSchema[0]
        const selectedColumns = mapToTuple({
            name: this.props.instanceParams.outputCols
        })

        return (
            <FormItem
                label={'数据质量-选择字段'}
                required
                {...getFormItemState(this.props.paramState.outputCols)}
            >
                <SelectFields
                    buttonText="选择字段"
                    onSelectFields={selectedColumns =>
                        this.handleSaveParams({
                            outputCols: selectedColumns.map(col => col.name)
                        })
                    }
                    allColumns={allColumns}
                    selectedColumns={selectedColumns}
                    isSelectMulti={true}
                    disabled={this.props.isLocked}
                />
            </FormItem>
        )
    };

    render() {
        return <div>{this.renderKeepCols()}</div>
    }
}

export default Form.create()(DataQuality)
