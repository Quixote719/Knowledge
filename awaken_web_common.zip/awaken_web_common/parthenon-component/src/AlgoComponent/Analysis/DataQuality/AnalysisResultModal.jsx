/**
 * Created by lizhoujie5 on 2018/1/4.
 */
import React from 'react'
import styles from './resultModal.less'
import { Modal, Select, Table } from 'antd'
const { Option } = Select

class AnalysisResultModal extends React.Component {
    static defaultProps = {
        showAll: false
    }

    constructor(props) {
        super(props)
        const { selectedCols } = this.props
        this.state = {
            selectedName: (selectedCols[0] && selectedCols[0].name) || ''
        }
    }

    render() {
        const {
            showAll,
            onCancel,
            selectedCols = [],
            componentName = `数据质量-${
                this.props.showAll ? '查看数据' : '查看分析结果'
            }`,
            tableSource,
            tableColumns
        } = this.props
        const selectOptions = selectedCols.map(col => {
            return (
                <Option value={col.name} key={col.name}>
                    {col.name}
                </Option>
            )
        })

        const dataSource = tableSource.map((data, index) => {
            let obj = {}
            Object.keys(data).forEach(item => {
                if (!data[item] && data[item] !== 0) {
                    obj[item] = '-'
                } else {
                    obj[item] = data[item]
                }
            })
            obj.key = index
            return obj
        })

        const columns = tableColumns.map(col => {
            return {
                ...col,
                width: 100
            }
        })

        return (
            <Modal
                title={componentName}
                visible={true}
                onCancel={onCancel}
                width={1000}
                footer={null}
                className={styles.resultModal}
                maskClosable={false}>
                <div className={styles.resultContent}>
                    {!showAll && (
                        <div>
                            <span>字段选择：</span>
                            <Select
                                onChange={this.handleChangeSelect}
                                value={this.state.selectedName}
                                style={{ width: '200px' }}>
                                {selectOptions}
                            </Select>
                        </div>
                    )}
                    <div className={styles.resultTable}>
                        <Table
                            dataSource={dataSource}
                            columns={columns}
                            pagination={false}
                            scroll={{ x: columns.length * 100, y: 500 }}
                            bordered
                        />
                    </div>
                </div>
            </Modal>
        )
    }

    handleChangeSelect = value => {
        const { getResultDataSource = () => {} } = this.props
        //切换所选表
        this.setState({
            selectedName: value
        })

        //获取新的表格数据
        getResultDataSource(value)
    }
}

export default AnalysisResultModal
