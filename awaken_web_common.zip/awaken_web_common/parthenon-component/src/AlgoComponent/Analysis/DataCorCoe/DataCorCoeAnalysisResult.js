/**
 * 相关系数矩阵组件查看分析结果组件
 * Created by yaojia7 on 2019/3/18.
 */
import React, { useMemo } from 'react'
import Modal from './resultModal'

export default React.memo(function({ component, onCancel }) {
    const props = useMemo(() => {
        const analysisData = JSON.parse(component.analysisData)
        const { columnInfo, values } = analysisData

        const fields = []

        for (let fieldData of columnInfo) {
            fields.push({
                fieldName: fieldData.columnName,
                fieldId: fieldData.columnName,
            })
        }

        return {
            fields,
            datas: values,
        }
    }, [component])

    return <Modal {...props} onCancel={onCancel} />
})
