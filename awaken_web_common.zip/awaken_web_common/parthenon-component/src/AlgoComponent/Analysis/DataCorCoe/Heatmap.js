/**
 * Created by yaojia7 on 2019/4/12.
 */
import React from 'react'
import Chart from '../../Shared/Charts/Chart'
import styles from './showModal.less'

export default React.memo(({ xData, yData, data, isLabelVisible = true }) => {
    return (
        <Chart
            className={styles.histogramChart}
            style={{ height: 600 }}
            option={{
                grid: {
                    left: 0,
                    containLabel: true,
                },
                tooltip: {
                    trigger: 'item',
                    axisPointer: {
                        type: 'shadow',
                    },
                    formatter: params => {
                        const { data } = params
                        return `${data[0]}，${data[1]}：<br/>${data[2]}`
                    },
                },
                itemStyle: {
                    normal: { label: { show: false } },
                    emphasis: { label: { show: true } },
                },
                series: [
                    {
                        data: data,
                        type: 'heatmap',
                        label: {
                            color: '#000',
                            normal: {
                                show: isLabelVisible,
                                formatter: function(params) {
                                    const value = String(params.value[2])
                                    const dotIndex = value.indexOf('.')
                                    return dotIndex > 0
                                        ? value.substring(0, dotIndex + 3)
                                        : value // 保留两位小数
                                },
                            },
                        },
                        itemStyle: {
                            emphasis: {
                                shadowBlur: 10,
                                shadowColor: 'rgba(0, 0, 0, 0.5)',
                                borderColor: '#f00',
                            },
                        },
                    },
                ],
                xAxis: {
                    type: 'category',
                    position: 'top',
                    data: xData,
                    splitArea: {
                        show: true,
                    },
                    axisLabel: {
                        interval: 0,
                        formatter: function(value) {
                            const CHART_WITHD = 500 // 画布宽度
                            const PIXEL_PER_LETTER = 6 // 一个字母所占的像素
                            let ydataValueMaxLength = 0
                            yData.forEach(str => {
                                ydataValueMaxLength =
                                    str.length > ydataValueMaxLength
                                        ? str.length
                                        : ydataValueMaxLength
                            })
                            const valueMaxLength =
                                (CHART_WITHD -
                                    PIXEL_PER_LETTER * ydataValueMaxLength) /
                                (xData && xData.length > 0 ? xData.length : 1) /
                                PIXEL_PER_LETTER
                            if (value.length > valueMaxLength) {
                                return (
                                    value.substring(0, valueMaxLength) + '...'
                                )
                            } else {
                                return value
                            }
                        },
                    },
                },
                yAxis: {
                    type: 'category',
                    data: yData,
                    splitArea: {
                        show: true,
                    },
                },
                visualMap: {
                    min: -1,
                    max: 1,
                    calculable: true,
                    orient: 'vertical',
                    right: '0',
                    top: 'center',
                    color: ['#7cb4ec', '#fff', '#f0d37b'],
                },
            }}
        />
    )
})
