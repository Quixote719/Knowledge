/**
 * Created by lizhoujie5 on 2018/1/4.
 */
import React from 'react'
import PropTypes from 'prop-types'
import memoize from 'memoize-one'
import styles from './showModal.less'
import { Modal, Table, Switch } from 'antd'
import Heatmap from './Heatmap'

export default class extends React.Component {
    static propTypes = {
        fields: PropTypes.array.isRequired,
        datas: PropTypes.array.isRequired,
    }

    constructor(props) {
        super(props)
        const fieldNames = props.fields.map(f => f.fieldName)
        this.state = {
            isLabelVisible: true,
            selectedFieldNames: fieldNames,
        }
        this.tableColumns = [
            {
                title: '字段名',
                key: 'fieldName',
                dataIndex: 'fieldName',
                width: '40%',
            },
        ]
    }

    getDataSource = memoize(fields => {
        return fields.map(f => {
            return {
                fieldName: f.fieldName,
                key: f.fieldId, //字段id
            }
        })
    })

    getChartYData = memoize(fields => {
        return fields.map(f => f.fieldName)
    })

    getChartXData = memoize(fields => {
        return fields.map(f => f.fieldName)
    })

    getChartData = memoize((datas, xData, yData) => {
        let data = []
        for (let row = 0; row < datas.length; row++) {
            const arr = datas[row]
            for (let col = 0; col < arr.length; col++) {
                data.push([xData[row], yData[col], arr[col]])
            }
        }
        return data
    })

    toggleShowLabel = () => {
        this.setState({
            isLabelVisible: !this.state.isLabelVisible,
        })
    }

    onSelect = record => {
        const prevSelectedFieldNames = this.state.selectedFieldNames
        if (prevSelectedFieldNames.includes(record.fieldName)) {
            this.setState({
                selectedFieldNames: prevSelectedFieldNames.filter(
                    name => name !== record.fieldName
                ),
            })
        } else {
            this.setState({
                selectedFieldNames: prevSelectedFieldNames.concat([
                    record.fieldName,
                ]),
            })
        }
    }

    render() {
        const { isLabelVisible, selectedFieldNames } = this.state
        const { onCancel, fields, datas } = this.props

        const dataSource = this.getDataSource(fields)

        let selectedFields = [] // 当前字段信息
        let currFieldIndex = [] // 当前选中字段在原始数据中对应的索引值
        fields.forEach((f, idx) => {
            if (selectedFieldNames.includes(f.fieldName)) {
                selectedFields.push(f)
                currFieldIndex.push(idx)
            }
        })

        // 筛选出当前选中项对应的数据
        let currDatas = []
        for (let row = 0; row < datas.length; row++) {
            let item = []
            if (currFieldIndex.includes(row)) {
                const arr = datas[row]
                for (let col = 0; col < arr.length; col++) {
                    if (currFieldIndex.includes(col)) {
                        item.push(arr[col])
                    }
                }
                currDatas.push(item)
            }
        }

        const xData = this.getChartXData(selectedFields)
        const yData = this.getChartYData(selectedFields)
        const data = this.getChartData(currDatas, xData, yData)

        return (
            <Modal
                title="相关系数矩阵 - 分析结果"
                visible={true}
                onCancel={onCancel}
                width={1200}
                footer={null}
                className={styles.resultModal}
                maskClosable={false}
            >
                <div className={styles.resultContent}>
                    {data.length > 0 && (
                        <div>
                            <span
                                key="labelToggle"
                                className={styles.densityToggle}
                            >
                                <Switch
                                    checked={isLabelVisible}
                                    checkedChildren={'显示相关系数'}
                                    unCheckedChildren={'不显示相关系数'}
                                    onChange={this.toggleShowLabel}
                                />
                            </span>
                        </div>
                    )}
                    <div className={styles.colChange}>
                        <header>
                            选择字段（已选{selectedFields.length}个）
                        </header>
                        <Table
                            dataSource={dataSource}
                            columns={this.tableColumns}
                            pagination={false}
                            scroll={{ y: 600 }}
                            bordered
                            rowClassName={record =>
                                selectedFieldNames.includes(record.fieldName)
                                    ? 'selectedRow'
                                    : ''
                            }
                            onRow={record => {
                                return {
                                    onClick: () => {
                                        this.onSelect(record)
                                    }, // 点击行
                                }
                            }}
                        />
                    </div>

                    <div className={styles.chartChange}>
                        <Heatmap
                            xData={xData}
                            yData={yData}
                            data={data}
                            isLabelVisible={isLabelVisible}
                        />
                    </div>
                </div>
            </Modal>
        )
    }
}
