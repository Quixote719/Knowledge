/**
 * Created by lizhoujie5 on 2018/1/4.
 */
import React from 'react'
import styles from './showModal.less'
import { Modal, Table, Tooltip } from 'antd'

const Pre = ({ text = '' }) => {
    return <pre className={styles.tooltip}>{text}</pre>
}

//生成固定宽度的表格列
const genFixedColumn = (key, dataIndex, title, width, enableTooltip = true) => {
    return {
        key,
        dataIndex,
        title,
        width,
        render: text =>
            enableTooltip ? (
                <Tooltip
                    title={
                        key === 'histogram' ? (
                            <Pre text={text.split(', ').join(', \n')} />
                        ) : (
                            text
                        )
                    }>
                    <div
                        style={{
                            width: '100%',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap'
                        }}>
                        {text}
                    </div>
                </Tooltip>
            ) : (
                <div
                    style={{
                        width: '100%',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap'
                    }}>
                    {text}
                </div>
            )
    }
}

const SINGLE_TABLE_COLUMNS = [
    genFixedColumn('number', 'number', '序号', 50),
    genFixedColumn('selectedColumn', 'selectedColumn', '统计字段', 150),
    genFixedColumn('histogram', 'histogram', '统计结果', 500)
]

const MULTI_TABLE_COLUMNS = [
    genFixedColumn('xAxis', 'xAxis', '横坐标', 200),
    genFixedColumn('dimen', 'dimen', '区分维度', 200),
    genFixedColumn('count', 'count', 'count', 300)
]

export default class extends React.Component {
    render() {
        const { onCancel, tableSource, bins } = this.props
        const dataSource = tableSource.map((item, index) => {
            return {
                ...item,
                key: index
            }
        })

        let columns = SINGLE_TABLE_COLUMNS

        columns[2].title = `统计结果 (${bins})`

        if (tableSource.length > 0 && tableSource[0].hasOwnProperty('xAxis')) {
            columns = MULTI_TABLE_COLUMNS
        }

        return (
            <Modal
                title="直方图-查看数据"
                visible={true}
                onCancel={onCancel}
                width="800px"
                footer={null}
                className={styles.resultModal}
                maskClosable={false}>
                <div className={styles.resultContent}>
                    <Table
                        dataSource={dataSource}
                        columns={columns}
                        pagination={false}
                        scroll={{ x: 700, y: 500 }}
                        bordered
                    />
                </div>
            </Modal>
        )
    }
}
