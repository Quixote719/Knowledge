/**
 * Created by yaojia7 on 2019/3/20.
 */
import React, { useMemo } from 'react'
import HistogramModal from './DataShowModal'

const simplifyNUmber = num => {
    let res = Number(num)
    if (res !== res) return num
    if (res > 1) return res.toFixed(2)
    const str = res.toString()
    let i
    for (i = 0; i < str.length; ++i) {
        if (str.charAt(i) !== '0' && str.charAt(i) !== '.') break
    }
    return Number(res.toFixed(i + 1))
}

export default React.memo(function({
    type = 'single',
    params,
    data,
    onCancel,
}) {
    const props = useMemo(() => {
        const { rowList, columnInfos } = data['0']
        const tableSource = []
        if (type === 'multi') {
            // 以下为跨字段统计分析
            const xAxisIndex = columnInfos.findIndex(
                col => col.columnName === params.firstStatColumns[0]
            )
            const dimenIndex = columnInfos.findIndex(
                col => col.columnName === params.secondStatColumns[0]
            )
            const countIndex = columnInfos.findIndex(
                col => col.columnName === 'count'
            )
            for (let i = 0; i < rowList.length; ++i) {
                const columnData = rowList[i]
                tableSource.push({
                    xAxis: columnData[xAxisIndex],
                    dimen: columnData[dimenIndex],
                    count: columnData[countIndex],
                })
            }
        } else {
            // 以下为单字段统计分析
            for (let i = 0; i < rowList.length; ++i) {
                const columnData = JSON.parse(rowList[i])
                tableSource.push({
                    number: i + 1,
                    selectedColumn: columnData.column,
                    histogram: columnData.metrics
                        .filter(item => item.count > 0)
                        .map(item => {
                            if (!columnData.isNum)
                                return `[${item.value}]: ${item.count}`
                            return `[${simplifyNUmber(
                                item.down
                            )},${simplifyNUmber(item.up)}): ${item.count}`
                        })
                        .join(', '),
                })
            }
        }
        return {
            onCancel,
            tableSource,
        }
    }, [data, onCancel])
    return <HistogramModal {...props} />
})
