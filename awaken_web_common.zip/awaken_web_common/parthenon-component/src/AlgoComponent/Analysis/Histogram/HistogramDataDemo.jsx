// 选择字段功能组件
import React from 'react'
import {Button} from 'antd'
import DataShowModal from './DataShowModal'


export default class extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            isDataShow: false, //模拟查看结果弹窗是否显示
        }
    }


    render() {
        return (
            <div>
                <Button type='primary' onClick={()=> {this.setState({isDataShow: !this.state.isDataShow})}}>查看数据</Button>
                {
                    this.state.isDataShow &&
                    <DataShowModal
                        onCancel={()=> {this.setState({isDataShow: false})}}
                        tableSource={TABLE_SOURCE}
                        tableColumns={TABLE_COLUMNS}
                    />
                }
            </div>
        )
    }
}

//模拟表格数据
const TABLE_SOURCE = [{
    number : 1,
    selectedColumn: 'age',
    histogram: '[1,2):16,[2,3):12,[3,4):9,[1,2):16,[2,3):12,[3,4):9,[1,2):16,[2,3):12,[3,4):9,[1,2):16,[2,3):12,[3,4):9',
},{
    number : 2,
    selectedColumn: 'namespace',
    histogram: '[1,2):16,[2,3):12,[3,4):9,[1,2):16,[2,3):12,[3,4):9,[1,2):16,[2,3):12,[3,4):9,[1,2):16,[2,3):12,[3,4):9',
}]

//模拟列
const TABLE_COLUMNS = [{
    title: '序号',
    dataIndex: 'number',
    key: 'number',
}, {
    title: '选择字段',
    dataIndex: 'selectedColumn',
    key: 'selectedColumn',
}, {
    title: '数据统计结果',
    dataIndex: 'histogram',
    key: 'histogram',
}]

