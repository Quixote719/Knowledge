/**
 * 直方图组件查看分析结果组件
 * Created by yaojia7 on 2019/3/18.
 */
import React, { useMemo } from 'react'
import SingleModal from './ResultModal'
import MultiModal from './MultiResultModal'

const simplifyNUmber = num => {
    let res = Number(num)
    if (res !== res) return num
    if (res > 1) return res.toFixed(2)
    const str = res.toString()
    let i
    for (i = 0; i < str.length; ++i) {
        if (str.charAt(i) !== '0' && str.charAt(i) !== '.') break
    }
    return Number(res.toFixed(i + 1))
}

export default React.memo(function({ component, onCancel }) {
    const props = useMemo(() => {
        const analysisData = JSON.parse(component.analysisData)
        // 以下为跨字段统计分析
        if (component.params.isCombineStatistics) {
            const schema = analysisData.schema || []
            let data = analysisData.data || []
            data = data.map(row => {
                let dataObj = {}
                row.forEach((d, idx) => {
                    const key = schema[idx]
                    dataObj[key] = d
                })
                return dataObj
            })
            return {
                type: 'multi',
                xAxis: component.params.firstStatColumns || [],
                dimen: component.params.secondStatColumns || [],
                data: data
            }
        }
        // 以下为单字段统计分析
        const intervalNumber = component.params.binNums
        const fields = []
        const dataList = []
        for (let row of analysisData) {
            const fieldData = JSON.parse(row)
            const numeric = fieldData.isNum
            let xData = numeric
                ? fieldData.metrics.map(
                      i => simplifyNUmber(i.down) + '-' + simplifyNUmber(i.up)
                  )
                : fieldData.metrics.map(i => i.value)
            let yData = fieldData.metrics.map(i => i.count)

            fields.push({
                fieldName: fieldData.column,
                fieldId: fieldData.column
            })

            dataList.push({
                xData,
                data: yData,
                numeric
            })
        }

        return {
            type: 'single',
            intervalNumber,
            fields,
            datas: dataList
        }
    }, [component])
    if (props.type === 'multi') {
        return <MultiModal {...props} onCancel={onCancel} />
    } else {
        return <SingleModal {...props} onCancel={onCancel} />
    }
})
