/**
 * Created by yaojia7 on 2019/4/12.
 */
import React from 'react'
import PropTypes from 'prop-types'
import { Checkbox } from 'antd'
import Chart from '../../../Shared/Charts/Chart'
import styles from '../showModal.less'

export default class extends React.Component {
    static propTypes = {
        series: PropTypes.object,
        seriesAxisName: PropTypes.string,
        yAxisName: PropTypes.string,
    }
    static defaultProps = {
        series: {},
        seriesAxisName: '',
        yAxisName: '',
    }

    constructor(props) {
        super(props)
        this.state = {
            indeterminate: false,
            checkAll: true,
            checkedList: [],
        }
        this.initPlainOptions()
    }

    initPlainOptions = () => {
        this.plainOptions = Object.keys(this.props.series)
    }

    renderEchartDomCallback = echartObj => {
        this.echartObj = echartObj
    }

    onLegendSelectChange = checkedList => {
        this.setState({
            checkedList,
            indeterminate:
                !!checkedList.length &&
                checkedList.length < this.plainOptions.length,
            checkAll: checkedList.length === this.plainOptions.length,
        })
    }

    onCheckAllChange = e => {
        const checkedList = e.target.checked ? this.plainOptions : [] // 选中的图例
        this.setState({
            checkedList: checkedList,
            indeterminate: false,
            checkAll: e.target.checked,
        })
        // 设置echarts的图例配置
        let option = this.echartObj.getOption()
        let obj = {}
        this.plainOptions.forEach(name => {
            obj[name] = checkedList.includes(name)
        })
        option.legend[0].selected = obj
        this.echartObj.setOption(option)
    }

    renderChart = () => {
        const { series, seriesAxisName, yAxisName } = this.props
        const { onLegendSelectChange } = this
        const dataZoomProps = Object.keys(series).length > 10 ? { end: 10 } : {} // 图例超过十个，默认显示数据区域前10%

        return (
            <Chart
                className={styles.histogramChart}
                style={{ height: 600 }}
                option={{
                    color: [
                        '#C9DCE9',
                        '#AECDE9',
                        '#80AFE2',
                        '#015BB6',
                        '#013775',
                        '#A5C3E8',
                        '#B2C9E4',
                        '#B8C7E5',
                        '#CAD6EA',
                        '#CBD0E6',
                        '#A0C9E5',
                        '#7EB4E1',
                        '#4F96D8',
                        '#0165B9',
                        '#00559B',
                        '#AECDE9',
                        '#9BB9E3',
                        '#6984D3',
                        '#B0C4E9',
                        '#A1A9DF',
                        '#90C6E5',
                        '#71B6E2',
                        '#499FDB',
                        '#0279C5',
                        '#005390',
                        '#80AFE2',
                        '#6690D8',
                        '#304FB8',
                        '#577DD7',
                        '#535BC0',
                        '#B4DAE5',
                        '#8DCFE7',
                        '#58B8E2',
                        '#0086CA',
                        '#02669E',
                        '#015BB6',
                        '#013CA2',
                        '#132192',
                        '#001EA3',
                        '#2A29A4',
                        '#94D3E2',
                        '#70C4DC',
                        '#2AABCE',
                        '#0396C0',
                        '#0274AD',
                        '#00559B',
                        '#003689',
                        '#002B74',
                        '#0F2977',
                        '#27298E',
                    ],
                    tooltip: {
                        trigger: 'axis',
                        axisPointer: {
                            type: 'shadow',
                        },
                        formatter: params => {
                            const name = params[0].name
                            let tip = `${name} <br/>`
                            params.forEach(param => {
                                const { data, seriesName } = param
                                tip += `${param.marker}${seriesName}:  ratio ${
                                    data[1]
                                }，count ${data[2]} <br/>`
                            })
                            return tip
                        },
                    },
                    legend: {
                        show: true,
                        type: 'scroll',
                        left: '56px',
                    },
                    xAxis: {
                        type: 'category',
                        name: seriesAxisName,
                    },
                    yAxis: {
                        type: 'value',
                        name: yAxisName,
                    },
                    series: Object.keys(series).map(item => {
                        return {
                            name: item,
                            data: series[item],
                            type: 'bar',
                            label: {
                                normal: {
                                    show: true,
                                    rotate: 90,
                                    align: 'left',
                                    verticalAlign: 'middle',
                                    position: 'insideBottom',
                                    distance: 15,
                                    formatter: params => {
                                        return params.seriesName
                                    },
                                },
                            },
                        }
                    }),
                    dataZoom: [
                        {
                            show: true,
                            startValue: 0,
                            ...dataZoomProps,
                        },
                    ],
                }}
                events={{
                    legendselectchanged: function(params) {
                        let selectedLegends = []
                        for (const name in params.selected) {
                            if (params.selected[name]) {
                                selectedLegends.push(name)
                            }
                        }
                        onLegendSelectChange(selectedLegends)
                    },
                }}
                renderEchartDomCallback={this.renderEchartDomCallback}
            />
        )
    }
    render() {
        return (
            <div className={styles.chartWithLegend}>
                <span className={styles.checkboxWrapper}>
                    <Checkbox
                        indeterminate={this.state.indeterminate}
                        onChange={this.onCheckAllChange}
                        checked={this.state.checkAll}
                    >
                        全选
                    </Checkbox>
                </span>
                {this.renderChart()}
            </div>
        )
    }
}
