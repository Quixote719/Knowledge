/**
 * Created by yaojia7 on 2019/4/12.
 */
import React from 'react'
import Chart from '../../../Shared/Charts/Chart'
import styles from '../showModal.less'

export default React.memo(({ xData, yData, columnName }) => {
    return (
        <Chart
            className={styles.histogramChart}
            style={{ height: 600 }}
            option={{
                grid: {
                    top: 50,
                    left: 50,
                    right: 10,
                    bottom: 120,
                },
                xAxis: [
                    {
                        type: 'category',
                        data: xData,
                        axisLabel: {
                            rotate: 45,
                            formatter: function(value, index) {
                                if (yData[index] > 0) return value
                                return null
                            },
                        },
                    },
                ],
                yAxis: [
                    {
                        type: 'value',
                        name: columnName,
                        nameLocation: 'center',
                        nameGap: 35,
                        nameRotation: 90,
                        nameTextStyle: {
                            fontSize: 14,
                        },
                        axisLabel: {
                            formatter: '{value}',
                        },
                    },
                ],
                tooltip: {
                    trigger: 'axis',
                    formatter: '{b}<br/>{c}',
                },
                series: [
                    {
                        data: yData || [],
                        type: 'bar',
                        barMaxWidth: 30,
                        label: {
                            show: true,
                            position: 'top',
                            formatter: function({ value }) {
                                return value || ''
                            },
                        },
                    },
                ],
                dataZoom: [
                    {
                        type: 'slider',
                        // startValue: 0,
                        // endValue: 9,
                        xAxisIndex: [0],
                        top: 'top',
                    },
                    {
                        type: 'inside',
                        // startValue: 0,
                        // endValue: 9,
                        xAxisIndex: [0],
                    },
                ],
            }}
        />
    )
})
