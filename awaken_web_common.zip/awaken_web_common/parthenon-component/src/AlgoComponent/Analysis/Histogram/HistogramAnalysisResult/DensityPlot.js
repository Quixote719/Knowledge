/**
 * Created by yaojia7 on 2019/4/9.
 */
import React, { useMemo } from 'react'
import Chart from '../../../Shared/Charts/Chart'
import styles from '../showModal.less'

const simplifyNumber = num => {
    let res = Number(num)
    if (res !== res) return num
    if (res > 1) return res.toFixed(2)
    const str = res.toString()
    let i
    for (i = 0; i < str.length; ++i) {
        if (str.charAt(i) !== '0' && str.charAt(i) !== '.') break
    }
    return Number(res.toFixed(i + 1))
}

const range = (start, end, step) => {
    let startInd = start
    let endInd = end
    let s = step
    if (!startInd && !endInd) {
        startInd = -5
        endInd = 5
        s = 0.2
    }
    const res = []
    for (let i = startInd; i < endInd; i += s) res.push(simplifyNumber(i))
    return res
}

const GaussianKernal = x =>
    Math.exp((-1 * x * x) / 2) / Math.pow(2 * Math.PI, 0.5)

/**
 * @param {Array} | arr [[x, weight]]
 */
const densityEstimator = (arr, bandwidth) => {
    const sum = arr.reduce((a, b) => [null, a[1] + b[1]], [null, 0])[1]
    const BW = bandwidth
    return x => {
        return (
            arr
                .filter(item => item[1] > 0)
                .map(item => {
                    return item[1] * GaussianKernal((x - item[0]) / BW)
                })
                .reduce((a, b) => a + b, 0) /
            (sum * BW)
        )
    }
}

const calcBandwidth = (max, min, len) => {
    const median = (max - min) / 2 + min
    const width = max - min
    if (width === 0) {
        if (median === 0) return 1
        return median / 5
    }
    return width / len
}

export default React.memo(({ xData, yData }) => {
    const { chartXData, chartYData } = useMemo(() => {
        let maxX = Number.NEGATIVE_INFINITY
        let minX = Number.POSITIVE_INFINITY

        const arr = xData
            .map((item, i) => {
                const tmp = item.split('-').map(n => Number(n))
                const x = (tmp[1] - tmp[0]) / 2 + tmp[0]
                return [x, yData[i]]
            })
            .filter(item => item[1] > 0)

        if (!Number.isFinite(maxX) || !Number.isFinite(minX)) {
            maxX = Number(xData[xData.length - 1].split('-')[1])
            minX = Number(xData[0].split('-')[0])
        }

        const halfXW = (maxX - minX) / 2
        const calcDensity = densityEstimator(
            arr,
            calcBandwidth(maxX, minX, xData.length)
        )
        let chartXData, chartYData

        if (halfXW === 0) chartXData = range(0, 2 * maxX, (2 * maxX) / 50)
        else
            chartXData = range(
                minX - halfXW / 2,
                maxX + halfXW / 2,
                (maxX - minX) / 50
            )

        chartYData = chartXData.map(i => calcDensity(i))

        return { chartXData, chartYData }
    }, [xData, yData])

    return (
        <Chart
            className={styles.densityPlot}
            style={{ height: 600 }}
            option={{
                grid: {
                    top: 50,
                    left: 50,
                    right: 10,
                    bottom: 120,
                },
                xAxis: [
                    {
                        type: 'category',
                        data: chartXData,
                        axisLabel: {
                            rotate: 45,
                        },
                    },
                ],
                yAxis: [
                    {
                        type: 'value',
                        min: 0,
                        max: Math.max(...chartYData) * 1.5,
                        axisLabel: {
                            formatter: '{value}',
                        },
                    },
                ],
                tooltip: {
                    trigger: 'axis',
                    formatter: '{b}<br/>{c}',
                },
                series: [
                    {
                        data: chartYData,
                        type: 'line',
                        smooth: true,
                    },
                ],
            }}
        />
    )
})
