/**
 * Created by lizhoujie5 on 2018/1/4.
 */
import React from 'react'
import PropTypes from 'prop-types'
import memoize from 'memoize-one'
import styles from '../showModal.less'
import { Modal, Table, Input, Button, Switch } from 'antd'
import DensityPlot from './DensityPlot'
import HistogramPlot from './HistogramPlot'

const STEP_MAG_LIST = [1, 2, 4, 5, 10, 20]

const InlineBarChart = ({ data, intervalNumber }) => {
    const maxHeight = Math.max(...data) || 0
    const barWidth = 50 / intervalNumber
    const marginRight = Math.min((100 / intervalNumber - barWidth) / 2, 5)

    if (!maxHeight) return null
    return (
        <div className={styles.inlineBarChart}>
            {data.map((d, i) => (
                <div
                    key={i + ''}
                    className={styles.inlineBar}
                    style={{
                        margin: `0 ${marginRight}%`,
                        width: `${barWidth}%`,
                        maxWidth: 30,
                        //如果柱子长度大于0，则设置最小宽度为1px，否则可能因为宽度小于1px原因无法显示出来
                        minWidth: d > 0 ? 1 : 0,
                        height: `${(100 * d) / maxHeight}%`
                    }}
                />
            ))}
        </div>
    )
}

export default class extends React.Component {
    static propTypes = {
        fields: PropTypes.array.isRequired,
        datas: PropTypes.arrayOf(
            PropTypes.shape({
                xData: PropTypes.array.isRequired,
                data: PropTypes.array.isRequired,
                numeric: PropTypes.bool.isRequired
            })
        ).isRequired,
        onCancel: PropTypes.func.isRequired
    }

    constructor(props) {
        super(props)
        const { fields } = this.props
        let defaultStepMagArray = {}
        if (fields && fields.length > 0) {
            fields.forEach(f => {
                defaultStepMagArray[f.fieldId] = 1
            })
        }
        this.state = {
            currFieldId: fields && fields.length > 0 ? fields[0].fieldId : null,
            stepMagArray: defaultStepMagArray, //每个字段的步长倍数
            showDensity: false
        }
        this.tableColumns = [
            {
                title: '统计字段',
                key: 'fieldName',
                dataIndex: 'fieldName',
                width: '40%'
            },
            {
                title: '预览',
                key: 'preview',
                width: '59%',
                render: (text, record) => (
                    <InlineBarChart
                        data={record.data}
                        intervalNumber={props.intervalNumber}
                    />
                )
            }
        ]
    }

    toggleShowDensity = () => {
        this.setState({
            showDensity: !this.state.showDensity
        })
    }

    handleStepMagChange = operate => {
        const { currFieldId, stepMagArray } = this.state
        const index = STEP_MAG_LIST.indexOf(stepMagArray[currFieldId])
        if (operate === 'minus' && index > 0) {
            let newArr = {
                ...stepMagArray,
                [currFieldId]: STEP_MAG_LIST[index - 1]
            }
            return this.setState({
                stepMagArray: newArr
            })
        }
        if (operate === 'plus' && index < STEP_MAG_LIST.length - 1) {
            let newArr = {
                ...stepMagArray,
                [currFieldId]: STEP_MAG_LIST[index + 1]
            }
            return this.setState({
                stepMagArray: newArr
            })
        }
    }

    //切换字段
    handleFieldSelect = fieldId => {
        this.setState({ currFieldId: fieldId, showDensity: false })
    }

    getDataSource = memoize((fields, datas) => {
        return fields.map((f, i) => {
            return {
                ...datas[i],
                fieldName: f.fieldName,
                key: f.fieldId //字段id
            }
        })
    })

    getChartData = memoize((currField, stepMagArray, currFieldId) => {
        if (!currField) {
            return []
        }
        const data = currField.data
        let chartData = []
        data.forEach((item, index) => {
            if (index % stepMagArray[currFieldId] === 0) {
                chartData.push(item)
            } else {
                chartData[chartData.length - 1] += item
            }
        })
        return chartData
    })

    getChartXData = memoize((currField, stepMagArray, currFieldId) => {
        if (!currField) {
            return []
        }
        const xData = currField.xData
        let chartXData = []

        xData.forEach((item, index) => {
            if (index % stepMagArray[currFieldId] === 0) {
                chartXData.push(item)
            } else if (
                index % stepMagArray[currFieldId] ===
                    stepMagArray[currFieldId] - 1 ||
                index === xData.length - 1
            ) {
                let startV = chartXData[chartXData.length - 1].split('-')[0]
                let endV = item.split('-')[1]
                chartXData[chartXData.length - 1] = `${startV}-${endV}`
            }
        })
        return chartXData
    })

    render() {
        const { onCancel, fields, datas, intervalNumber } = this.props
        const { currFieldId, stepMagArray, showDensity } = this.state
        if (fields.length !== datas.length) {
            return null
        }
        const dataSource = this.getDataSource(fields, datas) //缩略图表的展示数据(原始数据)
        const currField = dataSource.find(f => f.key === currFieldId)

        const chartData = this.getChartData(
            currField,
            stepMagArray,
            currFieldId
        )
        const chartXData = this.getChartXData(
            currField,
            stepMagArray,
            currFieldId
        )
        return (
            <Modal
                title="直方图-查看分析结果"
                visible={true}
                onCancel={onCancel}
                width={1200}
                footer={null}
                className={styles.resultModal}
                maskClosable={false}>
                <div className={styles.resultContent}>
                    <div className={styles.colChange}>
                        <Table
                            dataSource={dataSource}
                            columns={this.tableColumns}
                            pagination={false}
                            scroll={{ y: 600 }}
                            bordered
                            rowClassName={record =>
                                record.key === currFieldId ? 'selectedRow' : ''
                            }
                            onRow={record => ({
                                onClick: () => {
                                    this.handleFieldSelect(record.key)
                                }
                            })}
                        />
                    </div>

                    <div className={styles.chartChange}>
                        <div className={styles.setChange}>
                            <span key="step" className={styles.stepChange}>
                                <span className={styles.title}>修改步长: </span>
                                <Button
                                    key="minus"
                                    icon="minus"
                                    size="small"
                                    disabled={!currField.numeric}
                                    onClick={this.handleStepMagChange.bind(
                                        this,
                                        'minus'
                                    )}
                                />
                                <span className={styles.stepInput}>
                                    <Input
                                        size="small"
                                        value={stepMagArray[currFieldId]}
                                        readOnly
                                        addonAfter={'倍'}
                                        disabled={!currField.numeric}
                                    />
                                </span>
                                <Button
                                    key="plus"
                                    icon="plus"
                                    size="small"
                                    disabled={!currField.numeric}
                                    onClick={this.handleStepMagChange.bind(
                                        this,
                                        'plus'
                                    )}
                                />
                            </span>
                            <span
                                key="densityToggle"
                                className={styles.densityToggle}>
                                <Switch
                                    checked={showDensity}
                                    disabled={!currField.numeric}
                                    checkedChildren={'密度曲线'}
                                    unCheckedChildren={'直方图'}
                                    onChange={this.toggleShowDensity}
                                />
                            </span>
                            <span
                                key="interval"
                                className={styles.intervalChange}>
                                <span key="title" className={styles.title}>
                                    区间数:{' '}
                                </span>
                                <span>
                                    {Math.ceil(
                                        intervalNumber /
                                            stepMagArray[currFieldId]
                                    )}
                                </span>
                            </span>
                        </div>
                        {showDensity && (
                            <DensityPlot xData={chartXData} yData={chartData} />
                        )}
                        {!showDensity && (
                            <HistogramPlot
                                columnName={currField.fieldName}
                                xData={chartXData}
                                yData={chartData}
                            />
                        )}
                    </div>
                </div>
            </Modal>
        )
    }
}
