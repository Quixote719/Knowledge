/**
 * Created by lizhoujie5 on 2018/1/4.
 */
import React from 'react'
import PropTypes from 'prop-types'
import styles from '../showModal.less'
import { Modal } from 'antd'
import HistogramPlotWithLegend from './HistogramPlotWithLegend'

export default class extends React.Component {
    static propTypes = {
        onCancel: PropTypes.func.isRequired,
    }

    constructor(props) {
        super(props)
    }

    renderPlot = () => {
        const { xAxis, dimen, data } = this.props
        if (xAxis.length < 1 || dimen.length < 1 || data.length < 1) {
            return '暂无数据'
        }

        const series = {}
        const dimenAttriName = dimen[0] // 目前横坐标与维度都只能选一个
        const xAttriName = xAxis[0]
        const yAttriName = 'ratio'
        data.forEach(d => {
            const dimenValue = d[dimenAttriName]
            let plotData = series[dimenValue] ? series[dimenValue] : []
            plotData.push([d[xAttriName], d[yAttriName], d.count])
            series[dimenValue] = plotData
        })
        return (
            <div className={styles.chartWrapper}>
                <span className={styles.tip}>请选择需要展示的枚举值：</span>
                <HistogramPlotWithLegend
                    series={series}
                    seriesAxisName={dimenAttriName}
                    yAxisName={yAttriName}
                />
            </div>
        )
    }
    render() {
        const { onCancel } = this.props
        return (
            <Modal
                title="直方图-查看分析结果"
                visible={true}
                onCancel={onCancel}
                width={1200}
                footer={null}
                className={styles.resultModal}
                maskClosable={false}
            >
                <div className={styles.resultContent}>{this.renderPlot()}</div>
            </Modal>
        )
    }
}
