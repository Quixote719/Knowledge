// 选择字段功能组件
import React from 'react'
import HistogramResultModal from './ResultModal'

export default class extends React.Component {
    render() {
        return (
            <div>
                <HistogramResultModal
                    onCancel={this.props.onCancel}
                    intervalNumber={12} //区间数
                    fields={FILEDS}
                    datas={SOURCE_CHART_DATAS}
                />
            </div>
        )
    }
}

const FILEDS = [
    {
        fieldName: 'AGE1',
        fieldId: 'age1',
    },
    {
        fieldName: 'AGE2',
        fieldId: 'age2',
    },
    {
        fieldName: 'AGE3',
        fieldId: 'age3',
    },
]

const SOURCE_CHART_DATAS = [
    {
        data: [10, 20, 30, 50, 80, 10, 20, 30, 20, 30, 5, 5],
        xData: [
            '0-9',
            '10-19',
            '20-29',
            '30-39',
            '40-49',
            '50-59',
            '60-69',
            '70-79',
            '80-89',
            '90-99',
            '100-109',
            '110-119',
        ],
    },
    {
        data: [50, 30, 20, 10, 20, 30, 50, 20, 10, 20, 5, 5],
        xData: [
            '0-9',
            '10-19',
            '20-29',
            '30-39',
            '40-49',
            '50-59',
            '60-69',
            '70-79',
            '80-89',
            '90-99',
            '100-109',
            '110-119',
        ],
    },
    {
        data: [10, 20, 30, 50, 80, 10, 20, 30, 20, 30, 5, 5],
        xData: [
            '0-9',
            '10-19',
            '20-29',
            '30-39',
            '40-49',
            '50-59',
            '60-69',
            '70-79',
            '80-89',
            '90-99',
            '100-109',
            '110-119',
        ],
    },
]
