import React from 'react'
import { Form } from 'antd'
import PropTypes from 'prop-types'

import SelectFields from '../../Shared/SelectFields'
import {
    IntegerValidator,
    minValidator,
    maxValidator
} from './../../inputValidator'
import { Input } from 'antd'
import { mapToTuple } from '../../transformHelper'
import { getFormItemState, validateThenSave } from '../../common'

const FormItem = Form.Item

class Histogram extends React.Component {
    static defaultProps = {
        selectableTypes: null //为null时表示不对字段类型进行过滤
    }

    static propTypes = {
        instanceParams: PropTypes.shape({
            outputCols: PropTypes.array,
            intervalNumber: PropTypes.string
        }),
        isLocked: PropTypes.bool,
        inputSchema: PropTypes.shape({
            0: PropTypes.array
        }),
        selectableColumns: PropTypes.array,
        paramState: PropTypes.shape({
            outputCols: PropTypes.string,
            intervalNumber: PropTypes.string
        }),
        onSave: PropTypes.func,
        selectableTypes: PropTypes.array
    }

    constructor(props) {
        super(props)
        this.getFormItemState = getFormItemState.bind(this)
        this.validateThenSave = validateThenSave.bind(this)
        this.initIntervalNumber = props.instanceParams.intervalNumber ////this.props.instanceParams.intervalNumber
        this.state = {
            saveIntervaldNumber: this.initIntervalNumber
        }
    }

    handleSaveParams = params => {
        this.validateThenSave(params, this.props.onSave)
    }

    handleIntervalBlur = () => {
        const value = this.props.form.getFieldValue('intervalNumber')
        if (
            this.props.form.getFieldValue('intervalNumber') ===
            this.state.saveIntervaldNumber
        ) {
            return
        } else if (!this.props.form.getFieldValue('intervalNumber')) {
            //empty
            return
        } else if (this.props.form.getFieldError('intervalNumber')) {
            //error
            this.handleSaveParams({
                intervalNumber: Number(this.state.saveIntervaldNumber)
            })
            this.props.form.setFieldsValue({
                intervalNumber: this.state.saveIntervaldNumber
            })
        } else {
            //correct
            this.handleSaveParams({ intervalNumber: Number(value) })
            this.setState({
                saveIntervaldNumber: value
            })
        }
    }

    renderZoneNumber = () => {
        const { getFieldDecorator } = this.props.form

        return (
            <FormItem
                label={'区间数'}
                {...getFormItemState(this.props.paramState.intervalNumber)}>
                {getFieldDecorator('intervalNumber', {
                    initialValue: this.initIntervalNumber,
                    validateFirst: true,
                    rules: [
                        {
                            required: true,
                            // max: ,
                            message: '区间数必填'
                        },
                        IntegerValidator({ message: '输入必须是整数' }),
                        minValidator({ message: '输入不能小于1', min: 1 }),
                        maxValidator({
                            message: '输入不能大于2147020237',
                            max: 2147020237
                        })
                    ]
                })(
                    <Input
                        placeholder=""
                        title="请输入1以上的整数"
                        onBlur={this.handleIntervalBlur}
                        onPressEnter={e => {
                            e.target.blur()
                        }}
                        disabled={this.props.isLocked}
                    />
                )}
            </FormItem>
        )
    }

    renderKeepCols = () => {
        const { selectableTypes, inputSchema, selectableColumns } = this.props
        const allColumns = inputSchema[0]
        const selectedColumns = mapToTuple({
            name: this.props.instanceParams.outputCols
        })

        return (
            <FormItem
                label={'直方图-选择字段'}
                required
                {...getFormItemState(this.props.paramState.outputCols)}>
                <SelectFields
                    numericCols={true}
                    buttonText="选择字段"
                    onSelectFields={selectedColumns =>
                        this.handleSaveParams({
                            outputCols: selectedColumns.map(col => col.name)
                        })
                    }
                    allColumns={allColumns}
                    selectedColumns={selectedColumns}
                    selectableColumns={
                        selectableColumns.length > 0
                            ? selectableColumns
                            : allColumns.filter(
                                f =>
                                    !selectableTypes ||
                                      selectableTypes.includes(f.type)
                            )
                    }
                    isSelectMulti={true}
                    disabled={this.props.isLocked}
                />
            </FormItem>
        )
    }

    render() {
        return (
            <div>
                {this.renderKeepCols()}
                {this.renderZoneNumber()}
            </div>
        )
    }
}

export default Form.create()(Histogram)
