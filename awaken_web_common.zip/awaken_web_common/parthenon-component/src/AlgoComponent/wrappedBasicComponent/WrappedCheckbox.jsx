import React from 'react'
import { Form, Checkbox } from 'antd'
import PropTypes from 'prop-types'

import { getFormItemState, composeCompSaveState } from '../common'

const FormItem = Form.Item

/**
 * Radio组件的高阶组件，可以简化Component中使用Radio的地方
 */
class WrappedCheckbox extends React.Component {
    static propTypes = {
        onSave: PropTypes.func.isRequired,
        attrName: PropTypes.string.isRequired,
        label: PropTypes.oneOfType([PropTypes.string, PropTypes.object])
            .isRequired,
        isRequired: PropTypes.bool,
        instanceParams: PropTypes.any.isRequired,
        isLocked: PropTypes.bool.isRequired,
    }

    constructor(props) {
        super(props)

        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {},
            },
        }
    }

    render() {
        const {
            attrName,
            label,
            isRequired,
            instanceParams,
            onSave,
            isLocked,
        } = this.props
        return (
            <FormItem
                {...getFormItemState(this.state.params.state[attrName])}
                required={isRequired}
            >
                <Checkbox
                    checked={
                        instanceParams[attrName] == undefined
                            ? false
                            : instanceParams[attrName]
                    }
                    onChange={e => {
                        onSave(
                            { [attrName]: e.target.checked },
                            this.saveCompState
                        )
                    }}
                    disabled={isLocked}
                >
                    {label}
                </Checkbox>
            </FormItem>
        )
    }
}

export default WrappedCheckbox
