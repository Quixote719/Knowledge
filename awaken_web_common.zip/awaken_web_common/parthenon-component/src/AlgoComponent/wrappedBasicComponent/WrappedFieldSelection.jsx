import React from 'react'
import { Form, Table } from 'antd'
import PropTypes from 'prop-types'

import { getFormItemState, composeCompSaveState } from '../common'
import { fieldTableDesc } from '../tableDesc'
import { expandSelectedColumnsWithType } from '../Shared/util'
import {
    filterGenericNumericValue,
    filterNumericalValue,
    filterStringTypeValue,
    filterTypes
} from '../typeHelper'
import SelectFields from '../Shared/SelectFields'

const FormItem = Form.Item

/**
 * FieldSelection组件的高阶组件，可以简化Component中使用FieldSelection的地方
 */
class WrappedFieldSelection extends React.Component {
    static defaultProps = {
        hidePopupOutput: false,
        isSelectMulti: true,
        displayOutput: false,
        numericCols: false,
        genericNumericCols: false,
        stringTypeCols: false,
        isRequired: false
    }

    static propTypes = {
        onSave: PropTypes.func.isRequired,
        attrName: PropTypes.string.isRequired,
        label: PropTypes.string.isRequired,
        warnTips: PropTypes.arrayOf(PropTypes.string), // 提示语句
        isRequired: PropTypes.bool,
        instanceParams: PropTypes.any.isRequired,
        isLocked: PropTypes.bool.isRequired,
        onSelectFields: PropTypes.func,
        allColumns: PropTypes.array.isRequired,
        additionalParams: PropTypes.array,
        allowedTypes: PropTypes.array,
        isSelectMulti: PropTypes.bool,
        displayOutput: PropTypes.bool,
        numericCols: PropTypes.bool,
        genericNumericCols: PropTypes.bool,
        stringTypeCols: PropTypes.bool,
        selectedColumns: PropTypes.array,
        colsRequired: PropTypes.number,
        selectableColumns: PropTypes.array
    }

    constructor(props) {
        super(props)

        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {}
            }
        }
    }

    /**
     * onSelectFields必须返回要保存的数据，并在此调用onSave。若在父组件中直接保存，则保存的状态无法获取
     */
    handleSelectColumnsSave = selectedColumns => {
        const { onSelectFields, attrName, onSave } = this.props
        if (typeof onSelectFields === 'function') {
            const paramToSave = onSelectFields(selectedColumns)
            if (typeof paramToSave !== 'object') {
                console.error(
                    'WrappedFieldSelection的onSelectFields应该返回需要保存的参数，并交给WrappedFieldSelection组件保存'
                )
            } else {
                onSave(paramToSave, this.saveCompState)
            }
        } else {
            onSave(
                {
                    [attrName]: selectedColumns.map(col => col.name)
                },
                this.saveCompState
            )
        }
    }

    render() {
        const {
            label,
            attrName,
            instanceParams,
            allColumns,
            hidePopupOutput,
            isSelectMulti,
            displayOutput,
            numericCols,
            genericNumericCols,
            stringTypeCols,
            isRequired,
            additionalParams = [],
            allowedTypes = [],
            warnTips = [],
            isLocked,
            colsRequired,
            paramState
        } = this.props

        let { selectedColumns, selectableColumns } = this.props

        selectableColumns = selectableColumns || allColumns.slice()

        if (allowedTypes && allowedTypes.length > 0) {
            selectableColumns = filterTypes(selectableColumns, allowedTypes)
        } else if (genericNumericCols) {
            selectableColumns = filterGenericNumericValue(selectableColumns)
        } else if (numericCols) {
            selectableColumns = filterNumericalValue(selectableColumns)
        } else if (stringTypeCols) {
            selectableColumns = filterStringTypeValue(selectableColumns)
        }

        selectedColumns = selectedColumns || instanceParams[attrName]

        const outputDataSource = expandSelectedColumnsWithType(
            selectedColumns,
            allColumns
        )

        const additionalProps = {}
        if (colsRequired) {
            additionalProps.colsRequired = colsRequired
        }

        /**
         * 如果外界传入了state，则使用外界的state。
         */
        let paramStateToUse =
            paramState === undefined
                ? this.state.params.state[attrName]
                : paramState

        return (
            <div>
                <FormItem
                    label={label}
                    {...getFormItemState(paramStateToUse)}
                    required={isRequired}>
                    <SelectFields
                        buttonText="选择"
                        required={isRequired}
                        onSelectFields={this.handleSelectColumnsSave}
                        allColumns={allColumns}
                        selectableColumns={selectableColumns}
                        selectedColumns={selectedColumns}
                        isSelectMulti={isSelectMulti}
                        disabled={isLocked}
                        hidePopupOutput={hidePopupOutput}
                        numericCols={numericCols}
                        genericNumericCols={genericNumericCols}
                        allowedTypes={allowedTypes}
                        warnTips={warnTips}
                        stringTypeCols={stringTypeCols}
                        additionalParams={additionalParams}
                        {...additionalProps}
                    />
                </FormItem>
                {displayOutput &&
                    outputDataSource &&
                    outputDataSource.length > 0 && (
                        <div title="详细信息">
                            <Table
                                dataSource={outputDataSource}
                                columns={fieldTableDesc}
                                pagination={false}
                                bordered
                            />
                        </div>
                    )}
            </div>
        )
    }
}

export default WrappedFieldSelection
