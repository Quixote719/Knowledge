import React from 'react'
import { Form, Switch, Tooltip, Icon } from 'antd'
import PropTypes from 'prop-types'

import { getFormItemState, composeCompSaveState } from '../common'

const FormItem = Form.Item

/**
 * Switch组件的高阶组件，可以简化Component中使用Switch的地方
 */
class WrappedSwitch extends React.Component {
    static propTypes = {
        onSave: PropTypes.func.isRequired,
        attrName: PropTypes.string.isRequired,
        label: PropTypes.oneOfType([PropTypes.string, PropTypes.object])
            .isRequired,
        isRequired: PropTypes.bool,
        instanceParams: PropTypes.any.isRequired,
        isLocked: PropTypes.bool.isRequired,
    }

    constructor(props) {
        super(props)

        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {},
            },
        }
    }

    render() {
        const {
            attrName,
            label,
            isRequired,
            instanceParams,
            onSave,
            isLocked,
        } = this.props
        return (
            <FormItem
                {...getFormItemState(this.state.params.state[attrName])}
                required={isRequired}
                label={
                    <span>
                        {label}
                        <Tooltip title="开启则落盘存储该组件结果数据；  关闭则不存储该组件结果数据，后续执行将从上游存储数据的最近节点向下运行。">
                            <Icon type="question-circle-o" />
                        </Tooltip>
                    </span>
                }
            >
                <Switch
                    checkedChildren="开"
                    unCheckedChildren="关"
                    checked={
                        instanceParams[attrName] == undefined
                            ? true
                            : instanceParams[attrName]
                    }
                    onChange={checked => {
                        onSave({ [attrName]: checked }, this.saveCompState)
                    }}
                    disabled={isLocked}
                />
            </FormItem>
        )
    }
}

export default WrappedSwitch
