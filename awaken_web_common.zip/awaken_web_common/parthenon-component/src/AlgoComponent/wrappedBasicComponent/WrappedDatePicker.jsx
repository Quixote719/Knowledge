import React from 'react'
import { Form, DatePicker } from 'antd'
import PropTypes from 'prop-types'
import moment from 'moment'

import { getFormItemState, composeCompSaveState } from '../common'

const FormItem = Form.Item

/**
 * DatePicker组件的高阶组件，可以简化Component中使用DatePicker的地方
 */
class WrappedDatePicker extends React.Component {
    static defaultProps = {
        showTime: true,
    }

    static propTypes = {
        onSave: PropTypes.func.isRequired,
        attrName: PropTypes.string.isRequired,
        isRequired: PropTypes.bool,
        instanceParams: PropTypes.any.isRequired,
        isLocked: PropTypes.bool.isRequired,
        rules: PropTypes.array,
        form: PropTypes.any.isRequired,
        label: PropTypes.string.isRequired,
        format: PropTypes.string,
        invalidDefault: PropTypes.oneOfType([
            PropTypes.string,
            PropTypes.object,
        ]),
        showTime: PropTypes.bool,
    }

    constructor(props) {
        super(props)

        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {},
            },
        }
    }

    handleSaveParam = value => {
        const { onSave, attrName, format } = this.props

        if (format) {
            value = new moment(value).format(format)
        }

        onSave({ [attrName]: value }, this.saveCompState)
    }

    getAllRules = () => {
        const { rules, isRequired } = this.props
        const res = (rules || []).slice()
        if (isRequired) {
            res.push({ message: '必填', required: true })
        }

        return res
    }

    disabledDate = current => {
        // 可选择的日期在1970开始，到9999-12-31
        return current < moment('1970-01-01') || current > moment('9999-12-31')
    }

    render() {
        const {
            form,
            label,
            format,
            attrName,
            instanceParams,
            isLocked,
            invalidDefault,
            showTime,
        } = this.props

        const { getFieldDecorator } = form
        let defaultValue = moment(instanceParams[attrName])

        if (!defaultValue._isValid && invalidDefault) {
            defaultValue = invalidDefault
        }

        const allRules = this.getAllRules()

        return (
            <FormItem
                label={label}
                {...getFormItemState(this.state.params.state[attrName])}
            >
                {getFieldDecorator(attrName, {
                    initialValue: defaultValue,
                    rules: allRules,
                })(
                    <DatePicker
                        showTime={showTime}
                        style={{ width: '100%' }}
                        placeholder=""
                        onChange={this.handleSaveParam}
                        disabled={isLocked}
                        format={format}
                        disabledDate={this.disabledDate}
                    />
                )}
            </FormItem>
        )
    }
}

export default WrappedDatePicker
