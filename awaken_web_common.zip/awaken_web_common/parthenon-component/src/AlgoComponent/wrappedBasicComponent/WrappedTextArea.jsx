import React from 'react'
import { Form, Input } from 'antd'
import PropTypes from 'prop-types'

import { getFormItemState, composeCompSaveState } from '../common'

const FormItem = Form.Item
const TextArea = Input.TextArea

/**
 * Select组件的高阶组件，可以简化Component中使用Select的地方
 */
class WrappedTextArea extends React.Component {
    static propTypes = {
        onSave: PropTypes.func.isRequired,
        attrName: PropTypes.string.isRequired,
        label: PropTypes.string.isRequired,
        isRequired: PropTypes.bool,
        instanceParams: PropTypes.any.isRequired,
        isLocked: PropTypes.bool.isRequired,
        rules: PropTypes.array,
        placeholder: PropTypes.string,
        autosize: PropTypes.any,
    }

    constructor(props) {
        super(props)

        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {},
            },
        }
    }

    handleChange = () => {
        const { attrName } = this.props
        this.setState({
            params: {
                state: {
                    [attrName]: 'init',
                },
            },
        })
    }

    render() {
        const {
            form,
            label,
            attrName,
            rules = [],
            placeholder = '',
            autosize,
            instanceParams,
            isLocked,
            onSave,
        } = this.props

        const { getFieldDecorator } = form
        const defaultValue = instanceParams[attrName]
        const additionalParams = {}
        if (autosize) additionalParams.autosize = autosize

        return (
            <FormItem
                label={label}
                {...getFormItemState(this.state.params.state[attrName])}
            >
                {getFieldDecorator(attrName, {
                    initialValue: defaultValue,
                    rules,
                })(
                    <TextArea
                        placeholder={placeholder}
                        onChange={this.handleChange}
                        onBlur={e =>
                            onSave(
                                {
                                    [attrName]: e.target.value,
                                },
                                this.saveCompState
                            )
                        }
                        disabled={isLocked}
                        {...additionalParams}
                    />
                )}
            </FormItem>
        )
    }
}

export default WrappedTextArea
