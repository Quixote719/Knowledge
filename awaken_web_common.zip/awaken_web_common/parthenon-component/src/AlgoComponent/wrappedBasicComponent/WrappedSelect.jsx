import React from 'react'
import { Form, Select } from 'antd'
import PropTypes from 'prop-types'

import { getFormItemState, composeCompSaveState } from '../common'

const FormItem = Form.Item
const Option = Select.Option

/**
 * Select组件的高阶组件，可以简化Component中使用Select的地方
 */
class WrappedSelect extends React.Component {
    static defaultProps = {
        width: '100%',
        allowReset: false,
        colon: true
    }

    static propTypes = {
        onSave: PropTypes.func.isRequired,
        attrName: PropTypes.string.isRequired,
        label: PropTypes.oneOfType([PropTypes.string, PropTypes.object])
            .isRequired,
        isRequired: PropTypes.bool,
        instanceParams: PropTypes.any.isRequired,
        isLocked: PropTypes.bool.isRequired,
        form: PropTypes.any.isRequired,
        width: PropTypes.string,
        options: PropTypes.array.isRequired,
        allowReset: PropTypes.bool,
        colon: PropTypes.bool,
        disabledOptions: PropTypes.array,
        mode: PropTypes.string,
        defaultValue: PropTypes.string
    }

    constructor(props) {
        super(props)

        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {}
            }
        }
    }

    componentWillReceiveProps(nextProps) {
        const { attrName, form } = this.props
        const { setFieldsValue } = form
        if (this.prevAttrValue === undefined) {
            this.prevAttrValue = this.props.instanceParams[attrName]
        } else if (nextProps.instanceParams[attrName] !== this.prevAttrValue) {
            setFieldsValue({
                [attrName]: nextProps.instanceParams[attrName]
            })
            this.prevAttrValue = nextProps.instanceParams[attrName]
        }
    }

    /**
     * onSelectFields必须返回要保存的数据，并在此调用handleDirectSave。若在父组件中直接保存，则保存的状态无法获取
     */
    handleSelectChange = value => {
        const { attrName, onChange } = this.props

        if (typeof onChange === 'function') {
            onChange({
                [attrName]: 'init'
            })
        } else {
            this.setState({
                params: {
                    state: {
                        [attrName]: 'init'
                    }
                }
            })
        }
    }

    /**
     * 记录下拉菜单是否展开
     */
    onDropdownVisibleChange = open => {
        this.setState({ open })
    }

    /**
     * 在多选情况下，可以在文本域中，通过点击单标签的关闭按钮来删除该标签
     * 这时候没有展开下拉菜单，因此不能触发blur事件
     * 所以通过open状态手动触发blur
     */
    onDeselect = deSelectValue => {
        const { open } = this.state
        const { onSave, attrName, form, instanceParams, onChange } = this.props
        const { validateFields } = form

        const prevFieledValue = form.getFieldValue(attrName)
        const nextFieledValue = prevFieledValue.filter(v => {
            if (typeof v === 'object') {
                return JSON.stringify(v) !== JSON.stringify(deSelectValue)
            } else {
                return v !== deSelectValue
            }
        })

        if (!open) {
            /**
             * 因为antd 设置最新值setFields是在onChange之后
             * 所以延迟一定时间再触发blur,为了避免会被onChange后的setFields方法重新覆盖而无效
             */
            setTimeout(() => {
                this.onBlur(nextFieledValue)
            }, 50)
        }
    }

    onBlur = value => {
        const { onSave, attrName, form, instanceParams, onChange } = this.props
        const { validateFields } = form

        validateFields(Object.keys({ [attrName]: value }), {}, err => {
            if (err) {
                // 延迟一定时间再setFieldsValue,为了能让用户看清错误提示
                setTimeout(() => {
                    form.setFieldsValue({
                        [attrName]: instanceParams[attrName]
                    })
                }, 500)
            } else {
                onSave({ [attrName]: value }, this.saveCompState)
            }
        })
    }

    render() {
        const {
            form,
            label,
            attrName,
            width,
            isLocked,
            options = [],
            allowReset,
            isRequired,
            colon,
            disabledOptions = [],
            mode,
            paramState,
            instanceParams
        } = this.props

        let { defaultValue } = this.props

        const { getFieldDecorator } = form
        defaultValue = defaultValue || instanceParams[attrName]
        const additionalParams = {}
        if (mode) additionalParams.mode = mode

        const rules = []
        if (isRequired) {
            rules.push({ message: '必填', required: true })
        }

        /**
         * 如果外界传入了state，则使用外界的state。
         */
        let paramStateToUse =
            paramState === undefined
                ? this.state.params.state[attrName]
                : paramState

        return (
            <FormItem
                label={label}
                colon={colon}
                {...getFormItemState(paramStateToUse)}
                required={isRequired}>
                {getFieldDecorator(attrName, {
                    initialValue: defaultValue,
                    rules
                })(
                    <Select
                        name={attrName}
                        style={{ width: width }}
                        onChange={this.handleSelectChange}
                        onBlur={this.onBlur}
                        onDeselect={this.onDeselect}
                        onDropdownVisibleChange={this.onDropdownVisibleChange}
                        {...additionalParams}
                        disabled={isLocked}>
                        {allowReset && <Option value={''}>未设置</Option>}
                        {options.map(opt => {
                            if (typeof opt === 'string') {
                                return (
                                    <Option
                                        key={opt}
                                        value={opt}
                                        disabled={disabledOptions.includes(
                                            opt
                                        )}>
                                        {opt}
                                    </Option>
                                )
                            } else {
                                return (
                                    <Option
                                        key={opt.value}
                                        value={opt.value}
                                        disabled={disabledOptions.includes(
                                            opt.value
                                        )}>
                                        {opt.label}
                                    </Option>
                                )
                            }
                        })}
                    </Select>
                )}
            </FormItem>
        )
    }
}

export default WrappedSelect
