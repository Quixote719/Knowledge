import React from 'react'
import { Form, Input } from 'antd'
import PropTypes from 'prop-types'

import { getFormItemState, composeCompSaveState } from '../common'
import { isNumberType, getMax, getMin, getInputRules } from '../inputCommon'
import {
    maxValidator,
    minValidator,
    IntegerValidator,
    positiveIntegerValidator,
    numberValidator,
    precisionValidator,
    IntegerWithAnomalylValidator
} from '../inputValidator'

const FormItem = Form.Item
/**
 * Select组件的高阶组件，可以简化Component中使用Select的地方
 */
class WrappedInput extends React.Component {
    static defaultProps = {
        colon: true,
        readOnly: false
    }

    static propTypes = {
        onSave: PropTypes.func.isRequired,
        attrName: PropTypes.string.isRequired,
        label: PropTypes.oneOfType([PropTypes.string, PropTypes.object])
            .isRequired,
        isRequired: PropTypes.bool,
        instanceParams: PropTypes.any.isRequired,
        isLocked: PropTypes.bool,
        form: PropTypes.any.isRequired,
        rules: PropTypes.array,
        min: PropTypes.shape({
            include: PropTypes.bool,
            value: PropTypes.number
        }),
        max: PropTypes.shape({
            include: PropTypes.bool,
            value: PropTypes.number
        }),
        isPositiveInteger: PropTypes.bool,
        isNumber: PropTypes.bool,
        isInteger: PropTypes.bool,
        placeholder: PropTypes.string,
        colon: PropTypes.bool,
        readOnly: PropTypes.bool,
        precision: PropTypes.number,
        maxLength: PropTypes.number,
    }

    constructor(props) {
        super(props)

        this.saveCompState = composeCompSaveState(this)

        this.state = {
            params: {
                state: {}
            },
            max: getMax(props), // max比较特殊，由于它有安全值，不能直接用props.max
            min: getMin(props) // min比较特殊，由于它有安全值，不能直接用props.min
        }
    }

    componentWillReceiveProps(nextProps) {
        const { attrName, form } = this.props
        const { setFieldsValue } = form
        if (this.prevAttrValue === undefined) {
            this.prevAttrValue = this.props.instanceParams[attrName]
        } else if (nextProps.instanceParams[attrName] !== this.prevAttrValue) {
            setFieldsValue({
                [attrName]: nextProps.instanceParams[attrName]
            })
            this.prevAttrValue = nextProps.instanceParams[attrName]
        }
        // 更新max
        if (JSON.stringify(this.props.max) !== JSON.stringify(nextProps.max)) {
            this.setState({ max: getMax(nextProps) })
        }
        // 更新min
        if (JSON.stringify(this.props.min) !== JSON.stringify(nextProps.min)) {
            this.setState({ min: getMin(nextProps) })
        }
    }

    handleChangeParam = () => {
        const { attrName, onChange } = this.props
        if (typeof onChange === 'function') {
            onChange({
                [attrName]: 'init'
            })
        } else {
            this.setState({
                params: {
                    state: {
                        [attrName]: 'init'
                    }
                }
            })
        }
    }

    getAllRules = () => {
        const { min, max } = this.state
        return getInputRules(min, max, this.props)
    }

    isInputNumber = () => {
        return isNumberType(this.props)
    }

    /**
     * 如果有onSave函数，则优先使用onSave函数传的值
     */
    handleRouteSave = value => {
        const isNumber = this.isInputNumber()
        const { onSave, attrName, form, instanceParams } = this.props
        const { validateFields } = form

        validateFields(Object.keys({ [attrName]: value }), {}, err => {
            if (err) {
                form.setFieldsValue({ [attrName]: instanceParams[attrName] })
            } else {
                if (value) {
                    onSave(
                        {
                            [attrName]: isNumber ? Number(value) : value
                        },
                        this.saveCompState
                    )
                } else {
                    onSave(
                        {
                            [attrName]: value
                        },
                        this.saveCompState
                    )
                }
            }
        })
    }

    render() {
        const {
            form,
            label,
            attrName,
            placeholder,
            isRequired,
            instanceParams,
            isLocked,
            colon,
            paramState,
            readOnly,
            maxLength
        } = this.props

        const { getFieldDecorator } = form
        const defaultValue = instanceParams[attrName]

        const allRules = this.getAllRules()
        /**
         * 如果外界传入了state，则使用外界的state。
         */
        let paramStateToUse =
            paramState === undefined
                ? this.state.params.state[attrName]
                : paramState

        return (
            <FormItem
                label={label}
                required={isRequired}
                colon={colon}
                {...getFormItemState(paramStateToUse)}>
                {getFieldDecorator(attrName, {
                    initialValue: defaultValue,
                    rules: allRules
                })(
                    <Input
                        placeholder={placeholder || ''}
                        onChange={() => this.handleChangeParam(attrName)}
                        onBlur={e => {
                            this.handleRouteSave(e.target.value)
                        }}
                        onPressEnter={e => {
                            e.target.blur()
                        }}
                        disabled={isLocked || readOnly}
                        maxLength={maxLength}
                    />
                )}
            </FormItem>
        )
    }
}

export default WrappedInput
