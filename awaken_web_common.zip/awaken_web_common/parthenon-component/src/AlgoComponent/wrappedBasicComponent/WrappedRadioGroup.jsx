import React from 'react'
import { Form, Radio } from 'antd'
import PropTypes from 'prop-types'

import { getFormItemState, composeCompSaveState } from '../common'

const FormItem = Form.Item
const RadioGroup = Radio.Group

/**
 * Radio组件的高阶组件，可以简化Component中使用Radio的地方
 */
class WrappedRadioGroup extends React.Component {
    static propTypes = {
        onSave: PropTypes.func.isRequired,
        attrName: PropTypes.string.isRequired,
        label: PropTypes.string.isRequired,
        isRequired: PropTypes.bool,
        instanceParams: PropTypes.any.isRequired,
        isLocked: PropTypes.bool.isRequired,
        options: PropTypes.array.isRequired,
    }

    constructor(props) {
        super(props)

        this.saveCompState = composeCompSaveState(this)
        this.state = {
            params: {
                state: {},
            },
        }
    }

    render() {
        const {
            attrName,
            label,
            options = [],
            instanceParams,
            isRequired,
            isLocked,
            onSave,
        } = this.props
        const defaultValue = instanceParams[attrName]
        return (
            <FormItem
                label={label}
                required={isRequired}
                {...getFormItemState(this.state.params.state[attrName])}
            >
                <RadioGroup
                    name={attrName}
                    defaultValue={defaultValue}
                    onChange={e => {
                        onSave(
                            { [attrName]: e.target.value },
                            this.saveCompState
                        )
                    }}
                    disabled={isLocked}
                >
                    {options.map(opt => {
                        if (typeof opt === 'string') {
                            return (
                                <Radio key={opt} value={opt}>
                                    {opt}
                                </Radio>
                            )
                        } else {
                            return (
                                <Radio key={opt.value} value={opt.value}>
                                    {opt.label}
                                </Radio>
                            )
                        }
                    })}
                </RadioGroup>
            </FormItem>
        )
    }
}

export default WrappedRadioGroup
