export const COL_DEFAULT_WIDTH = 126
export const BUTTON_DEFAULT_WIDTH = 100

export const fieldTableDesc = [
    {
        title: '字段名',
        dataIndex: 'name',
        key: 'name',
        width: COL_DEFAULT_WIDTH,
    },
    {
        title: '字段类型',
        dataIndex: 'type',
        key: 'type',
        width: COL_DEFAULT_WIDTH,
    },
]

export const fieldTableDesc2 = [
    {
        title: '字段名',
        dataIndex: 'name',
        key: 'name',
        width: COL_DEFAULT_WIDTH,
    },
    {
        title: '字段类型',
        dataIndex: 'type',
        key: 'type',
        width: COL_DEFAULT_WIDTH,
    },
    {
        title: '字段描述',
        dataIndex: 'desc',
        key: 'desc',
        width: COL_DEFAULT_WIDTH,
    },
]

export const joinTableDesc2 = [
    {
        title: '输入字段',
        dataIndex: 'inputName',
        key: 'inputName',
        width: COL_DEFAULT_WIDTH,
    },
    {
        title: '来源',
        dataIndex: 'source',
        key: 'source',
        width: COL_DEFAULT_WIDTH,
    },
    {
        title: '输出字段',
        dataIndex: 'outputName',
        key: 'outputName',
        width: COL_DEFAULT_WIDTH,
    },
]
