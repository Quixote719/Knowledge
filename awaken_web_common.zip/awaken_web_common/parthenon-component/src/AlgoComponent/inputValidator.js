import {
    isNumeric,
    isPositiveInteger,
    minValidate,
    maxValidate,
    isInteger,
    emptyValidate,
    maxLenValidate,
    minLenValidate,
    noSpaceValidate,
    characterValidate,
    noUnderScoreHeadValidate,
    noCapitalValidate,
    jsonValidate,
    isIntegerArray,
    startWithAlphabetValidate,
    isConformPrecision,
    asciiValidate,
} from './validateRules'

export const wrapValidator = ({ message, ...rest }, validator) => {
    //(value, ...rest) => {return !value || isInteger(value, ...rest)}
    return {
        message,
        validator: (rule, value, callback) => {
            if (validator(value, rest)) {
                callback()
            } else {
                callback(false)
            }
        }
    }
}

export const createJsonValidator = () => {
    const rules = []
    rules.push(
        wrapValidator(
            {
                message: '输入不能为空'
            },
            emptyValidate
        )
    )
    rules.push(
        wrapValidator(
            {
                message: '输入不是合法的json格式'
            },
            jsonValidate
        )
    )
    return rules
}

export const createTableNameValidator = (opts = {}) => {
    const rules = []
    const {
        prefix = '写数据表名字',
        maxLength = 30,
        allowEmptySpace = false
    } = opts
    rules.push(
        wrapValidator(
            {
                message: `${prefix}不能为空`
            },
            emptyValidate
        )
    )
    rules.push(
        wrapValidator(
            {
                message: `${prefix}长度不能超过${maxLength}`,
                maxLength: maxLength
            },
            maxLenValidate
        )
    )
    rules.push(
        wrapValidator(
            {
                message: `${prefix}不能包含空格`,
                allowEmptySpace
            },
            noSpaceValidate
        )
    )
    rules.push(
        wrapValidator(
            {
                message: `${prefix}必须为数字，小写字母，下划线的组合`,
                allowChinese: false
            },
            (...rest) =>
                characterValidate(...rest) && noCapitalValidate(...rest)
        )
    )
    rules.push(
        wrapValidator(
            {
                message: `${prefix}不能以下划线开头`
            },
            noUnderScoreHeadValidate
        )
    )
    return rules
}

export const createDescValidator = (opts = {}) => {
    const rules = []
    const { prefix = '描述', maxLength = 200 } = opts
    rules.push(
        wrapValidator(
            {
                message: `${prefix}长度不能超过${maxLength}`,
                maxLength: maxLength
            },
            maxLenValidate
        )
    )
    return rules
}

export const createPasswordValidator = (opts = {}) => {
    const rules = []
    const {
        prefix = '密码',
        maxLength = 30,
        minLength = 6,
        allowEmptySpace = false,
        allowUndefined = false,
        required = false
    } = opts
    if (!allowUndefined) {
        rules.push(
            wrapValidator(
                {
                    message: `${prefix}不能为空`
                },
                emptyValidate
            )
        )
    }
    rules.push(
        wrapValidator(
            {
                message: `${prefix}长度不能超过${maxLength}`,
                maxLength: maxLength
            },
            maxLenValidate
        )
    )
    rules.push(
        wrapValidator(
            {
                message: `${prefix}长度不能短于${minLength}`,
                minLength: minLength
            },
            minLenValidate
        )
    )
    rules.push(
        wrapValidator(
            {
                message: `${prefix}不能包含空格`,
                allowEmptySpace
            },
            noSpaceValidate
        )
    )
    rules.push(
        wrapValidator(
            {
                message: `${prefix}必须是有效的 ascii 码字符`
            },
            asciiValidate
        )
    )
    if(required){
        rules.push({
            required: true
        })
    }
    return rules
}

export const createNameValidator = (opts = {}) => {
    const rules = []
    const {
        prefix = '名字',
        maxLength = 30,
        allowEmptySpace = false,
        allowChinese = true,
        allowUndefined = false,
        whiteList
    } = opts
    if (!allowUndefined) {
        rules.push(
            wrapValidator(
                {
                    message: `${prefix}不能为空`
                },
                emptyValidate
            )
        )
    }
    rules.push(
        wrapValidator(
            {
                message: `${prefix}长度不能超过${maxLength}`,
                maxLength: maxLength
            },
            maxLenValidate
        )
    )
    rules.push(
        wrapValidator(
            {
                message: `${prefix}不能包含空格`,
                allowEmptySpace
            },
            noSpaceValidate
        )
    )
    rules.push(
        wrapValidator(
            {
                message: `${prefix}必须为数字，字母，下划线${
                    allowChinese ? ', 中文字符' : ''
                }${
                    whiteList ? '以及' + Array.from(whiteList).join(' ') : ''
                }的组合`,
                whiteList,
                allowChinese
            },
            characterValidate
        )
    )
    return rules
}

export const createColNameValidator = (opts = {}) => {
    const rules = []
    const {
        prefix = '自定义列名',
        maxLength = 30,
        allowEmptySpace = false,
        allowChinese = false,
        allowUndefined = false,
        whiteList
    } = opts
    if (!allowUndefined) {
        rules.push(
            wrapValidator(
                {
                    message: `${prefix}不能为空`
                },
                emptyValidate
            )
        )
    }
    rules.push(
        wrapValidator(
            {
                message: `${prefix}必须以字母开头`
            },
            startWithAlphabetValidate
        )
    )
    rules.push(
        wrapValidator(
            {
                message: `${prefix}长度不能超过${maxLength}`,
                maxLength: maxLength
            },
            maxLenValidate
        )
    )
    rules.push(
        wrapValidator(
            {
                message: `${prefix}不能包含空格`,
                allowEmptySpace
            },
            noSpaceValidate
        )
    )
    rules.push(
        wrapValidator(
            {
                message: `${prefix}必须为数字，字母，下划线${
                    allowChinese ? ', 中文字符' : ''
                }${
                    whiteList ? '以及' + Array.from(whiteList).join(' ') : ''
                }的组合`,
                whiteList,
                allowChinese
            },
            characterValidate
        )
    )
    return rules
}

export const integerArrayValidator = ({ message }) => {
    return wrapValidator({ message }, isIntegerArray)
}

export const characterValidator = ({ message }) => {
    return wrapValidator({ message }, characterValidate)
}

export const positiveIntegerValidator = ({ message }) => {
    return wrapValidator({ message }, (value, ...rest) => {
        return !value || isPositiveInteger(value, ...rest)
    })
}

export const numberValidator = ({ message }) => {
    return wrapValidator({ message }, (value, ...rest) => {
        return !value || isNumeric(value, ...rest)
    })
}

export const minValidator = ({ message, min, include = true }) => {
    return wrapValidator({ message, min, include }, (value, ...rest) => {
        return !value || minValidate(value, ...rest)
    })
}

export const maxValidator = ({ message, max, include = true }) => {
    return wrapValidator({ message, max, include }, (value, ...rest) => {
        return !value || maxValidate(value, ...rest)
    })
}

export const IntegerValidator = ({ message }) => {
    return wrapValidator({ message }, (value, ...rest) => {
        return !value || isInteger(value, ...rest)
    })
}

export const precisionValidator = ({ message, precision }) => {
    return wrapValidator({ message }, (value, ...rest) => {
        return !value || isConformPrecision(value, precision, ...rest)
    })
}

export const sqlScriptValidator = ({ message }) => {
    return {
        message,
        validator: (rule, value, callback) => {
            if (!value) {
                callback(false)
                return
            }
            const val = value.trim()
            if (
                val.substring(0, 6).toLowerCase() !== 'select' ||
                val.substring(val.length - 1, val.length) === ';'
            ) {
                callback(false)
            } else {
                callback()
            }
        }
    }
}

const numberWithAnomalylValidator = ({
    numberValidate,
    message,
    anomalArr = []
}) => {
    const rules = []
    const hasAnomal = anomalArr.length > 0
    rules.push(
        wrapValidator(
            {
                message: `${message}${
                    hasAnomal ? `或${anomalArr.join('或')}` : ''
                }`
            },
            (value, ...rest) => {
                return (
                    numberValidate(value, ...rest) ||
                    (anomalArr.length > 0 && !!anomalArr.includes(value))
                )
            }
        )
    )
    return rules
}

export const IntegerWithAnomalylValidator = () => {
    return numberWithAnomalylValidator({
        numberValidate: isInteger,
        message: '允许输入整数',
        anomalArr: ['null']
    })
}

export const DoubleWithAnomalylValidator = () => {
    return numberWithAnomalylValidator({
        numberValidate: isNumeric,
        message: '允许输入数值',
        anomalArr: ['null', 'NaN']
    })
}
