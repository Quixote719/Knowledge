/**
 * Created by linhanzi on 2018/7/12.
 */
import React from 'react'
import PropTypes from 'prop-types'

import CodeMirror from 'jad-react-codemirror'
import 'jad-codemirror/lib/codemirror.css'
import 'jad-codemirror/lib/codemirror'
import 'jad-codemirror/mode/sql/sql'
import 'jad-codemirror/addon/hint/show-hint.css'
import 'jad-codemirror/addon/hint/show-hint.js'
import './sql-hint-fixup.js'
import 'jad-codemirror/addon/selection/active-line.js'
import 'jad-codemirror/theme/eclipse.css'
import 'jad-codemirror/theme/blackboard.css'

import './index.less'

import { trim } from '../../../DataAssetComponent/utils'

const OPTS = {
    lineNumbers: false, //显示行号
    extraKeys: { 'Alt-Space': 'autocomplete' }, //按 alt-space激活自动补全功能 (注：官方这里用的是ctrl-space，因为在我们日常输入中这个组合通常用于切换输入法，所以改了一下)
    theme: 'eclipse', //选中的theme
    indentUnit: 4, // 缩进单位为4
    styleActiveLine: true, // 当前行背景高亮
    matchBrackets: true, // 括号匹配
    lineWrapping: true, // 自动换行
    mode: 'text/x-mysql',
    indentWithTabs: true,
    smartIndent: true,
    autofocus: false
}

export default class extends React.Component {
    static propTypes = {
        defaultTable: PropTypes.string, //默认表格名。支持不输入表单名直接搜索字段
        autocompleteWords: PropTypes.object.isRequired, //联想信息
        options: PropTypes.object, //option配置
        defaultSqlValue: PropTypes.string, //sql默认值
        onChangeCallback: PropTypes.func.isRequired, //sql改变回调函数
        enableAutocomp: PropTypes.bool,
        max: PropTypes.number, //最大长度
        disabled: PropTypes.bool //是否禁用
    }
    static defaultProps = {
        defaultSqlValue: '',
        enableAutocomp: true,
        max: 10000000000,
        disabled: false
    }
    constructor(props) {
        super(props)
        this.state = {
            sqlValue: this.props.defaultSqlValue,
            hasBindEvente: false,
            options: {
                ...OPTS,
                ...this.props.options,
                hintOptions: {
                    tables: this.props.autocompleteWords //自定义提示
                }
            }
        }
        this.lastDisabled = false
        this.props.onChangeCallback(this.state.sqlValue)
    }

    // static getDerivedStateFromProps(props, state) {
    //     if (props.autocompleteWords !== state.options.hintOptions.tables) {
    //         const hintOptions = {
    //             tables: props.autocompleteWords,
    //         }
    //         if (props.defaultTable) {
    //             hintOptions.defaultTable = props.defaultTable
    //         }
    //         return {
    //             options: {
    //                 ...OPTS,
    //                 hintOptions,
    //             },
    //         }
    //     }
    //
    //     if (props.defaultSqlValue !== state.sqlValue) {
    //         this.CodeMirrorEditor.setValue(props.defaultSqlValue)
    //         return {
    //             sqlValue: props.defaultSqlValue
    //         }
    //     }
    //
    //     return null
    // }

    componentDidMount() {
        if (this.refs.editor && !this.state.hasBindEvente) {
            this.bindKeyupEvent()
        }
        if (this.refs.editor && this.props.autoFocus) {
            setTimeout(() => {
                /**
                 * 如果不用setTimeout，会导致点击画布上SQL组件时，
                 * 编辑框被focus了，但是却无法输入文字的缺陷
                 * 我猜测这个缺陷和点击画布导致codemirror判断输入框并未focus有关
                 */
                this.refs.editor.focus()
            }, 0)
        }
    }
    componentWillReceiveProps(nextProps) {
        if (nextProps.defaultSqlValue !== this.state.sqlValue) {
            this.setState({ sqlValue: nextProps.defaultSqlValue })
            this.CodeMirrorEditor.setValue(nextProps.defaultSqlValue)
        }

        let newOptions = this.state.options
        // 处理options
        if (nextProps.options !== this.props.options) {
            newOptions = {
                ...this.state.options,
                ...nextProps.options
            }
        }
        // 处理options里的hintOptions
        if (
            nextProps.autocompleteWords !==
            this.state.options.hintOptions.tables
        ) {
            const hintOptions = {
                tables: nextProps.autocompleteWords
            }
            if (nextProps.defaultTable) {
                hintOptions.defaultTable = nextProps.defaultTable
            }
            newOptions = {
                ...newOptions,
                hintOptions
            }
        }

        if (JSON.stringify(newOptions) !== JSON.stringify(this.state.options)) {
            this.setState({
                options: {
                    ...newOptions
                }
            })
        }
    }
    componentDidUpdate() {
        // 判断组件是否禁用状态(未用setState，某些操作时会导致死循环)
        const textareas = document.querySelectorAll('.CodeMirror-wrap textarea')
        if (
            this.props.disabled &&
            this.props.disabled !== this.lastDisabled &&
            textareas &&
            textareas.length > 0
        ) {
            this.lastDisabled = true
            textareas.forEach(ta => {
                ta.setAttribute('disabled', 'disabled')
            })
        } else if (
            !this.props.disabled &&
            this.props.disabled !== this.lastDisabled &&
            textareas &&
            textareas.length > 0
        ) {
            this.lastDisabled = false
            textareas.forEach(ta => {
                ta.removeAttribute('disabled')
            })
        }

        window.editor = this.refs.editor
        const { hasBindEvente } = this.state
        if (this.refs.editor && !hasBindEvente && this.props.enableAutocomp) {
            this.bindKeyupEvent()
        }
        if (this.refs.editor && this.props.autoFocus) {
            setTimeout(() => {
                /**
                 * 如果不用setTimeout，会导致点击画布上SQL组件时，
                 * 编辑框被focus了，但是却无法输入文字的缺陷
                 * 我猜测这个缺陷和点击画布导致codemirror判断输入框并未focus有关
                 */
                // this.refs.editor.focus()
            }, 0)
        }
    }

    // shouldComponentUpdate(nextProps) {
    //     const {disabled} = this.props;
    //     return disabled !== nextProps.disabled
    // }

    //CodeMirror绑定keyup事件，帮助自动提示
    bindKeyupEvent = () => {
        const editor = this.refs.editor.getCodeMirror()
        this.CodeMirrorEditor = editor
        editor.on('keyup', function(cm, event) {
            // 回退操作时，光标在token字符串结尾处，才会出现自动提示
            if (event.keyCode == 8) {
                const { line, ch } = cm.getCursor()
                let tokens = cm.getLineTokens(line)
                tokens = tokens.filter(
                    token =>
                        token.start <= ch &&
                        token.end == ch &&
                        trim(token.string).length > 0
                )
                if (tokens.length <= 0) {
                    return
                }
            }
            //所有的字母和'$','{','.'在键按下之后都将触发自动完成
            if (
                !cm.state.completionActive &&
                ((event.keyCode >= 65 && event.keyCode <= 90) ||
                    event.keyCode == 52 ||
                    event.keyCode == 219 ||
                    event.keyCode == 190)
            ) {
                editor.constructor.commands.autocomplete(cm, null, {
                    completeSingle: false
                })
            }
        })
        this.setState({ hasBindEvente: true })
    }

    //更新sqlValue值
    handleChangeCode = () => {
        if (this.refs.editor) {
            const codeMirror = this.refs.editor.codeMirror
            setTimeout(() => {
                //CodeMirror未提供change回调，故通过延时来获取styles值，用于区分普通代码和注释
                //将注释掉的代码剔除
                const lines = codeMirror.doc.children[0].lines.filter(line => {
                    return !(
                        line.styles &&
                        line.styles.length === 3 &&
                        line.styles[2] === 'comment'
                    )
                })
                const text = lines.map(line => line.text)
                let code = text.join('\n')
                //最大长度
                const max = this.props.max
                if (max && max > 0 && code.length > max) {
                    //改变前获取光标位置
                    var curPosition = this.CodeMirrorEditor.getCursor()

                    code = code.slice(0, max) //截取前MAX个字符
                    this.CodeMirrorEditor.setValue(code)

                    //改变后定位光标位置
                    this.CodeMirrorEditor.setCursor(curPosition)
                }
                //更新
                this.setState({ sqlValue: code })
                // this.props.onChangeCallback(code)
                if (!this.props.onFocusChange) {
                    this.props.onChangeCallback(code)
                }
            }, 400)
        }
    }

    handleFocusChange = focused => {
        this.props.onChangeCallback &&
            this.props.onChangeCallback(this.state.sqlValue)
        this.props.onFocusChange && this.props.onFocusChange(focused)
    }

    render() {
        return (
            <CodeMirror
                ref="editor"
                defaultValue={this.state.sqlValue}
                onChange={this.handleChangeCode.bind(this)}
                onFocusChange={this.handleFocusChange}
                options={this.state.options}
            />
        )
    }
}
