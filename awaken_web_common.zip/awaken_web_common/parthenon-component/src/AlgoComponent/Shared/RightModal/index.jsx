// 右侧滑动页面组件

import React from 'react'
import { Button } from 'antd'
import styles from './index.less'

export default class extends React.Component {
    render() {
        const { children, onOk, onCancel, title, style = {} } = this.props
        return (
            <div className={styles.modalBox} style={style}>
                <div className={styles.modalHead}>
                    <span>{title}</span>
                    <span className={styles.closeItem} onClick={onCancel}>
                        X
                    </span>
                </div>
                <div className={styles.modalBody}>{children}</div>
                <div className={styles.modalFooter}>
                    <Button className={styles.butOK} onClick={onOk}>
                        确定
                    </Button>
                    <Button className={styles.butCancel} onClick={onCancel}>
                        取消
                    </Button>
                </div>
            </div>
        )
    }
}
