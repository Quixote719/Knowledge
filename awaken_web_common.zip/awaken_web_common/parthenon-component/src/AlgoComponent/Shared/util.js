import { isUnderScore, isAlphaNumeric, isAlphabet } from '../validateRules'

const OUTPUT_COL_MAX_LENGTH = 100

export const getDefaultValue = (
    additionalParams,
    paramName,
    selectedRecord
) => {
    for (let i = 0; i < additionalParams.length; i++) {
        let param = additionalParams[i]
        if (param.paramName === paramName) {
            if (typeof param.defaultValue === 'function') {
                return param.defaultValue(selectedRecord)
            } else {
                return param.defaultValue
            }
        }
    }
    return null
}
export const expandSelectedColumnsWithType = (
    selectedColumns,
    allColumns,
    sourceType,
    targetType
) => {
    if (typeof selectedColumns === 'string') {
        let temp = []
        temp.push(selectedColumns)
        selectedColumns = temp
    }
    selectedColumns = selectedColumns || []
    return selectedColumns.map((col, index) => {
        return expandColWithType(col, allColumns, index, sourceType, targetType)
    })
}
export const expandSelectedColumnsWithTypeAndDesc = (
    selectedColumns,
    allColumns,
    sourceType,
    targetType
) => {
    if (typeof selectedColumns === 'string') {
        let temp = []
        temp.push(selectedColumns)
        selectedColumns = temp
    }
    selectedColumns = selectedColumns || []
    return selectedColumns.map((col, index) => {
        return expandColWithTypeAndDesc(
            col,
            allColumns,
            index,
            sourceType,
            targetType
        )
    })
}

const expandColWithType = (
    col,
    allColumns,
    index,
    sourceType = 'name',
    targetType = 'name'
) => {
    if (col.hasOwnProperty('type')) {
        return col
    } else if (typeof col === 'string') {
        return {
            name: col,
            key: index,
            type: findTypeByName(col, allColumns, targetType),
        }
    } else {
        return {
            ...col,
            key: index,
            type: findTypeByName(col[sourceType], allColumns, targetType),
        }
    }
}

const findTypeByName = (name, allColumns, targetType = 'name') => {
    for (let i = 0; i < allColumns.length; i++) {
        if (allColumns[i][targetType] === name) {
            return allColumns[i].type
        }
    }
    return '???'
}

const findPropNameByName = (
    name,
    allColumns,
    targetType = 'name',
    propName
) => {
    for (let i = 0; i < allColumns.length; i++) {
        if (allColumns[i][targetType] === name) {
            return allColumns[i][propName]
        }
    }
    return '未知'
}

const expandColWithTypeAndDesc = (
    col,
    allColumns,
    index,
    sourceType = 'name',
    targetType = 'name'
) => {
    if (col.hasOwnProperty('type') && col.hasOwnProperty('desc')) {
        return col
    } else if (typeof col === 'string') {
        return {
            name: col,
            key: index,
            type: findTypeByName(col, allColumns, targetType),
            desc: findPropNameByName(col, allColumns, targetType, 'desc'),
        }
    } else {
        return {
            ...col,
            key: index,
            type: findTypeByName(col[sourceType], allColumns, targetType),
            desc: findPropNameByName(
                col[sourceType],
                allColumns,
                targetType,
                'desc'
            ),
        }
    }
}

const isColumnValid = (col, allColumns) => {
    let foundMatch = false
    for (let k = 0; k < allColumns.length; k++) {
        const allCol = allColumns[k]
        if (typeof col === 'object' && col.name === allCol.name) {
            foundMatch = true
            break
        } else if (col === allCol.name) {
            foundMatch = true
            break
        }
    }
    return foundMatch
}
/**
 * 判断是否所有selectedColumns里面的都在allColumns里.
 * 如果都在, 则为有效的
 */
export const isSelectedColumnsValid = (selectedColumns = [], allColumns) => {
    if (Array.isArray(selectedColumns)) {
        for (let i = 0; i < selectedColumns.length; i++) {
            const col = selectedColumns[i]
            let foundMatch = isColumnValid(col, allColumns)
            if (!foundMatch) {
                return false
            }
        }
    } else if (typeof selectedColumns === 'string') {
        return isColumnValid(selectedColumns, allColumns)
    }
    return true
}

export const isComplexDropdownColumnsValid = (
    selectedColumns = [],
    input1 = []
) => {
    for (let selectedRow of selectedColumns) {
        let foundMatch = false
        for (let inputRow of input1) {
            if (inputRow.value === selectedRow.input1) {
                foundMatch = true
                break
            }
        }

        if (!foundMatch) {
            return false
        }
    }
    return true
}

/**
 * 移除所有未出现在allColumns里面的字段
 */
export const filterColumnsInAllColumns = (selectedColumns = [], allColumns) => {
    return selectedColumns.filter(col => isColumnValid(col, allColumns))
}

export const addElement = (eleArr, ele, key = 'name') => {
    let hasEle = false
    for (let i = 0; i < eleArr.length; i++) {
        if (eleArr[i][key] === ele[key]) hasEle = true
    }
    if (!hasEle) eleArr.push(ele)
}
export const deleteElement = (eleArr, ele, key = 'name') => {
    let hasEle = -1
    for (let i = 0; i < eleArr.length; i++) {
        if (eleArr[i][key] === ele[key]) hasEle = i
    }
    if (hasEle !== -1) eleArr.splice(hasEle, 1)
}

/**
 * 判断SelectFields与ComplexDropdownSelectModal中的字段是否有效
 */
export const isOutputColumnValid = (props = {}) => {
    const additionalParams = (props && props.additionalParams) || []
    const selectedColumns = (props && props.selectedColumns) || []

    for (let i = 0; i < additionalParams.length; i++) {
        const param = additionalParams[i]
        if (param.isOutputCol) {
            const paramName = param.paramName

            //获得所有输出的名字
            const outputColNames = selectedColumns.map(col => col[paramName])
            const res = isOutputNameArrayValid(outputColNames)
            if (!res.isValid) return res
        }
    }
    return {
        isValid: true,
        errorMessage: null,
    }
}

/**
 * 给定输出字段数组，判断这个数组是否有效
 */
export const isOutputNameArrayValid = (
    outputColNames = [],
    customValidate,
    hintName = '输出'
) => {
    const tempMap = {}
    for (let k = 0; k < outputColNames.length; k++) {
        const name = outputColNames[k]
        if (!name) {
            return {
                isValid: false,
                errorMessage: `第${k + 1}行：${hintName}不能为空`,
            }
        } else if (tempMap.hasOwnProperty(name.toLowerCase())) {
            return {
                isValid: false,
                errorMessage: `第${tempMap[name.toLowerCase()] + 1}行与第${k +
                    1}行重名`,
            }
        } else {
            const validation =
                typeof customValidate === 'function'
                    ? customValidate(name)
                    : isValidOutputName(name)
            if (!validation.isValid) {
                return {
                    isValid: false,
                    errorMessage: `第${k + 1}行：${validation.errorMessage}`,
                }
            } else {
                tempMap[name.toLowerCase()] = k
            }
        }
    }
    return {
        isValid: true,
        errorMessage: null,
    }
}

export const isValidOutputName = name => {
    if (!name || name.length === 0) {
        return {
            isValid: false,
            errorMessage: '输出字段名不能为空',
        }
    }
    if (name.length > OUTPUT_COL_MAX_LENGTH) {
        return {
            isValid: false,
            errorMessage: `字段长度不能超过${OUTPUT_COL_MAX_LENGTH}`,
        }
    }

    const firstCode = name.charCodeAt(0)
    if (!isAlphabet(firstCode)) {
        return {
            isValid: false,
            errorMessage: '字段名必须以字母开头',
        }
    }

    for (let i = 0; i < name.length; i++) {
        let code = name.charCodeAt(i)
        if (!isAlphaNumeric(code) && !isUnderScore(code)) {
            return {
                isValid: false,
                errorMessage: '字段名字必须是数字，字母及下划线的组合',
            }
        }
    }
    return {
        isValid: true,
        errorMessage: null,
    }
}
