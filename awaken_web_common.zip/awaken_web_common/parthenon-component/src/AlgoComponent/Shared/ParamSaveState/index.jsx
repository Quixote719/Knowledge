import React from 'react'
import { Icon } from 'antd'

import styles from './index.less'

export default class ParamSaveState extends React.Component {
    render() {
        const { validateStatus } = this.props
        if (validateStatus === 'validating') {
            return (
                <Icon
                    className={styles.icon + ' ' + styles.loading}
                    type="loading"
                />
            )
        } else if (validateStatus === 'success') {
            return (
                <Icon
                    className={styles.icon + ' ' + styles.success}
                    type="check-circle"
                />
            )
        } else if (validateStatus === 'error') {
            return (
                <Icon
                    className={styles.icon + ' ' + styles.error}
                    type="close-circle"
                />
            )
        } else {
            return null
        }
    }
}
