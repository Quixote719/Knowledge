import React from 'react'
import echarts from 'echarts'

export default class Chart extends React.Component {
    constructor(props) {
        super(props)
        this.echartRef = React.createRef()
    }

    componentDidMount() {
        this.echartInstance = echarts.init(this.echartRef.current)
        this.echartInstance.setOption(this.props)
    }

    componentWillReceiveProps(nextProps) {
        this.echartInstance.setOption(nextProps)
    }

    render() {
        return <div ref={this.echartRef} style={{width: '100%', height: '100%'}}/>
    }
}
