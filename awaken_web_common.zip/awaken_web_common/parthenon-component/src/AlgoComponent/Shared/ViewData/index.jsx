import React from 'react'
import { Button, Tabs } from 'antd'
import PropTypes from 'prop-types'
import DataTable from './DataTable'
import RightStats from './RightStats'
import TableStat from './TableStat'
import Relevance from './Relevance'
import styles from './index.less'

const TabPane = Tabs.TabPane
const defaultActiveKey = '1' // tab默认索引

export default class ViewData extends React.Component {
    static defaultProps = {
        onCancel: () => {},
        isFullWindow: false,
        showTabs: true,
        showRelevance: false,
        downLoadBtnVisible: false
    }

    static propTypes = {
        /**
         * 可选属性
         * 该端口的额外描述信息。若提供，则表格名会显示为 [描述-表格名]
         * 若否，则显示 [表格名]
         * descriptionOfPort的数组index需要和data的数组index一一匹配
         */
        descriptionOfPorts: PropTypes.objectOf(PropTypes.string.isRequired),
        showTabs: PropTypes.bool, // 是否显示tab
        onCancel: PropTypes.func,
        isFullWindow: PropTypes.bool,
        clientHeight: PropTypes.number, // 容器高度，用来在isFullWindow为true时判断列表条数，大于300时生效
        data: PropTypes.objectOf(
            //注意data的key是端口号，必须和descriptionOfPort对应。
            PropTypes.shape({
                /**
                 * 统计信息。数据来源：郝龙伟
                 */
                dataStatistics: PropTypes.shape({
                    /**
                     * tableInfo
                     * {
                     *   "行": 123,
                     *   "列": 4565
                     * }
                     */
                    tableInfo: PropTypes.objectOf(
                        PropTypes.oneOfType([
                            PropTypes.string,
                            PropTypes.number
                        ]).isRequired
                    ),
                    columnInfo: PropTypes.arrayOf(
                        PropTypes.shape({
                            columnName: PropTypes.string.isRequired,
                            columnType: PropTypes.string.isRequired,

                            // singleStatInfo: {
                            //     '最小值': 10,
                            //     '最大值': 100
                            // }
                            singleStatInfo: PropTypes.objectOf(
                                PropTypes.oneOfType([
                                    PropTypes.string,
                                    PropTypes.number
                                ]).isRequired
                            ),
                            // complexStatInfo: {
                            //     hist: {
                            //         '10-100': 30,
                            //         '100-200': 40
                            //     }
                            // }
                            complexStatInfo: PropTypes.shape({
                                hist: PropTypes.objectOf(
                                    PropTypes.oneOfType([
                                        PropTypes.string,
                                        PropTypes.number
                                    ]).isRequired
                                )
                            })
                        })
                    )
                }),
                /**
                 * 表格数据：对应于原查看数据的所有数据
                 */
                tableName: PropTypes.string.isRequired,
                tableTotal: PropTypes.oneOfType([
                    PropTypes.string,
                    PropTypes.number
                ]), // 当前展示的总条数
                columnInfos: PropTypes.arrayOf(
                    PropTypes.shape({
                        columnName: PropTypes.string.isRequired,
                        columnType: PropTypes.string.isRequired
                    })
                ).isRequired,
                rowList: PropTypes.arrayOf(
                    PropTypes.arrayOf(PropTypes.any).isRequired
                ).isRequired,
                updateTime: PropTypes.shape({
                    text: PropTypes.string.isRequired,
                    value: PropTypes.string.isRequired
                })
            })
        ).isRequired,
        showRelevance: PropTypes.bool // 是否展示关联分析功能
    }

    constructor(props) {
        super(props)
        this.state = {
            selected: '__table__',
            tabActiveKey: defaultActiveKey,
            showChartType: false,
            chartType: {}, // histgram or boxPlot
            relevanceState: {
                // [index]: {
                //     relevanceCols: [], //进行关联分析的字段名
                //     visible: false // 展示关联分析内容
                // }
            },
            sampleNum: '', // 关联分析-抽样样本数
            selectedColNames: [] // 关联分析-已选字段名
        }
        this.currentTabIndex = defaultActiveKey; // 当前tab索引, 下载数据表用
    }

    /**
     * 后端返回的统计数据可能不全。
     * 通过此函数可以补全表格的tableInfo中行，列信息。
     * 以及dataStatistic中columnInfo信息
     */
    getStatisticInfo(tableData) {
        const dataStatistics = tableData.dataStatistics || {}
        if (
            dataStatistics.tableInfo === null ||
            typeof dataStatistics.tableInfo !== 'object' ||
            Object.keys(dataStatistics.tableInfo).length === 0
        ) {
            dataStatistics.tableInfo = {
                列: tableData.columnInfos.length
            }
        }

        if (
            !Array.isArray(dataStatistics.columnInfo) ||
            dataStatistics.columnInfo.length === 0
        ) {
            dataStatistics.columnInfo = tableData.columnInfos.slice()
        }
        return dataStatistics
    }

    handleChangeSampleNum = value => {
        if (value !== this.state.sampleNum) {
            this.setState({ sampleNum: value })
        }
    }

    onChangeSelectedCols = selectedCols => {
        this.setState({
            selectedColNames: selectedCols.map(col => col.columnName)
        })
    }

    handleSelectColumn = columnInfo => {
        this.setState({
            selected: columnInfo.columnName
        })
    }

    handleSelectTableStat = () => {
        this.setState({
            selected: '__table__'
        })
    }

    changeChartType = (index, chartType) => {
        if (
            this.state.chartType[index] &&
            chartType === this.state.chartType[index]
        ) {
            return false
        }
        this.setState({
            chartType: { ...this.state.chartType, [index]: chartType }
        })
    }

    onChangeTab = index => {
        this.currentTabIndex = index
        this.setState({ tabActiveKey: index })
    }

    onChangeCheckbox = (e, col, index) => {
        let { relevanceState } = this.state
        let currRelevanceState = relevanceState[index] || {}
        let relevanceCols = currRelevanceState.relevanceCols || []
        if (e.target.checked) {
            relevanceCols.push(col.columnName)
        } else {
            relevanceCols = relevanceCols.filter(
                colName => colName !== col.columnName
            )
        }
        this.setState({
            relevanceState: {
                ...relevanceState,
                [index]: {
                    ...currRelevanceState,
                    relevanceCols
                }
            }
        })
    }
    // 点击“关联分析”
    handleRelevance = index => {
        this.changeRelevanceVisible(index, true)
    }

    hangleGoBack = index => {
        this.changeRelevanceVisible(index, false)
    }

    changeRelevanceVisible = (index, visible) => {
        let { relevanceState } = this.state
        let currRelevanceState = relevanceState[index] || {}
        this.setState({
            relevanceState: {
                ...relevanceState,
                [index]: {
                    ...currRelevanceState,
                    visible
                }
            }
        })
    }

    /**
     * 下载数据
     */
    downLoad = () => {
        const {data, showTabs, onDownLoad} = this.props
        if(onDownLoad){
            const index = Number(this.currentTabIndex) - 1
            let params = {tabIndex: index}
            if(showTabs){
                params.tableKey = Object.keys(data)[index]
                params.tableData = data[params.tableKey]
            }else{
                params.tableData = data[index]
            }
            this.props.onDownLoad(params)
        }
    }

    renderTabs = () => {
        const tabPanes = []
        const data = this.props.data

        if (this.props.showTabs) {
            const descriptionOfPorts = this.props.descriptionOfPorts || {}
            let index = 0
            for (let key in data) {
                index++
                const description = descriptionOfPorts[key] || ''
                const tableName = data[key].tableName
                let tabName = description
                    ? `${description}-${tableName}`
                    : tableName

                tabPanes.push(
                    <TabPane tab={tabName} key={index}>
                        {this.renderOneTab(data[key], index)}
                    </TabPane>
                )
            }
            return (
                <div className={styles.tabPaneWrap}>
                    {this.renderChartType()}
                    <Tabs
                        defaultActiveKey={defaultActiveKey}
                        onChange={this.onChangeTab}>
                        {tabPanes}
                    </Tabs>
                </div>
            )
        } else {
            const activeKey = Number(defaultActiveKey)
            return (
                <div className={styles.tabPaneWrap}>
                    {this.renderChartType()}
                    {/*添加两层 div，添加 flex 样式和 width，避免不显示tab时造成的样式错乱*/}
                    <div
                        style={{
                            display: 'flex'
                            // , marginTop: '40px'
                        }}>
                        <div style={{ width: '100%' }}>
                            {this.renderOneTab(data[activeKey - 1], activeKey)}
                        </div>
                    </div>
                </div>
            )
        }
    }

    renderRelevance = (_tableData, tabIndex) => {
        const chartType = this.state.chartType[tabIndex]
        const { relevanceState } = this.state
        const currRelevanceState = relevanceState[tabIndex] || {}
        const relevanceCols = currRelevanceState.relevanceCols || []
        return (
            <div className={styles.tabContainer}>
                <Relevance
                    relevanceCols={relevanceCols}
                    tableData={_tableData}
                    chartType={chartType}
                    hangleGoBack={() => this.hangleGoBack(tabIndex)}
                    sampleNum={this.state.sampleNum}
                    handleChangeSampleNum={this.handleChangeSampleNum}
                    selectedColNames={this.state.selectedColNames}
                    onChangeSelectedCols={this.onChangeSelectedCols}
                />
            </div>
        )
    }

    renderStatistics = (_tableData, tabIndex) => {
        const chartType = this.state.chartType[tabIndex] || 'histgram'

        let relevanceCols = []
        if (
            this.state.relevanceState[tabIndex] &&
            this.state.relevanceState[tabIndex].relevanceCols
        ) {
            relevanceCols = this.state.relevanceState[tabIndex].relevanceCols
        }
        return (
            <div className={styles.tabContainer}>
                <div className={styles.tabLeft}>
                    <div className={styles.titleStat}>
                        {this.props.showRelevance && (
                            <Button
                                type="primary"
                                className={styles.relevance}
                                disabled={relevanceCols.length <= 0}
                                onClick={this.handleRelevance.bind(
                                    this,
                                    tabIndex
                                )}>
                                关联分析
                            </Button>
                        )}
                        <TableStat
                            tableData={_tableData}
                            selected={this.state.selected}
                            statisticInfo={this.getStatisticInfo(_tableData)}
                            onClick={this.handleSelectTableStat}
                        />
                    </div>
                    <DataTable
                        selected={this.state.selected}
                        tableData={_tableData}
                        chartType={chartType}
                        onSelectColumn={this.handleSelectColumn}
                        isFullWindow={this.props.isFullWindow}
                        // hasTabs={!!this.props.descriptionOfPorts}
                        // clientHeight={!this.props.showTabs ? this.props.clientHeight + 80 : this.props.clientHeight}
                        clientHeight={this.props.clientHeight}
                        renderChartType={this.showChartType}
                        relevanceCols={relevanceCols}
                        onChangeCheckbox={(e, col) =>
                            this.onChangeCheckbox(e, col, tabIndex)
                        }
                    />
                </div>
                <div className={styles.tabRight}>
                    <RightStats
                        tableData={_tableData}
                        statisticInfo={this.getStatisticInfo(_tableData)}
                        selected={this.state.selected}
                        chartType={chartType}
                    />
                </div>
            </div>
        )
    }

    renderOneTab = (_tableData, tabIndex) => {
        this.tabIndex = tabIndex
        if (
            this.state.relevanceState[tabIndex] &&
            this.state.relevanceState[tabIndex].visible
        ) {
            return this.renderRelevance(_tableData, tabIndex)
        } else {
            return this.renderStatistics(_tableData, tabIndex)
        }
    }

    renderEmpty = () => {
        return <div className={styles.empty}>暂无数据</div>
    }

    renderHeader = () => {
        const { data, additionIcon, isFullWindow, downLoadBtnVisible } = this.props
        const dataLength = Object.keys(data || {}).length

        if (isFullWindow && downLoadBtnVisible){
            return (
                <div className={styles.header}>
                    <Button
                        type="primary"
                        className={styles.downLoad}
                        onClick={this.downLoad}
                        disabled={dataLength.length <= 0}
                    >
                        下载数据
                    </Button>
                </div>
            )
        }

        return (
            <div className={styles.header}>
                {
                    !isFullWindow &&
                    <div className={styles.delete} onClick={this.props.onCancel} />
                }

                {additionIcon}
            </div>
        )
    }

    showChartType = (hasHistgram, hasNumericType) => {
        if (hasHistgram && hasNumericType) {
            this.setState({ showChartType: true })
        }
    }
    renderBarchartIcon = () => {
        return (
            <svg
                viewBox="64 64 896 896"
                className=""
                data-icon="bar-chart"
                width="1em"
                height="1em"
                fill="currentColor"
                aria-hidden="true"
                focusable="false">
                <path
                    d="M888 792H200V168c0-4.4-3.6-8-8-8h-56c-4.4 0-8 3.6-8 8v688c0 4.4 3.6 8 8 8h752c4.4
                0 8-3.6 8-8v-56c0-4.4-3.6-8-8-8zm-600-80h56c4.4 0 8-3.6 8-8V560c0-4.4-3.6-8-8-8h-56c-4.4 0-8
                3.6-8 8v144c0 4.4 3.6 8 8 8zm152 0h56c4.4 0 8-3.6 8-8V384c0-4.4-3.6-8-8-8h-56c-4.4 0-8 3.6-8
                8v320c0 4.4 3.6 8 8 8zm152 0h56c4.4 0 8-3.6 8-8V462c0-4.4-3.6-8-8-8h-56c-4.4 0-8 3.6-8 8v242c0
                4.4 3.6 8 8 8zm152 0h56c4.4 0 8-3.6 8-8V304c0-4.4-3.6-8-8-8h-56c-4.4 0-8 3.6-8 8v400c0 4.4 3.6 8 8 8z"
                />
            </svg>
        )
    }
    renderBoxplotIcon = () => {
        return (
            <svg
                viewBox="64 64 896 896"
                className=""
                data-icon="box-plot"
                width="1em"
                height="1em"
                fill="currentColor"
                aria-hidden="true"
                focusable="false">
                <path
                    d="M952 224h-52c-4.4 0-8 3.6-8 8v248h-92V304c0-4.4-3.6-8-8-8H232c-4.4 0-8 3.6-8
                8v176h-92V232c0-4.4-3.6-8-8-8H72c-4.4 0-8 3.6-8 8v560c0 4.4 3.6 8 8 8h52c4.4 0 8-3.6
                8-8V548h92v172c0 4.4 3.6 8 8 8h560c4.4 0 8-3.6 8-8V548h92v244c0 4.4 3.6 8 8 8h52c4.4 0
                8-3.6 8-8V232c0-4.4-3.6-8-8-8zM296 368h88v288h-88V368zm432 288H448V368h280v288z"
                />
            </svg>
        )
    }
    renderChartType = () => {
        const index = this.state.tabActiveKey
        const chartType = this.state.chartType[index] || 'histgram'

        let boxPlotProps = {}
        if (this.state.showChartType) {
            boxPlotProps.onClick = this.changeChartType.bind(
                this,
                index,
                'boxPlot'
            )
        }
        return (
            <div className={styles.chartType} key={index}>
                <a
                    title="直方图"
                    className={chartType === 'histgram' ? styles.cur : ''}
                    onClick={this.changeChartType.bind(
                        this,
                        index,
                        'histgram'
                    )}>
                    {this.renderBarchartIcon()}
                </a>
                <a
                    title="箱线图"
                    className={`${
                        !this.state.showChartType ? [styles.disabled] : ''
                    } ${chartType === 'boxPlot' ? [styles.cur] : ''}`}
                    {...boxPlotProps}>
                    {this.renderBoxplotIcon()}
                </a>
            </div>
        )
    }

    render() {
        const {
            isFullWindow,
            className,
            data,
            style,
            onCancel,
            clientHeight
        } = this.props
        const dataLength = Object.keys(data || {}).length
        const propsClassName = className || ''
        const propsStyle = { ...style } || {}
        const width = isFullWindow
            ? window.innerWidth
            : Math.min(window.innerWidth, 1650)

        if (isFullWindow) {
            propsStyle.width = width
            propsStyle.maxHeight = clientHeight ? clientHeight : '100%'
        } else if (!propsStyle.maxWidth) {
            propsStyle.maxWidth = width
            propsStyle.minWidth = 1200
            propsStyle.maxHeight = 850
        }
        return (
            <div
                className={styles.compModal + ' ' + propsClassName}
                style={propsStyle}>
                {this.renderHeader()}
                {dataLength === 0 && this.renderEmpty()}
                {dataLength >= 1 && this.renderTabs()}
                {!isFullWindow && (
                    <Button
                        key="back"
                        onClick={onCancel}
                        className={styles.cancel}>
                        关闭
                    </Button>
                )}
            </div>
        )
    }
}
