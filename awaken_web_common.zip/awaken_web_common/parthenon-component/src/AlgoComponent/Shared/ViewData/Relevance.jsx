import React from 'react'
import { Button, Select, Table, Icon } from 'antd'
import LongText from './LongText'
import ColumnHistgram from './ColumnHistgram'
import ColumnBoxPlot from './ColumnBoxPlot'
import { isNumericType } from './../../typeHelper'
import styles from './Relevance.less'

const { Option } = Select

const options = [
    { label: '1000', value: '1000' },
    { label: '5000', value: '5000' },
    { label: '10000', value: '10000' },
    { label: '20000', value: '20000' },
]

/**
 * 关联分析
 */
export default class Relevance extends React.Component {
    constructor(props) {
        super(props)
    }

    handleDrawChart = () => {
        //const { sampleNum, selectedColNames } = this.props
    }

    renderColName = col => {
        return (
            <div>
                <div>
                    <LongText text={col.columnName} />
                </div>
                <div>
                    <LongText text={`(${col.columnType})`} />
                </div>
            </div>
        )
    }

    renderColChart = col => {
        return this.props.chartType === 'boxPlot' &&
            isNumericType(col.columnType)
            ? this.renderColBoxPlot(col)
            : this.renderColHistgram(col)
    }

    renderColBoxPlot = col => {
        if (!this.props.tableData || !this.props.tableData.dataStatistics) {
            return null
        }
        return (
            <ColumnBoxPlot
                columnName={col.columnName}
                statisticInfo={this.props.tableData.dataStatistics}
                type="thumbnail"
            />
        )
    }

    renderColHistgram = col => {
        if (!this.props.tableData || !this.props.tableData.dataStatistics) {
            return null
        }
        return (
            <ColumnHistgram
                columnName={col.columnName}
                statisticInfo={this.props.tableData.dataStatistics}
                type="thumbnail"
            />
        )
    }

    render() {
        const tableData = this.props.tableData || {}
        if (
            !Array.isArray(tableData.rowList) ||
            !Array.isArray(tableData.columnInfos)
        ) {
            return <div>数据异常</div>
        }

        const dataSource = tableData.columnInfos
            .filter(entry =>
                this.props.relevanceCols.includes(entry.columnName)
            )
            .map((entry, index) => {
                return {
                    key: index,
                    ...entry,
                }
            })

        let columns = [
            {
                title: 'name',
                dataIndex: 'name',
                render: (text, record) => this.renderColName(record),
            },
        ]
        if (this.props.tableData && this.props.tableData.dataStatistics) {
            columns.push({
                title: 'chart',
                dataIndex: 'chart',
                render: (text, record) => {
                    return (
                        <div style={{ height: '80px', width: '80px' }}>
                            {this.renderColChart(record)}
                        </div>
                    )
                },
            })
        }

        return (
            <div>
                <div className={styles.sider}>
                    <div className={styles.buttonWrap}>
                        <Button
                            type="primary"
                            title="返回"
                            onClick={this.props.hangleGoBack}
                        >
                            <Icon type="left" />
                        </Button>
                        <Button type="primary" onClick={this.handleDrawChart}>
                            关联分析
                        </Button>
                    </div>
                    <div className={styles.selectWrap}>
                        <Select
                            placeholder="抽样样本数"
                            value={this.props.sampleNum || options[0].value}
                            style={{ width: '100%' }}
                            onChange={this.props.handleChangeSampleNum}
                        >
                            {options.map(opt => (
                                <Option value={opt.value}>{opt.label}</Option>
                            ))}
                        </Select>
                    </div>
                    <Table
                        scroll={{ y: 600 }}
                        showHeader={false}
                        rowSelection={{
                            selectedRowKeys: (() => {
                                let keys = []
                                dataSource.forEach((col, index) => {
                                    if (
                                        this.props.selectedColNames.includes(
                                            col.columnName
                                        )
                                    ) {
                                        keys.push(index)
                                    }
                                })
                                return keys
                            })(),
                            onChange: (selectedRowKeys, selectedRows) =>
                                this.props.onChangeSelectedCols(selectedRows),
                            getCheckboxProps: record => ({
                                name: record.name,
                            }),
                        }}
                        dataSource={dataSource}
                        columns={columns}
                        pagination={false}
                    />
                </div>
                <div className={styles.chart}>
                    {this.props.selectedColNames.map(columnName => columnName)}
                </div>
            </div>
        )
    }
}
