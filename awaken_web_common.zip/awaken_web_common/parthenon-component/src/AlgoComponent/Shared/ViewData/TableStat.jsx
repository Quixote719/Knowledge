import React from 'react'
import ColumnTypePieChart from './ColumnTypePieChart'
import styles from './TableStat.less'

export default class TableStat extends React.Component {
    isSelected() {
        return this.props.selected === '__table__'
    }
    render() {
        const { statisticInfo, tableData } = this.props
        const tableInfo = statisticInfo.tableInfo

        const content = []
        for (let key in tableInfo) {
            content.push(
                <span key={key} className={styles.tableAttribute}>
                    {key} : {tableInfo[key]}
                </span>
            )
        }
        let className = styles.tableAttributeContainer
        if (this.isSelected()) {
            className += ' ' + styles.selected
        }

        return (
            <div>
                <div className={className} onClick={this.props.onClick}>
                    {content}
                    <span style={{ verticalAlign: 'top' }}>数据类型分布：</span>
                    <span
                        style={{
                            display: 'inline-block',
                            width: 40,
                            height: 40
                        }}>
                        <ColumnTypePieChart
                            columnInfo={tableData.columnInfos}
                            type="thumbnail"
                        />
                    </span>
                </div>
                {tableData.updateTime &&
                Object.keys(tableData.updateTime).length > 0 ? (
                    <div className={styles.tableUpdateTime}>
                        {tableData.updateTime['text']}:{' '}
                        {tableData.updateTime['value']}
                    </div>
                ) : (
                    ''
                )}
            </div>
        )
    }
}
