import React from 'react'
import Chart from './Chart'
import { isNumericType } from './../../typeHelper'

const MIN_BAR = 10

export default class ColumnHistgram extends React.Component {
    static defaultProps = {
        sortDirection: 'desc',
        sorted: false
    }

    getColumnInfo() {
        const { columnName, statisticInfo = {} } = this.props
        if (Array.isArray(statisticInfo.columnInfo)) {
            for (let i = 0; i < statisticInfo.columnInfo.length; i++) {
                if (statisticInfo.columnInfo[i].columnName === columnName) {
                    return statisticInfo.columnInfo[i]
                }
            }
        }
        return null
    }

    getSortedData() {
        const { sortDirection } = this.props
        const res = this.getUnsortedData()

        res.sort(function(a, b) {
            if (
                a.value > b.value &&
                (sortDirection === 'desc' || !sortDirection)
            ) {
                return -1
            } else if (a.value > b.value && sortDirection === 'asc') {
                return 1
            } else if (
                a.value < b.value &&
                (sortDirection === 'desc' || !sortDirection)
            ) {
                return 1
            } else if (a.value < b.value && sortDirection === 'asc') {
                return -1
            } else {
                return 0
            }
        })
        return res
    }

    getUnsortedData() {
        const hist = this.columnInfo.complexStatInfo.hist || {}
        const res = []
        for (let key in hist) {
            res.push({
                key,
                value: parseInt(hist[key])
            })
        }
        return res
    }

    getData() {
        const { sorted } = this.props
        return sorted ? this.getSortedData() : this.getUnsortedData()
    }

    getXdata() {
        const sortedData = this.getData()
        const res = sortedData.map(data => data.key)
        const arrLen = res.length

        try {
            const { columnName, statisticInfo } = this.props
            const { columns } = statisticInfo
            const isNumericalColumn = isNumericType(
                columns.find(c => c.name === columnName).dataType
            )

            const minBar = isNumericalColumn ? MIN_BAR : arrLen

            //保证至少有MIN_BAR个柱子。后面的柱子长度为0
            for (let i = 0; i < minBar - arrLen; i++) {
                res.push('')
            }
        } catch (e) {
            console.log(e)
        }
        return res
    }

    getYdata() {
        const sortedData = this.getData()
        const res = sortedData.map(data => data.value)
        const arrLen = res.length

        for (let i = 0; i < MIN_BAR - arrLen; i++) {
            res.push(0)
        }
        return res
    }

    getThumbProps() {
        return {
            series: [
                {
                    data: this.getYdata(),
                    type: 'bar',
                    barWidth: '80%',
                    barCategoryGap: '0%',
                    itemStyle: {
                        color: '#188df0'
                    },
                    slient: true
                }
            ],
            xAxis: {
                show: false,
                boundaryGap: false,
                data: this.getXdata()
            },
            yAxis: {
                show: false
            }
        }
    }

    getDetailedProps() {
        return {
            tooltip: {
                trigger: 'item'
            },
            series: [
                {
                    data: this.getYdata(),
                    type: 'bar',
                    barWidth: '80%',
                    barCategoryGap: '0%',
                    itemStyle: {
                        color: '#188df0'
                    },
                    label: {
                        show: true,
                        position: 'top',
                        formatter: '{c}',
                        color: '#000',
                        fontSize: 10
                    },
                    tooltip: {
                        formatter: '{b}: {c}'
                    }
                }
            ],
            xAxis: {
                data: this.getXdata(),
                axisTick: {
                    alignWithLabel: true
                },
                axisLabel: {
                    interval: 0,
                    rotate: 45,
                    fontSize: 10,
                    formatter: name => {
                        if (name.length > 9) {
                            name = name.slice(0, 7) + '..'
                        }
                        return name
                    }
                }
            },
            yAxis: {
                axisLabel: {
                    fontSize: 10,
                    margin: 3
                },
                splitLine: {
                    show: false
                },
                axisTick: {
                    show: false
                }
            }
        }
    }

    render() {
        this.columnInfo = this.getColumnInfo()
        if (
            !this.columnInfo ||
            !this.columnInfo.complexStatInfo ||
            !this.columnInfo.complexStatInfo.hist
        ) {
            return null
        }

        let chartProps = {}
        if (this.props.type === 'thumbnail') {
            chartProps = this.getThumbProps()
        } else if (this.props.type === 'detailChart') {
            chartProps = this.getDetailedProps()
        }

        return <Chart {...chartProps} />
    }
}
