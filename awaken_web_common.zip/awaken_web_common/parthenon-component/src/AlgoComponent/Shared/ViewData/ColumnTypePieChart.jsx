import React from 'react'
import Chart from './Chart'

/**
 * 使用tableData.columnInfos里面的数据。statisticInfo里面的columnInfo数据可能有缺失，因此不适合做表统计的数据
 */
export default class ColumnTypePieChart extends React.Component {
    getLegendData() {
        const { columnInfo } = this.props
        /**
         * typeCount:
         * {int: 1, string: 2}
         */
        const types = []
        if (Array.isArray(columnInfo)) {
            columnInfo.forEach(colInfo => {
                if (!types.includes(colInfo.columnType)) {
                    types.push(colInfo.columnType)
                }
            })
        }

        return types
    }

    getSeriesData() {
        const { columnInfo } = this.props
        /**
         * typeCount:
         * {int: 1, string: 2}
         */
        const typeCount = {}

        if (Array.isArray(columnInfo)) {
            columnInfo.forEach(colInfo => {
                if (!typeCount.hasOwnProperty(colInfo.columnType)) {
                    typeCount[colInfo.columnType] = 0
                }
                typeCount[colInfo.columnType]++
            })
        }

        const seriesData = []
        for (let type in typeCount) {
            seriesData.push({
                name: type,
                value: typeCount[type],
            })
        }

        return seriesData
    }

    getThumbProps() {
        const seriesData = this.getSeriesData()
        return {
            series: {
                type: 'pie',
                radius: '50%',
                center: ['50%', '50%'],
                data: seriesData,
                itemStyle: {
                    borderWidth: seriesData.length > 1 ? 1 : 0,
                    borderColor: '#fff',
                },
                hoverOffset: 0,
                labelLine: {
                    normal: {
                        show: false,
                    },
                },
                label: {
                    normal: {
                        show: false,
                    },
                },
                slient: true,
            },
            tooltip: {
                trigger: 'none',
            },
        }
    }

    getDetailedProps() {
        const seriesData = this.getSeriesData()
        return {
            series: {
                type: 'pie',
                radius: '50%',
                center: ['50%', '30%'],
                data: seriesData,
                itemStyle: {
                    borderWidth: seriesData.length > 1 ? 5 : 0,
                    borderColor: '#fff',
                },
                label: {
                    position: 'inside',
                    formatter: '{c}',
                },
                tooltip: {
                    formatter: '{b}: {c}',
                },
            },
            legend: {
                type: 'plain',
                data: this.getLegendData(),
                orient: 'horizontal',
                left: 'center',
                bottom: 40,
            },
            tooltip: {
                trigger: 'item',
            },
        }
    }

    render() {
        let chartProps = {}
        if (this.props.type === 'thumbnail') {
            chartProps = this.getThumbProps()
        } else if (this.props.type === 'detailChart') {
            chartProps = this.getDetailedProps()
        }

        return <Chart {...chartProps} />
    }
}
