import React from 'react'
import { Popover } from 'antd'

/**
 * 渲染较长的文字。
 */
export default class LongText extends React.Component {
    renderSuperLongText = () => {
        let { text } = this.props
        //let { text, maxDisplayLength = 2000 } = this.props
        text = (text || '').toString()

        // text =
        //     text.length > maxDisplayLength
        //         ? `${(text || '').slice(0, maxDisplayLength - 4)}... `
        //         : `${text}`
        return (
            <span
                style={{
                    maxWidth: '500px',
                    maxHeight: '500px',
                    overflowY: 'auto',
                    display: 'inline-block',
                    wordBreak: 'break-all'
                }}>
                {text}
            </span>
        )
    }

    render() {
        let { text, maxWidth = 300 } = this.props
        return (
            <Popover content={this.renderSuperLongText(text)}>
                <span
                    style={{
                        whiteSpace: 'nowrap',
                        textOverflow: 'ellipsis',
                        maxWidth,
                        display: 'inline-block',
                        overflowX: 'hidden',
                        verticalAlign: 'bottom'
                    }}>
                    {text || ''}
                </span>
            </Popover>
        )
    }
}
