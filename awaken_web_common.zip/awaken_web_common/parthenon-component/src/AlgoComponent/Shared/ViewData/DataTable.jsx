import React from 'react'
import PropTypes from 'prop-types'
import ColumnHistgram from './ColumnHistgram'
import ColumnBoxPlot from './ColumnBoxPlot'
import LongText from './LongText'
import styles from './DataTable.less'
import { isNumericType } from './../../typeHelper'
import { Checkbox, Table } from 'antd'

const compareNumbers = (a, b) => {
    return a - b
}
const compareNormal = (a, b) => {
    // var nameA = a.name.toUpperCase(); // ignore upper and lowercase
    // var nameB = b.name.toUpperCase(); // ignore upper and lowercase
    if (a < b) {
        return -1
    }
    if (a > b) {
        return 1
    }
    return 0
}

export default class DataTable extends React.Component {
    static defaultProps = {
        showRelevance: false,
        relevanceCols: [],
        onChangeCheckbox: () => {}
    }

    static propTypes = {
        showRelevance: PropTypes.bool, // 是否展示关联分析功能
        relevanceCols: PropTypes.array, // 需要进行关联分析的字段
        onChangeCheckbox: PropTypes.func, // 关联分析字段勾选回调
        clientHeight: PropTypes.number // 视窗高度
    }

    constructor(props) {
        super(props)

        const pageSize = this.getPageSize()
        this.state = {
            pageSize: pageSize
        }
        this.hasHistgram = false
        this.hasNumericType = false
    }
    // pageSize 计算公式
    pageSizeFormula = height => {
        if (height > 300) {
            return Math.floor((height - 250) / 39)
        }
        return 10
    }
    // 获得pageSize
    getPageSize = () => {
        let pageSize = 10
        // 若同时存在全屏isFullWindow 和 视窗高度clientHeight，首先用clientHeight
        if (this.props.clientHeight) {
            pageSize = this.pageSizeFormula(this.props.clientHeight)
        } else if (this.props.isFullWindow) {
            pageSize = this.pageSizeFormula(window.innerHeight)
        }
        return pageSize
    }

    componentWillReceiveProps(nextProps) {
        if (
            nextProps.clientHeight &&
            nextProps.clientHeight !== this.props.clientHeight
        ) {
            this.updatePageSize()
        }
    }

    componentDidMount() {
        if (this.props.isFullWindow) {
            window.addEventListener('resize', this.updatePageSize)
        }
        this.props.renderChartType(this.hasHistgram, this.hasNumericType)
    }

    componentWillUnmount() {
        if (this.props.isFullWindow) {
            window.removeEventListener('resize', this.updatePageSize)
        }
    }

    componentDidUpdate() {
        /**
         * 找到selectedTitle的父元素，并添加上边框，即选中列的列标题的上边框
         */
        let selectedTitle = document.getElementsByClassName('selectedTitle')
        if (selectedTitle.length === 1) {
            const titleContainer = selectedTitle[0].parentNode.parentNode
            titleContainer.className =
                titleContainer.className + ' ' + styles.selectedTitle
        }
    }

    updatePageSize = () => {
        const pageSize = this.getPageSize()
        if (pageSize !== this.state.pageSize) {
            this.setState({
                pageSize
            })
        }
    }

    shouldRenderTwoLine = () => {
        return true
    }

    shouldRenderHistThumb = () => {
        const { tableData } = this.props
        if (
            tableData.dataStatistics &&
            Array.isArray(tableData.dataStatistics.columnInfo)
        ) {
            for (let col of tableData.dataStatistics.columnInfo) {
                if (col.complexStatInfo && col.complexStatInfo.hist) {
                    return true
                }
            }
        }
        return false
    }

    handleClickCol = col => {
        if (this.isColClickable(col)) {
            return this.props.onSelectColumn(col)
        }
    }

    isColSelected = col => {
        const { selected } = this.props
        return col.columnName === selected
    }

    /**
     * 判断是否存在该列的统计信息
     */
    isColClickable = col => {
        const { tableData } = this.props
        if (
            tableData.dataStatistics &&
            Array.isArray(tableData.dataStatistics.columnInfo)
        ) {
            let colInfo = null
            for (let statCol of tableData.dataStatistics.columnInfo) {
                if (statCol.columnName === col.columnName) {
                    colInfo = statCol
                    break
                }
            }

            if (!colInfo) return false
            if (
                colInfo.hasOwnProperty('singleStatInfo') &&
                Object.keys(colInfo.singleStatInfo).length > 0
            ) {
                return true
            }
            if (
                colInfo.hasOwnProperty('complexStatInfo') &&
                Object.keys(colInfo.complexStatInfo.hist) > 0
            ) {
                return true
            }
        }
        return false
    }

    renderChart = col => {
        if (isNumericType(col.columnType)) {
            this.hasNumericType = true
        }
        return this.props.chartType === 'boxPlot' &&
            isNumericType(col.columnType)
            ? this.renderColBoxPlot(col)
            : this.renderColHistgram(col)
    }

    renderColBoxPlot = col => {
        if (!this.props.tableData || !this.props.tableData.dataStatistics) {
            return null
        }
        return (
            <ColumnBoxPlot
                columnName={col.columnName}
                statisticInfo={this.props.tableData.dataStatistics}
                type="thumbnail"
            />
        )
    }

    renderColHistgram = col => {
        if (!this.props.tableData || !this.props.tableData.dataStatistics) {
            return null
        }
        this.hasHistgram = true
        return (
            <ColumnHistgram
                columnName={col.columnName}
                statisticInfo={this.props.tableData.dataStatistics}
                type="thumbnail"
            />
        )
    }

    renderColTitle = (col, index) => {
        //echarts渲染柱状图小于60px高度时会有问题
        let className = styles.title
        if (this.isColClickable(col)) {
            className += ' ' + styles.selectable
        }
        if (this.isColSelected(col)) {
            className += ' selectedTitle'
        }
        return (
            <div
                key={index}
                className={className}
                onClick={() => this.handleClickCol(col)}>
                {this.drawTwoLine ? (
                    <div>
                        <div>
                            {this.renderCheckbox(col)}
                            <LongText text={col.columnName} />
                        </div>
                        <div>
                            <LongText text={`(${col.columnType})`} />
                        </div>
                        <div>
                            <LongText
                                text={`${col.columnDesc ? col.columnDesc : ''}`}
                            />
                        </div>
                    </div>
                ) : (
                    <div>
                        {this.renderCheckbox(col)}
                        {col.columnName} ({col.columnType})
                    </div>
                )}

                {this.drawHistThumb && (
                    <div
                        style={{
                            width: 60,
                            height: 30,
                            top: -3,
                            left: -4,
                            position: 'relative'
                        }}>
                        <div
                            style={{
                                position: 'absolute',
                                width: 160,
                                height: 80,
                                transform: 'scale(0.5, 0.5)',
                                transformOrigin: '0 0'
                            }}>
                            {this.renderChart(col)}
                        </div>
                    </div>
                )}
            </div>
        )
    }

    renderCheckbox = col => {
        if (!this.props.showRelevance) {
            return null
        }
        return (
            <Checkbox
                checked={
                    !!this.props.relevanceCols.find(
                        colName => colName === col.columnName
                    )
                }
                onChange={e => {
                    this.props.onChangeCheckbox(e, col)
                }}
            />
        )
    }

    compare = (textA, textB, type) => {
        const a = textA === false ? '' : textA // 空值时，antd返回的是false，为方便对比，把false转成空值
        const b = textB === false ? '' : textB

        return isNumericType(type) ? compareNumbers(a, b) : compareNormal(a, b)
    }

    render() {
        const tableData = this.props.tableData || {}
        const { tableTotal } = tableData

        if (
            !Array.isArray(tableData.rowList) ||
            !Array.isArray(tableData.columnInfos)
        ) {
            return <div>数据异常</div>
        }
        const dataSource = tableData.rowList.map((entry, index) => {
            let res = { key: index }
            entry.forEach((record, index) => {
                res[index] =
                    record !== undefined && record !== null && record.toString()
            })
            return res
        })

        this.drawTwoLine = this.shouldRenderTwoLine()
        this.drawHistThumb = this.shouldRenderHistThumb()
        const needMaxWidth = tableData.columnInfos.length > 1

        const columns = tableData.columnInfos.map((entry, index) => {
            const selected = this.isColSelected(entry)
            const selectable = this.isColClickable(entry)

            let renderFn
            if (selectable) {
                renderFn = text => (
                    <div
                        className={
                            styles.recordCell + ' ' + styles.selectableRecord
                        }
                        onClick={() => this.handleClickCol(entry)}>
                        <LongText
                            text={text}
                            maxWidth={!needMaxWidth ? 750 : 300}
                        />
                    </div>
                )
            } else {
                renderFn = text => (
                    <div className={styles.recordCell}>
                        <LongText
                            text={text}
                            maxWidth={!needMaxWidth ? 750 : 300}
                        />
                    </div>
                )
            }
            const columnObj = {
                title: this.renderColTitle(entry, index),
                dataIndex: index,
                key: index,
                width: 120,
                sorter: (a, b) =>
                    this.compare(a[index], b[index], entry.columnType),
                render: renderFn
            }
            if (selected) {
                columnObj.className = styles.selectedCol
            }

            return columnObj
        })
        return (
            <div
                className={
                    dataSource.length === 0
                        ? styles.emptyTable
                        : styles.fullTable
                }>
                <Table
                    dataSource={dataSource}
                    columns={columns}
                    bordered={false}
                    pagination={{
                        pageSize: this.state.pageSize || 10,
                        showQuickJumper: true,
                        showTotal: total =>
                            `当前展示${tableTotal ? tableTotal : total}条`
                    }}
                    scroll={{
                        x: 'max-content'
                    }}
                />
            </div>
        )
    }
}
