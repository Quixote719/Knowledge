import React from 'react'
import { Radio } from 'antd'
import ColumnTypePieChart from './ColumnTypePieChart'
import ColumnHistgram from './ColumnHistgram'
import ColumnBoxPlot from './ColumnBoxPlot'
import LongText from './LongText'
import styles from './RightStats.less'
import { isNumericType } from './../../typeHelper'

const RadioGroup = Radio.Group
const RadioButton = Radio.Button

export default class RightStats extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            histSorted: false
        }
    }
    handleSortChange = e => {
        this.setState({
            histSorted: e.target.value
        })
    }
    getSelectedColumnInfo() {
        const { selected, statisticInfo } = this.props
        if (statisticInfo && Array.isArray(statisticInfo.columnInfo)) {
            for (let oneColumnInfo of statisticInfo.columnInfo) {
                if (oneColumnInfo.columnName === selected) {
                    return oneColumnInfo || {}
                }
            }
        }
        return {}
    }
    getAttributes() {
        const { selected, statisticInfo } = this.props
        if (!statisticInfo) {
            return {}
        }
        if (selected === '__table__') {
            return statisticInfo.tableInfo
        } else {
            const oneColumnInfo = this.getSelectedColumnInfo()
            const stats = oneColumnInfo.singleStatInfo || {}
            const res = {}
            res['字段名称'] = selected
            res['字段类型'] = oneColumnInfo.columnType
            for (let key in stats) {
                res[key] = stats[key]
            }
            return res
        }
    }
    renderAttributes() {
        const attributes = this.getAttributes()
        const content = []
        let maxKeyLen = 0
        for (let key in attributes) {
            maxKeyLen = Math.max(maxKeyLen, key.length)
        }
        let keyWordLength = maxKeyLen * 15 + 5

        for (let key in attributes) {
            // 没有值的不显示
            if (
                attributes[key] === null ||
                !attributes[key] ||
                (attributes[key] && attributes[key].length <= 0)
            ) {
                continue
            }
            content.push(
                <div key={key} className={styles.attribute}>
                    <span
                        className={styles.left}
                        style={{ width: keyWordLength }}>
                        {key}:{' '}
                    </span>
                    <span className={styles.right}>
                        <LongText text={attributes[key]} />
                    </span>
                </div>
            )
        }
        return (
            <div className={styles.attributeContainer}>
                <div className={styles.title}>记录统计</div>
                {content}
            </div>
        )
    }
    renderChart() {
        let chart = null
        const { statisticInfo, selected, tableData, chartType } = this.props
        if (statisticInfo && selected === '__table__') {
            chart = (
                <ColumnTypePieChart
                    columnInfo={tableData.columnInfos}
                    type="detailChart"
                />
            )
        } else if (statisticInfo) {
            const col = tableData.columnInfos.find(
                column => column.columnName === selected
            )
            console.log(statisticInfo)
            chart = (
                <div
                    style={{
                        position: 'absolute',
                        left: 0,
                        top: 0,
                        bottom: 0,
                        right: 0
                    }}>
                    {chartType === 'boxPlot' &&
                    isNumericType(col.columnType) ? (
                        <ColumnBoxPlot
                            columnName={selected}
                            statisticInfo={statisticInfo}
                            type="detailChart"
                        />
                    ) : (
                        <span>
                            {this.renderSortSwitch()}
                            <ColumnHistgram
                                columnName={selected}
                                statisticInfo={statisticInfo}
                                type="detailChart"
                                sorted={this.state.histSorted}
                            />
                        </span>
                    )}
                </div>
            )
        }
        return (
            <div className={styles.chartContainer}>
                <div className={styles.title}>图表</div>
                {chart}
            </div>
        )
    }
    renderSortSwitch() {
        return (
            <RadioGroup
                value={this.state.histSorted}
                onChange={this.handleSortChange}
                style={{
                    position: 'absolute',
                    top: 10,
                    left: '50%',
                    transform: 'translate(-50%)',
                    zIndex: 10
                }}>
                <RadioButton value={false}>默认</RadioButton>
                <RadioButton value={true}>排序</RadioButton>
            </RadioGroup>
        )
    }
    render() {
        return (
            <div style={{ height: '100%' }}>
                {this.renderAttributes()}
                {this.renderChart()}
            </div>
        )
    }
}
