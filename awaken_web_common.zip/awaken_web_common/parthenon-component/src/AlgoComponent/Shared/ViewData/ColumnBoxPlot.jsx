import React from 'react'
import Chart from './Chart'

export default class ColumnBoxPlot extends React.Component {
    getColumnInfo() {
        const { columnName, statisticInfo = {} } = this.props
        if (Array.isArray(statisticInfo.columnInfo)) {
            for (let i = 0; i < statisticInfo.columnInfo.length; i++) {
                if (statisticInfo.columnInfo[i].columnName === columnName) {
                    return statisticInfo.columnInfo[i]
                }
            }
        }
        return null
    }

    getXdata() {
        return [this.columnInfo.columnName]
    }

    getYdata() {
        const res = []
        const keys = ['最小值', '下四分位', '中位数', '上四分位', '最大值']
        const data = keys.map(key => {
            return this.columnInfo.singleStatInfo[key]
        })
        res.push(data)
        return res
    }

    getThumbProps() {
        return {
            series: [
                {
                    data: this.getYdata(),
                    type: 'boxplot',
                    itemStyle: {
                        borderColor: '#188df0',
                    },
                    slient: true,
                },
            ],
            xAxis: {
                show: false,
                data: this.getXdata(),
            },
            yAxis: {
                show: false,
            },
        }
    }

    getDetailedProps() {
        return {
            tooltip: {
                trigger: 'item',
                axisPointer: {
                    type: 'shadow',
                },
            },
            series: [
                {
                    data: this.getYdata(),
                    type: 'boxplot',
                    itemStyle: {
                        borderColor: '#188df0',
                    },
                    tooltip: {
                        formatter: function(param) {
                            return [
                                param.name + ': ',
                                '最大值: ' + param.data[5],
                                '上四分位数: ' + param.data[4],
                                '中位数: ' + param.data[3],
                                '下四分位数: ' + param.data[2],
                                '最小值: ' + param.data[1],
                            ].join('<br/>')
                        },
                    },
                },
            ],
            xAxis: {
                type: 'category',
                data: this.getXdata(),
                splitArea: {
                    show: false,
                },
                splitLine: {
                    show: false,
                },
            },
            yAxis: {
                type: 'value',
                splitArea: {
                    show: true,
                },
            },
        }
    }

    render() {
        this.columnInfo = this.getColumnInfo()
        if (
            !this.columnInfo ||
            !this.columnInfo.complexStatInfo ||
            !this.columnInfo.complexStatInfo.hist
        ) {
            return null
        }

        let chartProps = {}
        if (this.props.type === 'thumbnail') {
            chartProps = this.getThumbProps()
        } else if (this.props.type === 'detailChart') {
            chartProps = this.getDetailedProps()
        }

        return <Chart {...chartProps} />
    }
}
