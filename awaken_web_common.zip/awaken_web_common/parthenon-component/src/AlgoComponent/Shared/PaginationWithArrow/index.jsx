import { Pagination } from 'antd'
import React from 'react'
import styles from './index.less'

class PaginationWithArrow extends React.Component {
    render() {
        const itemRender = (current, type, originalElement) => {
            if (type === 'prev') {
                return (
                    <span className={styles.noAdditionalArrow}>
                        <a className="ant-pagination-item-link">
                            <i className="anticon anticon-left" />
                        </a>
                    </span>
                )
            } else if (type === 'next') {
                return (
                    <span className={styles.noAdditionalArrow}>
                        <a className="ant-pagination-item-link">
                            <i className="anticon anticon-right" />
                        </a>
                    </span>
                )
            }
            return originalElement
        }

        return <Pagination {...this.props} itemRender={itemRender} />
    }
}

export default PaginationWithArrow
