import React from 'react'

import styles from './index.less'

const ITEM_IN_ONE_ROW = 8

export default class EditLabels extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            editing: false,
            selectStartAt: props.start,
            selectEndAt: props.end,
        }
    }

    handleClickCell = index => {
        if (!this.state.editing) {
            this.setState({
                editing: true,
                selectStartAt: index,
            })
        } else {
            this.setState({
                editing: false,
                selectEndAt: (index + 1) % 24,
            })
            this.props.onChange(
                this.state.selectStartAt,
                this.state.selectEndAt
            )
        }
    }

    handleMouseOverCell = index => {
        this.setState({
            selectEndAt: index + 1,
        })
    }

    getSelectedBlocks = (start, end) => {
        const blocks = []
        if (start === null || start === undefined) return []
        if (end === null || end === undefined) return []
        if (start < end) {
            for (let i = start; i < end; i++) blocks.push(i)
        } else {
            for (let i = 0; i < end; i++) blocks.push(i)
            for (let i = start; i < 24; i++) blocks.push(i)
        }
        return blocks
    }

    isDisAllowedCell = index => {
        return (
            this.state.editing &&
            (index < this.state.selectStartAt ||
                index >= this.state.selectStartAt + 24)
        )
    }

    renderEditBlocks = () => {
        const renderEndAt = this.state.selectStartAt + 24
        return this.renderBlocks(
            0,
            renderEndAt,
            this.state.selectStartAt,
            this.state.selectEndAt
        )
    }

    renderNonEditBlock = () => {
        return this.renderBlocks(
            0,
            24,
            this.state.selectStartAt,
            this.state.selectEndAt
        )
    }

    renderBlocks = (renderStartAt, renderEndAt, selectStartAt, selectEndAt) => {
        const selectedBlocks = this.getSelectedBlocks(
            selectStartAt,
            selectEndAt
        )
        let curr = renderStartAt,
            i = 0
        const rows = []
        while (curr < renderEndAt) {
            const isLastRow = curr + ITEM_IN_ONE_ROW >= renderEndAt
            rows.push(this.renderRow(i, selectedBlocks, isLastRow))
            i++
            curr += ITEM_IN_ONE_ROW
        }

        return <div>{rows}</div>
    }

    renderRow = (rowIndex, selectedBlocks, isLastRow = false) => {
        let start = rowIndex * ITEM_IN_ONE_ROW
        let end = start + ITEM_IN_ONE_ROW
        let row = []
        for (let i = start; i < end; i++) {
            const disAllowClick = this.isDisAllowedCell(i)
            const borderColor = 'rgba(0,0,0,.3)'
            const style = {
                borderTop: `1px solid ${borderColor}`,
                borderLeft: `1px solid ${borderColor}`,
                display: 'inline-block',
                height: 35,
                lineHeight: '35px',
                textAlign: 'center',
                flexBasis: 35,
                flexGrow: 1,
            }
            if (i === end - 1 || this.isDisAllowedCell(i + 1)) {
                style.borderRight = `1px solid ${borderColor}`
            }
            if (isLastRow || this.isDisAllowedCell(i + ITEM_IN_ONE_ROW)) {
                style.borderBottom = `1px solid ${borderColor}`
            }
            if (disAllowClick) {
                style.opacity = 0
            }
            if (selectedBlocks.includes(i)) {
                style.background = 'rgba(0,0,0,.25)'
            }

            row.push(
                <span
                    className={styles.cell}
                    onClick={() => {
                        if (!disAllowClick) {
                            this.handleClickCell(i)
                        }
                    }}
                    onMouseOver={() => {
                        if (this.state.editing && !disAllowClick) {
                            this.handleMouseOverCell(i)
                        }
                    }}
                    style={style}
                    key={i}
                >
                    {i % 24}
                </span>
            )
        }
        return <div style={{ display: 'flex' }}>{row}</div>
    }

    render() {
        return (
            <div>
                {this.state.editing && this.renderEditBlocks()}
                {!this.state.editing && this.renderNonEditBlock()}
            </div>
        )
    }
}
