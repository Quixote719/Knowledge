import React from 'react'
import { Switch } from 'antd'

class AdvancedOption extends React.Component {
    render() {
        const switchOn = this.props.visible
        return (
            <div style={{ marginBottom: 10 }}>
                <span>显示高级选项：</span>
                <Switch checked={switchOn} onChange={this.props.onChange} />
            </div>
        )
    }
}

export default AdvancedOption
