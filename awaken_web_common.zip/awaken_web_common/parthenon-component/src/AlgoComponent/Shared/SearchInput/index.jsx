import React from 'react'
import { Input } from 'antd'

const Search = Input.Search

export default class SearchInput extends React.Component {
    static defaultProps = {
        searchType: '',
        placeholder: '搜索关键词',
        onSearch: () => {},
    }

    constructor(props) {
        super(props)
    }

    keyWordsChange = e => {
        const { searchType } = this.props
        let value = e.target.value
        if (searchType != 'enter') {
            this.onSearch(value)
        }
    }

    onSearch = value => {
        this.props.onSearch(value)
    }

    render() {
        let { placeholder, maxLength, className } = this.props
        className = className || ''
        return (
            <Search
                className={className}
                maxLength={maxLength}
                placeholder={placeholder}
                onChange={this.keyWordsChange}
                onSearch={this.onSearch}
            />
        )
    }
}
