/**
 * Created by yaojia7 on 2017/5/20.
 */
// 引入 ECharts 主模块
import echarts from './echarts'
import React from 'react'
import PropTypes from 'prop-types'
import elementResizeEvent from 'element-resize-event'
import { deepCopy } from 'parthenon-lib'

class Chart extends React.Component {
    /**
     * 声明组件props类型，option为穿件echarts图表所需的option
     * style为echarts图表容器的style
     * theme为创建echarts实例时的图表主体
     * className为echarts图表容器的className
     * @type {Object}
     */
    static propTypes = {
        option: PropTypes.object.isRequired,
        style: PropTypes.object,
        theme: PropTypes.string,
        className: PropTypes.string,
        getEchartsInstance: PropTypes.func,
        optionMerge: PropTypes.bool //使用setOption更新时是否需要合并option
    }

    static defaultProps = {
        style: { height: '300px' },
        theme: null,
        className: '',
        optionMerge: true
    }
    /**
     * 初始化函数，创建指向echarts图表容器的变量
     * @param  {[type]} props [description]
     */
    constructor(props) {
        super(props)
        this.divElement = null
    }

    /**
     * 获取echarts实例并执行setOption方法绘制图表
     * 如果option.series中含有关系图，则先剔除关系图中节点不存在的link
     * @return {[type]} [description]
     */
    renderEchartDom = (themeChanged = false) => {
        let echartObj = null
        if (themeChanged) {
            echarts.dispose(this.divElement)
            echartObj = echarts.init(this.divElement, this.props.theme)
        } else echartObj = this.getEchartsInstance()

        let option = deepCopy(this.props.option)
        echartObj.setOption(option, !this.props.optionMerge)
        if (this.props.renderEchartDomCallback) {
            this.props.renderEchartDomCallback(echartObj)
        }
        return echartObj
    }

    /**
     * 根据容器DOM节点获取echarts实例
     * @return {[type]} [description]
     */
    getEchartsInstance = () => {
        return (
            echarts.getInstanceByDom(this.divElement) ||
            echarts.init(this.divElement, this.props.theme)
        )
    }

    /**
     * 容器渲染完成后执行echarts图表的渲染，并对容器绑定resize事件
     */
    componentDidMount() {
        const {option, getEchartsInstance, handleSelect, onLegendSelectChange, onMouseover} = this.props
        if (!option) return
        let echartObj = this.renderEchartDom()
        this.echartInst = echartObj

        if(getEchartsInstance){
            getEchartsInstance(echartObj)
        }

        if (handleSelect) {
            echartObj.on('click', params => {
                this.handlerClick(params)
            })
        }
        if(onLegendSelectChange){
            echartObj.on( 'legendselectchanged', onLegendSelectChange )
        }
        if(onMouseover){
            echartObj.on('click', onMouseover)
        }
        // 绑定echarts提供的事件
        if (this.props.events) {
            for (const eventName in this.props.events) {
                echartObj.on(eventName, params => {
                    this.props.events[eventName](params)
                })
            }
        }
        elementResizeEvent(this.divElement, () => {
            echartObj.resize()
        })
    }

    /**
     * 组件props有更新后重新渲染echarts图表
     * 也可用于设置图表动画
     */
    componentDidUpdate(prevProps) {
        const { option, theme, getEchartsInstance } = this.props
        if (prevProps.option && !option && this.echartInst) {
            this.echartInst.clear()
            return
        }
        if (!this.props.option) return
        if (prevProps.option !== option || prevProps.theme !== theme) {
            const echartObj = this.renderEchartDom(prevProps.theme !== theme)
            if(getEchartsInstance){
                getEchartsInstance(echartObj)
            }
        }
    }

    //组件卸载后删除echarts实例
    componentWillUnmount() {
        if (this.divElement) {
            echarts.dispose(this.divElement)
        }
    }

    handlerClick(params) {
        this.props.handleSelect(params.name, this.props.property)
    }
    /**
     * 渲染函数，渲染echarts容器组件，渲染完成后再绘制echarts图表
     * @return {[type]} [description]
     */
    render() {
        const style = this.props.style
        return (
            <div
                ref={e => {
                    this.divElement = e
                }}
                style={style}
                className={this.props.className}
            />
        )
    }
}

export default Chart
