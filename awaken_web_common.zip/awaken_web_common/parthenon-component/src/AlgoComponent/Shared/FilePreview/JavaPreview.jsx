import React from 'react'
import CodeMirror from 'jad-react-codemirror'
import 'jad-codemirror/lib/codemirror.css'
import 'jad-codemirror/lib/codemirror'
import 'jad-codemirror/mode/clike/clike'
import 'jad-codemirror/addon/selection/active-line.js'
import 'jad-codemirror/theme/eclipse.css'

class JavaPreview extends React.Component {
    render = () => {
        return (
            <CodeMirror
                value={this.props.code}
                options={{ mode: 'text/x-java' }}
            />
        )
    }
}

export default JavaPreview
