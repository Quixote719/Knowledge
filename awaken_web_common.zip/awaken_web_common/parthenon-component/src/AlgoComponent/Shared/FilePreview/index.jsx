import React from 'react'
import { Form, message } from 'antd'
import JavaPreview from './JavaPreview'
import PythonPreview from './PythonPreview'
import ScalaPreview from './ScalaPreview'

const styles = require('./index.less')

class FilePreview extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            code: null,
        }
    }
    static defaultProps = {
        showError: true,
    }
    componentDidMount() {
        const { downloadPath } = this.props
        this.loading = message.loading('正在下载代码...')
        downloadPath({ filePath: this.props.filePath })
            .then(res => res.blob())
            .then(blob => {
                const reader = new FileReader()
                reader.readAsText(blob)
                reader.onload = evt => {
                    this.setState({
                        code: evt.target.result,
                    })
                }
            })
            .catch(err => {
                if (this.props.showError) {
                    message.error(
                        err && err.message ? err.message : '无法下载原文件'
                    )
                }
                this.props.onClose()
            })
            .finally(() => {
                setTimeout(() => {
                    this.loading()
                }, 0)
            })
    }

    getCodeMirrorByProgrammingLanguage = language => {
        switch (language) {
            case 'python':
                return PythonPreview
            case 'java':
                return JavaPreview
            case 'scala':
                return ScalaPreview
            default:
                return null
        }
    }

    renderCodeView = () => {
        const Preview = this.getCodeMirrorByProgrammingLanguage(
            this.props.programmingLanguage
        )
        if (Preview) {
            return <Preview code={this.state.code} />
        } else {
            return null
        }
    }

    render = () => {
        if (this.state.code === null) {
            return null
        } else {
            return (
                <div className={styles.container}>
                    <div className={styles.title}>
                        <span>文件预览</span>
                        <span
                            className={styles.delete}
                            onClick={this.props.onClose}
                        />
                    </div>
                    {this.renderCodeView()}
                </div>
            )
        }
    }
}

export default Form.create()(FilePreview)
