// 选择字段功能组件
import React from 'react'
import { message } from 'antd'
import { isOutputColumnValid } from '../util'
import RightModal from '../RightModal'
import SearchInput from '../SearchInput'

import styles from './SelectFieldsModal.less'

import LeftTable from './LeftTable'
import RightTable from './RightTable'

export default class extends React.Component {
    constructor(props) {
        super(props)
        const { selectedColumns } = this.props
        this.state = {
            selectedColumns: selectedColumns || [],
            keywordsOfInput: '',
            keywordsOfOutput: '',
        }
    }

    /**
     * 输出字段是否有效
     */
    get isOutputColumnValid() {
        const { required, colsRequired = 1 } = this.props
        const selectedColumns = this.state.selectedColumns || []
        if (required && selectedColumns.length < colsRequired) {
            return {
                isValid: false,
                errorMessage: `必须选中至少${colsRequired}个字段`,
            }
        }
        return isOutputColumnValid({
            additionalParams: this.props.additionalParams,
            selectedColumns: this.state.selectedColumns,
        })
    }

    handleChangeSelectedColumns = selectedColumns => {
        this.setState({
            selectedColumns,
        })
    }

    //弹窗内点击取消按钮
    handleCancelButton = () => {
        this.props.onCancel()
    }

    // 把选择的字段传给组件显示
    handleOKButton = () => {
        if (!this.isOutputColumnValid.isValid) {
            return message.error(
                `无法保存：${this.isOutputColumnValid.errorMessage}`
            )
        }
        this.props.onConfirm(this.state.selectedColumns)
    }

    onSearchInput = v => {
        this.setState({
            keywordsOfInput: v,
        })
    }

    onSearchOutput = v => {
        this.setState({
            keywordsOfOutput: v,
        })
    }

    render() {
        const {
            isSelectMulti,
            allColumns,
            selectableColumns,
            additionalParams,
            groupByType,
        } = this.props
        const selectedColumns = this.state.selectedColumns || []

        return (
            <RightModal
                onOk={this.handleOKButton}
                onCancel={this.handleCancelButton}
                title="选择字段"
            >
                <div
                    className={`${styles.container} ${
                        isSelectMulti ? styles.multi : styles.single
                    }`}
                >
                    <div className={styles.leftPart}>
                        <SearchInput
                            className={styles.searchInput}
                            onSearch={this.onSearchInput}
                            maxLength={35}
                            placeholder="搜索输入表"
                        />
                        <LeftTable
                            groupByType={groupByType}
                            isSelectMulti={isSelectMulti}
                            allColumns={allColumns}
                            selectableColumns={selectableColumns}
                            selectedColumns={selectedColumns}
                            keywords={this.state.keywordsOfInput}
                            additionalParams={additionalParams}
                            onChangeSelectedColumns={
                                this.handleChangeSelectedColumns
                            }
                        />
                    </div>
                    <div className={styles.rightPart}>
                        <SearchInput
                            className={styles.searchInput}
                            onSearch={this.onSearchOutput}
                            maxLength={35}
                            placeholder="搜索输出表"
                        />
                        <RightTable
                            additionalParams={additionalParams}
                            selectedColumns={selectedColumns}
                            allColumns={allColumns}
                            keywords={this.state.keywordsOfOutput}
                            isOutputColumnValid={this.isOutputColumnValid}
                            onChangeSelectedColumns={
                                this.handleChangeSelectedColumns
                            }
                        />
                    </div>
                </div>
            </RightModal>
        )
    }
}
