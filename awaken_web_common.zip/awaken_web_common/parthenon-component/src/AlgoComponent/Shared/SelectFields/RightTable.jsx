// 选择字段功能组件
import React from 'react'
import { Icon, Tooltip, Select, Input } from 'antd'
import { DragTable } from '../../../index'
import { isSelectedColumnsValid } from '../util'
import { COL_DEFAULT_WIDTH, fieldTableDesc } from '../../tableDesc'

import styles from './SelectFieldsModal.less'

const Option = Select.Option

export default class extends React.Component {
    /**
     * 参数是否来自于正确的表结构
     */
    get isColsFromRightSchema() {
        return isSelectedColumnsValid(
            this.props.selectedColumns,
            this.props.allColumns
        )
    }

    getFilteredColumns = columnArray => {
        let { keywords } = this.props
        keywords = keywords || ''
        return (columnArray || [])
            .filter(r => {
                return r.name.toLowerCase().includes(keywords.toLowerCase())
            })
            .map(col => ({
                ...col,
                key: col.name
            }))
    }

    /**
     * 移动输出行的顺序
     */
    handleMoveOutputRow = selectedColumns => {
        this.props.onChangeSelectedColumns(selectedColumns)
    }

    /**
     * 删除选中的列
     */
    handleRemoveSelectedColumns = record => {
        const selectedColumns = this.props.selectedColumns || []
        let index = -1

        for (let i = 0; i < selectedColumns.length; i++) {
            if (selectedColumns[i].name === record.name) {
                index = i
            }
        }

        if (index === -1) return
        this.props.onChangeSelectedColumns([
            ...this.props.selectedColumns.slice(0, index),
            ...this.props.selectedColumns.slice(index + 1)
        ])
    }

    /**
     * 附加参数变化
     */
    handleAdditionalParamChange = (value, paramDesc, index) => {
        let selectedColumns = this.props.selectedColumns.slice()
        let record = selectedColumns[index]
        for (let paramName in record) {
            if (paramName === paramDesc.paramName) {
                record[paramName] = value
            }
        }
        this.props.onChangeSelectedColumns(selectedColumns)
    }

    renderAdditionalParams = (paramDesc, record, index) => {
        let key = paramDesc.paramName
        const Comp = paramDesc.Comp
        let value = record[key]

        if (Comp) {
            return (
                <Comp
                    value={record[key]}
                    onSave={value => {
                        this.handleAdditionalParamChange(
                            value,
                            paramDesc,
                            index
                        )
                    }}
                />
            )
        }
        if (!paramDesc.hasOwnProperty('inputType')) {
            return <span>{value}</span>
        } else if (paramDesc.inputType === 'textInput') {
            return (
                <Input.TextArea
                    autosize
                    value={value}
                    style={{ width: '100%', resize: 'none' }}
                    onChange={e =>
                        this.handleAdditionalParamChange(
                            e.target.value,
                            paramDesc,
                            index
                        )
                    }
                />
            )
        } else if (
            paramDesc.inputType === 'dropdown' &&
            Array.isArray(paramDesc.options)
        ) {
            return (
                <Select
                    dropdownMatchSelectWidth={false}
                    onChange={value =>
                        this.handleAdditionalParamChange(
                            value,
                            paramDesc,
                            index
                        )
                    }
                    style={{ minWidth: '77px' }}
                    value={value}>
                    {paramDesc.options.map(opt => {
                        return (
                            <Option key={opt.value} value={opt.value}>
                                {opt.text}
                            </Option>
                        )
                    })}
                </Select>
            )
        }
    }

    renderSelectedTable = () => {
        const { additionalParams = [] } = this.props
        let tableSchema = fieldTableDesc.slice()
        for (let i = 0; i < additionalParams.length; i++) {
            tableSchema.push({
                title: additionalParams[i].title,
                dataIndex: additionalParams[i].paramName,
                key: additionalParams[i].paramName,
                width: COL_DEFAULT_WIDTH,
                render: (text, record, index) => {
                    return this.renderAdditionalParams(
                        additionalParams[i],
                        record,
                        index
                    )
                }
            })
        }

        tableSchema.push({
            title: '操作',
            dataIndex: 'operation',
            key: 'operation',
            width: COL_DEFAULT_WIDTH / 2,
            render: (text, record) => {
                return (
                    <a onClick={() => this.handleRemoveSelectedColumns(record)}>
                        删除
                    </a>
                )
            }
        })

        const selectedColumns = this.props.selectedColumns || []
        const filteredSeletableColumns = this.getFilteredColumns(
            selectedColumns
        )
        return (
            <DragTable
                dataSource={filteredSeletableColumns}
                columns={tableSchema}
                pagination={false}
                scroll={{ y: 650 }}
                bordered
                onMove={this.handleMoveOutputRow}
            />
        )
    }

    render() {
        const { isOutputColumnValid } = this.props

        return (
            <div className={styles.rightTable}>
                <span style={{ display: 'inline-block', marginRight: 10 }}>
                    已选
                </span>
                {!this.isColsFromRightSchema && (
                    <Tooltip placement="top" title="参数无效">
                        <span>
                            <Icon
                                type="exclamation-circle-o"
                                className={styles.warnIcon}
                            />
                        </span>
                    </Tooltip>
                )}
                {!isOutputColumnValid.isValid && (
                    <Tooltip
                        placement="top"
                        title={isOutputColumnValid.errorMessage}>
                        <span>
                            <Icon
                                type="exclamation-circle-o"
                                className={styles.errorIcon}
                            />
                        </span>
                    </Tooltip>
                )}
                {this.renderSelectedTable()}
            </div>
        )
    }
}
