// 选择字段功能组件

import React from 'react'
import { Button, Icon, Tooltip, Popover, Table } from 'antd'
import PropTypes from 'prop-types'

import SelectFieldsModal from './SelectFieldsModal'
import { isSelectedColumnsValid, expandSelectedColumnsWithType } from '../util'
import {
    BUTTON_DEFAULT_WIDTH,
    COL_DEFAULT_WIDTH,
    fieldTableDesc
} from '../../tableDesc'
import sharedStyles from '../../component.less'
import styles from './index.less'

/**
 * 选择字段按钮
 * 点击该按钮会弹出选择字段弹窗
 * 弹窗确定后会返回选择的字段结果
 */
export default class extends React.Component {
    static defaultProps = {
        buttonText: '选择',
        required: true,
        hidePopupOutput: false,
        groupByType: true
    }

    static propTypes = {
        groupByType: PropTypes.bool,
        allColumns: PropTypes.arrayOf(
            PropTypes.shape({
                name: PropTypes.string.isRequired,
                type: PropTypes.string.isRequired
            })
        ),
        selectableColumns: PropTypes.arrayOf(
            PropTypes.shape({
                name: PropTypes.string.isRequired,
                type: PropTypes.string.isRequired
            })
        ),
        selectedColumns: PropTypes.oneOfType([
            PropTypes.arrayOf(
                PropTypes.shape({
                    name: PropTypes.string.isRequired
                    //additionalParams中的paramName
                })
            ),
            PropTypes.arrayOf(PropTypes.string)
        ]),
        isSelectMulti: PropTypes.bool,

        //在输出表格中，添加输入框，或者下拉选择框
        additionalParams: PropTypes.arrayOf(
            PropTypes.shape({
                title: PropTypes.string.isRequired,
                paramName: PropTypes.string.isRequired,
                inputType: PropTypes.string.isRequired, //textInput或者dropdown
                defaultValue: PropTypes.oneOfType([
                    PropTypes.string,
                    PropTypes.boolean,
                    PropTypes.func
                ]).isRequired,
                isOutputCol: PropTypes.boolean,
                options: PropTypes.arrayOf({
                    value: PropTypes.string.isRequired,
                    text: PropTypes.string.isRequired
                })
            })
        ),

        //有默认值
        hidePopupOutput: PropTypes.bool, //是否隐藏悬浮表单提示
        buttonText: PropTypes.string, //按钮文字
        required: PropTypes.bool, //是否为必填。若为必填，则不能不选择任何字段

        //限制字段类型
        numericCols: PropTypes.bool, //是否为只支持数值型字段(double, int)
        doubleCols: PropTypes.bool,
        genericNumericCols: PropTypes.bool, //是否只支持数值型字段(所有数值型字段)
        stringTypeCols: PropTypes.bool, //是否只支持字符串型字段
        allowedTypes: PropTypes.arrayOf(PropTypes.string.isRequired), //显示指明支持的类型
        warnTips: PropTypes.arrayOf(PropTypes.string), //显示指明支持的类型

        colsRequired: PropTypes.number, //至少需要选中N个字段
        style: PropTypes.object //自定义样式
    }

    constructor(props) {
        super(props)
        this.state = {
            showSelectModal: false
        }
    }

    get isParamsValid() {
        //注意isColsValid是判断参数是否可以上游表结构推断出来。
        //isParamValid则判断选中的参数是否为空，是否个数大于指定个数等限制
        const {
            required = true,
            selectedColumns = [],
            colsRequired = 1
        } = this.props
        if (!required || selectedColumns.length >= colsRequired) {
            return {
                isValid: true
            }
        } else {
            return {
                isValid: false,
                errorMessage: `必须选中至少${colsRequired}个字段`
            }
        }
    }

    //点击选择按钮, 打开字段筛选弹窗
    handleClickButton = () => {
        this.setState({
            showSelectModal: true
        })
    }

    /**
     * 取消字段筛选
     */
    handleCancel = () => {
        this.setState({
            showSelectModal: false
        })
    }

    /**
     * 字段筛选保存结果
     */
    handleSelectColumns = (...rest) => {
        this.setState({
            showSelectModal: false
        })
        this.props.onSelectFields(...rest)
    }

    renderSelectFieldsModal = () => {
        let {
            allColumns,
            isSelectMulti,
            selectedColumns,
            additionalParams = [],
            selectableColumns,
            required = true,
            colsRequired,
            groupByType
        } = this.props
        const temp = expandSelectedColumnsWithType(selectedColumns, allColumns)

        if (!selectableColumns) {
            selectableColumns = allColumns.slice()
        }

        return (
            <SelectFieldsModal
                selectableColumns={selectableColumns}
                groupByType={groupByType}
                allColumns={allColumns}
                isSelectMulti={isSelectMulti}
                additionalParams={additionalParams}
                selectedColumns={temp}
                onCancel={this.handleCancel}
                onConfirm={this.handleSelectColumns}
                required={required}
                colsRequired={colsRequired}
            />
        )
    }

    /**
     * 渲染输出表单弹窗
     */
    renderPopupSelectedTable = () => {
        let { allColumns, selectedColumns, additionalParams = [] } = this.props

        let tableSchema = fieldTableDesc.slice()
        for (let i = 0; i < additionalParams.length; i++) {
            tableSchema.push({
                title: additionalParams[i].title,
                dataIndex: additionalParams[i].paramName,
                key: additionalParams[i].paramName,
                width: COL_DEFAULT_WIDTH,
                render: (text, record) => {
                    return this.renderAdditionalParams(
                        additionalParams[i],
                        record
                    )
                }
            })
        }

        const temp = expandSelectedColumnsWithType(selectedColumns, allColumns)

        return (
            <Table
                dataSource={temp}
                columns={tableSchema}
                pagination={false}
                scroll={{ y: 650 }}
                bordered
            />
        )
    }

    renderAdditionalParams = (paramDesc, record) => {
        let key = paramDesc.paramName
        let value = record[key]
        if (
            !paramDesc.hasOwnProperty('inputType') ||
            paramDesc.inputType === 'textInput'
        ) {
            return <span>{value}</span>
        } else if (
            paramDesc.inputType === 'dropdown' &&
            Array.isArray(paramDesc.options)
        ) {
            for (let i = 0; i < paramDesc.options.length; i++) {
                if (paramDesc.options[i].value === value) {
                    return <span>{paramDesc.options[i].text}</span>
                }
            }
        }
    }

    renderTips = () => {
        const {
            numericCols,
            doubleCols,
            genericNumericCols,
            stringTypeCols,
            allowedTypes = [],
            warnTips = []
        } = this.props

        let tips = []
        if (warnTips && warnTips.length > 0) {
            tips.push([...warnTips])
        }
        if (allowedTypes && allowedTypes.length > 0) {
            let allowedTypesText = allowedTypes.map(item => {
                const t = typeof item === 'object' ? item.typeName : item

                if (t.toLowerCase() === 'genericNumericCols'.toLowerCase())
                    return '数值型'
                if (t.toLowerCase() === 'numericCols'.toLowerCase())
                    return '数值类型'
                if (t.toLowerCase() === 'doubleCols'.toLowerCase())
                    return 'double'
                if (t.toLowerCase() === 'stringTypeCols'.toLowerCase())
                    return 'string或者类型名包含char'
                return t
            })
            tips.push(`仅支持${allowedTypesText.join(', ')}`)
        }
        if (genericNumericCols) {
            tips.push('仅支持选择数值型字段')
        }
        if (numericCols) {
            tips.push('仅支持数值类型的字段')
        }
        if (doubleCols) {
            tips.push('仅支持选择类型为double的字段')
        }
        if (stringTypeCols) {
            tips.push('仅支持选择类型为string, 或者类型名包含char的字段')
        }

        if (tips.length <= 0) {
            return null
        }

        return (
            <span style={{ marginLeft: 10, display: 'inline-block' }}>
                <Tooltip
                    placement="top"
                    title={
                        <span>
                            {tips.map(t => (
                                <span>
                                    {t}
                                    <br />
                                </span>
                            ))}
                        </span>
                    }>
                    <span>
                        <Icon
                            type="exclamation-circle-o"
                            style={{
                                color: '#787878',
                                transform: 'scale(1.2)'
                            }}
                        />
                    </span>
                </Tooltip>
            </span>
        )
    }

    render() {
        const {
            hidePopupOutput,
            buttonText,
            selectedColumns,
            allColumns,
            style = {}
        } = this.props
        const isColsValid = isSelectedColumnsValid(selectedColumns, allColumns)
        const btn = (
            <Button
                disabled={this.props.disabled}
                className={
                    sharedStyles.button +
                    ' ' +
                    (this.props.disabled ? sharedStyles.transparent : '')
                }
                style={{ width: BUTTON_DEFAULT_WIDTH }}
                onClick={this.handleClickButton}>
                {buttonText}
            </Button>
        )

        return (
            <div style={style} className={styles.container}>
                {this.state.showSelectModal || hidePopupOutput ? (
                    btn
                ) : (
                    <Popover
                        placement="left"
                        content={this.renderPopupSelectedTable()}
                        mouseEnterDelay={0.2}>
                        {btn}
                    </Popover>
                )}

                {this.renderTips()}
                {!isColsValid && (
                    <span style={{ marginLeft: 10, display: 'inline-block' }}>
                        <Tooltip placement="top" title="参数无效">
                            <span>
                                <Icon
                                    type="exclamation-circle-o"
                                    style={{
                                        color: '#faad14',
                                        transform: 'scale(1.2)'
                                    }}
                                />
                            </span>
                        </Tooltip>
                    </span>
                )}
                {!this.isParamsValid.isValid && (
                    <span style={{ marginLeft: 10, display: 'inline-block' }}>
                        <Tooltip
                            placement="top"
                            title={this.isParamsValid.errorMessage}>
                            <span>
                                <Icon
                                    type="exclamation-circle-o"
                                    style={{
                                        color: '#fa4646',
                                        transform: 'scale(1.2)'
                                    }}
                                />
                            </span>
                        </Tooltip>
                    </span>
                )}
                {this.state.showSelectModal && this.renderSelectFieldsModal()}
            </div>
        )
    }
}
