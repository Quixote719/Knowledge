// 选择字段功能组件
import React from 'react'
import { Table } from 'antd'
import { fieldTableDesc, COL_DEFAULT_WIDTH } from '../../tableDesc'

import styles from './LeftTableView.less'

export default class extends React.Component {
    getColumnInfo = () => {
        const { allColumns } = this.props
        let hasDescription = false
        allColumns.forEach(col => {
            if (col.hasOwnProperty('description')) {
                hasDescription = true
            }
        })

        let columnInfo = fieldTableDesc.slice()
        if (hasDescription) {
            columnInfo.push({
                title: '字段描述',
                dataIndex: 'description',
                key: 'description',
                width: COL_DEFAULT_WIDTH,
            })
        }
        return columnInfo
    }

    render() {
        const {
            isSelectMulti,
            selectedRowKeys,
            rowSelect,
            rowSelectAll,
            allColumns,
            selectableColumns,
        } = this.props
        const selectableNames = selectableColumns.map(col => col.name)

        return (
            <div className={styles.leftTable}>
                可选
                <span
                    className={styles.groupByChange}
                    onClick={this.props.onGroupByChange}
                >
                    点击切换显示
                </span>
                <Table
                    dataSource={allColumns}
                    columns={this.getColumnInfo()}
                    pagination={false}
                    scroll={{ y: 650 }}
                    bordered
                    rowSelection={{
                        onSelect: rowSelect,
                        onSelectAll: rowSelectAll,
                        type: isSelectMulti ? 'checkbox ' : 'radio',
                        selectedRowKeys: selectedRowKeys,
                        getCheckboxProps: record => {
                            return {
                                disabled: !selectableNames.includes(
                                    record.name
                                ),
                            }
                        },
                    }}
                />
            </div>
        )
    }
}
