// 选择字段功能组件
import React from 'react'
import LeftTableView from './LeftTableView'
import LeftTableTypeGroupedView from './LeftTableTypeGroupedView'
import {
    filterColumnsInAllColumns,
    getDefaultValue,
    addElement,
    deleteElement,
} from '../util'

export default class extends React.Component {
    constructor(props) {
        super(props)
        this.additionalParamNameArr = (this.props.additionalParams || []).map(
            param => param.paramName
        )

        const groupByType =
            this.props.groupByType !== undefined ? this.props.groupByType : true
        this.state = {
            groupByType,
        }
    }

    handleGroupByChange = () => {
        this.setState({
            groupByType: !this.state.groupByType,
        })
    }

    /**
     * 选中某一行
     */
    rowSelect = (record, selected) => {
        const { isSelectMulti, selectableColumns } = this.props
        let selectedArr = this.props.selectedColumns || []
        selectedArr = filterColumnsInAllColumns(selectedArr, selectableColumns)

        selectedArr = setSelectedArrVariable(
            selectedArr,
            isSelectMulti,
            record,
            selected
        )
        this.setSelectedRows(selectedArr)
    }

    rowMultiSelect = (recordArray, selected) => {
        const { isSelectMulti, selectableColumns } = this.props
        let selectedArr = this.props.selectedColumns || []
        selectedArr = filterColumnsInAllColumns(selectedArr, selectableColumns)

        recordArray.forEach(record => {
            selectedArr = setSelectedArrVariable(
                selectedArr,
                isSelectMulti,
                record,
                selected
            )
        })

        this.setSelectedRows(selectedArr)
    }

    rowSelectAll = selected => {
        const { isSelectMulti, selectableColumns } = this.props
        let selectedArr = this.props.selectedColumns || []
        selectedArr = filterColumnsInAllColumns(selectedArr, selectableColumns)

        let filteredSeletableColumns =
            this.getFilteredColumns(selectableColumns) || []
        filteredSeletableColumns.forEach(col => {
            selectedArr = setSelectedArrVariable(
                selectedArr,
                isSelectMulti,
                col,
                selected
            )
        })
        this.setSelectedRows(selectedArr)
    }
    /**
     * 设置选中的列. 根据additionalParams 给新的行设置默认值
     */
    setSelectedRows = selectedRows => {
        const { additionalParams } = this.props

        selectedRows = selectedRows.map(row => {
            for (let i = 0; i < this.props.selectedColumns.length; i++) {
                if (this.props.selectedColumns[i].name === row.name) {
                    return row
                }
            }

            //新列, 需要设置默认值
            this.additionalParamNameArr.forEach(paramName => {
                row[paramName] = getDefaultValue(
                    additionalParams,
                    paramName,
                    row
                )
            })
            return row
        })

        this.props.onChangeSelectedColumns(selectedRows)
    }

    getFilteredColumns = columnArray => {
        let { keywords } = this.props
        keywords = keywords || ''
        return (columnArray || [])
            .filter(r => {
                return r.name.toLowerCase().includes(keywords.toLowerCase())
            })
            .map(col => ({
                ...col,
                key: col.name,
            }))
    }

    render() {
        const { isSelectMulti, allColumns, selectableColumns } = this.props
        const selectedColumns = this.props.selectedColumns || []
        const filteredAllColumns = this.getFilteredColumns(allColumns) || []
        const filteredSeletableColumns =
            this.getFilteredColumns(selectableColumns) || []
        const selectedRowKeys = selectedColumns.map(col => col.name)

        if (this.state.groupByType) {
            return (
                <LeftTableTypeGroupedView
                    isSelectMulti={isSelectMulti}
                    allColumns={filteredAllColumns}
                    selectableColumns={filteredSeletableColumns}
                    selectedRowKeys={selectedRowKeys}
                    selectedColumns={selectedColumns}
                    rowSelectAll={this.rowSelectAll}
                    rowSelect={this.rowSelect}
                    rowMultiSelect={this.rowMultiSelect}
                    onGroupByChange={this.handleGroupByChange}
                />
            )
        } else {
            return (
                <LeftTableView
                    isSelectMulti={isSelectMulti}
                    allColumns={filteredAllColumns}
                    selectableColumns={filteredSeletableColumns}
                    selectedRowKeys={selectedRowKeys}
                    rowSelect={this.rowSelect}
                    rowSelectAll={this.rowSelectAll}
                    onGroupByChange={this.handleGroupByChange}
                />
            )
        }
    }
}

/**
 * 根据是否多选，选择的行，是否选中，已经选中的行来返回新的返回的行
 */
const setSelectedArrVariable = (
    selectedArr,
    isSelectMulti,
    record,
    selected
) => {
    if (isSelectMulti && selected) {
        //支持多选, 选中该元素
        addElement(selectedArr, record)
    } else if (isSelectMulti && !selected) {
        //支持多选, 反选该元素
        deleteElement(selectedArr, record)
    } else if (!isSelectMulti && selected) {
        //仅支持单选
        selectedArr = [record]
    } else {
        selectedArr = []
    }
    return selectedArr
}
