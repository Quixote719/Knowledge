// 选择字段功能组件
import React from 'react'
import { Icon, Checkbox, Radio } from 'antd'
import styles from './LeftTableTypeGroupedView.less'

export default class extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            leftCloseList: [] //左侧可选列表关闭的类型
        }
    }

    get seletableTypes() {
        const res = []
        this.props.selectableColumns.forEach(col => {
            const type = col.type ? col.type.toLowerCase() : '未知'
            if (!res.includes(type)) {
                res.push(type)
            }
        })
        return res
    }

    get selectableNames() {
        return this.props.selectableColumns.map(col => col.name)
    }

    //将可选列表数据按type分类
    groupDataByType = data => {
        let obj = {}
        data.forEach(item => {
            const type = item.type ? item.type.toLowerCase() : '未知'
            if (obj.hasOwnProperty(type)) {
                obj[type].push(item)
            } else {
                obj[type] = []
                obj[type].push(item)
            }
        })
        return obj
    }

    /**
     * 选中某一类型
     */
    onSelectType = (type, selected) => {
        const { selectableColumns, rowMultiSelect } = this.props
        const typeDataSource = this.groupDataByType(selectableColumns)
        rowMultiSelect(typeDataSource[type] || [], selected)
    }

    //开关子类型
    onToggleTypeVisibility = type => {
        const newList = this.state.leftCloseList.slice()
        if (newList.includes(type)) {
            const index = newList.indexOf(type)
            newList.splice(index, 1)
        } else {
            newList.push(type)
        }
        this.setState({
            leftCloseList: newList
        })
    }

    /**
     * 渲染某一类型的字段
     */
    renderOneType = (typeDataSource, type) => {
        const leftCloseList = this.state.leftCloseList || []
        const contentLi = typeDataSource[type].map((content, index) => {
            return this.renderOneRow(content, index)
        })

        return (
            <li className={styles.typeLi} key={type}>
                <div className={styles.titleLi}>
                    {this.renderTypeSelectBtn(typeDataSource, type)}
                    <span
                        className={`${styles.showIcon} ${leftCloseList.includes(
                            type
                        ) && styles.close}`}
                        onClick={() => {
                            this.onToggleTypeVisibility(type)
                        }}>
                        <Icon type="caret-down" />
                    </span>
                </div>
                <ul
                    className={`${styles.contentUl} ${leftCloseList.includes(
                        type
                    ) && styles.close}`}>
                    {contentLi}
                </ul>
            </li>
        )
    }

    renderTypeSelectBtn = (typeDataSource, type) => {
        type = type ? type.toLowerCase() : '未知'
        const { isSelectMulti, selectedRowKeys, rowSelect } = this.props
        const cols = typeDataSource[type]
        const allSelected =
            cols.length > 0 &&
            cols.every(obj => {
                return selectedRowKeys.includes(obj.key)
            })
        const oneSelected =
            cols.length > 0 &&
            cols.filter(obj => {
                return selectedRowKeys.includes(obj.key)
            }).length > 0

        if (isSelectMulti) {
            return (
                <Checkbox
                    indeterminate={oneSelected && !allSelected}
                    checked={allSelected}
                    onChange={e => {
                        this.onSelectType(type, e.target.checked)
                    }}
                    disabled={!this.seletableTypes.includes(type)}>
                    <span className={styles.labelSpan}>{type}</span>
                </Checkbox>
            )
        } else if (cols.length === 1) {
            return (
                <Radio
                    checked={allSelected}
                    onChange={e => {
                        this.onSelectType(type, e.target.checked)
                    }}
                    disabled={!this.seletableTypes.includes(type)}>
                    <span className={styles.labelSpan}>{type}</span>
                </Radio>
            )
        } else if (cols.length > 1) {
            return (
                <Radio
                    checked={oneSelected}
                    onChange={e => {
                        rowSelect(
                            cols.filter(c =>
                                this.selectableNames.includes(c.key)
                            )[0],
                            e.target.checked
                        )
                    }}
                    disabled={!this.seletableTypes.includes(type)}>
                    <span className={styles.labelSpan}>{type}</span>
                </Radio>
            )
        }
    }

    /**
     * 渲染一行字段
     */
    renderOneRow = (content, index) => {
        const { rowSelect, isSelectMulti } = this.props
        const selectedColumns = this.props.selectedColumns || []
        const InputType = isSelectMulti ? Checkbox : Radio
        const checked = selectedColumns
            .map(obj => obj.name)
            .includes(content.key)
        const cb = isSelectMulti
            ? {
                  onChange: e => {
                      rowSelect(content, e.target.checked)
                  }
              }
            : {
                  onClick: e => {
                      e.preventDefault()
                      e.stopPropagation()
                      rowSelect(content, !checked)
                  }
              }

        return (
            <li className={styles.contentLi} key={content.key + '-' + index}>
                <InputType
                    checked={checked}
                    {...cb}
                    disabled={!this.selectableNames.includes(content.key)}
                    style={{ wordBreak: 'break-all' }}>
                    {content.name}
                </InputType>
            </li>
        )
    }

    /**
     * 渲染数据质量组件-选择字段弹窗-可选列表
     * @returns {*}
     */
    renderLeftSelectTable = () => {
        const { allColumns } = this.props

        const typeDataSource = this.groupDataByType(allColumns)

        /**
         * 可选类型排前面
         */
        const sortByTypeSelectable = (typeA, typeB) => {
            const aSelectable = this.seletableTypes.includes(typeA)
            const bSelectable = this.seletableTypes.includes(typeB)
            if (
                (aSelectable && bSelectable) ||
                (!aSelectable && !bSelectable)
            ) {
                return 0
            } else if (aSelectable && !bSelectable) {
                return -1
            } else {
                return 1
            }
        }

        return (
            <ul className={styles.leftUl}>
                {Object.keys(typeDataSource)
                    .sort(sortByTypeSelectable)
                    .map(type => {
                        return this.renderOneType(typeDataSource, type)
                    })}
            </ul>
        )
    }

    render = () => {
        const {
            selectableColumns,
            selectedRowKeys,
            rowSelectAll,
            isSelectMulti
        } = this.props
        const selectedLen = selectableColumns.filter(col => {
            return selectedRowKeys.includes(col.key)
        }).length
        return (
            <div className={styles.leftTable}>
                {isSelectMulti ? (
                    <Checkbox
                        indeterminate={
                            selectedLen > 0 &&
                            selectedLen < selectableColumns.length
                        }
                        checked={
                            selectableColumns.length > 0 &&
                            selectableColumns.length === selectedLen
                        }
                        onChange={e => {
                            rowSelectAll(e.target.checked)
                        }}
                        className={styles.allSelectCheckbox}>
                        全选
                    </Checkbox>
                ) : (
                    <span>可选</span>
                )}
                <span
                    className={styles.groupByChange}
                    onClick={this.props.onGroupByChange}>
                    点击切换显示
                </span>
                {this.renderLeftSelectTable()}
            </div>
        )
    }
}
