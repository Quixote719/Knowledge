// 选择字段功能组件
import React from 'react'
import { Table, Select, Input, message, Tooltip, Icon } from 'antd'
import DragTable from '../../../DragTable'
import { COL_DEFAULT_WIDTH } from '../../tableDesc'

import {
    getDefaultValue,
    isOutputColumnValid,
    isComplexDropdownColumnsValid,
} from '../util'
import RightModal from '../RightModal'
import {
    getOutputSchema,
    filterColumnsInAllColumnCombination,
    addElement,
    deleteElement,
    getElePos,
    getDerivedInput2,
} from './util'
import styles from './Modal.less'

const Option = Select.Option

export default class extends React.Component {
    constructor(props) {
        super(props)
        const { selectedColumns, additionalParams, input1 } = this.props
        this.additionalParamNameArr = additionalParams.map(
            param => param.paramName
        )
        this.state = {
            selectedColumns: selectedColumns || [],
            currInput1:
                input1 &&
                input1.length > 0 &&
                (input1.find(row => !row.disabled)
                    ? input1.find(row => !row.disabled).value
                    : ''), //input1[0].value,
        }
    }
    /**
     * 输出字段是否有效
     */
    get isOutputColumnValid() {
        const { required } = this.props
        const selectedColumns = this.state.selectedColumns || []
        if (required && selectedColumns.length === 0) {
            return {
                isValid: false,
                errorMessage: '必须选中至少一个字段',
            }
        }

        return isOutputColumnValid({
            additionalParams: this.props.additionalParams,
            selectedColumns: this.state.selectedColumns,
        })
    }

    /**
     * 参数是否来自于正确的表结构
     */
    get isColsFromRightSchema() {
        return isComplexDropdownColumnsValid(
            this.state.selectedColumns,
            this.props.input1
        )
    }
    //弹窗内点击取消按钮
    handleCancelButton = () => {
        this.props.onCancel()
    }
    // 把选择的字段传给组件显示
    handleOKButton = () => {
        if (!this.isOutputColumnValid.isValid) {
            return message.error(
                `无法保存：${this.isOutputColumnValid.errorMessage}`
            )
        }
        this.props.onConfirm(this.state.selectedColumns)
    }
    handleMoveOutputRow = selectedColumns => {
        this.setState({ selectedColumns })
    }
    /**
     * 附加参数变化
     */
    handleAdditionalParamChange = (value, paramDesc, index) => {
        let selectedColumns = this.state.selectedColumns.slice()
        let record = selectedColumns[index]
        record[paramDesc.paramName] = value
        this.setState({
            selectedColumns: selectedColumns,
        })
    }

    /**
     * 获得input2表格的数据
     */
    getThisDerivedInput2 = (currInput1 = this.state.currInput1) => {
        const { input1, input2 } = this.props

        return getDerivedInput2(input1, input2, currInput1)
    }
    /**
     * 获得input2中文
     */
    getInput2RenderValue = (text, record) => {
        const { input2 } = this.props
        const derivedInput2 = this.getThisDerivedInput2(record.input1)
        if (derivedInput2.find(row => row.value === text)) {
            return derivedInput2.find(row => row.value === text).name
        } else if (typeof input2 === 'function') {
            const input2List = input2({ type: record.input1Type }) || []
            if (input2List.find(row => row.value === text)) {
                return input2List.find(row => row.value === text).name
            }
        }
        return '???'
    }
    /**
     * 选中某一行
     */
    rowSelect = (record, selected) => {
        if (!this.state.currInput1) {
            return message.warn('请先选择字段')
        }

        const { isSelectMulti, input1 } = this.props

        record = {
            input1: this.state.currInput1,
            input2: record.value,
        }
        let selectedArr = this.state.selectedColumns.slice()

        if (isSelectMulti && selected) {
            //支持多选, 选中该元素
            addElement(selectedArr, record, ['input1', 'input2'])
        } else if (isSelectMulti && !selected) {
            //支持多选, 反选该元素
            deleteElement(selectedArr, record, ['input1', 'input2'])
        } else {
            //仅支持单选
            selectedArr = [record]
        }

        //删除无效的行
        selectedArr = filterColumnsInAllColumnCombination(
            selectedArr,
            input1,
            this.props.input2
        )

        this.setSelectedRows(selectedArr)
    }

    rowSelectAll = (selected, selectedRows) => {
        if (!this.state.currInput1) {
            return message.warn('请先选择字段')
        }

        let newSelectedArr
        //已经选择的所有行
        let oldSelectedArr = this.state.selectedColumns.slice()

        if (selected) {
            //当前表当中选中的行, 且非已选的行
            selectedRows = selectedRows
                .map(col => ({
                    input1: this.state.currInput1,
                    input2: col.value,
                }))
                .filter(record => {
                    return (
                        getElePos(oldSelectedArr, record, [
                            'input1',
                            'input2',
                        ]) === -1
                    )
                })
            newSelectedArr = oldSelectedArr.concat(selectedRows)
        } else {
            //清空
            newSelectedArr = oldSelectedArr.filter(record => {
                return record.input1 !== this.state.currInput1
            })
        }

        this.setSelectedRows(newSelectedArr)
    }

    /**
     * 设置选中的列. 根据additionalParams 给新的行设置默认值
     */
    setSelectedRows = selectedRows => {
        const { additionalParams, input1 } = this.props

        selectedRows = selectedRows.map(row => {
            for (let i = 0; i < this.state.selectedColumns.length; i++) {
                if (
                    this.state.selectedColumns[i].input1 === row.input1 &&
                    this.state.selectedColumns[i].input2 === row.input2
                ) {
                    //拷贝已有列的数据row中。否则在有部分元素被选中的表单中执行全选操作时，会出现异常
                    const temp = { ...row }
                    this.additionalParamNameArr.forEach(paramName => {
                        temp[paramName] = this.state.selectedColumns[i][
                            paramName
                        ]
                    })
                    return temp
                }
            }

            //新列, 需要设置默认值
            this.additionalParamNameArr.forEach(paramName => {
                row[paramName] = getDefaultValue(
                    additionalParams,
                    paramName,
                    row
                )
            })
            row.input1Type = input1.find(item => row.input1 === item.value).type // 存储input1类型，方便切换数据源时，可以找到input2的中文显示
            return row
        })

        this.setState({
            selectedColumns: selectedRows,
        })
    }

    renderInput1 = () => {
        const input1 = this.props.input1 || []
        return (
            <Select
                style={{ width: '200px' }}
                value={this.state.currInput1}
                onChange={val => {
                    this.setState({ currInput1: val })
                }}
            >
                {input1.map(row => (
                    <Option
                        value={row.value}
                        key={row.value}
                        disabled={row.disabled || false}
                    >
                        {row.name}
                    </Option>
                ))}
            </Select>
        )
    }
    renderInput2AsTable = () => {
        const derivedInput2 = this.getThisDerivedInput2()

        const { input2TableHead, isSelectMulti } = this.props
        const selectedRowKeys = (this.state.selectedColumns || [])
            .filter(col => col.input1 === this.state.currInput1)
            .map(col => col.input2)

        return (
            <Table
                dataSource={derivedInput2}
                scroll={{ y: 700 }}
                columns={[
                    {
                        title: input2TableHead,
                        dataIndex: 'name',
                        width: COL_DEFAULT_WIDTH,
                        key: 'name',
                    },
                ]}
                rowSelection={{
                    onSelect: this.rowSelect,
                    onSelectAll: this.rowSelectAll,
                    type: isSelectMulti ? 'checkbox ' : 'radio',
                    selectedRowKeys: selectedRowKeys,
                }}
                pagination={false}
                bordered
            />
        )
    }
    renderOutputTable = () => {
        let tableSchema = getOutputSchema(
            this.props,
            this.renderAdditionalParams,
            COL_DEFAULT_WIDTH,
            this.deleteRow
        )

        tableSchema.map(row => {
            if (row.key === 'input2') {
                // 将分析指标值改为中文
                row.render = (text, record) =>
                    this.getInput2RenderValue(text, record)
            }
            return row
        })
        const selectedColumns = this.state.selectedColumns || []
        return (
            <DragTable
                dataSource={selectedColumns}
                columns={tableSchema}
                pagination={false}
                bordered
                scroll={{ y: 700 }}
                onMove={this.handleMoveOutputRow}
            />
        )
    }
    deleteRow = index => {
        this.setState({
            selectedColumns: [
                ...this.state.selectedColumns.slice(0, index),
                ...this.state.selectedColumns.slice(index + 1),
            ],
        })
    }
    renderAdditionalParams = (paramDesc, record, index) => {
        let key = paramDesc.paramName
        let value = record[key]
        if (!paramDesc.hasOwnProperty('inputType')) {
            return <span>{value}</span>
        } else if (paramDesc.inputType === 'textInput') {
            return (
                <Input.TextArea
                    autosize
                    value={value}
                    style={{ width: '100px', resize: 'none' }}
                    onChange={e => {
                        this.handleAdditionalParamChange(
                            e.target.value,
                            paramDesc,
                            index
                        )
                    }}
                />
            )
        } else if (
            paramDesc.inputType === 'dropdown' &&
            Array.isArray(paramDesc.options)
        ) {
            return (
                <Select
                    dropdownMatchSelectWidth={false}
                    onChange={value =>
                        this.handleAdditionalParamChange(
                            value,
                            paramDesc,
                            index
                        )
                    }
                    style={{ minWidth: '77px' }}
                    value={value}
                >
                    {paramDesc.options.map(opt => {
                        return (
                            <Option value={opt.value} key={opt.value}>
                                {opt.text}
                            </Option>
                        )
                    })}
                </Select>
            )
        }
    }
    render() {
        const {
            isSelectMulti,
            input2Label,
            outputLabel,
            input1Label,
        } = this.props
        return (
            <RightModal
                onOk={this.handleOKButton}
                onCancel={this.handleCancelButton}
                title={input1Label}
            >
                {this.renderInput1()}
                <div
                    className={`${styles.container} ${
                        isSelectMulti ? styles.multi : styles.single
                    }`}
                >
                    <div className={styles.leftTable}>
                        {input2Label}
                        {this.renderInput2AsTable()}
                    </div>
                    <div className={styles.rightTable}>
                        {outputLabel}
                        {!this.isOutputColumnValid.isValid && (
                            <Tooltip
                                placement="top"
                                title={this.isOutputColumnValid.errorMessage}
                            >
                                <span>
                                    <Icon
                                        type="exclamation-circle-o"
                                        className={styles.errorIcon}
                                    />
                                </span>
                            </Tooltip>
                        )}
                        {!this.isColsFromRightSchema && (
                            <Tooltip placement="top" title="参数无效">
                                <span>
                                    <Icon
                                        type="exclamation-circle-o"
                                        className={styles.warnIcon}
                                    />
                                </span>
                            </Tooltip>
                        )}
                        {this.renderOutputTable()}
                    </div>
                </div>
            </RightModal>
        )
    }
}
