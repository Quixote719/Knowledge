import React from 'react'

export const getOutputSchema = (
    props,
    renderAdditionalParams,
    COL_DEFAULT_WIDTH,
    deleteRow
) => {
    const { input1TableHead, input2TableHead, additionalParams } = props

    let tableSchema = [
        {
            title: input1TableHead,
            dataIndex: 'input1',
            key: 'input1',
            width: COL_DEFAULT_WIDTH,
        },
        {
            title: input2TableHead,
            dataIndex: 'input2',
            key: 'input2',
            width: COL_DEFAULT_WIDTH,
        },
    ]
    for (let i = 0; i < additionalParams.length; i++) {
        tableSchema.push({
            title: additionalParams[i].title,
            dataIndex: additionalParams[i].paramName,
            key: additionalParams[i].paramName,
            width: COL_DEFAULT_WIDTH,
            render: (text, record, index) => {
                return renderAdditionalParams(
                    additionalParams[i],
                    record,
                    index
                )
            },
        })
    }

    if (typeof deleteRow === 'function') {
        tableSchema.push({
            title: '操作',
            dataIndex: 'operation',
            width: 55,
            key: 'operation',
            render: (text, record, index) => {
                return (
                    <span>
                        <a
                            style={{ marginLeft: 5 }}
                            onClick={() => {
                                deleteRow(index)
                            }}
                        >
                            删除
                        </a>
                    </span>
                )
            },
        })
    }

    return tableSchema
}

export const filterColumnsInAllColumnCombination = (
    selectedColumns = [],
    input1,
    getInput2
) => {
    return selectedColumns.filter(col => {
        for (let i = 0; i < input1.length; i++) {
            if (input1[i].value === col.input1) {
                const input2 =
                    typeof getInput2 === 'function'
                        ? getInput2(input1[i])
                        : getInput2 || []
                for (let i = 0; i < input2.length; i++) {
                    if (input2[i].value === col.input2) {
                        return true
                    }
                }
            }
        }
        return false
    })
}

export const addElement = (eleArr, ele, keyArr) => {
    const elePos = getElePos(eleArr, ele, keyArr)
    if (elePos === -1) eleArr.push(ele)
}
export const deleteElement = (eleArr, ele, keyArr) => {
    const elePos = getElePos(eleArr, ele, keyArr)
    if (elePos !== -1) eleArr.splice(elePos, 1)
}

export const getElePos = (eleArr, ele, keyArr) => {
    let elePos = -1
    for (let i = 0; i < eleArr.length; i++) {
        let allMatch = true
        for (let key of keyArr) {
            if (eleArr[i][key] !== ele[key]) allMatch = false
        }
        if (allMatch) {
            elePos = i
            break
        }
    }
    return elePos
}

/**
 * 若input2是函数, 则将当前input1的值作为参数作为函数，函数返回值作为input2表格的数据
 * 否则则直接返回input2
 */
export const getDerivedInput2 = (input1, input2, currInput1) => {
    if (typeof input2 === 'function') {
        let input1Record = null

        //找到当前Input1对应的数据
        if (currInput1) {
            for (let i = 0; i < input1.length; i++) {
                if (input1[i].value === currInput1) {
                    input1Record = input1[i]
                    break
                }
            }
        }

        if (input1Record) {
            return input2(input1Record)
        } else {
            return []
        }
    } else {
        return input2 || []
    }
}
