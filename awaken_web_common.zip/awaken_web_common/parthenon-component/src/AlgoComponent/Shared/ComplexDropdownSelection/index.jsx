// 选择字段功能组件

import React from 'react'
import { Button, Popover, Table, Tooltip, Icon } from 'antd'

import { isComplexDropdownColumnsValid } from '../util'
import { BUTTON_DEFAULT_WIDTH, COL_DEFAULT_WIDTH } from '../../tableDesc'

import { getOutputSchema, getDerivedInput2 } from './util'
import ComplexDropdownSelectModal from './Modal'
import styles from './index.less'

/**
 * 选择字段按钮
 * 点击该按钮会弹出选择字段弹窗
 * 弹窗确定后会返回选择的字段结果
 */
export default class extends React.Component {
    static defaultProps = {
        buttonText: '选择',
    }

    constructor(props) {
        super(props)
        this.state = {
            showModal: false,
        }
    }

    get isParamsValid() {
        const { required = true, selectedColumns = [] } = this.props
        if (!required || selectedColumns.length > 0) {
            return {
                isValid: true,
            }
        } else {
            return {
                isValid: false,
                errorMessage: '必须选中至少一个字段',
            }
        }
    }

    //点击选择按钮, 打开字段筛选弹窗
    handleClickButton = () => {
        this.setState({
            showModal: true,
        })
    }

    /**
     * 取消字段筛选
     */
    handleCancel = () => {
        this.setState({
            showModal: false,
        })
    }

    /**
     * 字段筛选保存结果
     */
    handleSelectColumns = (...rest) => {
        this.setState({
            showModal: false,
        })
        this.props.onSelectFields(...rest)
    }
    /**
     * 获得input2表格的数据
     */
    getThisDerivedInput2 = currInput1 => {
        const { input1, input2 } = this.props
        return getDerivedInput2(input1, input2, currInput1)
    }
    /**
     * 获得input2中文
     */
    getInput2RenderValue = (text, record) => {
        const { input2 } = this.props
        const derivedInput2 = this.getThisDerivedInput2(record.input1)
        if (derivedInput2.find(row => row.value === text)) {
            return derivedInput2.find(row => row.value === text).name
        } else if (typeof input2 === 'function') {
            const input2List = input2({ type: record.input1Type }) || []
            if (input2List.find(row => row.value === text)) {
                return input2List.find(row => row.value === text).name
            }
        }
        return '???'
    }
    /**
     * 渲染输出的表单
     */
    renderPopupSelectedTable = () => {
        let { selectedColumns } = this.props

        let tableSchema = getOutputSchema(
            this.props,
            this.renderAdditionalParams,
            COL_DEFAULT_WIDTH
        )

        tableSchema.map(row => {
            if (row.key === 'input2') {
                // 将分析指标值改为中文
                row.render = (text, record) =>
                    this.getInput2RenderValue(text, record)
            }
            return row
        })

        return (
            <Table
                dataSource={selectedColumns}
                columns={tableSchema}
                pagination={false}
                bordered
            />
        )
    }

    renderAdditionalParams = (paramDesc, record) => {
        let key = paramDesc.paramName
        let value = record[key]
        if (
            !paramDesc.hasOwnProperty('inputType') ||
            paramDesc.inputType === 'textInput'
        ) {
            return <span>{value}</span>
        } else if (
            paramDesc.inputType === 'dropdown' &&
            Array.isArray(paramDesc.options)
        ) {
            for (let i = 0; i < paramDesc.options.length; i++) {
                if (paramDesc.options[i].value === value) {
                    return <span>{paramDesc.options[i].text}</span>
                }
            }
        }
    }

    renderModal = () => {
        let {
            input1,
            input2,
            input1Label,
            input2Label,
            outputLabel,
            input1TableHead,
            input2TableHead,
            selectedColumns,
            additionalParams,
            isSelectMulti,
            required = true,
        } = this.props
        additionalParams = additionalParams || []
        return (
            <ComplexDropdownSelectModal
                input1={input1}
                input2={input2}
                input1Label={input1Label}
                input2Label={input2Label}
                outputLabel={outputLabel}
                input1TableHead={input1TableHead}
                input2TableHead={input2TableHead}
                isSelectMulti={isSelectMulti}
                selectedColumns={selectedColumns}
                additionalParams={additionalParams}
                onCancel={this.handleCancel}
                onConfirm={this.handleSelectColumns}
                required={required}
            />
        )
    }

    render() {
        const {
            buttonText,
            hidePopupOutput,
            selectedColumns,
            input1,
        } = this.props
        const isColsValid = isComplexDropdownColumnsValid(
            selectedColumns,
            input1
        )

        const btn = (
            <Button
                disabled={this.props.disabled}
                className={
                    styles.button +
                    ' ' +
                    (this.props.disabled ? styles.transparent : '')
                }
                onClick={this.handleClickButton}
                style={{ width: BUTTON_DEFAULT_WIDTH }}
            >
                {buttonText}
            </Button>
        )
        return (
            <div>
                {this.state.showModal || hidePopupOutput ? (
                    btn
                ) : (
                    <Popover
                        placement="left"
                        content={this.renderPopupSelectedTable()}
                        mouseEnterDelay={0.2}
                    >
                        {btn}
                    </Popover>
                )}
                {!isColsValid && (
                    <span style={{ marginLeft: 10, display: 'inline-block' }}>
                        <Tooltip placement="top" title="参数无效">
                            <span>
                                <Icon
                                    type="exclamation-circle-o"
                                    style={{
                                        color: '#faad14',
                                        transform: 'scale(1.2)',
                                    }}
                                />
                            </span>
                        </Tooltip>
                    </span>
                )}
                {!this.isParamsValid.isValid && (
                    <span style={{ marginLeft: 10, display: 'inline-block' }}>
                        <Tooltip
                            placement="top"
                            title={this.isParamsValid.errorMessage}
                        >
                            <span>
                                <Icon
                                    type="exclamation-circle-o"
                                    style={{
                                        color: '#fa4646',
                                        transform: 'scale(1.2)',
                                    }}
                                />
                            </span>
                        </Tooltip>
                    </span>
                )}
                {this.state.showModal && this.renderModal()}
            </div>
        )
    }
}
