import React from 'react'
import { Icon } from 'antd'
import moment from 'moment'

import InputOrDatePicker from '../InputOrDatePicker'

import styles from './index.less'

export default class EditLabels extends React.Component {
    constructor(props) {
        super(props)

        this.state = {
            inputValue: '',
        }
    }
    handleInputChange = value => {
        this.setState({
            inputValue: value,
        })
    }
    handleConfirm = value => {
        const { onAddLabel, isDate } = this.props
        this.setState({
            inputValue: '',
        })

        if (isDate) {
            onAddLabel([value])
        } else {
            const valueArray = value.split(',')
            const tempMap = {}
            const labelsToAdd = []
            for (let i = 0; i < valueArray.length; i++) {
                if (valueArray[i].length > 0) {
                    if (!tempMap.hasOwnProperty(valueArray[i])) {
                        labelsToAdd.push(valueArray[i])
                        tempMap[valueArray[i]] = true
                    }
                }
            }
            onAddLabel(labelsToAdd)
        }
    }
    render() {
        const {
            onDeleteLabel,
            labels = [],
            isDate = false,
            format,
            placeholder = '请输入，用","分开',
            labelContainerStyle = {},
            style = {}
        } = this.props

        return (
            <div style={style}>
                <div className={styles.labelContainer} style={labelContainerStyle}>
                    {labels
                        .filter(w => w && w.toString().length > 0)
                        .map((label, index) => {
                            const text = isDate
                                ? moment(parseInt(label)).format(
                                    'YYYY-MM-DD HH:mm:ss'
                                )
                                : label
                            return (
                                <span className={styles.label} key={index}>
                                    {text}
                                    <Icon
                                        type="close"
                                        className={styles.closeBtn}
                                        onClick={() =>
                                            onDeleteLabel &&
                                            onDeleteLabel(index)
                                        }
                                    />
                                </span>
                            )
                        })}
                </div>
                <InputOrDatePicker
                    value={this.state.inputValue}
                    onOk={this.handleConfirm}
                    onBlur={this.handleConfirm}
                    onChange={this.handleInputChange}
                    placeholder={placeholder}
                    isDate={isDate}
                    format={format}
                />
            </div>
        )
    }
}
