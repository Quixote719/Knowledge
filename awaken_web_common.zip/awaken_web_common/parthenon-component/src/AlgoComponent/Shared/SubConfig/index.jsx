import React from 'react'
import styles from './index.less'

export default class extends React.Component {
    render() {
        const { title, isRequire, children, maxLength } = this.props
        return (
            <div className={styles.subConfig}>
                <div className={styles.subTitle}>
                    {isRequire ? (
                        <span className={styles.subTitle}>*</span>
                    ) : null}
                    {title}
                </div>
                <div className={styles.subContent} maxLength={maxLength}>
                    {children}
                </div>
            </div>
        )
    }
}
