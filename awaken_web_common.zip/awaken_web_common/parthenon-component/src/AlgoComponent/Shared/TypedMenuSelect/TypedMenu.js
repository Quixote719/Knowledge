/**
 * Created by yaojia7 on 2019/3/4.
 */
import React from 'react';
import memoize from 'memoize-one';
import {Menu, Checkbox} from 'antd';
import styles from './index.less';

const SubMenu = Menu.SubMenu;
const Item = Menu.Item;

const classify = memoize((fields) => {
    const typeMap = {};
    for(let f of fields){
        if(!typeMap[f.fieldType]) {
            typeMap[f.fieldType] = [];
        }
        typeMap[f.fieldType].push({
            fieldName: f.fieldName,
            fieldType: f.fieldType,
            selected: f.selected
        });
    }
    return typeMap;
});

export default class extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            data: {},
            openKeys: [],
            lastFields: []
        };
    }

    static getDerivedStateFromProps(props, state){
        if(props.fields !== state.lastFields){
            const nextData = classify(props.fields);
            return {
                data: nextData,
                openKeys: nextData._keys(),
                lastFields: props.fields
            };
        }

        return null
    }

    handleOpenKeysChange = (openKeys) => {
        this.setState({ openKeys });
    };

    handleChange = (type, key, e) => {
        try {
            const selected = e.target.checked;
            const {data} = this.state;
            const {onChange} = this.props;
            if (type === 'fieldType') {
                data[key].forEach(f => {
                    f.selected = selected;
                });
            } else {
                for (let fieldType in data) {
                    let field = data[fieldType].find(f => f.fieldName === key);
                    if (field) {
                        field.selected = selected;
                        break;
                    }
                }
            }
            onChange(data);
        } catch (e){
            console.log(e);
        }
    };

    render(){
        const {data, openKeys} = this.state;
        return (
            <div className={styles.menu}>
                <Menu
                    mode="inline"
                    selectable={false}
                    openKeys={openKeys}
                    onOpenChange={this.handleOpenKeysChange}
                >
                    {
                        Object.keys(data).map(k => <SubMenu
                            key={k}
                            title={
                                <span>
                                    <Checkbox
                                        checked={data[k].every(f => f.selected)}
                                        onChange={this.handleChange.bind(this, 'fieldType', k)}
                                    />
                                    {k}
                                </span>
                            }
                        >
                            {
                                data[k].map(i =>
                                    <Item key={i.fieldName}>
                                        <Checkbox checked={i.selected} onChange={this.handleChange.bind(this, 'field', i.fieldName)}/>
                                        <span>{i.fieldName}</span>
                                    </Item>
                                )
                            }
                        </SubMenu>)
                    }
                </Menu>
            </div>
        )
    }
};
