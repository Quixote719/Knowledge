/**
 * Created by yaojia7 on 2019/3/4.
 */
import React from 'react';
import Proptypes from 'prop-types';
import memoize from 'memoize-one';
import {Checkbox, Modal, Table, Input, Button, Tooltip} from 'antd';
import TypeMenu from './TypedMenu';
import TableWithDel from './TableWithDelete';
import styles from './index.less';

//生成固定宽度的表格列
const genFixedColumn = (key, dataIndex, title, width) => {
    return {
        key,
        dataIndex,
        title,
        width,
        render: (text) => <Tooltip title={text}>
                <div style={{
                    width: '100%',
                    overflow: 'hidden',
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap'
                }}>{text}</div>
            </Tooltip>
    }
};

const COLUMNS = [
    genFixedColumn('fieldName', 'fieldName', '字段名', 120),
    genFixedColumn('fieldType', 'fieldType', '字段类型', 100),
    genFixedColumn('fieldDesc', 'fieldDesc', '字段描述', 120),
];

export default class extends React.Component{
    static propTypes = {
        inputFields: Proptypes.arrayOf(Proptypes.shape({
            fieldName: Proptypes.string.isRequired,
            fieldType: Proptypes.string,
            fieldDesc: Proptypes.string
        })),
        outputFields: Proptypes.arrayOf(Proptypes.shape({
            fieldName: Proptypes.string.isRequired,
            fieldType: Proptypes.string,
            fieldDesc: Proptypes.string
        })),
        visible: Proptypes.bool.isRequired,
        onSave: Proptypes.func.isRequired,
        onCancel: Proptypes.func.isRequired
    };

    static defaultProps = {
        inputFields: [],
        outputFields: []
    };

    state = {
        keywords: '',
        filterWords: '',
        fields: [], //输出字段数组
        lastOutputFields: this.props.outputFields
    };

    static getDerivedStateFromProps(props, state) {
        if (props.outputFields !== state.lastOutputFields)
            return { fields: props.outputFields.slice(),  lastOutputFields: props.outputFields};
        return null;
    }

    handleInput = e => {
        this.setState({keywords: e.target.value});
    };

    handleSearch = () => {
        this.setState({filterWords: this.state.keywords});
    };

    handleSelectAll = (e) => {
        const {inputFields} = this.props;
        const checked = e.target.checked;
        this.setState({
            fields: checked ? inputFields.slice() : []
        });
    };


    handleSelectFields = data => {
        let fields = [];
        for(let ft in data){
            for(let f of data[ft]){
                if(f.selected)
                    fields.push(f);
            }
        }
        this.setState({fields});
    };

    handleDeleteField = fieldName => {
        const fields = [...this.state.fields];
        let index = fields.findIndex(f => f.fieldName === fieldName);
        if(index > -1){
            fields.splice(index, 1);
            this.setState({fields});
        }
    };

    handleSave = () => {
        this.props.onSave(this.state.fields);
        this.handleCancel();
    };

    handleCancel = () => {
        this.setState({
            keywords: '',
            filterWords: ''
        });
        this.props.onCancel();
    };

    getInputFields = memoize((inputFields, outputFields, filterWords) => {
        return inputFields
            .filter(f => !filterWords || f.fieldName.includes(filterWords))
            .map(f => ({
                ...f,
                selected: outputFields.find(of => of.fieldName === f.fieldName) ? true : false
            }));
    });

    render(){
        const {inputFields, visible} = this.props;
        const {fields, keywords, filterWords} = this.state;

        return (
            <Modal
                title="选择字段"
                width={900}
                visible={visible}
                okText="保存"
                cancelText="取消"
                onOk={this.handleSave}
                onCancel={this.handleCancel}
            >
                <div className={styles.searchZone}>
                    <Input.Search value={keywords} onChange={this.handleInput} onSearch={this.handleSearch}/>
                </div>
                <div className={styles.tableZone}>
                    <div>
                        <div className={styles.allSelect}>
                            <Checkbox
                                checked={inputFields.length === fields.length}
                                onChange={this.handleSelectAll}
                            />
                            全选
                        </div>
                        <TypeMenu
                            fields={this.getInputFields(inputFields, fields, filterWords)}
                            onChange={this.handleSelectFields}
                        />
                    </div>
                    <TableWithDel
                        title="已选"
                        data={fields.map(f => ({...f, key: f.fieldName}))}
                        columns={COLUMNS}
                        onDelete={this.handleDeleteField}
                    />
                </div>
            </Modal>
        )
    }
}
