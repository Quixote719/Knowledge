/**
 * Created by yaojia7 on 2019/3/4.
 */
import React from 'react';
import {Table, Icon} from 'antd';

export default ({data = [], columns = [], height = 500, onDelete = () => {}, size='small', title=null}) => {
    const newColums = [...columns];
    newColums.unshift(
        {
            key: 'action',
            dataIndex: 'action',
            title: '',
            width: 32,
            render: (text, record) => {
                return <Icon
                    type="delete"
                    onClick={() => {
                        if (record)
                            onDelete(record.key);
                    }}/>
            },
        }
    );

    const props = {
        size,
        dataSource: data,
        columns: newColums,
        bordered: true,
        pagination: false,
        scroll: {y: height}
    };
    if(title)
        props.title= typeof title === 'function' ? title : () => title;

    return <Table
        {...props}
    />;
};
