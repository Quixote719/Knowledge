// 选择字段功能组件

import React from 'react'
import { Form, Radio, Input, Select, Tooltip, Icon } from 'antd'
// import {toJS} from 'mobx'
import styles from './index.less'

import SubConfig from '../SubConfig'
import SelectFields from '../SelectFields'

import { getFormItemState } from '../../common'
import { mapToTuple } from '../../transformHelper'
import { isDateType } from '../../typeHelper'
import { positiveIntegerValidator, maxValidator } from '../../inputValidator'

const FormItem = Form.Item
const RadioGroup = Radio.Group
const Option = Select.Option

const MAX_NUMBER = Math.pow(2, 31) // INT最大值。

/**
 * Props:
 * 1. 参数: slideType, windowSize, windowStep, timeCol, timeWindowSize, timeWindowStep, timeWindowSizeUnit, timeWindowStepUnit,
 * 2. 状态: paramState
 * 3. 保存: saveParams
 */

/**
 *  时间滑窗
 */
class TimeSlide extends React.Component {
    static defaultProps = {
        title: '滑窗参数',
        slideType: 'record',
        windowSize: '',
        windowStep: '',
        timeCol: '',
        timeWindowSize: '',
        timeWindowStep: '',
        timeWindowSizeUnit: '',
        timeWindowStepUnit: '',
        allColumns: [],
    }

    constructor(props) {
        super(props)
        const {
            slideType,
            windowSize,
            windowStep,
            timeCol,
            timeWindowSize,
            timeWindowStep,
            timeWindowSizeUnit,
            timeWindowStepUnit,
        } = this.props
        this.state = {
            slideType,
            windowSize,
            windowStep,
            timeCol,
            timeWindowSize,
            timeWindowStep,
            timeWindowSizeUnit,
            timeWindowStepUnit,
        }
    }

    get isParamValid() {
        if (this.state.slideType === 'record') {
            if (
                this.state.windowSize.length > 0 &&
                this.state.windowStep.length > 0
            ) {
                if (
                    Number(this.state.windowSize) <
                    Number(this.state.windowStep)
                ) {
                    return {
                        isValid: false,
                        errorMessage: '长度必须大于等于步长',
                    }
                }
            }
        } else if (this.state.slideType === 'time') {
            if (
                this.state.timeWindowSize.length > 0 &&
                this.state.timeWindowStep.length > 0
            ) {
                const sizeUnit =
                    this.state.timeWindowSizeUnit === 'day' ? 24 : 1
                const stepUnit =
                    this.state.timeWindowStepUnit === 'day' ? 24 : 1

                if (
                    Number(this.state.timeWindowSize) * sizeUnit <
                    Number(this.state.timeWindowStep) * stepUnit
                ) {
                    return {
                        isValid: false,
                        errorMessage: '长度必须大于等于步长',
                    }
                }
            }
        }

        return {
            isValid: true,
        }
    }

    get isTimeColValid() {
        if (this.state.slideType === 'time') {
            const dateTypeNames = this.getDateTypes().map(col => col.name)
            if (!dateTypeNames.includes(this.state.timeCol)) {
                return {
                    isValid: false,
                    errorMessage: '时间字段无效',
                }
            }
        }

        return {
            isValid: true,
        }
    }

    getDateTypes = () => {
        return this.props.allColumns.filter(col => {
            return isDateType(col.type)
        })
    }

    handleSaveParam = params => {
        const { onSave } = this.props
        const { validateFields } = this.props.form
        validateFields(Object.keys(params), {}, err => {
            if (!err) {
                onSave(params)
            } else {
                for (let key in params) {
                    this.props.form.setFieldsValue({ [key]: this.props[key] })
                }
            }
        })
    }

    handleChangeParam = param => {
        this.setState(
            {
                ...param,
            },
            () => {
                this.handleSaveParam(param)
            }
        )
    }

    renderParamValidation = () => {
        const paramValid = this.isParamValid
        if (paramValid.isValid) return null
        return (
            <Tooltip placement="right" title={paramValid.errorMessage}>
                <div
                    style={{
                        position: 'relative',
                        top: -3,
                        display: 'inline-block',
                        verticalAlign: 'middle',
                    }}
                >
                    <Icon
                        type="exclamation-circle-o"
                        style={{
                            marginLeft: 10,
                            marginTop: 5,
                            color: '#fa4646',
                            transform: 'scale(1.2)',
                        }}
                    />
                </div>
            </Tooltip>
        )
    }

    renderTimeColValidation = () => {
        const paramValid = this.isTimeColValid
        if (paramValid.isValid) return null
        return (
            <Tooltip placement="right" title={paramValid.errorMessage}>
                <div
                    style={{
                        position: 'relative',
                        top: -3,
                        display: 'inline-block',
                        verticalAlign: 'middle',
                    }}
                >
                    <Icon
                        type="exclamation-circle-o"
                        style={{
                            marginLeft: 10,
                            marginTop: 5,
                            color: '#faad14',
                            transform: 'scale(1.2)',
                        }}
                    />
                </div>
            </Tooltip>
        )
    }

    renderTypeSelections = () => {
        return (
            <FormItem
                {...formItemLayout}
                label="方式: "
                required
                {...getFormItemState(this.props.paramState.slideType)}
            >
                <RadioGroup
                    disabled={this.props.disabled}
                    onChange={e =>
                        this.handleChangeParam({ slideType: e.target.value })
                    }
                    value={this.state.slideType}
                >
                    <Radio value="record">记录数滑窗</Radio>
                    <Radio value="time">时间滑窗</Radio>
                </RadioGroup>
            </FormItem>
        )
    }

    renderRecordSlide = () => {
        const { getFieldDecorator } = this.props.form
        const { allColumns, orderByASC, orderByCols } = this.props

        const selectedColumns = mapToTuple({
            name: orderByCols,
            order: orderByASC,
        })

        return [
            <FormItem
                {...formItemLayout}
                label={'分组排序'}
                key="orderByGroup"
                {...getFormItemState(this.props.paramState.orderByCols)}
            >
                <SelectFields
                    style={{ position: 'relative', top: -10 }}
                    required={false}
                    buttonText="选择"
                    onSelectFields={selectedColumns =>
                        this.handleChangeParam({
                            orderByCols: selectedColumns.map(col => col.name),
                            orderByASC: selectedColumns.map(col => col.order),
                        })
                    }
                    allColumns={allColumns}
                    selectedColumns={selectedColumns}
                    isSelectMulti={true}
                    disabled={this.props.disabled}
                    additionalParams={[
                        {
                            title: '排序',
                            paramName: 'order',
                            inputType: 'dropdown',
                            defaultValue: 'true',
                            options: [
                                { text: '升序', value: 'true' },
                                { text: '降序', value: 'false' },
                            ],
                        },
                    ]}
                />
            </FormItem>,
            <FormItem
                {...formItemLayout}
                label="长度: "
                key="length"
                required
                {...getFormItemState(this.props.paramState.windowSize)}
            >
                {getFieldDecorator('windowSize', {
                    initialValue: this.state.windowSize,
                    rules: [
                        positiveIntegerValidator({ message: '必须是正整数' }),
                        maxValidator({
                            message: `必须小于${MAX_NUMBER}`,
                            max: MAX_NUMBER,
                        }),
                    ],
                })(
                    <Input
                        disabled={this.props.disabled}
                        onChange={() => this.props.onChangeInput('windowSize')}
                        onBlur={e =>
                            this.handleChangeParam({
                                windowSize: e.target.value,
                            })
                        }
                        onPressEnter={e => {
                            e.target.blur()
                        }}
                    />
                )}
            </FormItem>,
            <FormItem
                {...formItemLayout}
                label="步长: "
                key="stepLength"
                required
                {...getFormItemState(this.props.paramState.windowStep)}
            >
                {getFieldDecorator('windowStep', {
                    initialValue: this.state.windowStep,
                    rules: [
                        positiveIntegerValidator({ message: '必须是正整数' }),
                        maxValidator({
                            message: `必须小于${MAX_NUMBER}`,
                            max: MAX_NUMBER,
                        }),
                    ],
                })(
                    <Input
                        disabled={this.props.disabled}
                        onChange={() => this.props.onChangeInput('windowStep')}
                        onBlur={e =>
                            this.handleChangeParam({
                                windowStep: e.target.value,
                            })
                        }
                        onPressEnter={e => {
                            e.target.blur()
                        }}
                    />
                )}
            </FormItem>,
        ]
    }

    renderTimeSlide = () => {
        return (
            <div>
                <FormItem
                    {...formItemLayout}
                    label="时间字段: "
                    key="timeCol"
                    required
                    {...getFormItemState(this.props.paramState.timeCol)}
                >
                    <Select
                        disabled={this.props.disabled}
                        value={this.state.timeCol}
                        style={{ width: '100%' }}
                        onChange={value =>
                            this.handleChangeParam({ timeCol: value })
                        }
                    >
                        {this.getDateTypes().map(col => {
                            return <Option value={col.name}>{col.name}</Option>
                        })}
                    </Select>
                </FormItem>
                {this.renderSlideLengthByTime()}
                {this.renderSlideLengthByStep()}
            </div>
        )
    }

    renderSlideLengthByTime = () => {
        const { getFieldDecorator } = this.props.form
        return (
            <div className={styles.slideContainer}>
                <FormItem
                    {...formItemLayout}
                    label="长度单位: "
                    required
                    className={styles.twoLineFormItem}
                    {...getFormItemState(
                        this.props.paramState.timeWindowSizeUnit
                    )}
                >
                    <RadioGroup
                        disabled={this.props.disabled}
                        className={styles.radioGroup}
                        value={this.state.timeWindowSizeUnit}
                        onChange={e =>
                            this.handleChangeParam({
                                timeWindowSizeUnit: e.target.value,
                            })
                        }
                    >
                        <Radio value="day">天</Radio>
                        <Radio value="hour">时</Radio>
                    </RadioGroup>
                </FormItem>
                <FormItem
                    {...formItemLayout}
                    label="长度: "
                    required
                    className={styles.twoLineFormItem}
                    {...getFormItemState(this.props.paramState.timeWindowSize)}
                >
                    {getFieldDecorator('timeWindowSize', {
                        initialValue: this.state.timeWindowSize,
                        rules: [
                            positiveIntegerValidator({
                                message: '必须是正整数',
                            }),
                            maxValidator({
                                message: `必须小于${MAX_NUMBER}`,
                                max: MAX_NUMBER,
                            }),
                        ],
                    })(
                        <Input
                            className={styles.input}
                            disabled={this.props.disabled}
                            onChange={() =>
                                this.props.onChangeInput('timeWindowSize')
                            }
                            onBlur={e =>
                                this.handleChangeParam({
                                    timeWindowSize: e.target.value,
                                })
                            }
                            onPressEnter={e => {
                                e.target.blur()
                            }}
                        />
                    )}
                </FormItem>
            </div>
        )
    }

    renderSlideLengthByStep = () => {
        const { getFieldDecorator } = this.props.form
        return (
            <div className={styles.slideContainer}>
                <FormItem
                    {...formItemLayout}
                    label="步长单位: "
                    required
                    className={styles.twoLineFormItem}
                    {...getFormItemState(
                        this.props.paramState.timeWindowStepUnit
                    )}
                >
                    <RadioGroup
                        disabled={this.props.disabled}
                        className={styles.radioGroup}
                        value={this.state.timeWindowStepUnit}
                        onChange={e =>
                            this.handleChangeParam({
                                timeWindowStepUnit: e.target.value,
                            })
                        }
                    >
                        <Radio value="day">天</Radio>
                        <Radio value="hour">时</Radio>
                    </RadioGroup>
                </FormItem>
                <FormItem
                    {...formItemLayout}
                    label="步长: "
                    required
                    className={styles.twoLineFormItem}
                    {...getFormItemState(this.props.paramState.timeWindowStep)}
                >
                    {getFieldDecorator('timeWindowStep', {
                        initialValue: this.state.timeWindowStep,
                        rules: [
                            positiveIntegerValidator({
                                message: '必须是正整数',
                            }),
                            maxValidator({
                                message: `必须小于${MAX_NUMBER}`,
                                max: MAX_NUMBER,
                            }),
                        ],
                    })(
                        <Input
                            className={styles.input}
                            disabled={this.props.disabled}
                            onChange={() =>
                                this.props.onChangeInput('timeWindowStep')
                            }
                            onBlur={e =>
                                this.handleChangeParam({
                                    timeWindowStep: e.target.value,
                                })
                            }
                            onPressEnter={e => {
                                e.target.blur()
                            }}
                        />
                    )}
                </FormItem>
            </div>
        )
    }

    render() {
        return (
            <div className={styles.container}>
                <SubConfig
                    title={
                        <div style={{ height: 21 }}>
                            <div
                                style={{
                                    lineHeight: '21px',
                                    height: 21,
                                    display: 'inline-block',
                                }}
                            >
                                滑窗参数
                            </div>
                            {this.renderParamValidation()}
                            {this.renderTimeColValidation()}
                        </div>
                    }
                >
                    {this.renderTypeSelections()}
                    {this.state.slideType === 'record' &&
                        this.renderRecordSlide()}
                    {this.state.slideType === 'time' && this.renderTimeSlide()}
                </SubConfig>
            </div>
        )
    }
}

const formItemLayout = {
    labelCol: {
        span: 5,
    },
    wrapperCol: {
        span: 18,
        offset: 1,
    },
}

export default Form.create()(TimeSlide)
