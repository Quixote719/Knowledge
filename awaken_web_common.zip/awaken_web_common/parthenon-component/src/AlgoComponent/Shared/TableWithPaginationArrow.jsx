import { Table } from 'antd'
import React from 'react'
import styles from './TableWithPaginationArrow.less'

class TableWithPaginationArrow extends React.Component {
    render() {
        const pagination =
            this.props.pagination === false
                ? false
                : {
                    ...this.props.pagination,
                    itemRender: (current, type, originalElement) => {
                        if (type === 'prev') {
                            return (
                                <span className={styles.noAdditionalArrow}>
                                    <a className="ant-pagination-item-link">
                                        <i className="anticon anticon-left" />
                                    </a>
                                </span>
                            )
                        } else if (type === 'next') {
                            return (
                                <span className={styles.noAdditionalArrow}>
                                    <a className="ant-pagination-item-link">
                                        <i className="anticon anticon-right" />
                                    </a>
                                </span>
                            )
                        }
                        return originalElement
                    },
                }
        return <Table {...this.props} pagination={pagination} />
    }
}

export default TableWithPaginationArrow
