import React from 'react'
import { DatePicker, Input } from 'antd'
import moment from 'moment'

import styles from './index.less'

export default class InputOrDatePicker extends React.Component {
    handleInputChange = val => {
        const { onChange } = this.props
        return onChange && onChange(val)
    }

    disabledDate = current => {
        // 可选择的日期在1970开始，到9999-12-31
        return current < moment('1970-01-01') || current > moment('9999-12-31')
    }

    render() {
        const {
            onOk,
            value,
            onBlur,
            placeholder = '',
            isDate,
            format = 'YYYY-MM-DD HH:mm',
        } = this.props

        let dateValue = value
        let dateValueInMoment = null
        if (isDate) {
            const temp = new moment(parseInt(value))
            //只有当value有效时才设置value，否则antd插件会显示异常
            if (temp._isValid) {
                dateValueInMoment = temp
            }
        }

        return (
            <div>
                {isDate && (
                    <DatePicker
                        showTime
                        className={styles.wordFrequencyDatePicker}
                        onChange={val => {
                            if (val) {
                                this.handleInputChange(val.valueOf())
                            } else {
                                this.handleInputChange(val)
                            }
                            return val._isUTC && onOk && onOk(val.valueOf())
                        }}
                        value={dateValueInMoment}
                        onOk={() => onOk && onOk(dateValue.valueOf())}
                        format={format}
                        placeholder={placeholder}
                        disabledDate={this.disabledDate}
                    />
                )}
                {!isDate && (
                    <Input
                        onPressEnter={e => {
                            onOk && onOk(e.target.value)
                        }}
                        onBlur={() => {
                            onBlur && onBlur(value)
                        }}
                        value={value}
                        onChange={e => this.handleInputChange(e.target.value)}
                        placeholder={placeholder}
                    />
                )}
            </div>
        )
    }
}
