/**
 * Created by yaojia7 on 2019/4/12.
 */
import React from 'react'
import Chart from '../../Shared/Charts/Chart'
import styles from './showModal.less'

export default React.memo(({ xData, yData, type = 'detailChart' }) => {
    if (type === 'thumbnail') {
        return (
            <Chart
                className={styles.histogramChart}
                style={{ height: 64 }}
                option={{
                    series: [
                        {
                            data: yData,
                            type: 'boxplot',
                            itemStyle: {
                                borderColor: '#188df0',
                            },
                            slient: true,
                        },
                    ],
                    xAxis: {
                        show: false,
                        data: xData,
                    },
                    yAxis: {
                        show: false,
                    },
                }}
            />
        )
    } else if (type === 'detailChart') {
        return (
            <Chart
                className={styles.histogramChart}
                style={{ height: 600 }}
                option={{
                    tooltip: {
                        trigger: 'item',
                        axisPointer: {
                            type: 'shadow',
                        },
                    },
                    series: [
                        {
                            data: yData,
                            type: 'boxplot',
                            itemStyle: {
                                borderColor: '#188df0',
                            },
                            tooltip: {
                                formatter: function(param) {
                                    return [
                                        param.name + ': ',
                                        '最大值: ' + param.data[5],
                                        '上四分位数: ' + param.data[4],
                                        '中位数: ' + param.data[3],
                                        '下四分位数: ' + param.data[2],
                                        '最小值: ' + param.data[1],
                                    ].join('<br/>')
                                },
                            },
                        },
                    ],
                    xAxis: {
                        type: 'category',
                        data: xData,
                        splitArea: {
                            show: false,
                        },
                        splitLine: {
                            show: false,
                        },
                    },
                    yAxis: {
                        type: 'value',
                        splitArea: {
                            show: true,
                        },
                    },
                }}
            />
        )
    } else {
        return null
    }
})
