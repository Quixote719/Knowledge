/**
 * 直方图组件查看分析结果组件
 * Created by yaojia7 on 2019/3/18.
 */
import React, { useMemo } from 'react'
import BoxplotModal from './BoxplotResultModal'

export default React.memo(function({ component, onCancel }) {
    const props = useMemo(() => {
        const { rowList } = component.compResult['0']
        const fields = []
        const dataList = []
        const keys = [
            'min',
            'lower_quartile',
            'median_quartile',
            'upper_quartile',
            'max',
        ] // 箱线图数据

        for (let row of rowList) {
            const fieldData = JSON.parse(row)

            if (!fieldData.isNum) {
                continue
            }
            fields.push({
                fieldName: fieldData.column,
                fieldId: fieldData.column,
            })
            dataList.push({
                xData: [fieldData.column],
                data: [keys.map(key => fieldData.metrics[key])],
                numeric: fieldData.isNum,
            })
        }

        return {
            fields,
            datas: dataList,
        }
    }, [component])

    return <BoxplotModal {...props} onCancel={onCancel} />
})
