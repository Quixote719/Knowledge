export function getFormItemState(stateArray) {
    let state = null
    if (Array.isArray(stateArray)) {
        if (stateArray.includes('error')) {
            state = 'error'
        } else if (stateArray.includes('init')) {
            state = 'init'
        } else if (stateArray.includes('saving')) {
            state = 'saving'
        } else {
            state = 'saved'
            for (let i = 0; i < stateArray.length; i++) {
                if (stateArray[i] !== 'saved') {
                    state = 'init'
                    break
                }
            }
        }
    } else {
        state = stateArray
    }
    switch (state) {
        case 'saved':
            return {
                validateStatus: 'success',
                hasFeedback: true
            }
        case 'saving':
            return {
                validateStatus: 'validating',
                hasFeedback: true
            }
        case 'saveError': {
            return {
                validateStatus: 'error',
                help: '保存失败',
                hasFeedback: true
            }
        }
        default:
            return {}
    }
}

/**
 * 校验参数是否正确
 */
export function validateThenSave(updatedValues, cb) {
    const { form, instanceParams } = this.props
    const { validateFields } = form
    validateFields(Object.keys(updatedValues), {}, err => {
        if (err) {
            for (let key in updatedValues) {
                form.setFieldsValue({ [key]: instanceParams[key] })
            }
        } else {
            cb(updatedValues, composeCompSaveState(this))
        }
    })
}

export function composeCompSaveState(comp) {
    return (values, state) => {
        const { instance } = comp.props

        //若修改来自于集成模型组件中嵌套组件，则修改参数时无须修改组件状态
        if (instance && instance.isSubComponent) return

        let params = Object.assign({}, comp.state.params)
        for (let key in values) {
            Object.assign(params.state, {
                [key]: state
            })
        }
        comp.setState({
            params
        })
    }
}
