import FlowChart from "../../src/main";
import {message} from "antd";
import components from "../datatest/components1";
import classInfo from "../datatest/classInfo1";
let flowChart;
/**
 * resize时一定要通知到画布进行resize重绘
 */
function htmlContentResize(){
    let height = document.body.clientHeight-50;
    document.getElementById('bodycontent').style.height = height+'px';
    if(flowChart){
        floatChart.resize();
    }
}
/**
 * 初始化事件
 */
function initEvents(){
    //resize事件
    window.addEventListener('resize',()=>{htmlContentResize()});
}
/**
 * 信息提示由应用提供
 */
function messageTip(data){
    message.warning(data)
}
function init(){
    initEvents();
    htmlContentResize();
    //配置初始化参数
    let param = {
        dom:document.getElementById('rightDiv'),
        link:{
            //是否强制接口类型 默认为true，接口类型固定了以后则使用强制类
            isPortType:true,
            //是否输入必须一个，默认为true，针对接口无限连接的
            isInPortOne:true,
            //是否为不可循环流程图,用于连接验证
            isDAG:false,
            //连接样式 后置
            linkStyle:{
                shape:{
                    connected:'bezierCurve',//曲线  bezierCurve
                    unConnect:'straightLine'//直线 用于未连接的测试连接
                }
            }
        },
        //组件类描述信息
        classInfomation:{
            //是否使用classInformation 强制使用class
            //isClass:true,
            classInfo

        },
        
        //菜单
        menu:{
            list:[
                {
                    type:'btn',
                    img:'',//图片url
                    text:'从此节点执行',
                    //可显示状态 和下面的是并集的关系
                    show:{
                        //运行状态：在编辑状态
                        runState:['EDITSTATE'],
                        //节点要求：1个 或者 n表示多个
                        node:'1',
                        //类型要求：节点的类型要求
                        //classType:''
                    },
                    //不可显示状态
                    unShow:{},
                    //业务来决定的是否显示
                    showFun:function(){

                    }
                }
            ]
        },
        
        events:{
            //提示消息
            'messageTip':(data)=>{messageTip(data)}
            //
            //'contextEvent':
            //运行画布
            //runCanvas
            //运行组件
            //runComponent
            //拓扑改变事件
            //topologyChange
            //节点坐标改变事件
            //positionChange
            //选中元素事件
            //selectElement
        },
        //鹰眼设定
        eagleEye:{
            isCreate:false
            //默认显示
            //方位角
            
        }
    };
    flowChart = new FlowChart(param);

    //测试参数
    //metadata 画布信息 id，status状态（如果不提供则认为）
    let metadata = {id:1,status:'EDITSTATE'}
    let loadFrom = 'SELECT_EXPR'
    let testParam = {
        metadata,
        components,
        loadFrom
    }
    //传递数据
    //
    
    flowChart.changeCanvas(testParam);
    //setTimeout  多次变化测试
}
init();