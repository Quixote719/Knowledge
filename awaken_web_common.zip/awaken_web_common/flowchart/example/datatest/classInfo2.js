const classInfo=[
    {
        name:'jar包',
        clazz:'1111111',
        compId:'1',
        image:'icon_machine',
        input:[{
            name:'data',
            type:'data',
            index:'0',
            description:'输出数据'
        }],
        output:[{
            name:'data',
            type:'data',
            index:'0',
            description:'输出数据'
        }]
    }
    
]

export default classInfo