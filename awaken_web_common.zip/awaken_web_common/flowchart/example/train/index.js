import FlowChat from "../../src/main";
new FlowChat()
debugger
let height = document.body.clientHeight-50;
document.getElementById('bodycontent').style.height = height+'px';
