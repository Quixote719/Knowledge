import FlowChat from "../../src/main";
new FlowChat()
let height = document.body.clientHeight-50;
document.getElementById('bodycontent').style.height = height+'px';
