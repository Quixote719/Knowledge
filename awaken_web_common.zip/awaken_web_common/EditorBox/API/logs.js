import {
    isSuccess,
    fetchOrGetSuccessSimulation,
    errorMessageHelper
} from './util'

const getLogsHistory = async history => {
    const obj = {
        url: history.url,
        method: 'post',
        params: history.params
    }
    let res = await fetchOrGetSuccessSimulation(obj).catch(err => {
        errorMessageHelper(err, '无法获取历史日志')
    })
    if (isSuccess(res)) {
        return res
    } else {
        throw res
    }
}

export { getLogsHistory }