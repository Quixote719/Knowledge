import { message } from 'antd'

const interfaceReadyTree  = {
    logs: [
        { url: `http://10.3.70.122:9010/awaken/loghub/api/v1/logs/history`, method: 'post' },
    ]
}
const sharedSuccessResponse = {
    status: 200,
    message: 'Successfully',
    mocking: true
}

const fetchOrGetSuccessSimulation = obj => {
    if (isInterfaceReady(obj)) {
        return fetchProxy(obj)
    } else {
        return Promise.resolve(sharedSuccessResponse)
    }
}
const isSuccess = res => {
    return res && getStatus(res) == 200
}
const getStatus = res => {
    if (res) {
        if (res.hasOwnProperty('status')) return res.status
        if (res.hasOwnProperty('statusCode')) return res.statusCode
        if (res.hasOwnProperty('code')) return res.code == 0 ? 200 : res.code
    }
    return 404
}
const errorMessageHelper = (err, optMessage) => {
    if (err && err.constructor === TypeError && err.message === 'Failed to fetch') {
        message.error('接口异常，无法获取数据')
    } else if (err.status > 1000 && err.status <= 1050) {
        message.error('你的页面可能已经过期。请刷新页面后重试。')
    } else if (err === 'request timeout') {
        message.error('请求超时')
    } else {
        message.error(err && err.message && err.message !== 'null' ? err.message : optMessage)
    }
}
const isInterfaceReady = ({ url, method }) => {
    for (let key in interfaceReadyTree) {
        for (let entry of interfaceReadyTree[key]) {
            if (url.indexOf(entry.url) === 0 && entry.method.toLowerCase() === method.toLowerCase()) {
                return true
            }
        }
    }
    return false
}
const fetchProxy = ({ url, method, params, contentType = 'application/json' }) => {
    let headers = {
        // todo:后期统一修改userId
        'X-User-Id': userId
    }

    // contentType为空用来处理上传文件
    if (!contentType) {
        // headers.unionId = '0000000' // 内网用
        //headers.unionId = unionId // 蓝口用
    } else {
        headers['Content-Type'] = contentType
    }

    if (method.toLowerCase() === 'get') {
        return fetch(url, { headers }).then(data => {
            const contentType = data.headers.get('content-type')
            if (
                contentType === 'application/python' ||
                contentType === 'application/scala' ||
                contentType === 'application/java' ||
                contentType === 'application/sourcecode' ||
                contentType === 'application/octet-stream'
            ) {
                return handleHttpError(data)
            } else {
                return data.text().then(text => {
                    const res = JSONbig.parse(text)
                    return handleHttpError(res)
                })
            }
        })
    } else {
        let payload = params
        let obj = {
            method,
            headers
        }
        if (!contentType) {
            obj.method = method.toLowerCase()
            obj.mode = 'cors'
            if (payload) {
                let params = new FormData()
                for (let key in payload) {
                    params.append(`${key}`, payload[key])
                }
                obj.body = params
            }
        } else {
            obj.headers['Content-Type'] = contentType
            if (payload) obj.body = JSON.stringify(payload)
        }

        return fetch(url, obj).then(data => {
            return data.text().then(text => {
                const res = JSONbig.parse(text)
                return handleHttpError(res)
            })
        })
    }
}
export {
    isSuccess,
    sharedSuccessResponse,
    fetchOrGetSuccessSimulation,
    errorMessageHelper,
}