import object from 'lodash/fp/object'
class Util{
    constructor(){
    }
    /**
     * 深度克隆
     */
    static deepClone=(obj)=>{
        var proto=Object.getPrototypeOf(obj);
        return Object.assign({},Object.create(proto),obj);
    }
    /**
     * 深度覆盖 获得原始对象没有的内容，并替换原始对象里面没有的
     * original 原始对象
     * substitute 代替对象 
     */
    static deepCover=(original,substitute)=>{
        //使用lodash扩展
        return object.defaultsDeep(original,substitute)
    }
    /**
     * 深度覆盖 获得原始对象没有的内容，并替换原始对象里面没有的
     * original 原始对象
     * substitute 代替对象 
     */
    static assign=(original,substitute)=>{
        //使用lodash扩展
        return object.assign(original,substitute)
    }
    /**
     * 深度覆盖 获得原始对象没有的内容，并合并替换原始对象里面有的内容
     * original 原始对象
     * substitute 代替对象 
     */
    static merge=(original,substitute)=>{
        return object.merge(original,substitute)
    }
    /**
     * 是否包含属性
     * obj
     * {string} attrName
     */
    static isContain = (obj,attrName)=>{
        if(Array.isArray(obj)){
            if(obj.indexOf(attrName)>-1){
                return true
            }
            if(typeof attrName.length != 'undefined'){
                if(obj.indexOf(parseInt(attrName))>-1) {
                    return true
                }
            }
        }else if(obj && typeof(obj[attrName])!='undefined'){
            return true
        }else{
            return false
        }
    }
}

export default Util