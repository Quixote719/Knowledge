import EVENTS from './eventdeclara'
import Util from '../util'
import { debounce } from 'parthenon-lib'
/**
 * 事件管理
 * 监听事件，派发，需要事件的进行监听
 */
class EventManage {
    constructor(main) {
        this.main = main
        this.addEvent()
        //注册事件属性发生改动
        this.main.bind(EVENTS['scrollEvents'], this.scrollEvents)
        this.main.bind(EVENTS['scrollTop'], this.scrollTop)
        this.main.bind(EVENTS['scrollCenter'], this.scrollCenter)
        this.main.bind(EVENTS['scrollBottom'], this.scrollBottom)
        this.main.bind(EVENTS['clear'], this.clear)
        //滚动条状态
        this.scrollstate = null
    }
    addEvent = () => {

    }
    removeAll = () => {

    }
    /**
     * 清空操作
     */
    clear = () => {
        //滚动条状态
        this.scrollstate = null
    }
    //防抖的滚动条事件
    scrollEvents = debounce((type) => {
        //console.log('scrollEvents')
        //console.log(this.scrollstate,type,this.scrollstate==type)
        //防止重复的连接请求
        if (this.scrollstate && this.scrollstate == type) {
            return false
        }
        this.triggerScroll(type)
    }, 300)
    //防止乒乓球式的滚动
    triggerScroll = debounce((type) => {
        this.main.triggerEvent(EVENTS[type], type)
    }, 500)
    /**
     * 滚动到头部，进行历史查询
     */
    scrollTop = () => {
        if (this.main.params.isShowAll) {
            //this.main.triggerEvent(EVENTS['messageTip'],'无需通讯')
            return false
        }
        this.scrollstate = 'scrollTop'
        // console.log('scrollTop||||||||')
        let lastLine = this.main.chart.Editor.lastLine()
        if (lastLine >= this.main.params.maxLine - 1 || !this.main.params.isPush) {
            this.main.triggerEvent(EVENTS['historySearch'], 'top')
        }
    }
    /**
     * 滚动条在中间时，且是从底部划过这个事件，通知chart当前状态，目前策略是画布不满则推送请求,画布满的则停止推送
     */
    scrollCenter = () => {
        if (this.main.params.isShowAll) {
            //this.main.triggerEvent(EVENTS['messageTip'],'无需通讯')
            return false
        }
        this.scrollstate = 'scrollCenter'
        console.log('scrollCenter||||||||')
        let lastLine = this.main.chart.Editor.lastLine()
        //业务上判断,推送给业务
        //this.main.triggerEvent(EVENTS['scrollCenter'])
        if (lastLine >= this.main.params.maxLine - 1) {
            this.main.triggerEvent(EVENTS['pushStop'])
        }
    }
    /**
     * 滚动条底部事件触发
     */
    scrollBottom = () => {
        if (this.main.params.isShowAll) {
            //this.main.triggerEvent(EVENTS['messageTip'],'无需通讯')
            return false
        }
        // console.log('scrollBottom||||||||')
        this.scrollstate = 'scrollBottom'
        //做历史的向下查询
        // let lastLine = this.main.chart.Editor.lastLine()
        if (!this.main.params.isPush) { // && lastLine >= this.main.params.maxLine - 1
            this.main.triggerEvent(EVENTS['historySearch'], 'bottom')
        } else {
            //拉至底部开启推送，chart端通过后端服务可以直接获得最近的行数
            this.main.triggerEvent(EVENTS['pushStart'])
        }
    }
}

export default EventManage