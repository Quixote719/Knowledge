/**
 * 事件声明
 * 方便各个模块查看事件及其对应监听
 */
const EVENTS={
    //滚动条顶部事件触发
    'scrollTop':'scrollTop',
    //滚动条在中间时
    'scrollCenter':'scrollCenter',
    //滚动条底部事件触发
    'scrollBottom':'scrollBottom',
    'scrollEvents':'scrollEvents',
    
    //查询历史分页 需要得到chart内的时间戳，然后向上或向下
    historySearch:'historySearch',
    //开始推送
    pushStart:'pushStart',
    //停止推送
    pushStop:'pushStop',
    //关闭所有查询
    closeSearch:'closeSearch',
    //数据渲染在当前的顶部
    renderDataTop:'renderDataTop',
    //数据渲染在当前的底部
    renderDataBottom:'renderDataBottom',
    //数据渲染覆盖全部
    //消息提示，
    messageTip:'messageTip',

    //清空操作
    clear:'clear',
}

export default EVENTS
