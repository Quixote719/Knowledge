import EVENTS from '../event/eventdeclara'
// import * as logsAPI from '../../API/logs'
/**
 * 查询
 * 查询是互斥的，每次最新的请求，关闭其它所有的请求
 *
 */
class Search {
    constructor(main) {
        this.main = main
        this.params = this.main.params
        this.searchParam = this.params.searchParam
        this.main.bind(EVENTS['historySearch'], this.historySearch)
        this.main.bind(EVENTS['pushStart'], this.pushStart)
        this.main.bind(EVENTS['pushStop'], this.pushStop)
        this.main.bind(EVENTS['clear'], this.closeSearch)
        /*
         *初始化属性
         */
        //服务信息
        this.ws = null
        //服务状态 close 关闭 open 开启
        this.wsState = 'close'
        this.repeat = 0
        this.pingTimeOut = 15000
        this.pongTimeOut = 10000
        this.reconnectTimeOut = 2000
        this.pintMsg = 'ping'
        this.repeatLimit = 10
        this.lockReconnect = false
    }

    /**
     * 历史查询
     */
    historySearch = (type = 'top') => {
        // console.log('historySearch')
        // 请求历史时停止推送
        this.main.triggerEvent(EVENTS['pushStop'])

        let search = JSON.parse(
            JSON.stringify(this.main.params.searchParam.history.params)
        )
        let limit = JSON.parse(
            JSON.stringify(this.searchParam.history.params.limit)
        )

        let historyUrl =
            this.searchParam.history.url ||
            `${window.loghubPrefix}/logs/history`
        let time = null
        let timers = this.main.chart ? this.main.chart.timers : [null]
        if (timers && timers.length) {
            time = type === 'top' ? timers[0] : timers[timers.length - 1]
        }
        search.time = time
        if (timers && timers.length <= 1) {
            search.direction = 'FORWARD' // FORWARD 页面初次加载时 time为null 以最新时间从第一条向下请求历史日志
            search.limit = this.main.params.maxLine || 10000
        } else {
            search.direction = type === 'bottom' ? 'FORWARD' : 'BACKWARD'
            search.limit = this.searchParam.history.params.limit || 3000
        }
        fetch(historyUrl, {
            method: 'POST',
            mode: 'cors',
            body: JSON.stringify(search),
            headers: new Headers({
                'Content-Type': 'application/json',
                'X-Token': window.localStorage.token
            })
        })
            .then(res => {
                return res.json()
            })
            .then(res => {
                if (!!res.data) {
                    if (type === 'top') {
                        this.main.triggerEvent(
                            EVENTS['renderDataTop'],
                            res.data.list
                        )
                    } else {
                        this.main.triggerEvent(
                            EVENTS['renderDataBottom'],
                            res.data.list
                        )
                    }
                }
            })
            .catch(err => {
                console.log(err)
            })
    }
    /**
     * 开启推送
     */
    pushStart = () => {
        if (this.main.params.isShowAll || !this.main.params.isPush) {
            //this.main.triggerEvent(EVENTS['messageTip'],'无需通讯')
            return false
        }
        let historyStartTime = null
        let timers = this.main.chart ? this.main.chart.timers : [null]
        let {
            groupTraceId,
            traceId,
            tags,
            tagCondition,
            historyLimit = 3000
        } = this.main.params.searchParam.push.params

        if (timers && timers.length <= 1) {
            // 第一次请求为maxLine
            // JSON.parse(JSON.stringify(this.main.params.maxLine))
            historyLimit = this.main.params.maxLine || 10000
        } else {
            // JSON.parse(JSON.stringify(this.main.params.searchParam.push.params.historyLimit))
            historyLimit =
                this.main.params.searchParam.push.params.historyLimit || 3000
            historyStartTime = timers[timers.length - 1]
        }
        let wsPrefix =
            this.searchParam.push.wsPrefix ||
            `ws://${window.loghubPrefix.slice(7)}/logs/websocket`
        this.wsUrl = `${wsPrefix}?groupTraceId=${groupTraceId}&historyLimit=${historyLimit}`

        if (traceId) {
            let traceIdURL = `&traceId=${traceId}`
            this.wsUrl += traceIdURL
        }
        if (historyStartTime) {
            this.wsUrl += `&historyStartTime=${historyStartTime}`
        }
        if (tags && tagCondition) {
            this.wsUrl += `&tags=${tags}&tagCondition=${tagCondition}`
        }

        groupTraceId && this.createWebSocket()
    }
    /**
     * 推送停止
     */
    pushStop = () => {
        // console.log('pushStop')
        this.wsState = 'close'
        this.heartReset()
        //判断是否连接
        if (this.ws) {
            this.ws.close()
        }
        this.ws = null
    }
    /**
     * 关闭查询
     */
    closeSearch = () => {
        this.pushStop()
    }
    createWebSocket = () => {
        console.log('建立连接')
        try {
            if ('WebSocket' in window) {
                if (this.wsState != 'close' || this.ws) {
                    this.pushStop()
                }
                this.ws = new WebSocket(this.wsUrl) // (this.wsUrl, [window.localStorage.token])
                this.wsState = 'open'
            }
            this.initEventHandle()
        } catch (e) {
            this.reconnect()
            console.log(e)
        }
    }
    initEventHandle = () => {
        this.ws.onclose = e => {
            console.log('断开连接')
            this.reconnect()
        }
        this.ws.onerror = e => {
            console.log('wsOnerror', e)
            this.reconnect()
        }
        this.ws.onopen = () => {
            // this.ws.send(window.localStorage.token)
            this.heartCheck()
        }
        this.ws.onmessage = event => {
            this.heartCheck()
            // console.log(JSON.parse(event.data))
            this.main.triggerEvent(
                EVENTS['renderDataBottom'],
                JSON.parse(event.data)
            )
            //渲染数据
        }
        // window.onbeforeunload = () => {
        //     this.ws.close()
        // }
    }
    /**
     * 异常断开的话需要重连接
     */
    reconnect = () => {
        if (this.repeatLimit > 0 && this.repeatLimit <= this.repeat) {
            console.log('超出重连次数上限')
            this.repeat = 0
            return
        }
        if (this.lockReconnect || this.wsState === 'close') {
            return
        }
        console.log('重新连接')
        this.lockReconnect = true
        this.repeat++
        this.reconnectId = setTimeout(() => {
            this.createWebSocket()
            this.lockReconnect = false
        }, this.reconnectTimeOut)
    }
    /**
     * 心跳检查
     */
    heartCheck = () => {
        // console.log('heartCheck')
        this.heartReset()
        this.heartStart()
    }
    /**
     * 心跳开始
     */
    heartStart = () => {
        if (this.wsState === 'close') {
            return
        }
        // console.log('heartStart')
        this.pingTimeOutId = setTimeout(() => {
            // console.log('维持心跳')
            this.ws.send(this.pintMsg)
            this.pongTimeOutId = setTimeout(() => {
                this.ws.close()
            }, this.pongTimeOut)
        }, this.pingTimeOut)
    }
    /**
     * 心跳重置
     */
    heartReset = () => {
        clearTimeout(this.pingTimeOutId)
        clearTimeout(this.pongTimeOutId)
        //重点，防止多次重启重连
        clearTimeout(this.reconnectId)
    }
}
export default Search
