import Util from '../util'
import EVENTS from '../event/eventdeclara'
import FlinkSQLModel from '../config/mode/FlinkSQL'
import { debounce } from 'parthenon-lib'

import CodeMirror from 'codemirror/lib/codemirror'
import 'codemirror/lib/codemirror.css'
// import 'codemirror/mode/css/css.js'
import 'codemirror/theme/monokai.css' // 主题样式
// neo 白色主题 monokai 黑色主题
import 'codemirror/addon/selection/active-line' // 光标所在行突出颜色
import 'codemirror/addon/hint/show-hint.js' // 代码提示功能
import 'codemirror/addon/edit/closebrackets.js' // 括号补全功能
import 'codemirror/addon/hint/show-hint.css' // 代码提示样式

// import 'codemirror/addon/hint/javascript-hint' // JS代码提示语库
// import 'codemirror/mode/javascript/javascript'

import '../config/mode/free/free' // 自定义语言mode
import '../config/mode/free/free-hint' // 自定义补全提示

// import 'codemirror/addon/hint/sql-hint' // SQL代码提示语库
// import 'codemirror/mode/sql/sql'

import 'codemirror/addon/display/fullscreen.js' // 编辑框全屏
import 'codemirror/addon/display/fullscreen.css'

// import 'codemirror/addon/display/autorefresh.js' // 自动刷新

import 'codemirror/addon/dialog/dialog.js' // 搜索功能 --暂未实现
import 'codemirror/addon/dialog/dialog.css'
import 'codemirror/addon/search/search.js'
import 'codemirror/addon/search/searchcursor.js'
import 'codemirror/addon/search/jump-to-line.js' // ctrl+f搜索 alt+g跳行

import 'codemirror/addon/scroll/simplescrollbars.js' // 滚动条
import 'codemirror/addon/scroll/simplescrollbars.css'

import 'codemirror/addon/merge/merge.js' // 版本差异对比
import 'codemirror/addon/merge/merge.css'

import DiffMatchPatch from 'diff-match-patch'

window.diff_match_patch = DiffMatchPatch
window.DIFF_DELETE = -1
window.DIFF_INSERT = 1
window.DIFF_EQUAL = 0

/**
 * 
 */
class Chart {
    constructor(main) {
        this.main = main
        this.params = main.params

        // 自动保存倒计时，默认30， 单位为秒
        this.autoSaveTime = main.params.autoSaveTime || 30
        // 用户自定义options覆盖默认值
        this.options = Object.assign({}, FlinkSQLModel, main.params.options)
        // 滚动条贴底 logsGoOn=true 日志动态输出向下加载
        this.logsGoOn = true
        // 自动保存完成标识
        this.saved = true
        // 当前编辑框实例化对象
        this.Editor = null
        //当前渲染的数据
        this.datas = []
        this.main.bind(EVENTS['renderDataTop'], this.renderDataTop)
        this.main.bind(EVENTS['renderDataBottom'], this.renderDataBottom)
        this.main.bind(EVENTS['clear'], this.clear)
        // 时间戳缓存
        this.timers = []

        this.initDom()
        this.initEditor()
    }
    /**
     * 初始化容器
     */
    initDom = () => {
        this.dom = document.createElement('textarea')
        this.params.dom.appendChild(this.dom)
    }
    // 初始化编辑器
    initEditor = () => {
        let {
            value = '',
            width = '100%',
            height = '100%',
            type = 'basic',
            autoSaveTime = 30,
            maxLine = 10000,
            keywords = [],
            hintwords,
            tablenames,
        } = this.params

        let myCodeMirror

        if (type === 'diff') {
            // 基础编辑框参数
            myCodeMirror = this.diffCompare()
        } else {
            myCodeMirror = CodeMirror.fromTextArea(this.dom, this.options)
            // 初始化value
            myCodeMirror.setValue(value || '')
        }
        this.Editor = myCodeMirror

        // 设定宽高
        myCodeMirror.setSize(width, height)

        // 自定义高亮颜色
        type === 'logs' || this.addStyles()

        // 基础编辑框
        if (type === 'basic') {
            // 自定义关键字（无高亮效果）
            // keywords && keywords.forEach(keyword => {
            //     CodeMirror.resolveMode("free").keywords[keyword] = true
            // })
            // 实时代码补全提示
            // myCodeMirror.on('inputRead', () => {
            //     // cursorActivity 光标触发
            //     // inputRead 用户手动操作触发
            //     myCodeMirror.showHint({
            //         completeSingle: false
            //         // 只有一个匹配项时自动补全 默认为true
            //     })
            // })
            myCodeMirror.setOption('extraKeys', {
                // Ctrl: 'autocomplete',
                'Ctrl-/': this.annotate, // 注释快捷键
                'Ctrl-S': this.S2S, // Ctrl+S保存到服务器
                // F11: function (cm) {
                //     cm.setOption('fullScreen', !cm.getOption('fullScreen'))
                // },
                // Esc: function (cm) {
                //     if (cm.getOption('fullScreen')) cm.setOption('fullScreen', false)
                // }
            })
            myCodeMirror.on('changes', (cm, changes) => {
                this.updateValue()
            })
        }
        // 日志输出
        type === 'logs' && this.resetScroll()
    }
    // 自定义高亮颜色
    addStyles(target = this.dom) {
        const commentColor = 'yellow',
            keywordColor = '#F92672',
            numberColor = 'aqua',
            stringColor = '#567300'
        const style = document.createElement('style')
        style.type = 'text/css'
        const textNode = document.createTextNode(`
            .CodeMirror-line{
                font-size: 16px !important;
            }
            .cm-comment
            {
                color: ${commentColor} !important; 
                font-size: 14px  !important;
            }
            .cm-keyword
            {
                color: ${keywordColor} !important; 
            }
            .cm-number
            {
                color: ${numberColor} !important; 
            }
            .cm-string
            {
                color: ${stringColor} !important; 
            }
            .CodeMirror-merge,
            .CodeMirror-merge .CodeMirror{
                height: ${this.params.height}px !important; 
            }
            `)
        style.appendChild(textNode)
        target.appendChild(style)
    }

    // 日志输出框参数设置
    resetScroll = () => {
        let editor = this.Editor
        editor.setOption('mode', 'logs')
        // editor.setOption('readOnly', true)
        // editor.setOption('lineNumbers', false)
        editor.setOption('lineWrapping', true)
        let style = document.createElement('style')
        style.type = 'text/css'
        let textNode = document.createTextNode(`
        .CodeMirror-lines{
            color: rgb(199, 237, 204);
        }`)
        style.appendChild(textNode)
        this.params.dom.appendChild(style)
        editor.setValue(this.params.value || '')
        let isPush = this.params.isPush
        if (isPush) {
            this.main.triggerEvent(EVENTS['pushStart'])
        }
        if (isPush === false) {
            this.main.triggerEvent(EVENTS['historySearch'])
        }
        let top
        editor.on('changes', (cm, changes) => {
            if (this.logsGoOn) {
                // cm.scrollTo(null, cm.doc.height)
                cm.scrollIntoView({ line: this.Editor.lastLine() })
            } else {
                cm.scrollTo(null, top)
            }
        })
        // let temp = false // 防止重复历史请求的标识
        editor.on('scroll', cm => {
            let data = cm.doc
            let clientHeight = cm.display.lastWrapHeight
            top = data.scrollTop
            let type = 'scrollBottom'
            if (data.scrollTop + clientHeight >= data.height - 2) {
                type = 'scrollBottom'
                this.logsGoOn = true
            } else {
                type = 'scrollCenter'
                if (top <= 3) {
                    type = 'scrollTop'
                }
                this.logsGoOn = false
            }
            this.main.triggerEvent(EVENTS['scrollEvents'], type)
        })
    }
    // 差异对比编辑框渲染
    diffCompare = () => {
        let diffCompare = this.params.dom
        diffCompare.innerHTML = ''
        let myCodeMirror = CodeMirror.MergeView(diffCompare, {
            value: this.params.value || '',
            origLeft: null,
            orig: this.params.orig,
            lineNumbers: true,
            mode: this.options.mode,
            // theme: this.options.theme,
            styleActiveLine: true,
            highlightDifferences: false,
            scrollbarStyle: 'simple',
            // connect: 'align',
            revertButtons: false, // 是否显示还原按钮
            readOnly: true, // 只读 不可修改
            // 悬浮提示需修改源代码
            // autoRefresh: true,
        })
        this.addStyles(this.params.dom)
        const style = document.createElement('style')
        style.type = 'text/css'
        const textNode = document.createTextNode(`
        .CodeMirror-merge,
        .CodeMirror-merge .CodeMirror{
            height: ${this.params.height}px !important; 
        }
        .CodeMirror-merge-r-chunk{
            background: none;
        }
        .CodeMirror-merge-r-chunk-start{
            border-top: none;
        }
        .CodeMirror-merge-r-chunk-end{
            border-bottom: none;
        }`)
        style.appendChild(textNode)
        this.params.dom.appendChild(style)
        return myCodeMirror.edit
    }

    // 按光标所在位置插入指定代码
    insertValue = (insertValue = 'insertValue') => {
        let editor = this.Editor
        editor.replaceSelection(insertValue)
    }

    // 修改编辑框value
    updateValue = () => {
        // this.params.updateParams(this.Editor.getValue())
        this.autoSaveTime = this.params.autoSaveTime || 30 // 若限定时间内再次操作 则重置倒计时时间
        if (this.saved) {
            this.saved = false
            let saveTimer = setInterval(() => {
                this.autoSaveTime--
                // console.log(this.autoSaveTime)
                if (this.autoSaveTime <= 0) {
                    clearInterval(saveTimer)
                    this.saved || this.S2S()
                }
            }, 1000)
        }
    }
    S2S = () => {
        document.onkeydown = () => {
            // 阻止浏览器Ctrl+S
            if (window.event.ctrlKey === true && window.event.keyCode === 83) {
                return false
            }
        }
        // 此次保存完成 自动保存时间倒计时置零 自动保存标识置为true
        this.autoSaveTime = 0
        // 这里放保存到后端的方法
        this.main.params.autoSave && this.params.autoSave()
        this.saved = true
    }
    annotate = () => {
        // 单行注释
        let currentLine = this.Editor.getCursor().line
        let currentLineContent = this.Editor.getLine(currentLine)
        this.Editor.replaceRange('--' + currentLineContent, { line: currentLine, ch: 0 }, { line: currentLine })
        // console.log('所选范围内容', this.Editor.getSelection('\n'))
    }

    // 获取当前编辑框对象
    getEditor = () => {
        return this.Editor
    }

    setValue = (value) => {
        this.Editor.setValue(value)
    }

    getValue = () => {
        return this.Editor.getValue()
    }
    renderDataBottom = (data = []) => {
        // let newValue = this.Editor.getValue()
        // this.Editor.setCursor({ line: this.Editor.lastLine() + 1 })

        let currentValue = this.Editor.getValue()
        let newValue = []
        let timersLen = this.timers.length
        for (let i = 0; i < data.length; i++) {
            if (timersLen >= this.params.maxLine) {
                this.timers.shift()
            }
            this.timers.push(data[i].time)
            newValue.push(data[i].msg)
        }
        if (!!currentValue) {
            let fragment
            if (timersLen >= this.params.maxLine) {
                fragment = currentValue.split('\n').slice(data.length, this.params.maxLine)
            } else {
                fragment = currentValue.split('\n')
            }
            newValue = fragment.concat(newValue)
        }
        this.Editor.setValue(newValue.join('\n'))
        if (this.timers.length >= this.params.maxLine && !this.params.isPush) { // 超出上限加载历史日志时需设置滚动条空隙
            this.Editor.setCursor({ line: this.params.maxLine - data.length, ch: 0 })
            if (data.length >= this.params.searchParam.history.params.limit) {
                // 本次请求数据量不够 则不重置滚动条位置
                const currentLines = Math.floor(this.Editor.display.lastWrapHeight / this.Editor.display.cachedTextHeight) // 当前视窗的行数
                this.Editor.scrollTo(null, this.Editor.doc.scrollTop - this.Editor.display.cachedTextHeight * (currentLines - 2))
            }
        }
    }
    renderDataTop = (data = []) => {
        let currentValue = this.Editor.getValue()
        let newValue = []
        let timersLen = this.timers.length
        for (let i = data.length - 1; i >= 0; i--) {
            if (timersLen >= this.params.maxLine) {
                this.timers.pop()
            }
            this.timers.unshift(data[i].time)
            newValue.unshift(data[i].msg)
        }
        if (!!currentValue) {
            let fragment
            if (timersLen >= this.params.maxLine) {
                fragment = currentValue.split('\n').slice(0, this.params.maxLine - data.length)
            } else {
                fragment = currentValue.split('\n')
            }
            newValue = newValue.concat(fragment)
        }

        this.Editor.setValue(newValue.join('\n'))
        if (this.timers.length >= this.params.maxLine) { // 超出上限加载历史日志时需设置滚动条空隙
            this.Editor.setCursor({ line: data.length, ch: 0 })
            if (data.length >= this.params.searchParam.history.params.limit) {
                const currentLines = Math.floor(this.Editor.display.lastWrapHeight / this.Editor.display.cachedTextHeight)// 当前视窗的行数
                this.Editor.scrollTo(null, this.Editor.doc.scrollTop + this.Editor.display.cachedTextHeight * (currentLines - 2))
            }
        }
    }
    /**
     * 清空操作
     */
    clear = () => {
        // 清空当前编辑框内容
        this.Editor.setValue('')
        // 清空时间缓存
        this.timers = []
        // 重置滚动条位置
        // this.Editor.scrollIntoView({ line: this.Editor.lastLine() })
    }
}
export default Chart