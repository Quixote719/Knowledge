import Util from './util'
import paramMode from './config'
import { EventEmitter } from 'events'
import EventManage from './event'
import Search from './search'
import Chart from './chart'
import EVENTS from './event/eventdeclara'

class EditorBox {
    constructor(params) {
        //深度拷贝然后深度覆盖
        this.params = Util.deepCover(paramMode, params)
        //事件监听初始化
        this.emitter = new EventEmitter()
        //查询对象
        this.event = new EventManage(this)
        //查询对象
        this.search = new Search(this)
        //初始化图形对象
        this.chart = new Chart(this)
    }
    /**
     * 事件绑定
     * @param {*} eventName
     * @param {*} fun
     */
    bind(eventName, fun) {
        this.emitter.addListener(eventName, fun)
    }
    /**
     * 事件监听
     */
    triggerEvent() {
        this.emitter.emit(...arguments)
    }
    /**
     * 停止请求，清空渲染
     */
    clear() {
        this.triggerEvent(EVENTS['clear'])
    }
    /**
     * 删除清空对象信息
     */
    destroy() {
        // console.log('destroy')
        this.clear()
    }
    /**
     * 重设配置参数
     */
    resetParams(params) {
        this.params = Util.deepCover(this.params, params)
    }
    /**
     * 画布外围重置时
     */
    resize() {}
}
export default EditorBox
