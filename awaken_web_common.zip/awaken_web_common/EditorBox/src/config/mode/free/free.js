// CodeMirror, copyright (c) by Marijn Haverbeke and others
// Distributed under an MIT license: https://codemirror.net/LICENSE

(function(mod) {
    if (typeof exports == "object" && typeof module == "object") // CommonJS
      mod(require("codemirror/lib/codemirror"));
    else if (typeof define == "function" && define.amd) // AMD
      define(["codemirror/lib/codemirror"], mod);
    else // Plain browser env
      mod(CodeMirror);
  })(function(CodeMirror) {
  "use strict";
  
  CodeMirror.defineMode("free", function(config, parserConfig) {
    var client         = parserConfig.client || {},
        atoms          = parserConfig.atoms || {"false": true, "true": true, "null": true},
        builtin        = parserConfig.builtin || set(defaultBuiltin),
        keywords       = parserConfig.keywords || set(sqlKeywords),
        funcKeywords   = parserConfig.funcKeywords || set(funcKeywords),
        operatorChars  = parserConfig.operatorChars || /^[*+\-%<>!=&|~^\/]/,
        support        = parserConfig.support || {},
        hooks          = parserConfig.hooks || {},
        dateSQL        = parserConfig.dateSQL || {"date" : true, "time" : true, "timestamp" : true},
        backslashStringEscapes = parserConfig.backslashStringEscapes !== false,
        brackets       = parserConfig.brackets || /^[\{}\(\)\[\]]/,
        punctuation    = parserConfig.punctuation || /^[;.,:]/
  
    function tokenBase(stream, state) {
      var ch = stream.next();
  
      // call hooks from the mime type
      if (hooks[ch]) {
        var result = hooks[ch](stream, state);
        if (result !== false) return result;
      }
  
      if (support.hexNumber &&
        ((ch == "0" && stream.match(/^[xX][0-9a-fA-F]+/))
        || (ch == "x" || ch == "X") && stream.match(/^'[0-9a-fA-F]+'/))) {
        // hex
        // ref: http://dev.mysql.com/doc/refman/5.5/en/hexadecimal-literals.html
        return "number";
      } else if (support.binaryNumber &&
        (((ch == "b" || ch == "B") && stream.match(/^'[01]+'/))
        || (ch == "0" && stream.match(/^b[01]+/)))) {
        // bitstring
        // ref: http://dev.mysql.com/doc/refman/5.5/en/bit-field-literals.html
        return "number";
      } else if (ch.charCodeAt(0) > 47 && ch.charCodeAt(0) < 58) {
        // numbers
        // ref: http://dev.mysql.com/doc/refman/5.5/en/number-literals.html
        stream.match(/^[0-9]*(\.[0-9]+)?([eE][-+]?[0-9]+)?/);
        support.decimallessFloat && stream.match(/^\.(?!\.)/);
        return "number";
      } else if (ch == "?" && (stream.eatSpace() || stream.eol() || stream.eat(";"))) {
        // placeholders
        return "variable-3";
      } else if (ch == "'" || (ch == '"' && support.doubleQuote)) {
        // strings
        // ref: http://dev.mysql.com/doc/refman/5.5/en/string-literals.html
        state.tokenize = tokenLiteral(ch);
        return state.tokenize(stream, state);
      } else if ((((support.nCharCast && (ch == "n" || ch == "N"))
          || (support.charsetCast && ch == "_" && stream.match(/[a-z][a-z0-9]*/i)))
          && (stream.peek() == "'" || stream.peek() == '"'))) {
        // charset casting: _utf8'str', N'str', n'str'
        // ref: http://dev.mysql.com/doc/refman/5.5/en/string-literals.html
        return "keyword";
      } else if (support.escapeConstant && (ch == "e" || ch == "E")
          && (stream.peek() == "'" || (stream.peek() == '"' && support.doubleQuote))) {
        // escape constant: E'str', e'str'
        // ref: https://www.postgresql.org/docs/current/sql-syntax-lexical.html#SQL-SYNTAX-STRINGS-ESCAPE
        state.tokenize = function(stream, state) {
          return (state.tokenize = tokenLiteral(stream.next(), true))(stream, state);
        }
        return "keyword";
      } else if (support.commentSlashSlash && ch == "/" && stream.eat("/")) {
        // 1-line comment
        stream.skipToEnd();
        return "comment";
      } else if ((support.commentHash && ch == "#")
          || (ch == "-" && stream.eat("-") && (!support.commentSpaceRequired || stream.eat(" ")))) {
        // 1-line comments
        // ref: https://kb.askmonty.org/en/comment-syntax/
        stream.skipToEnd();
        return "comment";
      } else if (ch == "/" && stream.eat("*")) {
        // multi-line comments
        // ref: https://kb.askmonty.org/en/comment-syntax/
        state.tokenize = tokenComment(1);
        return state.tokenize(stream, state);
      } else if (ch == ".") {
        // .1 for 0.1
        if (support.zerolessFloat && stream.match(/^(?:\d+(?:e[+-]?\d+)?)/i))
          return "number";
        if (stream.match(/^\.+/))
          return null
        // .table_name (ODBC)
        // // ref: http://dev.mysql.com/doc/refman/5.6/en/identifier-qualifiers.html
        if (support.ODBCdotTable && stream.match(/^[\w\d_]+/)){
            stream.eatWhile(/^[_\w\d]/);
            var word = stream.current();
            // custom：.后跟着关键字需高亮，需区分大小写
            if(keywords.hasOwnProperty(word.split('.')[1])) return "keyword"
            if(funcKeywords.hasOwnProperty(word.split('.')[1])) return "funcKeywords"
            return "variable-2";
        }
      } else if (operatorChars.test(ch)) {
        // operators
        stream.eatWhile(operatorChars);
        return "operator";
      } else if (brackets.test(ch)) {
        // brackets
        return "bracket";
      } else if (punctuation.test(ch)) {
        // punctuation
        stream.eatWhile(punctuation);
        return "punctuation";
      } else if (ch == '{' &&
          (stream.match(/^( )*(d|D|t|T|ts|TS)( )*'[^']*'( )*}/) || stream.match(/^( )*(d|D|t|T|ts|TS)( )*"[^"]*"( )*}/))) {
        // dates (weird ODBC syntax)
        // ref: http://dev.mysql.com/doc/refman/5.5/en/date-and-time-literals.html
        return "number";
      } else {
        stream.eatWhile(/^[_\w\d]/);
        var word = stream.current()
            // .toLowerCase();
        // dates (standard SQL syntax)
        // ref: http://dev.mysql.com/doc/refman/5.5/en/date-and-time-literals.html
        if (dateSQL.hasOwnProperty(word) && (stream.match(/^( )+'[^']*'/) || stream.match(/^( )+"[^"]*"/)))
          return "number";
        if (atoms.hasOwnProperty(word)) return "atom";
        if (builtin.hasOwnProperty(word)) return "builtin";
        if (keywords.hasOwnProperty(word)) return "keyword";
        if (funcKeywords.hasOwnProperty(word)) return "funcKeywords";
        if (client.hasOwnProperty(word)) return "string-2";
        return null;
      }
    }
  
    // 'string', with char specified in quote escaped by '\'
    function tokenLiteral(quote, backslashEscapes) {
      return function(stream, state) {
        var escaped = false, ch;
        while ((ch = stream.next()) != null) {
          if (ch == quote && !escaped) {
            state.tokenize = tokenBase;
            break;
          }
          escaped = (backslashStringEscapes || backslashEscapes) && !escaped && ch == "\\";
        }
        return "string";
      };
    }
    function tokenComment(depth) {
      return function(stream, state) {
        var m = stream.match(/^.*?(\/\*|\*\/)/)
        if (!m) stream.skipToEnd()
        else if (m[1] == "/*") state.tokenize = tokenComment(depth + 1)
        else if (depth > 1) state.tokenize = tokenComment(depth - 1)
        else state.tokenize = tokenBase
        return "comment"
      }
    }
  
    function pushContext(stream, state, type) {
      state.context = {
        prev: state.context,
        indent: stream.indentation(),
        col: stream.column(),
        type: type
      };
    }
  
    function popContext(state) {
      state.indent = state.context.indent;
      state.context = state.context.prev;
    }
  
    return {
      startState: function() {
        return {tokenize: tokenBase, context: null};
      },
  
      token: function(stream, state) {
        if (stream.sol()) {
          if (state.context && state.context.align == null)
            state.context.align = false;
        }
        if (state.tokenize == tokenBase && stream.eatSpace()) return null;
  
        var style = state.tokenize(stream, state);
        if (style == "comment") return style;
  
        if (state.context && state.context.align == null)
          state.context.align = true;
  
        var tok = stream.current();
        if (tok == "(")
          pushContext(stream, state, ")");
        else if (tok == "[")
          pushContext(stream, state, "]");
        else if (state.context && state.context.type == tok)
          popContext(state);
        return style;
      },
  
      indent: function(state, textAfter) {
        var cx = state.context;
        if (!cx) return CodeMirror.Pass;
        var closing = textAfter.charAt(0) == cx.type;
        if (cx.align) return cx.col + (closing ? 0 : 1);
        else return cx.indent + (closing ? 0 : config.indentUnit);
      },
  
      blockCommentStart: "/*",
      blockCommentEnd: "*/",
      lineComment: support.commentSlashSlash ? "//" : support.commentHash ? "#" : "--",
      closeBrackets: "()[]{}''\"\"``"
    };
  });
  
    // `identifier`
    function hookIdentifier(stream) {
      // MySQL/MariaDB identifiers
      // ref: http://dev.mysql.com/doc/refman/5.6/en/identifier-qualifiers.html
      var ch;
      while ((ch = stream.next()) != null) {
        if (ch == "`" && !stream.eat("`")) return "variable-2";
      }
      stream.backUp(stream.current().length - 1);
      return stream.eatWhile(/\w/) ? "variable-2" : null;
    }
  
    // "identifier"
    function hookIdentifierDoublequote(stream) {
      // Standard SQL /SQLite identifiers
      // ref: http://web.archive.org/web/20160813185132/http://savage.net.au/SQL/sql-99.bnf.html#delimited%20identifier
      // ref: http://sqlite.org/lang_keywords.html
      var ch;
      while ((ch = stream.next()) != null) {
        if (ch == "\"" && !stream.eat("\"")) return "variable-2";
      }
      stream.backUp(stream.current().length - 1);
      return stream.eatWhile(/\w/) ? "variable-2" : null;
    }
  
    // variable token
    function hookVar(stream) {
      // variables
      // @@prefix.varName @varName
      // varName can be quoted with ` or ' or "
      // ref: http://dev.mysql.com/doc/refman/5.5/en/user-variables.html
      if (stream.eat("@")) {
        stream.match(/^session\./);
        stream.match(/^local\./);
        stream.match(/^global\./);
      }
  
      if (stream.eat("'")) {
        stream.match(/^.*'/);
        return "variable-2";
      } else if (stream.eat('"')) {
        stream.match(/^.*"/);
        return "variable-2";
      } else if (stream.eat("`")) {
        stream.match(/^.*`/);
        return "variable-2";
      } else if (stream.match(/^[0-9a-zA-Z$\.\_]+/)) {
        return "variable-2";
      }
      return null;
    };
  
    // short client keyword token
    function hookClient(stream) {
      // \N means NULL
      // ref: http://dev.mysql.com/doc/refman/5.5/en/null-values.html
      if (stream.eat("N")) {
          return "atom";
      }
      // \g, etc
      // ref: http://dev.mysql.com/doc/refman/5.5/en/mysql-commands.html
      return stream.match(/^[a-zA-Z.#!?]/) ? "variable-2" : null;
    }
  
    // these keywords are used by all SQL dialects (however, a mode can still overwrite it)
    // gremlin 语法关键字
    var sqlKeywords = ""
    var freeKeywords = "E order map tail group limit value count profile values min max V identity in out key store path sum filter toV tree match range is properties select id from to and or constant asAdmin flatMap label both toE outE inE bothE inV outV bothV otherV propertyMap valueMap mapValues mapKeys sack loops project unfold fold mean groupV3d0 groupCount addV addE addOutE addInE inject dedup where has hasNot hasLabel hasId hasKey hasValue not coin timeLimit simplePath cyclicPath sample drop sideEffect cap subgraph aggregate branch choose optional union coalesce repeat emit until times local pageRank peerPressure program as barrier by option iterate property start"

    sqlKeywords += freeKeywords
    // gremlin 函数关键字
    var funcKeywords = "lt test eq and or not negate within getBiPredicate neq lte gt gte inside outside between without isWildCardMatch isFuzzy preevaluate evaluateRaw tokenize isValidValueType hasNegation isQNF textContains textPrefix textRegex textFuzzy textWildCard textContainsPrefix textContainsRegex textContainsFuzzy P Text"
        // .toLowerCase()
    // turn a space-separated list into an array
    function set(str) {
      var obj = {}, words = str.split(" ");
      for (var i = 0; i < words.length; ++i) obj[words[i]] = true;
      return obj;
    }
  
    var defaultBuiltin = "bool boolean bit blob enum long longblob longtext medium mediumblob mediumint mediumtext time timestamp tinyblob tinyint tinytext text bigint int int1 int2 int3 int4 int8 integer float float4 float8 double char varbinary varchar varcharacter precision real date datetime year unsigned signed decimal numeric"
  
    // A generic SQL Mode. It's not a standard, it just try to support what is generally supported
    CodeMirror.defineMIME("free", {
      name: "free",
      keywords: set(sqlKeywords + "begin"),
      funcKeywords: set(funcKeywords),
      builtin: set(defaultBuiltin),
      atoms: set("false true null unknown"),
      dateSQL: set("date time timestamp"),
      support: set("ODBCdotTable doubleQuote binaryNumber hexNumber")
    });
  });