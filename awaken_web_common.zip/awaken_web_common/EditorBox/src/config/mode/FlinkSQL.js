// SQL语言模式默认配置
const FlinkSQLModel = {
    mode: 'free',
    // theme: 'monokai',
    lineNumbers: true,
    styleActiveLine: true,
    indentWithTabs: true,
    scrollbarStyle: 'simple',
    readOnly: false,
    autoCloseBrackets: true,
    // hintOptions: {
    //     tables: {
    //         自定义提示语: ['TAB_1'],
    //         自定义表名: ['TAB_2']
    //     },
    // },
}
export default FlinkSQLModel
