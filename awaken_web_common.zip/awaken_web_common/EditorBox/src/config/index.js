const paramModel = {
    //日志容器对象，必填的参数
    dom:null,
    //是否全量显示，默认否，全量显示对编辑框有意义，不做滚动及各种历史和推送接口的操作
    isShowAll:false,
    //是否要求推送, 默认是推送 ,推送的话就默认使用推送条件，不是推送则使用历史请求最新
    isPush:true,
    //是否可编辑,默认不可以编辑,可编辑应该有对应的保存接口
    isEdit:false,
    //页面存留的最大行数,超出则反向删除内容
    maxLine:10000,
    // 编辑框第一次加载的数据条数
    // initLoadLimit: 100,
    //请求条件
    searchParam:{
        history:{
            //请求前缀，固定的前缀，避免业务一次次的封装
            url:'',
            //请求后缀，类似业务后缀如日志的组件id等信息
            params: {
                groupTraceId: '',
                // tags: '',
                // tagCondition: "INCLUDE",
                time: 0,
                limit: 1000,
                direction: "FORWARD",
            },
        },
        push:{
            //请求前缀，固定的前缀，避免业务一次次的封装
            wsPrefix:'',
            //请求后缀，类似业务后缀如日志的组件id等信息
            params: {
                groupTraceId: '',
                tags: '',
                tagCondition: "INCLUDE",
                historyLimit: 1000,
            },
        }
    },
    //显示样式
    style:{
        //是否显示行号
        isShowLineNum:false,
        //关键字的设置，颜色大小
        //默认文字颜色和大小
        //默认背景色
    }
    
}
export default paramModel
