let orchestrationParmas = {
    searchParam : {
        history: {
            url: `http://10.3.70.122:9010/awaken/loghub/api/v1/logs/history`,
            params: {
                groupTraceId: "string"
                traceId: "string",
                limit: 1000,
                // direction: 'FORWARD'
            }
        },
        push: {
            wsPrefix: `ws://10.3.70.122:9010/awaken/loghub/api/v1/logs/websocket`,
            params: {
                groupTraceId: "string"
                traceId: "string"
                historyLimit: 1000,
            }
        }
    }
}
editor.clear()
editor.resetParams(orchestrationParmas)