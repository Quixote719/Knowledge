import {EditorBox} from '../src/'

//运维需要提供的方法和参数
let param1 = {
    //日志容器对象，必填的参数
    dom:document.getElementById('box'),
    //是否要求推送, 默认是推送 ,推送的话就默认使用推送条件，不是推送则使用历史请求最新
    isPush:false,
    //是否可编辑,默认不可以编辑,可编辑应该有对应的保存接口
    isEdit:false,
    //是否全量显示，默认否，全量显示对编辑框有意义，不做滚动及各种历史和推送接口的操作
    isShowAll:false,
    //页面存留的最大行数,超出则反向删除内容
    maxLineNum:10000,
    //请求条件
    searchParam:{
        history:{
            //请求前缀，固定的前缀，避免业务一次次的封装
            urlPrefix:'http://xxxxxx/history?',
            //请求后缀，类似业务后缀如日志的组件id等信息
            urlSuffix:'type:r&id:1',
            //每次请求的历史行数上限
            searchLineNum:1000,
        },
        /* 不需要推送，不用配置推送的参数
        push:{
            //请求前缀，固定的前缀，避免业务一次次的封装
            urlPrefix:'http://xxxxxx/push?',
            //请求后缀，类似业务后缀如日志的组件id等信息
            urlSuffix:'type:r&id:1',
            //每次请求的历史行数
            searchLineNum:1000,
        }*/
    },
    //显示样式
    style:{
        //是否显示行号
        isShowLineNum:false,
        //关键字的设置，颜色大小
        //默认文字颜色和大小
        //默认背景色
    }
}
let box = new EditorBox(param1)
//清除,停止查询，清空内容，删除对象
box.destroy()



//流日志需要提供的方法和参数
let param2 = {
    //日志容器对象，必填的参数
    dom:document.getElementById('box'),
    //是否要求推送, 默认是推送 ,推送的话就默认使用推送条件，不是推送则使用历史请求最新
    isPush:true,
    //是否可编辑,默认不可以编辑,可编辑应该有对应的保存接口
    isEdit:false,
    //是否全量显示，默认否，全量显示对编辑框有意义，不做滚动及各种历史和推送接口的操作
    isShowAll:false,
    //页面存留的最大行数,超出则反向删除内容
    maxLineNum:10000,
    //请求条件
    searchParam:{
        history:{
            //请求前缀，固定的前缀，避免业务一次次的封装
            urlPrefix:'http://xxxxxx/history?',
            //请求后缀，类似业务后缀如日志的组件id等信息
            urlSuffix:'type:r&id:1',
            //每次请求的历史行数
            searchLineNum:1000,
        },
        push:{
            //请求前缀，固定的前缀，避免业务一次次的封装
            urlPrefix:'http://xxxxxx/push?',
            //请求后缀，类似业务后缀如日志的组件id等信息
            urlSuffix:'type:r&id:1',
            //每次请求的历史行数
            searchLineNum:1000,
        }
    },
    //显示样式
    style:{
        //是否显示行号
        isShowLineNum:false,
        //关键字的设置，颜色大小
        //默认文字颜色和大小
        //默认背景色
    }
}
let box = new EditorBox(param2)
//清除,停止查询，清空内容，删除对象  包含了clear
box.destroy()

//编排日志需要提供的方法和参数
let param3 = {
    //日志容器对象，必填的参数
    dom:document.getElementById('box'),
    //是否要求推送, 默认是推送 ,推送的话就默认使用推送条件，不是推送则使用历史请求最新 
    isPush:true,//这里很关键，需要得到实际的组件状态，已经运行完毕的话 为false
    //是否可编辑,默认不可以编辑,可编辑应该有对应的保存接口
    isEdit:false,
    //是否全量显示，默认否，全量显示对编辑框有意义，不做滚动及各种历史和推送接口的操作
    isShowAll:false,
    //页面存留的最大行数,超出则反向删除内容
    maxLineNum:10000,
    //请求条件
    searchParam:{
        history:{
            //请求前缀，固定的前缀，避免业务一次次的封装
            urlPrefix:`http://10.3.70.122:9010/awaken/loghub/api/v1/logs/history`,
            //请求后缀，类似业务后缀如日志的组件id等信息
            urlSuffix:'type:r&id:1',
            //每次请求的历史行数
            searchLineNum:1000,
        },
        push:{
            //请求前缀，固定的前缀，避免业务一次次的封装
            urlPrefix:`ws://10.3.70.122:9010/awaken/loghub/api/v1/logs/websocket?`,
            //请求后缀，类似业务后缀如日志的组件id等信息
            urlSuffix:'groupTraceId=4f952c687aac4ff3a0b2a618190e59b3&tags=abc,def&tagCondition=EXCLUDE"',
            //每次请求的历史行数
            searchLineNum:1000,
        }
    },
    //显示样式
    style:{
        //是否显示行号
        isShowLineNum:false,
        //关键字的设置，颜色大小
        //默认文字颜色和大小
        //默认背景色
    }
}
let box = new EditorBox(param3)
//清除,停止查询，清空内容,但不删除对象 停止socket
box.clear()

//编排日志2需要提供的方法和参数
let param4 = {
    //日志容器对象，必填的参数
    dom:document.getElementById('box'),
    //是否要求推送, 默认是推送 ,推送的话就默认使用推送条件，不是推送则使用历史请求最新 
    isPush:false,//这里很关键，需要得到实际的组件状态，已经运行完毕的话 为false
    //是否可编辑,默认不可以编辑,可编辑应该有对应的保存接口
    isEdit:false,
    //是否全量显示，默认否，全量显示对编辑框有意义，不做滚动及各种历史和推送接口的操作
    isShowAll:false,
    //请求条件
    searchParam:{
        history:{
            //请求前缀，固定的前缀，避免业务一次次的封装
            urlPrefix:'http://xxxxxx/history?',
            //请求后缀，类似业务后缀如日志的组件id等信息
            urlSuffix:'type:r&id:1',
            //每次请求的历史行数
            searchLineNum:1000,
        },
        push:{
            //请求前缀，固定的前缀，避免业务一次次的封装
            urlPrefix:'http://xxxxxx/push?',
            //请求后缀，类似业务后缀如日志的组件id等信息
            urlSuffix:'type:r&id:1',
            //每次请求的历史行数
            searchLineNum:1000,
        }
    },

}
box.setParam(param4)
//清除,停止查询，清空内容，删除对象  包含了clear
box.destroy()




//流编辑sql
let param5 = {
    //日志容器对象，必填的参数
    dom:document.getElementById('box'),
    //是否要求推送, 默认是推送 ,推送的话就默认使用推送条件，不是推送则使用历史请求最新 
    isPush:false,//这里很关键，需要得到实际的组件状态，已经运行完毕的话 为false
    //是否可编辑,默认不可以编辑,可编辑应该有对应的保存接口
    isEdit:true,
    //是否全量显示，默认否，全量显示对编辑框有意义，不做滚动及各种历史和推送接口的操作
    isShowAll:true,
    //页面存留的最大行数,超出则反向删除内容
    maxLineNum:10000,
    //显示样式
    style:{
        //是否显示行号
        isShowLineNum:false,
        //关键字的设置，颜色大小
        //默认文字颜色和大小
        //默认背景色
    }
}
box.setParam(param5)
