/**
 * Created by yaojia7 on 2019/5/30.
 */
const fs = require('fs');
const path = require('path');
const geoDataPath = path.resolve(__dirname, './geoData.json');
const geoDataList = JSON.parse(fs.readFileSync(geoDataPath));

const find = (key, value) => {
    return new Promise((resolve, reject) => {
        try{
            const res = geoDataList.find(z => z[key].includes && z[key].includes(value));
            if(!res)
                reject('null');
            const children = geoDataList.filter(z => z.parent == res.adcode);
            res.children = children.map(z => z.adcode);
            resolve(res);
        } catch (e){
            reject(e.toString());
        }
    })
};

/**
 * {
 *  province: name,
 *  city: name,
 *  district: name,
 *  adcode: district_adcode
 * }
 * @type {Array}
 */
let nameCodeList = [];

const fetchNameCodeList = () => {
    if(nameCodeList.length > 0)
        return Promise.resolve(nameCodeList);
    
    return new Promise((resolve, reject) => {
        try{
            const res = [];
            for(let z of geoDataList){
                const tmp = {
                    [z.level]: z.name,
                    adcode: z.adcode
                };

                for(let i = z.acroutes.length - 1; i > 0; --i){
                    const parent = geoDataList.find(zone => zone.adcode == z.acroutes[i]);
                    if(parent)
                        tmp[parent.level] = parent.name
                }
                res.push(tmp);
            }
            resolve(res)
        } catch (e){
            reject(e.toString());
        }
    })
};

fetchNameCodeList().then(data => {
    nameCodeList = data;
});

module.exports = {find, fetchNameCodeList};
