/**
 * Created by yaojia7 on 2018/5/25.
 */
const path = require('path');
const webpack = require('webpack');

module.exports = (env, argv) => {
    const isDev = argv.mode === 'development'
    const config = {
        output: {
            path: __dirname + '/res/js',
            filename: '[name].js',
            publicPath: 'http://127.0.0.1:3002/js/'
        },
        resolve: {
            extensions: ['.js', '.jsx']
        },
        module: {
            rules: [
                {
                    test: /\.(jsx|js)?$/,
                    exclude: /node_modules/,
                    loader: 'babel-loader'
                },
                {
                    test: /\.css$/,
                    loader: "style-loader!css-loader"
                },
                {
                    test: /\.less$/,
                    use: [
                        "style-loader",
                        "css-loader?modules&localIdentName=[path][name]---[local]---[hash:base64:5]",
                        "less-loader"
                    ]
                },
                {
                    test: /\.(png|jpg)$/,
                    loader: 'url-loader?limit=8192'
                },
                {
                    test: /\.glsl$/,
                    loader: 'webpack-glsl-loader'
                },
                {
                    test: /\.worker\.js$/,
                    loader: 'worker-loader',
                    options: {
                        inline: true,
                        fallback: false
                    }
                }
            ]
        }
    }
    if(isDev){
        config.devtool = 'inline-source-map'
        config.entry = {
            bundle: [
                'eventsource-polyfill',
                `webpack-hot-middleware/client?path=http://127.0.0.1:${3002}/__webpack_hmr&timeout=20000`,
                __dirname + '/src/index.js'
            ]
        }
        config.mode = 'development'
        config.plugins = [
            new webpack.optimize.OccurrenceOrderPlugin(),
            new webpack.HotModuleReplacementPlugin(),
            new webpack.DllReferencePlugin({
                context: __dirname,
                manifest: require(__dirname + '/res/js/manifest.json')
            }),
        ]
    } else {
        config.entry = {
            heat: __dirname + '/src/Demo/HeatMapDemo.js',
            scatter: __dirname + '/src/Demo/ScatterMapDemo.js',
            area: __dirname + '/src/Demo/AreaMapDemo.js',
        }
        config.mode = 'production'
        config.output.path = path.resolve(__dirname, 'example')
    }

    return config
};
