/**
 * Created by yaojia7 on 2018/5/25.
 */

const path = require('path');
const fs = require('fs');
const Koa = require('koa');
const koaStatic = require('koa-static');
const bodyParser = require('koa-bodyparser');
const request = require('request-promise');
const cors = require('koa2-cors');
const {find, fetchNameCodeList} = require('./zoneModel');

const TILE_PATH = path.resolve(__dirname, './res/img/daping/tiles');
const app = new Koa();

app.use(cors());

// 配置热加载
const hotUpdate = true;
if(hotUpdate) {
    const webpackHotMiddleware = require('koa-webpack-hot-middleware');
    const webpackDevMiddleware = require('koa-webpack-dev-middleware');
    const webpack = require('webpack');
    let webpackConfig = require(path.resolve(__dirname, './webpack.config'));
    if(typeof webpackConfig == 'function'){
        webpackConfig = webpackConfig({}, {mode: 'development'})
    }
    const compiler = webpack(webpackConfig);
    app.use(webpackDevMiddleware(compiler, {
        noInfo: false,
        quiet: false,
        publicPath: webpackConfig.output.publicPath
    }));
    app.use(webpackHotMiddleware(compiler, {}));
}

// 配置ctx.body解析中间件
app.use(bodyParser({
    formLimit: '5000mb'
}));

// 配置静态资源加载中间件
app.use(koaStatic(
    path.join(__dirname , './res'),
    {maxage: 24 * 60 * 60 * 1000}
));

// 初始化路由中间件
app.use(async (ctx, next) => {
    if(ctx.method === 'GET' && ctx.request.path.includes('daping/tiles')){
        await getTile(ctx);
    } else if(ctx.method === 'POST' && ctx.request.path.includes('tile')){
        await postTile(ctx);
    } else{
        await next();
    }
});

app.use(async (ctx, next) => {
    if(ctx.method === 'GET' && ctx.request.path.includes('zoneNameCodeList')){
        const res = await fetchNameCodeList();
        ctx.body = res;
    } else {
        await next()
    }
});

app.use(async (ctx, next) => {
    if(ctx.method === 'GET' && ctx.request.path.includes('zone/')){
        await getZone(ctx);
    } else {
        await next();
    }
});

app.use(async (ctx, next) => {
    if(ctx.method === 'GET' && ctx.request.path.includes('/zone')){
        await queryZone(ctx);
    } else {
        await next();
    }
});

app.use(async (ctx) => {
    ctx.response.type = 'html';
    ctx.response.body = fs.createReadStream('./res/index.html');
});

const port = 3002;
app.listen(port);
console.log(`Listen on port ${port}`);





const postTile = async (ctx) => {
    try {
        const filename = ctx.request.body.filename;
        const data = ctx.request.body.data;
        const dataBuffer = new Buffer(data, 'base64');
        const tileFile = path.resolve(TILE_PATH, filename);
        if (fs.existsSync(tileFile)) {
            fs.unlinkSync(tileFile);
        }
        fs.writeFileSync(tileFile, dataBuffer);
        ctx.body = '1'
    }catch(error){
        console.error(error);
        ctx.throw(500);
    }
};

const getTile = async ctx => {
    try{
        const reqPath = ctx.request.path;
        ctx.type = 'image/png';
        const zxy = reqPath.match(/([^\/]+)$/g)[0].match(/.*(?=\.png)/g)[0].split('_');
        const tileFile = path.resolve(TILE_PATH, `${zxy.join('_')}.png`);
        if(fs.existsSync(tileFile)){
            ctx.body = fs.createReadStream(tileFile);
        } else {
            ctx.throw(404);
        }
    }catch (e){
        if(ctx.status) ctx.throw(ctx.status);
        console.log(e);
        ctx.throw(500);
    }
};

const getZone = async ctx => {
    try{
        const adcode = ctx.request.path.split('zone/')[1];
        console.log(adcode);
        const zoneData = await find('adcode', adcode);
        ctx.body = zoneData
    } catch (e){
        ctx.throw(e.toString());
    }
};

const queryZone = async ctx => {
    try{
        const query = ctx.request.query;
        console.log(query);
        const key = Object.keys(query)[0];
        const value = query[key];
        const zoneData = await find(key, value);
        ctx.body = zoneData
    } catch (e){
        ctx.throw(e.toString())
    }
}