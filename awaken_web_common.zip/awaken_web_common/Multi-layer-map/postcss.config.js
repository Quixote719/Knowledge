/**
 * Created by yaojia7 on 2018/5/25.
 */
module.exports = {
    plugin: [
        require('autoprefixer')
    ]
};