/**
 * Created by yaojia7 on 2018/5/25.
 */
const path = require('path');
const webpack = require('webpack');

module.exports = (env, argv) => {
    const isDev = argv.mode === 'development'
    const config = {
        entry: [
            __dirname + '/src/Map/Map.js'
        ],
        output: {
            path: __dirname + '/dist',
            filename: 'jamp.js',
            library: 'Jamp',
            libraryTarget: "umd",
            libraryExport: 'default'
        },
        resolve: {
            extensions: ['.js', '.jsx']
        },
        module: {
            rules: [
                {
                    test: /\.(jsx|js)?$/,
                    exclude: /node_modules/,
                    loader: 'babel-loader'
                },
                {
                    test: /\.css$/,
                    loader: "style-loader!css-loader"
                },
                {
                    test: /\.less$/,
                    use: [
                        "style-loader",
                        "css-loader?modules&localIdentName=[path][name]---[local]---[hash:base64:5]",
                        "less-loader"
                    ]
                },
                {
                    test: /\.(png|jpg)$/,
                    loader: 'url-loader?limit=8192'
                },
                {
                    test: /\.glsl$/,
                    loader: 'webpack-glsl-loader'
                },
                {
                    test: /\.worker\.js$/,
                    loader: 'worker-loader',
                    options: {
                        inline: true,
                        fallback: false
                    }
                }
            ]
        }
    }

    if(isDev){
        config.mode = 'development'
        config.devtool = 'source-map'
    } else {
        config.mode = 'production'
        config.output.filename = 'jamp.min.js'
    }

    return config
};
