/**
 * Created by yaojia7 on 2019/4/16.
 */
import React from 'react';
import ReactDOM from 'react-dom';
import styles from '../Map/index.less';
import Map from '../Map/Map';
import mock from './Areamap.json'

export default class Demo extends React.Component{

    constructor(props){
        super(props);
        this.mapDom = null;
    }

    componentDidMount(){
        this.Map = new Map({
            target: this.mapDom,
            zoom: 8,
            center: [120.114, 29.137],
            ref: this,
            mapType: 'area'
        });
        setTimeout(
            () => this.Map.render(mock.data, mock.style),
            5000
        );
    }

    componentWillUnmount(){
        this.Map.destructor();
    }

    render(){
        return <div
            ref={e => this.mapDom = e}
            className={styles.container}
        >
        </div>
    }
}

if(!window.dev) {
    ReactDOM.render(
        <Demo />,
        document.getElementById('main')
    );
}
