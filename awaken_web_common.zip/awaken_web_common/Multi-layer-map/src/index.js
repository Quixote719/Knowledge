/**
 * Created by yaojia7 on 2018/9/14.
 */
import React from 'react';
import ReactDOM from 'react-dom';
import {Router, Route, Redirect, browserHistory, Link} from 'react-router';
import HeatMap from './Demo/HeatMapDemo';
import ScaterMap from './Demo/ScatterMapDemo'
import AreaMap from './Demo/AreaMapDemo'
import styles from './index.less'

const Home = () => {
    return <div className={styles.home}>
        <Link to="/scattermap"><div className={styles.btn}>散点图</div></Link>
        <Link to="/heatmap"><div className={styles.btn}>热力图</div></Link>
        <Link to="/areamap"><div className={styles.btn}>区域图</div></Link>
    </div>
}

const routers = (
    <Route>
        <Route path="/" component={Home}/>
        <Route path="/heatmap" component={HeatMap}/>
        <Route path="/scattermap" component={ScaterMap}/>
        <Route path="/areamap" component={AreaMap}/>
    </Route>
);

const Routers = () => (
    <Router history={browserHistory}>
        {routers}
    </Router>
);

ReactDOM.render(
    <Routers/>,
    document.getElementById('main')
);
