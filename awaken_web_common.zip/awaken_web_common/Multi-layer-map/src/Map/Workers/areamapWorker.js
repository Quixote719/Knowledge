/**
 * Created by yaojia7 on 2019/9/25.
 */
import AreamapWorker from './Areamap.worker'
import BaseWorker from './BaseWorker'
import {WORKER_EVENT_TYPE} from '../utils'

class Worker extends BaseWorker{
    constructor(WebWorker){
        super(WebWorker)
    }

    setAdcodeList(adcodeList){
        return new Promise(resolve => {
            this.postMessage({
                eventType: WORKER_EVENT_TYPE.AREAMAP_SET_ADCODE_LIST,
                adcodeList
            })
            const handler = data => {
                resolve(data)
                this.removeMessageListener(WORKER_EVENT_TYPE.AREAMAP_SET_ADCODE_LIST, handler)
            }
            this.addMessageListener(WORKER_EVENT_TYPE.AREAMAP_SET_ADCODE_LIST, handler)
        })
    }

    insertAdcodeToData(data){
        return new Promise(resolve => {
            this.postMessage({
                eventType: WORKER_EVENT_TYPE.AREAMAP_INSERT_ADCODE,
                data
            })
            const handler = data => {
                resolve(data)
                this.removeMessageListener(WORKER_EVENT_TYPE.AREAMAP_INSERT_ADCODE, handler)
            }
            this.addMessageListener(WORKER_EVENT_TYPE.AREAMAP_INSERT_ADCODE, handler)
        })
    }
}

const areamapWorker = new Worker(AreamapWorker)
export  default areamapWorker
