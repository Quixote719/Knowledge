/**
 * Created by yaojia7 on 2019/9/25.
 */
const WORKER_EVENT_TYPE = {
    AREAMAP_SET_ADCODE_LIST: '设置行政区域adcode列表',
    AREAMAP_INSERT_ADCODE: '更新 areamap 渲染数据中的adcode'
}

let zoneNameCodeList = [];

//根据传入的数据中的省市区县等信息，找到数据列表中每条数据对应的行政区编号adcode
const findAdcode = (zone) => {
    const {province, city, district} = zone;
    const res = {};
    for(let k in zone)
        res[k] = zone[k]
    try {
        if (province) {
            const item = zoneNameCodeList.find(z => z.province == province);
            if(item)
                res.provinceCode = item.adcode;
        }
        if (city) {
            //因为市级行政区域可能存在缩写缩写，如杭州市在数据中为杭州
            //故当在zoneNameCodeList中找不到该数据对应的市时，
            //就在省级行政区域中找以该数据city字段开头的市的adcode
            const item = zoneNameCodeList.find(
                z => z.province === province && z.city && z.city.startsWith(city)
            );
            if(item)
                res.cityCode = item.adcode;
            else
                console.log(item)
        }
        if (district) {
            const item = zoneNameCodeList.find(z => z.district == district);
            if(item)
                res.districtCode = item.adcode
        }
    } catch (e){
        console.log(zone);
        console.log(e)
    }
    return res;
}

//对传入的数据进行初始化
const insertAdcodeToData = (data) => {
    //对不同行政区域级别的value进行聚合
    const res = {
        province: {
            /**
             * [adcode]: value
             */
        },
        city: {},
        district: {},
    };
    for(let item of data){
        const itemWithCode = findAdcode(item);
        const province = itemWithCode.provinceCode;
        const city = itemWithCode.cityCode;
        const district = itemWithCode.districtCode;
        const value = item.value;
        if(province) {
            if(!res.province[province])
                res.province[province] = value;
            else
                res.province[province] += value;
        }
        if(city) {
            if(!res.city[city])
                res.city[city] = value;
            else
                res.city[city] += value;
        }
        if(district) {
            if(!res.district[district])
                res.district[district] = value;
            else
                res.district[district] += value;
        }
    }

    self.postMessage({
        eventType: WORKER_EVENT_TYPE.AREAMAP_INSERT_ADCODE,
        data: res
    })
}

self.onmessage = e => {
    const {eventType, data, adcodeList} = e.data;
    switch (eventType){
        case WORKER_EVENT_TYPE.AREAMAP_SET_ADCODE_LIST:{
            zoneNameCodeList = adcodeList
            break
        }
        case WORKER_EVENT_TYPE.AREAMAP_INSERT_ADCODE: {
            insertAdcodeToData(data)
            break
        }
        default:
            break
    }
}
