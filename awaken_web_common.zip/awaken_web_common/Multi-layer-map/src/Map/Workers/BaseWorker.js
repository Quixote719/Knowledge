
class BaseWorker{
    constructor(Worker){
        this.worker = new Worker()
        this.worker.onmessage = this.onmessage.bind(this)
        this.postMessage = this.worker.postMessage.bind(this.worker)
    }
    listeners = {
        /**
         * [eventType]: [handler1, handler2,...]
         */
    }

    removeMessageListener(eventType, handler){
        if (this.listeners[eventType] && this.listeners[eventType].includes(handler)) {
            this.listeners[eventType].splice(this.listeners[eventType].indexOf(handler), 1)
        }
    }

    addMessageListener(eventType, handler){
        const handlerList = this.listeners[eventType]
        if (!handlerList) this.listeners[eventType] = [handler]
        else handlerList.push(handler)
    }

    onmessage(e){
        const { data, eventType } = e.data
        const handlerList = this.listeners[eventType]
        for (let handler of handlerList) handler(data)
    }
}

export default BaseWorker