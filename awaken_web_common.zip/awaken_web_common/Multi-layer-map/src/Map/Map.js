/**
 * Created by yaojia7 on 2019/4/16.
 */
import EventEmitter from 'event-emitter';
import elementResizeEvent from 'element-resize-event'
import OlLayer from './Layers/BaseMapLayer/OlLayer';
import DOMLayer from './Layers/DOMLayer';
import HeatmapLayer from './Layers/WebglLayer/Heatmap'
import ScattermapLayer from './Layers/WebglLayer/Scatter'
import AreamapLayer from './Layers/WebglLayer/Areamap'
import View from './View';
import './preDefines';
import {lonDeltaDeg} from './utils';
import {
    TWEEN,
    tweenWrap
} from './tween';

class Map{

    constructor(props){

        //Layer 左上角在屏幕坐标系中的坐标
        this.top = props.top || 0;
        this.left = props.left || 0;
        //base map
        this.center = props.center || [120.13, 30.23];
        this.zoom = props.zoom || 13;

        this.worldOriginCoord = []; //世界空间原点的经纬度坐标
        this.scale = 1; //世界空间x轴和屏幕横轴像素的比例

        this.target = props.target;
        if(!this.target)
            throw(new Error('the target canvas is undefined'));
        this.target.style.overflow = 'hidden';

        this.width = props.width || this.target.clientWidth;
        this.height = props.height || this.target.clientHeight;


        this.onresize = this.onresize.bind(this)
        elementResizeEvent(this.target, this.onresize)

        this.baseLayer = null;
        this.createBaseLayer(props);

        this.domLayer = null;
        this.createDOMLayer(props);

        this.view = new View({
            map: this,
            target: this.target,
            width: this.width
        });

        //监听 View 的 center 和 zoom 的变化;
        // this.baseLayer.on('moveend', this.view.handleViewChange);

        this.webglLayer = null
        switch (props.mapType){
            case 'heat':{
                this.webglLayer = new HeatmapLayer({
                    map: this
                })
                break
            }
            case 'scatter':{
                this.webglLayer = new ScattermapLayer({
                    map: this
                })
                break
            }
            case 'area':{
                this.webglLayer = new AreamapLayer({
                    map: this
                })
                break
            }
            default:
                break
        }
    }

    destructor(){
        this.emit('destroy');
    }

    onresize(){
        setTimeout(() => {
            this.width = this.target.clientWidth;
            this.height = this.target.clientHeight;
            this.updateScale()
            this.baseLayer.map.updateSize()
            if(this.webglLayer)
                this.webglLayer.onresize()
            this.emit('viewChange')
        }, 200)
    }

    createBaseLayer(props){
        //创建openlayers图层
        this.baseLayer = new OlLayer({
            target: props.target,
            tileUrlTemplate: props.tileUrlTemplate,
            width: this.width,
            height: this.height,
            center: this.center,
            zoom: this.zoom,
            postrenderCallback: this.init
        });

    }

    createDOMLayer(props){
        //创建顶部的dom图层
        this.domLayer = new DOMLayer({
            container: props.target,
            map: this,
            width: this.width,
            height: this.height,
        })
    }

    updateWorldOriginCoord(){
        const originCoord = this.getCoordinateFromPixel([
            this.width / 2,
            this.height / 2
        ]);
        if(!Number.isNaN(originCoord[0]) && !Number.isNaN(originCoord[1])) {
            this.worldOriginCoord[0] = originCoord[0];
            this.worldOriginCoord[1] = originCoord[1];
        }

    }

    isMapReady = () => this.worldOriginCoord.length === 2

    init = () => {
        //绑定openlayers地图上的部分方法到Map
        this.getCoordinateFromPixel = this.baseLayer.getCoordinateFromPixel;
        this.setCenter = this.baseLayer.view.setCenter.bind(this.baseLayer.view);
        this.getCenter = this.baseLayer.view.getCenter.bind(this.baseLayer.view);
        this.setZoom = this.baseLayer.view.setZoom.bind(this.baseLayer.view);
        this.getZoom = this.baseLayer.view.getZoom.bind(this.baseLayer.view);
        //[westLon, southLat, eastLon, northLat]
        this.getExtent = this.baseLayer.view.calculateExtent.bind(this.baseLayer.view);

        this.updateWorldOriginCoord();

        this.on('viewChange', this.updateScale);

        this.on(
            'zoom',
            (newZoom) => tweenWrap({
                start: {zoom: this.getZoom()},
                end: {zoom: newZoom},
                delay: 150,
                onUpdate: obj => {
                    this.setZoom(obj.zoom);
                    this.emit('viewChange');
                }
            })
        );

        const animate = () => {
            requestAnimationFrame(animate);
            TWEEN.update();
        };

        animate();

        window.map = this;

        this.emit('viewChange');

        // this.render();
    };

    updateScale = () => {
        const extent = this.getExtent();
        this.scale = this.width / Math.abs(extent[0] - extent[2]);
    }

    setExtent = (newFitExtent) => {
        return new Promise((resolve) => {
            tweenWrap(({
                start: this.getExtent(),
                end: newFitExtent,
                delay: 500,
                onUpdate: extent => {
                    if(extent.every(e => !Number.isNaN(e))) {
                        this.baseLayer.view.fit(extent, {
                            constrainResolution: false
                        });
                        this.emit('viewChange');
                    }
                },
                onEnd: resolve
            }));
        });
    }

    render = (data, style) => {
        this.emit('render', data, style);
    }

    handleMouseCoordUpdate = (x, y) => {
        if(this.getCoordinateFromPixel) {
            const mouseCoord = this.getCoordinateFromPixel([x, y]);
            let text = '';

            this.emit('mousehover', {
                mouseCoord,
                updateText: t => text = t
            });

            this.domLayer.renderHoverText(text, mouseCoord);
        }
    };

    transformCoordToPixel = (coord) => {
        try{
            const extent = this.getExtent();
            const scale = this.width / lonDeltaDeg( extent[0], extent[2] );
            return [
                (  coord[0] - extent[0] ) * scale,
                ( -coord[1] + extent[3] ) * scale
            ];
        } catch (e){
            return [0, 0];
        }
    }

    renderAreaNames(areaList = []){
        this.domLayer.renderAreaNames(areaList);
    }
}

EventEmitter(Map.prototype);

export default Map;
