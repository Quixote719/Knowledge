/**
 * Created by yaojia7 on 2019/5/8.
 */
import styles from './index.less';

class DOMLayer{

    constructor(props){
        this.container = props.container;
        if(!this.container)
            throw('the container dom is undefined');

        this.width = props.width || this.container.clientWidth;
        this.height = props.height || this.container.clientHeight;

        this.map = props.map;
        if(!this.map)
            throw('the map is undefined');

        this.areaNameClone = document.createElement('span');
        this.areaNameClone.className = styles.areaName;
        this.labelClone = document.createElement('pre');
        this.labelClone.className = styles.label;

        //渲染Areamap时，显示区域名称的dom元素
        this.areaNameList = [
            /**
             * {
             *  name: '',
             *  coord: [],
             *  dom: null
             * }
             */
        ];

        this.map.on('viewChange', this.updateAreaNamePosition);
    }

    updateAreaNamePosition = () => {
        for(let area of this.areaNameList){
            const pos = this.map.transformCoordToPixel(area.coord);
            const areaNameDom = area.dom;
            if(areaNameDom) {
                areaNameDom.style.left = pos[0] - 18 + 'px';
                areaNameDom.style.top = pos[1] - 9  + 'px';
            }
        }
    };

    renderAreaNames(areaList = [
        /**
         * {
         *  name: '',
         *  coord: []
         * }
         */
    ]){
        let areaNameDomList = this.container.querySelectorAll(`.${styles.areaName}`);
        for(let a of areaNameDomList)
            this.container.removeChild(a);

        this.areaNameList = areaList.slice();
        for(let area of this.areaNameList){
            let areaNameDom = this.areaNameClone.cloneNode(true);
            areaNameDom.innerText = area.name;
            area.dom = areaNameDom;
            this.container.appendChild(areaNameDom);
        }

        this.updateAreaNamePosition()
    }

    renderHoverText(text = '', coord){
        let labelDom = this.container.querySelector(`.${styles.label}`);
        if(labelDom)
            this.container.removeChild(labelDom);

        if(text) {
            const pos  = this.map.transformCoordToPixel(coord);
            labelDom = this.labelClone.cloneNode(true);
            labelDom.innerHTML = text;
            labelDom.style.left = pos[0] + 'px';
            labelDom.style.top = pos[1] + 'px';
            this.container.appendChild(labelDom);
        }
    }
}

export default DOMLayer;

