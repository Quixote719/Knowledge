/**
 * Created by yaojia7 on 2019/4/16.
 */
import 'ol/ol.css';
import Map from 'ol/Map.js';
import View from 'ol/View.js';
import TileLayer from 'ol/layer/Tile';
import {Group as LayerGroup} from 'ol/layer.js';
import XYZ from 'ol/source/XYZ.js';

class OlLayer{

    constructor(props){

        // this.tileUrl = props.tileUrl || '/img/map/{z}_{x}_{y}.png';
        this.tileUrlTemplate = props.tileUrlTemplate || 'http://10.3.73.186:5555/img/map/{z}_{x}_{y}.png';
        this.center = props.center;
        this.zoom = props.zoom;
        this.target = props.target;
        this.width = props.width || this.target.clientWidth;
        this.height = props.height || this.target.clientHeight;
        this.postrenderCallback = props.postrenderCallback;

        this.map = null;
        this.layer = null
        this.view = null;

        this.render();
    }

    genGeoLayer = () => {
        const layer = new TileLayer({
            source: new XYZ({
                url: this.tileUrlTemplate,
            })
        });

        this.layer = layer
        return new LayerGroup({layers: [layer]});
    };

    setVisible = (visible) => {
        this.layer && this.layer.setVisible(visible)
    }

    render(){
        this.map = new Map({
            interactions: [],
            view: new View({
                center: this.center,
                zoom: this.zoom,
                minZoom: 3,
                maxZoom: 16,
                projection: 'EPSG:4326'
            }),
            target: this.target,
            layers: [
                this.genGeoLayer()
            ]
        });

        window.map = this.map;

        this.view = this.map.getView();

        this.getCoordinateFromPixel = this.map.getCoordinateFromPixel.bind(this.map);
        this.on = this.map.on.bind(this.map);
        this.once = this.map.once.bind(this.map);

        this.map.once('postrender', async () => {

            //该回调中，frameState.pixelToCoordinateTransform 中存在NaN分量，
            //导致 getCoordinateFromPixel返回NaN。
            //故人为等半秒
            setTimeout(() => {
                if(this.postrenderCallback)
                    this.postrenderCallback();
            }, 200);

        })
    }

}

export default OlLayer;
