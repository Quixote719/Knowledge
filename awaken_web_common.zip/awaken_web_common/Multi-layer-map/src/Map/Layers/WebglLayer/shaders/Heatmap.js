/**
 * Created by yaojia7 on 2019/5/13.
 */

export const vertexShader = `
    precision mediump float;
    
    uniform float uScale;
    uniform float uRadius;
    uniform vec2 originCoord;
    
    #ifndef SAME_VALUE
        attribute float value;
        varying float vValue;
    #endif
    
    vec3 transformCoord(vec3);
    
    void main(){
    
        #ifndef SAME_VALUE
            vValue = value;
        #endif
    
        gl_PointSize = uRadius * 2.0;
        
        gl_Position = projectionMatrix * modelViewMatrix * vec4( transformCoord(position), 1.0 );
        
    }
    
    vec3 transformCoord(vec3 coord){
    
        float dLon = coord.x - originCoord.x;
        float dLat = coord.y - originCoord.y;
        
        float x = dLon * uScale;
        float y = dLat * uScale;
        
        return vec3(x, y, 0);
    }
    
`;


export const fragmentShader = `
    precision mediump float;
    
    uniform float uBlurFactor;
    
    varying float vValue;
    
    float calcAlpha(vec2);
    
    float calcHeatValue(vec2);
    
    float _distance(vec2 coord){
        vec2 xy = 2.0 * coord - 1.0;
        return sqrt(dot(xy, xy));
    }
    
    void main(){
    
        float alpha = calcAlpha(gl_PointCoord);
        
        gl_FragColor = vec4(calcHeatValue(gl_PointCoord), 0.0, 0.0, 1.0) * alpha;
    }
    
    float calcAlpha(vec2 pointCoord){
    
        float d = _distance(pointCoord);
        float alpha = 1.0;
        float delta = 0.0;
        
        if(d > 1.0){
            discard;
        }
        
        delta = fwidth(d);
        alpha = 1.0 - smoothstep(1.0 - delta, 1.0, d);
        
        return alpha;
    }
    
    float calcHeatValue( vec2 pointCoord){
    
        #ifdef SAME_VALUE
            float value = 1.0;
        #else
            float value = vValue;
        #endif
        
        float dist = _distance(pointCoord);
        
        if(dist > 1.0){
            discard;
        }
        
        return value * clamp( ( 1.0 - dist ) / uBlurFactor, 0.0, 1.0 );
        // return value * pow(clamp( ( 1.0 - dist ) / uBlurFactor, 0.0, 1.0 ), 2.0);
    }
`;

export const GaussianPass = {
    uniforms: {
        tDiffuse: {
            value: null
        },
        uResolution: {
            type: 'vec2',
            value: [],
        }
    },
    vertexShader: `
        varying vec2 vUv;
        
        void main(){
            
            vUv = uv;
            
            gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0);
            
        }
    `,
    fragmentShader: `
        precision mediump float;
        
        uniform sampler2D tDiffuse;
        uniform vec2 uResolution;
        
        varying vec2 vUv;
        
        void main(){
            float dx = 1.0 / uResolution.x;
            float dy = 1.0 / uResolution.y;
            
            vec4 c11 = texture2D(tDiffuse, vUv - vec2(1.0 * dx, 1.0 * dy)) * 0.02748805872886607;
            vec4 c12 = texture2D(tDiffuse, vUv - vec2(0.0 * dx, 1.0 * dy)) * 0.11023787943830274;
            vec4 c13 = texture2D(tDiffuse, vUv - vec2(-1.0 * dx, 1.0 * dy)) *  0.0274880587288660;
            vec4 c21 = texture2D(tDiffuse, vUv - vec2(1.0 * dx, 0.0 * dy)) * 0.11023787943830274;
            vec4 c22 = texture2D(tDiffuse, vUv - vec2(0.0 * dx, 0.0 * dy)) * 0.44209706414415373;
            vec4 c23 = texture2D(tDiffuse, vUv - vec2(-1.0 * dx, 0.0 * dy)) * 0.11023787943830274;
            vec4 c31 = texture2D(tDiffuse, vUv - vec2(1.0 * dx, -1.0 * dy)) * 0.02748805872886607;
            vec4 c32 = texture2D(tDiffuse, vUv - vec2(0.0 * dx, -1.0 * dy)) * 0.11023787943830274;
            vec4 c33 = texture2D(tDiffuse, vUv - vec2(-1.0 * dx, -1.0 * dy)) * 0.02748805872886607;
            
            gl_FragColor = c11 + c12 + c13 + c21 + c22 + c23 + c31 + c32 + c33;
            // gl_FragColor = texture2D(tDiffuse, vUv);
        }
    
    `
};

export const ShaderPass = {
    uniforms: {
        tDiffuse: {value: null},
        uColor1: {value: []},
        uColor2: {value: []},
        uColor3: {value: []},
        uColor4: {value: []},
        uColor5: {value: []},
    },
    vertexShader: `
        varying vec2 vUv;

        void main() {
        
            vUv = uv;
            
            gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
            
        }
    `,
    fragmentShader: `
        precision mediump float;
        
        uniform sampler2D tDiffuse;
        uniform vec3 uColor1;
        uniform vec3 uColor2;
        uniform vec3 uColor3;
        uniform vec3 uColor4;
        uniform vec3 uColor5;
        
        varying vec2 vUv;

        float fade(float, float, float);
        
        vec3 getColor(float);
        
        void main() {

            float heatValue = smoothstep( 0.0, 1.0, texture2D(tDiffuse, vUv).r );
            float alpha = heatValue;
            
            gl_FragColor = vec4(getColor(heatValue) * alpha, alpha);
            // gl_FragColor = texture2D(tDiffuse, vUv);

        }
        
        float fade(float low, float high, float value){
            float mid = (low + high) / 2.0;
            float range = abs(high - low) / 2.0;
            float x = 1.0 - clamp(abs(mid - value) / range, 0.0, 1.0);
            
            return smoothstep(0.0, 1.0, x);
        }
        
        vec3 getColor(float value){
            vec3 blue = vec3(0.0, 0.0, 1.0);
            vec3 cyan = vec3(0.0, 1.0, 1.0);
            vec3 green = vec3(0.0, 1.0, 0.0);
            vec3 yellow = vec3(1.0, 1.0, 0.0);
            vec3 red = vec3(1.0, 0.0, 0.0);
            
            vec3 color = (
                fade(-0.25, 0.25, value) * uColor5 +
                fade(0.0, 0.5, value) * uColor4 +
                fade(0.25, 0.75, value) * uColor3 +
                fade(0.5, 1.0, value) * uColor2 +
                fade(0.75, 1.25, value) * uColor1
            );
            
            return color;
        }
    `
};
