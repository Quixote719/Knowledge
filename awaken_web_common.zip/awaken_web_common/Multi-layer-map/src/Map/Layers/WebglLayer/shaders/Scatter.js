/**
 * Created by yaojia7 on 2019/4/28.
 */

export const vertexShader = `
    precision mediump float;
    
    uniform vec2 originCoord; //世界空间原点所在的经纬度坐标
    uniform float uSize; //散点的默认半径
    uniform float uScale; //屏幕像素宽度与屏幕区域经度宽度比例
    uniform float uColorMax;
    uniform float uColorMin;
    uniform float uSizeMax;
    uniform float uSizeMin;
    
    #ifdef USE_ATTRIBUTE_COLOR
        attribute float color;
        
        varying float vColor;
    #endif
    
    #ifdef USE_ATTRIBUTE_SIZE
        attribute float size;
    #endif
    
    vec3 transformCoord(vec3 coord){
    
        float dLon = coord.x - originCoord.x;
        float dLat = coord.y - originCoord.y;
        
        float x = dLon * uScale;
        float y = dLat * uScale;
        
        return vec3(x, y, 0);
    }
    
    void main(){
    
        #ifdef USE_ATTRIBUTE_COLOR
            vColor = clamp(( color - uColorMin ) / ( uColorMax - uColorMin ), 0.001, 0.999);
        #endif
        
        #ifdef USE_ATTRIBUTE_SIZE
            gl_PointSize = clamp(( size - uSizeMin ) / ( uSizeMax - uSizeMin), 0.001, 0.999) * uSize * 2.0;
        #else
            gl_PointSize = uSize * 2.0;
        #endif
        
        
        
        gl_Position = projectionMatrix * modelViewMatrix * vec4( transformCoord(position), 1.0 );
        
    }
`;

export const fragmentShader = `
    precision mediump float;
    
    uniform vec3 uSingleColor;
    uniform vec3 uColor1;
    uniform vec3 uColor2;
    uniform vec3 uColor3;
    uniform vec3 uColor4;
    uniform vec3 uColor5;
    uniform float uOpacity;
    
    #ifdef USE_ATTRIBUTE_COLOR
        uniform vec2 uColorValueRange; //要显示的归一化后的颜色权重范围
        varying float vColor;
    #endif
    
    float _distance(vec2 coord){
        vec2 xy = 2.0 * coord - 1.0;
        return sqrt(dot(xy, xy));
    }
    
    float fade(float, float, float);
    
    vec3 getColor(float);
        
    void main(){
        #ifdef USE_ATTRIBUTE_COLOR
            if(vColor > uColorValueRange[0] || vColor < uColorValueRange[1]){
                discard;
            }
            vec4 color = vec4(getColor(vColor), uOpacity);
        #else
            vec4 color = vec4(uSingleColor, uOpacity);
        #endif
    
        float d = _distance(gl_PointCoord);
        float alpha = 1.0;
        float delta = 0.0;
        
        if(d > 1.0){
            discard;
        }
        
        delta = fwidth(d);
        alpha = 1.0 - smoothstep(1.0 - delta, 1.0, d);
        
        gl_FragColor = color * alpha;
    }
    
    float fade(float low, float high, float value){
        float mid = (low + high) / 2.0;
        float range = abs(high - low) / 2.0;
        float x = 1.0 - clamp(abs(mid - value) / range, 0.0, 1.0);
        
        return smoothstep(0.0, 1.0, x);
    }
    
    vec3 getColor(float value){
        vec3 color = (
            fade(-0.25, 0.25, value) * uColor5 +
            fade(0.0, 0.5, value) * uColor4 +
            fade(0.25, 0.75, value) * uColor3 +
            fade(0.5, 1.0, value) * uColor2 +
            smoothstep(0.95, 1.0, value) * uColor1
        );
        
        return color;
    }
`;
