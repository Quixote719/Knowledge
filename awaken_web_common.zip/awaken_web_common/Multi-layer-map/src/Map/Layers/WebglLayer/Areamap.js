/**
 * Created by yaojia7 on 2019/5/23.
 */
import Base from './index';
import * as THREE from 'three';
import { delay, genGeoJsonPath, formatColor, getColor } from './../../utils';
import { vertexShader, fragmentShader } from './shaders/Areamap';
import areamapWorker from '../../Workers/areamapWorker'

const AREA_LEVEL_MAP = {
    province: 3,
    city: 2,
    district: 1
};

const AREA_LEVEL_LIST = ['', 'district', 'city', 'province'];

const GEO_DATA_CACHE = {};

fetch(`http://10.3.73.186:5555/map/zoneNameCodeList`)
    .then(res => res.json())
    .then(data => areamapWorker.setAdcodeList(data));

class Areamap extends Base{
    constructor(props){
        super(props);

        this.hoverZone = null;//当前鼠标指向的区域Mesh对象

        this.areaList = new THREE.Group();
        this.zoneCentriodList = new THREE.Group();

        this.renderColorSlider();

        this.highAreaLevel = 0; //传入数据列表中，最高级别的行政区域 1: district, 2: city, 3: province
        this.lowAreaLevel = 0; //传入数据列表中，最低级别的行政区域
        this.currAreaLevel = 0; //当前正在绘制的行政区域级别

        this.zoneValueCache = null;//缓存导入数据中各个区域的value，

        this.maxValue = 1.0;
        this.minValue = 0.0;

        this.nameCoordList = [] //area 名称和中心坐标的数组

        this.init();
    }

    init(){
        super.init();
        this.material = new THREE.ShaderMaterial({
            uniforms: {
                uColor: {
                    type: 'vec3',
                    value: [0.8, 0.8, 0.8]
                },
                uHoverColor: {
                    type: 'vec3',
                    value: formatColor('#fddd52')
                },
                uOpacity: {
                    type: 'f',
                    value: 0.9
                }
            },
            vertexShader: vertexShader,
            fragmentShader: fragmentShader
        });
        this.material.extensions.derivatives = true;
        this.material.transparent = true;

        this.scene.add(this.areaList);
        this.scene.add(this.zoneCentriodList);
        this.initZoom = this.camera.zoom;

        this.map.baseLayer.setVisible(false)
    }

    async fetchZoneDatas(zones){
        const res = [];
        for(let zone of zones) {
            if (zone.adcode) {
                try {
                    let zoneData = null;
                    if(GEO_DATA_CACHE[zone.adcode])
                        zoneData = GEO_DATA_CACHE[zone.adcode];
                    else {
                        zoneData = await fetch(genGeoJsonPath(zone.adcode)).then(res => res.json());
                        GEO_DATA_CACHE[zone.adcode] = zoneData;
                    }

                    if(zoneData) {
                        res.push({
                            ...zoneData,
                            ...zone
                        });
                    }
                } catch (e){
                    console.log(e);
                }
            }
        }
        return res;
    }

    updateStyle(zone, style){
        const maxValue = this.maxValue;
        const minValue = this.minValue;
        const value = (zone.value || zone.value === 0)
            ? (
                maxValue !== minValue
                    ? ( zone.value - minValue ) / ( maxValue - minValue )
                    : 1
            ) : 1;

        const material = zone.material;
        if(style.colorRange) {
            const color = getColor(value, style.colorRange);
            material.uniforms.uColor.value = color;
            const midColor = formatColor(style.colorRange[2])
            material.uniforms.uHoverColor.value = [1 - midColor[0], 1 - midColor[1], 1- midColor[2]];
        }
        if(style.opacity)
            material.uniforms.uOpacity.value = style.opacity;
        if(style.bgColor && !style.bgColor.includes(this.renderer.getClearColor().getHexString()))
            this.renderer.setClearColor(style.bgColor)
        material.needsUpdate = true;
    }

    lastData = null;
    async render(data, style) {
        if(!this.lastData && data.length === 0) return
        if (!this.map.isMapReady()) {
            //世界空间原点坐标为空，说明Map未初始化
            await delay(500);
        }

        // super.render();
        //
        if (this.lastData === data) {
            //如果只是style变化，那么只更新material
            for (let zone of this.areaList.children) {
                this.updateStyle(zone, style);
            }
            //更新ColorSlider的颜色
            if(style.colorRange)
                this.renderColorSlider(style.colorRange, [this.maxValue, this.minValue])

            return;
        }

        //更新ColorSlider的颜色
        if(style.colorRange)
            this.renderColorSlider(style.colorRange, [this.maxValue, this.minValue])

        this.lastData = data;

        //设置此次渲染数据中最高和最低的行政区域级别
        const firstZone = data[0];
        if(firstZone){
            if(firstZone.province)
                this.highAreaLevel = AREA_LEVEL_MAP['province'];
            else if(firstZone.city)
                this.highAreaLevel = AREA_LEVEL_MAP['city'];
            else if(firstZone.district)
                this.highAreaLevel = AREA_LEVEL_MAP['district'];
            else
                this.highAreaLevel = 0;

            if(firstZone.district)
                this.lowAreaLevel = AREA_LEVEL_MAP['district'];
            else if(firstZone.city)
                this.lowAreaLevel = AREA_LEVEL_MAP['city'];
            else if(firstZone.province)
                this.lowAreaLevel = AREA_LEVEL_MAP['province'];
            else
                this.lowAreaLevel = 0;

            this.currAreaLevel = this.highAreaLevel;
        }

        this.zoneValueCache = await areamapWorker.insertAdcodeToData(data);

        this.style = style;

        if(this.currAreaLevel > 0){
            const currAreaLvel = AREA_LEVEL_LIST[this.currAreaLevel];
            const renderData = this.zoneValueCache[currAreaLvel];
            await this._render(
                renderData.__keys().map(i => ({
                    adcode: i,
                    value: renderData[i]
                })),
                style,
            )
        }
    }

    async _render(zoneList, style = this.style){
        const renderData = await this.fetchZoneDatas(zoneList);

        this.resetExtent();
        this.clearAreas();

        this.nameCoordList = [];

        this.maxValue = Math.max(...zoneList.map(z => z.value));
        this.minValue = Math.min(...zoneList.map(z => z.value));

        for(let zone of renderData){
            const material = this.material.clone();

            let coordinates = zone.coordinates;
            const shapeList = [];

            if(zone.geoType === 'MultiPolygon'){
                coordinates = coordinates.map(polygon => polygon[0]);
            }
            for(let coordArr of coordinates) {
                const pts = [];
                for (let p of coordArr) {

                    this.updateExtent(p);

                    pts.push(
                        new THREE.Vector2(
                            ...this.transformCoordToWorld(p).slice(0, 2)
                        )
                    );
                }

                shapeList.push(new THREE.Shape(pts));
            }

            const geometry = new THREE.ShapeBufferGeometry(shapeList);

            const zoneMesh = new THREE.Mesh( geometry, material );
            zoneMesh.name = zone.name;
            zoneMesh.adcode = zone.adcode;
            zoneMesh.acroutes = zone.acroutes;
            zoneMesh.parentCode = zone.parent;
            zoneMesh.level = zone.level;
            if(zone.value || zone.value === 0)
                zoneMesh.value = zone.value;
            zoneMesh.frustumCulled = false;

            if(zone.centroid.length == 2) {
                this.nameCoordList.push({
                    name: zone.name,
                    coord: zone.centroid
                });
            }

            this.updateStyle(zoneMesh, style);
            this.areaList.add(zoneMesh)

            //center point
            // if(zone.centroid.length == 2) {
            //     //centroid字段为区域的地理中心点，center字段为行政中心点
            //     const centralPos = this.transformCoordToWorld(zone.centroid);
            //     const circle = new THREE.Mesh(
            //         new THREE.CircleGeometry(3, 32),
            //         new THREE.MeshBasicMaterial({color: '#4e4e4e'})
            //     );
            //     circle.position.x = centralPos[0];
            //     circle.position.y = centralPos[1];
            //     circle.position.z = 1.0;
            //     circle.frustumCulled = false;
            //     this.zoneCentriodList.add(circle);
            // }
        }

        //如果data为空，就不需要根据data的来设定地图可视边框范围
        if(zoneList.length > 0)
            this.fitExtent();

        if(this.colorSlider) {
            this.colorSlider.resetCursor();
            this.colorSlider.valueRange = [this.maxValue, this.minValue];
        }

        this.map.renderAreaNames(this.nameCoordList);
    }

    fitExtent() {
        super.fitExtent().then(() => {
            this.lastRenderZoom = this.map.getZoom();

            //根据zoom调整center点的大小
            for (let zc of this.zoneCentriodList.children) {
                const scaleRatio = this.initZoom / this.camera.zoom;
                zc.scale.x = scaleRatio;
                zc.scale.y = scaleRatio;
            }
        });
    }


    clearAreas(){
        const areas = this.areaList.children.slice();
        for(let a of areas)
            this.areaList.remove(a);

        const centroids = this.zoneCentriodList.children.slice();
        for(let c of centroids)
            this.zoneCentriodList.remove(c);
    }

    clickHandling = false;
    async handleClick(coord){
        if(
            this.clickHandling ||
            this.lowAreaLevel == this.highAreaLevel
        )
            return;

        const intersections = this.getObjsAtCoord(coord, this.areaList);
        if(intersections && intersections.length > 0){
            const zone = intersections[0].object;
            if(
                zone.level !== 'district' &&
                AREA_LEVEL_MAP[zone.level] > this.lowAreaLevel
            ){
                this.clickHandling = true;
                try {
                    this.currAreaLevel = AREA_LEVEL_MAP[zone.level] - 1;

                    //非区级行政区域，可以点击展开该区域
                    const data = await this.fetchZoneDatas([{adcode: zone.adcode}]);
                    const valueCache = this.zoneValueCache[AREA_LEVEL_LIST[this.currAreaLevel]];
                    const res = [];
                    for (let childAdcode of data[0].children) {
                        res.push({
                            adcode: childAdcode,
                            value: valueCache[childAdcode] || 0
                        })
                    }
                    if (res.length > 0)
                        await this._render(res);
                } catch (e){
                    console.log(e);
                }
                this.clickHandling = false;
            }
        }
    }

    handleHover({mouseCoord, updateText}){

        const intersections = this.getObjsAtCoord(mouseCoord, this.areaList);

        if(intersections && intersections.length > 0) {
            const zone = intersections[0].object;
            updateText( ` ${zone.name}\n${zone.value || ''}` );
            if(zone !== this.hoverZone){
                //悬浮高亮处理
                if(this.hoverZone){
                    this.removeHover(this.hoverZone.material);
                    this.hoverZone.material.needsUpdate = true;
                }
                this.addHover(zone.material);
                zone.material.needsUpdate = true;
                this.hoverZone = zone;
            }
        } else if(this.hoverZone){
            this.removeHover(this.hoverZone.material);
            this.hoverZone.material.needsUpdate = true;
            this.hoverZone = null;
        }
    }

    addHover(material){
        material.vertexShader = '#define HOVER\n' + vertexShader;
        material.fragmentShader = '#define HOVER\n' + fragmentShader;
    }

    removeHover(material){
        material.vertexShader = vertexShader;
        material.fragmentShader = fragmentShader;
    }

    zoomHandling = false;
    async handleZoom(){
        const zoom = this.map.getZoom();
        const firstAreaMesh = this.areaList.children[0];
        if(
            !firstAreaMesh ||
            this.lowAreaLevel == this.highAreaLevel
        )
            return;
        const level = 4 - firstAreaMesh.acroutes.length;
        //上卷操作
        if(
            level === 1 && (this.lastRenderZoom - zoom) > 1 ||
            level === 2 && (this.lastRenderZoom - zoom) > 1.5
        ) {
            if(this.zoomHandling)
                return;

            this.currAreaLevel = level + 1;
            this.zoomHandling = true;

            try {
                const valueCache = this.zoneValueCache[AREA_LEVEL_LIST[this.currAreaLevel]];

                const data = await fetch(
                    genGeoJsonPath(
                        firstAreaMesh.acroutes[firstAreaMesh.acroutes.length - 2]
                    )
                ).then(res => res.json());

                const res = [];
                for (let childAdcode of data.children) {
                    res.push({
                        adcode: childAdcode,
                        value: valueCache[childAdcode] || 0
                    })
                }
                await this._render(res);
            } catch (e){
                console.log(e);
            }
            this.zoomHandling = false;
        }

        //根据zoom调整center点的大小
        for(let zc of this.zoneCentriodList.children){
            const scaleRatio = this.initZoom / this.camera.zoom;
            zc.scale.x = scaleRatio;
            zc.scale.y = scaleRatio;
        }
    }

    handleCursorChange = (max, min) => {
        this.areaList.children.forEach(area => {
            if(area.value > max || area.value < min){
                area.visible = false;
            } else {
                area.visible = true;
            }
        })
        this.map.renderAreaNames(
            this.nameCoordList.filter(item => {
                const area = this.areaList.children.find(a => a.name === item.name)
                if(!area) return false
                return area.visible
            })
        )
    }
}

export default Areamap;
