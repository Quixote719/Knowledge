/**
 * data: [
 *  {
 *    coord: [1.0, 1.0],
 *    value: 1.0,
 *  }
 * ]
 *
 * style: {
 *  blur: 1.0,
 *  radius: 1.0,
 * }
 *
 * Created by yaojia7 on 2019/4/28.
 */
import * as THREE from 'three';
import {RenderPass} from 'three/examples/jsm/postprocessing/RenderPass';
import {EffectComposer} from 'three/examples/jsm/postprocessing/EffectComposer';
import {ShaderPass} from 'three/examples/jsm/postprocessing/ShaderPass';
import Base from './index';
import {
    vertexShader,
    fragmentShader,
    ShaderPass as _ShaderPass,
    GaussianPass
} from './shaders/Heatmap';
import {delay, formatColor, HEAT_COLOR_RANGE} from './../../utils';


const mockStyle = {
    radius: 6.0,
    blur: 6.0
}; //webgl图层的元素样式

// const colorGradient = {
//     0.3: 'blue',
//     0.5: 'lime',
//     0.7: 'yellow',
//     1.0: 'red'
// };

class Heatmap extends Base{
    constructor(props){
        super(props);
        this.points = null; //Points Mesh

        this.init();
    }

    init(){
        super.init();

        this.rtt = new THREE.WebGLRenderTarget( this.width, this.height );
        this.composer = new EffectComposer(this.renderer, this.rtt);
        this.composer.setSize(this.width, this.height);
        const renderEffect = new RenderPass(this.scene, this.camera);
        this.composer.addPass(renderEffect);

        const effect1 = new ShaderPass( _ShaderPass );
        effect1.uniforms.uColor1.value = formatColor(HEAT_COLOR_RANGE[0]);
        effect1.uniforms.uColor2.value = formatColor(HEAT_COLOR_RANGE[1]);
        effect1.uniforms.uColor3.value = formatColor(HEAT_COLOR_RANGE[2]);
        effect1.uniforms.uColor4.value = formatColor(HEAT_COLOR_RANGE[3]);
        effect1.uniforms.uColor5.value = formatColor(HEAT_COLOR_RANGE[4]);
        this.composer.addPass(effect1);
        this.shaderPassEffect = effect1;

        const effect = new ShaderPass( GaussianPass );
        effect.uniforms.uResolution.value = [this.width, this.height];
        this.composer.addPass(effect);
        effect.renderToScreen = true;

        const geometry = new THREE.BufferGeometry();
        const material = new THREE.ShaderMaterial({
            uniforms: {
                uRadius: {
                    type: 'f',
                    value: mockStyle.radius
                },
                uBlurFactor: {
                    type: 'f',
                    value: mockStyle.blur
                },
                uScale: {
                    type: 'f',
                    value: this.map.scale
                },
                originCoord: {
                    type: 'vec2',
                    value: this.worldOriginCoord
                }
            },
            vertexShader: vertexShader,
            fragmentShader: fragmentShader
        });

        material.transparent = true;
        material.blending = THREE.CustomBlending;
        material.blendEquation = THREE.AddEquation;
        material.blendSrc = THREE.OneFactor;
        material.blendDst = THREE.OneFactor;
        material.extensions.derivatives = true;

        this.points = new THREE.Points(
            geometry,
            material
        );
        this.points.frustumCulled = false;
        this.scene.add( this.points );
    }

    lastData = null;
    async render(data, style = mockStyle){
        if(!this.map.isMapReady()){
            //世界空间原点坐标为空，说明Map未初始化
            await delay(500);
        }

        // super.render();
        //
        if(data.length == 0 || !data[0].coord[0] || !data[0].coord[1])
            return;

        const positions = [];
        const values = [];

        const {geometry, material} = this.points;

        //geometry
        if(geometry && this.lastData !== data) {
            this.resetExtent();
            for (let p of data) {
                this.updateExtent(p.coord);
                positions.push(...p.coord, 0);
                if(p.value)
                    values.push(p.value);
            }

            geometry.addAttribute(
                'position',
                new THREE.BufferAttribute(
                    new Float32Array(positions),
                    3
                )
            );

            if(values.length > 0) {
                geometry.addAttribute(
                    'value',
                    new THREE.BufferAttribute(
                        new Float32Array(values),
                        1
                    )
                );
            }
        }

        //material
        if(material){
            material.vertexShader = this.genVS(vertexShader, values.length == 0);
            material.fragmentShader = this.genFS(fragmentShader, values.length == 0);

            if(style.radius)
                material.uniforms.uRadius.value = style.radius;
            if(style.blur)
                material.uniforms.uBlurFactor.value = style.blur;
            if(this.camera)
                material.uniforms.uScale.value = this.map.scale / this.camera.zoom;

        }

        if(this.shaderPassEffect && style.colorRange){
            this.shaderPassEffect.uniforms.uColor1.value = formatColor(style.colorRange[0]);
            this.shaderPassEffect.uniforms.uColor2.value = formatColor(style.colorRange[1]);
            this.shaderPassEffect.uniforms.uColor3.value = formatColor(style.colorRange[2]);
            this.shaderPassEffect.uniforms.uColor4.value = formatColor(style.colorRange[3]);
            this.shaderPassEffect.uniforms.uColor5.value = formatColor(style.colorRange[4]);
        }

        this.points.geometry.needsUpdate  = true;
        this.points.material.needsUpdate  = true;
        this.shaderPassEffect.needsUpdate = true;

        if(data.length > 0 && data !== this.lastData)
            this.fitExtent();
        if(data !== this.lastData)
            this.lastData = data
    }

    genVS = (vs, sameValue = false) => {
        let res = vs;
        if(sameValue)
            res = '#define SAME_VALUE\n' + res;
        return res;
    };

    genFS = (fs, sameValue = false) => {
        let res = fs;
        if(sameValue)
            res = '#define SAME_VALUE\n' + res;

        return res;
    };

    handleViewChange(extent){
        super.handleViewChange(extent);

        if(this.points && this.points.material)
            this.points.material.needsUpdate = true;
    }

}

export default Heatmap;