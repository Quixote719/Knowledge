/**
 * Created by yaojia7 on 2019/4/25.
 */
import * as THREE from 'three';
import {initCamera, initScene, initRenderer,
    render3, lonDeltaDeg, calcCenter} from '../../utils';
import ColorSlider from './../../components/ColorSlider';

class WebGLLayer{

    constructor(props){

        this.alive = true;

        this.map = props.map;
        if(!this.map)
            throw('the map is undefined');

        this.container = props.container || this.map.target;
        if(!this.container)
            throw('the container dom is undefined');

        this.width = props.width || this.container.clientWidth;
        this.height = props.height || this.container.clientHeight;

        this.camera = null;

        this.worldOriginCoord = props.map.worldOriginCoord; //世界空间原点对应的经纬度

        this.colorSlider = null;

        this.animate = this.animate.bind(this);

        this.init = this.init.bind(this);
        this.render = this.render.bind(this);
        this.handleViewChange = this.handleViewChange.bind(this);
        this.handleHover = this.handleHover.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.handleZoom = this.handleZoom.bind(this);
        this.destructor = this.destructor.bind(this);

        this.lastRenderZoom = 0; //最近一次render时，fit extent时的zoom
        this.initZoom = 1; //初始化时camera的zoom值

        this.resetExtent();

        //event
        this.on_off_event('on');
    }

    destructor(){
        this.map.baseLayer.setVisible(true)

        this.alive = false;

        this.container.removeChild(this.renderer.domElement)

        this.renderer.dispose();

        this.on_off_event('off');

        if(this.colorSlider)
            this.container.removeChild(this.colorSlider.element);
    }

    on_off_event(action){
        this.map[action]('render', this.render);
        this.map[action]('viewChange', this.handleViewChange);
        this.map[action]('mousehover', this.handleHover);
        this.map[action]('click', this.handleClick);
        this.map[action]('destroy', this.destructor);
        this.map[action]('zoom', this.handleZoom);
    }

    render(){
        // this.map.updateWorldOriginCoord();
        console.error('the function render is undefined')
    }

    onresize(){
        this.width = this.container.clientWidth;
        this.height = this.container.clientHeight;

        if(this.camera){
            this.camera.left = this.width / -2
            this.camera.right = this.width / 2
            this.camera.top = this.height / 2
            this.camera.bottom = this.height / -2

            this.lastExtent = this.map.getExtent().slice()
            this.camera.updateProjectionMatrix()

        }
        this.renderer && this.renderer.setSize(this.width, this.height)
    }

    init(){
        this.scene = initScene();
        this.camera = initCamera({
            scene: this.scene,
            clientWidth: this.width,
            clientHeight: this.height,
        });
        this.renderer = initRenderer({
            scene: this.scene,
            clearColor: 0x000000,
            alpha: .0,
            clientWidth: this.width,
            clientHeight: this.height,
        })

        this.renderer.domElement.style.position = 'absolute';
        this.renderer.domElement.style.top = '0px';

        this.container.appendChild(this.renderer.domElement);

        window.camera3 = this.camera;
        window.scene = this.scene;
        window.renderer = this.renderer

        this.animate();

    }

    animate(){
        if(this.alive) {
            requestAnimationFrame(this.animate);
            if(this.composer)
                this.composer.render();
            else
                render3(this.renderer, this.scene, this.camera);
        }
    };

    //渲染颜色滚动条，用于按照颜色进行过滤
    renderColorSlider(colorRange, valueRange=[1.0, 0.0]){
        if(this.colorSlider)
            this.container.removeChild(this.colorSlider.element);

        this.colorSlider = new ColorSlider({
            colorRange,
            onUpdate: this.handleCursorChange,
            valueRange
        });
        this.container.appendChild(this.colorSlider.element);
    }

    handleCursorChange(){}

    lastExtent = [];
    handleViewChange(_extent){
        const extent = _extent || this.map.getExtent();
        const dx = Math.abs(extent[0] - extent[2]);

        if(this.camera) {
            if( this.lastExtent.length == 4 ){
                const prevDx = Math.abs(this.lastExtent[0] - this.lastExtent[2]);
                const scaleZoom = prevDx / dx;
                this.camera.zoom *= scaleZoom;
            }

            const center = calcCenter(extent);
            this.camera.position.x = 1 / this.camera.zoom * (center[0] - this.worldOriginCoord[0]) * this.width / dx;
            this.camera.position.y = 1 / this.camera.zoom * (center[1] - this.worldOriginCoord[1]) * this.width / dx;

            this.camera.updateProjectionMatrix();
        }

        this.lastExtent = extent.slice();
    }

    handleClick(){}

    handleHover(){}

    handleZoom(){}

    //调整可视区域
    fitExtent(){
        return this.map.setExtent([
            this.west,
            this.south,
            this.east,
            this.north
        ])
    }

    //重置可视区域范围
    resetExtent(){
        //当前显示区域的边界
        this.west = 180;
        this.east = -180;
        this.north = -90;
        this.south = 90;
    }

    //更新可视区域范围
    updateExtent(p){
        if(p[0] < this.west)
            this.west = p[0];
        if(p[0] > this.east)
            this.east = p[0];
        if(p[1] < this.south)
            this.south = p[1];
        if(p[1] > this.north)
            this.north = p[1];
    }

    getObjsAtCoord(coord, group = this.scene){
        //检查scene是否已经初始化
        if(!this.scene)
            return;

        const mousePos = this.map.transformCoordToPixel(coord);

        const vector = new THREE.Vector2(
            mousePos[0] / this.width * 2 - 1,
            -mousePos[1] / this.height * 2 + 1,
        );
        const rayCaster = new THREE.Raycaster();
        rayCaster.setFromCamera( vector, this.camera);
        const intersections = rayCaster.intersectObjects(group.children);

        return intersections;
    }

    transformCoordToWorld = (coord) => {
        try{
            const extent = this.map.getExtent();
            let dLon = lonDeltaDeg(coord[0], this.worldOriginCoord[0]);
            dLon = coord[0] > this.worldOriginCoord[0] ? dLon : -1 * dLon;
            const dLat = coord[1] - this.worldOriginCoord[1];

            const scale = this.width /
                lonDeltaDeg(
                    extent[0], extent[2]
                );
            return [
                dLon * scale /  this.camera.zoom, //x
                dLat * scale /  this.camera.zoom, //y
                0 //z
            ]

        } catch (e){
            return [ 0, 0, 0 ];
        }
    }
}

export default WebGLLayer;
