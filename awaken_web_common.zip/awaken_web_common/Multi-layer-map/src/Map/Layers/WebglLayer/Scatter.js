/**
 * data: [
 *  {
 *    coord: [1.0, 1.0],
 *    size: 1.0,
 *    color: [1.0, 1.0, 1.0]
 *  }
 * ]
 *
 * style: {
 *  color: 1.0,
 *  size: 1.0
 * }
 *
 * Created by yaojia7 on 2019/4/28.
 */
import * as THREE from 'three';
import Base from './index';
import {vertexShader, fragmentShader} from './shaders/Scatter';
import KDTree from './../../kdTree';
import {distance as _distance} from './../../utils';
import {delay, EXTENT, formatColor, COLOR_RANGE} from './../../utils';


class Scatter extends Base{
    constructor(props){
        super(props);
        this.points = null; //Points Mesh
        this.kdTree = new KDTree([], this.distance);

        this.pointSize = 1; //设置的散点统一半径，用于散点没有设置半径时，KD树的检索

        this.maxColor = Number.MIN_SAFE_INTEGER;
        this.minColor = Number.MAX_SAFE_INTEGER;
        this.hasColorField = false; //attributes中是否含有color属性

        this.maxSize = Number.MIN_SAFE_INTEGER;
        this.minSize = Number.MAX_SAFE_INTEGER;
        this.hasSizeField = false; //attributes中是否含有size属性

        this.init();

        this.renderColorSlider();
    }

    init(){
        super.init();
        const geometry = new THREE.BufferGeometry();
        const material = new THREE.ShaderMaterial({
            uniforms: {
                uColor1: {
                    type: 'vec3',
                    value: formatColor(COLOR_RANGE[0])
                },
                uColor2: {
                    type: 'vec3',
                    value: formatColor(COLOR_RANGE[1])
                },
                uColor3: {
                    type: 'vec3',
                    value: formatColor(COLOR_RANGE[2])
                },
                uColor4: {
                    type: 'vec3',
                    value: formatColor(COLOR_RANGE[3])
                },
                uColor5: {
                    type: 'vec3',
                    value: formatColor(COLOR_RANGE[4])
                },
                uSingleColor: {
                    type: 'vec3',
                    value: formatColor(COLOR_RANGE[0])
                },
                uColorValueRange: { //要显示的颜色字段值归一化后值范围
                    type: 'vec2',
                    value: [1.0, 0.0]
                },
                uOpacity: {
                    type: 'f',
                    value: 1.0
                },
                uSize: {
                    type: 'f',
                    value: 15.0
                },
                //color attribute 的最大值
                uColorMax: {
                    type: 'f',
                    value: 1.0
                },
                uColorMin: {
                    type: 'f',
                    value: 0.0
                },
                //size attribute 的最大值
                uSizeMax: {
                    type: 'f',
                    value: 1.0
                },
                uSizeMin: {
                    type: 'f',
                    value: 0.0
                },
                uScale: {
                    type: 'f',
                    value: this.map.scale
                },
                originCoord: {
                    type: 'vec2',
                    value: this.worldOriginCoord
                }
            },
            vertexShader: vertexShader,
            fragmentShader: fragmentShader
        });

        material.transparent = true;
        material.extensions.derivatives = true;

        this.points = new THREE.Points(
            geometry,
            material
        );
        this.points.frustumCulled = false;
        this.scene.add( this.points );
    }

    lastData = null;
    async render(data, style){
        if(!this.map.isMapReady()){
            //世界空间原点坐标为空，说明Map未初始化
            await delay(500);
        }

        // super.render();
        //
        const colors = [];
        const sizes = [];
        const positions = [];
        this.kdTree.refresh(data);

        if(data.length == 0 || !data[0].coord[0] || !data[0].coord[1])
            return;

        const {geometry, material} = this.points;

        //geometry
        if(geometry && this.lastData !== data) { //如果数据没有变化，则不更新geometry
            this.resetExtent();
            this.maxColor = Number.MIN_SAFE_INTEGER
            this.minColor = Number.MAX_SAFE_INTEGER;
            this.maxSize = Number.MIN_SAFE_INTEGER;
            this.minSize = Number.MAX_SAFE_INTEGER;

            for (let p of data) {
                this.updateExtent(p.coord);
                positions.push(...p.coord, 0);
                if (!Number.isNaN(Number(p.color))) {
                    if(p.color > this.maxColor)
                        this.maxColor = p.color;
                    if(p.color < this.minColor)
                        this.minColor = p.color;
                    colors.push(p.color);
                }
                if (!Number.isNaN(Number(p.size))) {
                    if(p.size > this.maxSize)
                        this.maxSize = p.size;
                    if(p.size < this.minSize)
                        this.minSize = p.size;
                    sizes.push(p.size);
                }
            }

            geometry.addAttribute(
                'position',
                new THREE.BufferAttribute(
                    new Float32Array(positions),
                    3
                )
            );

            if (colors.length > 0) {
                this.hasColorField = true;
                geometry.addAttribute(
                    'color',
                    new THREE.BufferAttribute(
                        new Float32Array(colors),
                        1
                    )
                );
            } else {
                this.hasColorField = false;
            }

            if (sizes.length > 0) {
                this.hasSizeField = true;
                geometry.addAttribute(
                    'size',
                    new THREE.BufferAttribute(
                        new Float32Array(sizes),
                        1
                    )
                );
            } else {
                this.hasSizeField = false;
            }
        }

        //material
        if(material){
            material.vertexShader = this.genVS(vertexShader);
            material.fragmentShader = this.genFS(fragmentShader);

            if(style.colorRange){
                material.uniforms.uColor1.value = formatColor(style.colorRange[0]);
                material.uniforms.uColor2.value = formatColor(style.colorRange[1]);
                material.uniforms.uColor3.value = formatColor(style.colorRange[2]);
                material.uniforms.uColor4.value = formatColor(style.colorRange[3]);
                material.uniforms.uColor5.value = formatColor(style.colorRange[4]);
            }
            if(style.color)
                material.uniforms.uSingleColor.value = formatColor(style.color)
            if(this.hasColorField){
                material.uniforms.uColorMax.value = this.maxColor;
                material.uniforms.uColorMin.value = this.minColor;
            }
            if(this.hasSizeField){
                material.uniforms.uSizeMax.value = this.maxSize;
                material.uniforms.uSizeMin.value = this.minSize;
            }
            if(style.size) {
                material.uniforms.uSize.value = style.size;
                this.pointSize = style.size;
            }
            if(style.opacity)
                material.uniforms.uOpacity.value = style.opacity;
            if(this.camera)
                material.uniforms.uScale.value = this.map.scale / this.camera.zoom;
        }

        this.points.geometry.needsUpdate = true;
        this.points.material.needsUpdate = true;

        if(colors.length == 0){
            //当没有散点颜色字段时，隐藏colorSlider
            this.colorSlider.visible = false;
        } else if( this.colorSlider){
            this.colorSlider.resetCursor();
            this.colorSlider.valueRange = [this.maxColor, this.minColor];
            if(this.colorSlider.visible == false)
                this.colorSlider.visible = true;
        }

        if(data.length > 0 && data !== this.lastData)
            this.fitExtent();
        if(this.lastData !== data)
            this.lastData = data
    }

    genVS = (vs) => {
        let res = vs;
        if(this.hasColorField)
            res = '#define USE_ATTRIBUTE_COLOR\n' + res;
        if(this.hasSizeField)
            res = '#define USE_ATTRIBUTE_SIZE\n' + res;

        return res;
    };

    genFS = (fs) => {
        let res = fs;
        if(this.hasColorField)
            res = '#define USE_ATTRIBUTE_COLOR\n' + res;

        return res;
    };

    handleViewChange(extent){
        super.handleViewChange(extent);

        if(this.points && this.points.material)
            this.points.material.needsUpdate = true;
    }

    distance = (a, b) => {
        if(this.hasColorField) {
            //hover时不提示被右下角颜色条带过滤掉的点
            if (
                b.color < (this.filterMinColor || this.minColor)
                ||
                b.color > (this.filterMaxColor || this.maxColor)
            )
                return 1;
        }

        return _distance([a.lon, a.lat], [b.lon, b.lat]) * this.map.scale
            - (
                this.hasSizeField
                    ? ((b.size - this.minSize) / (this.maxSize - this.minSize) * this.pointSize)
                    : this.pointSize
           );
    };

    //返回当前鼠标指向的所有点
    handleHover({mouseCoord, updateText}){

        //检查scene是否已经初始化
        if(!this.scene)
            return;

        const hoverPoints = this.kdTree.nearest(mouseCoord);

        let text = '';
        for (let l of hoverPoints) {
            text += `经度: ${l.coord[0]}\n`;
            text += `纬度: ${l.coord[1]}\n`;
            if(Object.keys((l.labelFields)).length > 0){
                for(let k in l.labelFields)
                    text += `${k}: ${l.labelFields[k]}\n`
            }
            text += '\n'
        }

        updateText(text);
    }

    handleCursorChange = (max, min) => {
        this.points.material.uniforms.uColorValueRange.value = [
            (max - this.minColor) / (this.maxColor - this.minColor),
            (min - this.minColor) / (this.maxColor - this.minColor),
        ];
        this.filterMaxColor = max;
        this.filterMinColor = min;
    }
}

export default Scatter;