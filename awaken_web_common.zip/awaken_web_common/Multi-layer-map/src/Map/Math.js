/**
 * Created by yaojia7 on 2019/5/27.
 */
export const clamp  = (val, low, high) => {
    if(val < low)
        return low;
    if(val > high)
        return high;
    return val;
};

export const smoothstep = (low, high, val) => {
    if(val <= low)
        return 0.0;
    if(val >= high)
        return 1.0;

    const t = ( val - low ) / ( high - low );

    return 3 * Math.pow(t, 2) - 2 * Math.pow(t, 3);
};

export const fade = (low, high, val) => {
    const mid = (low + high) / 2;
    const range = Math.abs(high - low) / 2;
    const x = 1.0 - clamp(Math.abs(mid - val) / range, 0, 1);

    return smoothstep(0, 1, x);
};

export const GaussionKernel = (sigma = 0.6, size = 5) => {
    const res = new Array();
    const sigma2 = sigma * sigma;
    if(size % 2 == 0)
        size++;
    let start = -1 * parseInt(size / 2);
    let end = parseInt(size / 2);

    function Gaussion(m, n){
        return Math.exp( -0.5 * (m * m + n * n) / sigma2) / ( 2 * Math.PI * sigma2);
    }

    for(let m = start; m <= end; ++m){
        if(!res[m - start])
            res[m - start] = new Array();
        for(let n = start; n <= end; ++n){
            res[m - start][n - start] = Gaussion(m, n);
        }
    }

    return res;
};
