/**
 * Created by yaojia7 on 2019/4/17.
 */
import * as THREE from 'three';
import * as extent from 'ol/extent';
import {
    fade,
    smoothstep
} from './Math';

export const delay = (time = 1000) => new Promise(resolve => {setTimeout(resolve, time)})

export const simplifyNumber = (num) => {
    let res = Number(num);
    if(res !== res)
        return num;
    if(res > 1)
        return res.toFixed(2);
    const str = res.toString();
    let i;
    for(i = 0; i < str.length; ++i){
        if(str.charAt(i) !== '0' && str.charAt(i) !== '.')
            break;
    }
    return Number(res.toFixed(i + 1));
};

export const initScene = () => {
    const scene = new THREE.Scene();

    return scene;
}

export const initCamera = ({
    scene,
    initPosition = new THREE.Vector3(0, 0, 100),
    clientWidth = window.innerWidth,
    clientHeight = window.innerHeight,
}) => {
    if(scene){
        const camera = new THREE.OrthographicCamera(
            clientWidth / -2,
            clientWidth / 2,
            clientHeight / 2,
            clientHeight / -2,
            1,
            10000
        );
        window.cam = camera
        camera.position.copy(initPosition);
        camera.lookAt(scene.position);
        return camera;
    }
    return null;
};

export const initRenderer = ({
    enableAntialias = true,
    enableAlpha = true,
    alpha = 0.5,
    clearColor = 0xffffff,
    clientWidth = window.innerWidth,
    clientHeight = window.innerHeight
}) => {
    const renderer = new THREE.WebGLRenderer({
        antialias: enableAntialias,
        alpha: enableAlpha,
    });

    renderer.setClearColor(clearColor, alpha);
    renderer.setPixelRatio(window.devicePixelRatio);
    renderer.setSize(clientWidth, clientHeight);
    renderer.autoClear = true;

    const gl = renderer.context;
    if (!gl.getExtension('OES_texture_float')) {
        alert('OES_texture_float not supported');
        throw 'missing webgl extension';
    }

    if (!gl.getExtension('OES_texture_float_linear') ) {
        alert('OES_texture_float_linear not supported');
        throw 'missing webgl extension';
    }

    return renderer;
};

export const render3 = (renderer, scene, camera) => {
    renderer.render(scene, camera);
};

export const debounce = (func, timeout) => {
    let timer = null;
    return function(){
        const args = Array.from(arguments);
        if(timer)
            clearTimeout(timer);

        timer = setTimeout(function(){
            func.apply(this, Array.from(args));
            timer = null;
        }, timeout);
    }
};


export const lonDeltaDeg = (lon1, lon2) => {
    let res = 0;
    if(lon1 * lon2 > 0)
         res =Math.abs(lon2 - lon1);

    else if(lon1 > 0)
         res =(lon2 + 360) - lon1;

    else if(lon2 > 0)
        res = (lon1 + 360) - lon2;

    if(res > 180)
        return 180 - res % 180;
    return res;
};

//计算 westLon 与 eastLon 之间的中间数
export const middleLon = (westLon, eastLon) => {
    const hd = lonDeltaDeg(westLon, eastLon) / 2;
    return ( westLon + hd ) % 180;
};

export const middleLat = (southLat, northLat) => {
    return ( northLat - southLat ) / 2 + southLat;
};

export const calcCenter = (extent) => {
    return [
        middleLon(extent[0], extent[2]),
        middleLat(extent[1], extent[3])
    ]
};

export const containsCoordinate = (_extent, center) => {
    return extent.containsCoordinate(_extent, center);
}

export const distance = (s, e) => {
    try {
        return Math.pow(Math.pow(e[0] - s[0], 2) + Math.pow(e[1] - s[1], 2), 0.5);
    }catch (e){
        console.log(e);
        return 0;
    }
};

//数组乱序
export const randomOrderArr = (arr) => {
    const res = arr.slice();

    for(let i = 0; i < res.length; ++i){
        const randIndex = i + 1 + Math.floor(Math.random() * (res.length - i - 1));
        const tmp = res[i];
        res[i] = res[randIndex];
        res[randIndex] = tmp;
    }

    return res;
};

export const EXTENT = [73.3, 3.5, 135.3, 53.4]; //中国
// export const EXTENT = [120.0, 30.1, 120.3, 30.4]; //杭州主城区

export const genGeoJsonPath = (code) => `http://10.3.73.186:5555/map/zone/${code}`;

export const COLOR_RANGE = [
    '#ff4600',
    '#ffa100',
    '#fefe00',
    '#c9e971',
    '#87cef9',
];

export const HEAT_COLOR_RANGE = [
    '#ff0000',
    '#ffff00',
    '#00ff00',
    '#00ffff',
    '#0000ff'
]

export const getColor = (value, colorRange = []) => {

    value = Number(value);
    colorRange = colorRange.length > 1 ? colorRange : COLOR_RANGE;
    const colorList = colorRange.map(c => formatColor(c));
    const weightList = colorList.map(() => 0);
    const len = colorList.length;

    const step = 1.0 / (len - 1);
    weightList[0] = smoothstep(1 - step, 1, value);
    for(let i = 1; i < len; ++i)
        weightList[i] = fade(
            (len - 1 - i - 1) * step,
            (len - 1 - i + 1) * step,
            value
        );

    let color = [0, 0, 0];
    for(let i = 0; i < len; ++i)
        color._add(
            colorList[i]._mul(weightList[i])
        );

    return color;
};

export const formatColor = (color) => {
    if(typeof color == 'number'){
        //0xffffff
        const r = ( color & 0xff0000 ) >> 16;
        const g = ( color & 0x00ff00 ) >> 8;
        const b = color & 0x0000ff;
        return [r / 255, g / 255, b / 255];
    }

    if(typeof color == 'string'){
        //'#ffffff'
        const hexNum = Number(color.replace('#', '0x'));
        const r = ( hexNum & 0xff0000 ) >> 16;
        const g = ( hexNum & 0x00ff00 ) >> 8;
        const b = hexNum & 0x0000ff;
        return [r / 255, g / 255, b / 255];
    }

    let res = color.slice();

    if(res.some(i => i > 1))
        res = res.map(i => i / 255);
    if(res.length == 3)
        res = [...res];

    return res;
}

export const WORKER_EVENT_TYPE = {
    AREAMAP_SET_ADCODE_LIST: '设置行政区域adcode列表',
    AREAMAP_INSERT_ADCODE: '更新 areamap 渲染数据中的adcode'
}

if(!Object.prototype.__values){
    Object.defineProperty(Object.prototype, '__values', {
        value: function(){
            const keyList = Object.keys(this);
            return keyList.map(k => this[k]);
        },
        enumerable: false,
        writable: false
    })
}

if(!Object.prototype.__keys){
    Object.defineProperty(Object.prototype, '__keys', {
        value: function(){
            return Object.keys(this);
        },
        enumerable: false,
        writable: false
    })
}
