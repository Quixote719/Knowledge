/**
 * Created by yaojia7 on 2019/5/27.
 */
if(!Array.prototype._mul){
    Object.defineProperty(Array.prototype, '_mul', {
        value: function (num) {
            for (let i = 0; i < this.length; ++i)
                this[i] *= num;
            return this;
        }
    })
}

if(!Array.prototype._add){
    Object.defineProperty(Array.prototype, '_add', {
        value: function(arr){
            if(arr.length !== this.length)
                return this;
            for(let i = 0; i < arr.length; ++i)
                this[i] += arr[i];

            return this;
        }
    })
}
