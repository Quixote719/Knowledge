# Multi-layer-map
> Multi-layer-map is a JavaScript library used to render the map in the Big Data Visualization



## USAGE

 - install
 ```bash
 npm install multi-layer-map.js
 ```
 
 - import 
 ```ts
 import jamp from 'multi-layer-map.js';
 ```
 
 ```html
 <script src="dist/jamp.min.js"></script>
 ```
 
 - example
 ```ts
 // init map
 const map = new Jamp({
    target: document.querySelector('#main'),
    zoom: 8,
    center: [120.114, 29.137],
    mapType: 'area' // 'scatter' | 'heat'
});
// render data
map.render(data, style);
 ```
 
 - format
 1. scatter map
 ```ts
 //data
 [
    {
        id: String,
        coord: [Number, Number],
        color: Number, //use the value to generate color by color interpolation
        size: Number, //use the normalized value to generate scatter radius style.size
        labelFields: {
            [key]: value
        } //shown in the scatter's tooltip
    }
 ]
 //style
 {
     colorRange: [
        "#ff4600",
        "#ffa100",
        "#fefe00",
        "#c9e971",
        "#87cef9"
     ], //used in the color interpolation of scatter
     size: Number, //scatter's radius. When data.item.size is defined, this value will be used to calculate each scatter's radius as the max value
     opacity: Number, // [0 - 1]
 }
 ```
 2. heat map
 //data 
```ts
[
    {
        coord: [Number, Number]
    }
]
```
//style
{
    blur: Number,
    radius: Number
}
3. area map
//data
```ts
//data
[
    {
        id: String, //adcode
        city: String, //资阳市
        province: String, //四川省
        district: String, //安岳县
        value: Number //the statistic value of the lowest level administrative region of this item
    }
]
//style
{
    colorRange: [
        "#ff4600",
        "#ffa100",
        "#fefe00",
        "#c9e971",
        "#87cef9"
    ], //used in the color interpolation of the region color
    opacity: Number
}
```

## Build
- npm run build

## Run
- node app.js
- npm start
