/**
 * Created by yaojia7 on 2019/5/30.
 */
const fs = require('fs');
const path = require('path')
const {add} = require('./zoneModel');
const geoPath = path.resolve(__dirname, './res/data');

function readJson(adcode, full=false){
    try {
        const geoData = JSON.parse(
            fs.readFileSync(
                path.resolve(
                    geoPath,
                    adcode + (full ? '_full.json' : '.json')
                )
            )
        );
        return geoData;
    } catch (e){
        console.log(e);
        return null;
    }
}

function getTelecode(adcode){
    try {
        const data = readJson(adcode);
        return data.features[0].properties.telecode
    } catch (e){
        console.log(e);
        return ''
    }
}

async function insertSubZone(adcode){

    const fullData = readJson(adcode, true);

    if(fullData) {
        for (let item of fullData.features) {
            const props = item.properties;
            const geometry = item.geometry;
            if(props.adcode != 100000) {
                const zone = {
                    adcode: props.adcode,
                    parent: props.parent.adcode,
                    level: props.level,
                    name: props.name,
                    center: props.center,
                    centroid: props.centroid,
                    geoType: geometry.type,
                    acroutes: props.acroutes,
                    telecode: getTelecode(props.adcode),
                    coordinates: geometry.coordinates
                };

                await add(zone);

                if ( props.level !== 'district' )
                    await insertSubZone(props.adcode);
            }
        }
    }
}

insertSubZone(
    '100000'
);
