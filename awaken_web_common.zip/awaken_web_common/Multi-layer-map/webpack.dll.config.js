/**
 * Created by yaojia7 on 2018/5/25.
 */
const webpack = require('webpack');

const vendors = [
    'react',
    'react-dom',
    'react-router',
    'three',
    'moment',
    'ol'
];

module.exports = {
    output: {
        path: __dirname + '/res/js',
        filename: '[name].js',
        library: '[name]'
    },
    entry: {
        "lib": vendors
    },
    module: {
        rules: [
            {
                test: /\.(jsx|js)?$/,
                exclude: /node_modules/,
                loader: 'babel-loader'
            },
            {
                test: /\.(png|jpg)$/,
                loader: 'url-loader?limit=8192'
            },
        ]
    },
    plugins: [
        new webpack.DllPlugin({
            path: __dirname + '/res/js/manifest.json',
            name: '[name]',
            context: __dirname
        })
    ]
};
