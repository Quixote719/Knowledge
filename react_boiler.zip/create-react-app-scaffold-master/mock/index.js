const requireContext = require('require-context')
let results = {}
const context = requireContext(__dirname, false, /\.js$/)
context
    .keys()
    .filter(item => !['index.js', 'config.js'].includes(item))
    .forEach(key => {
        results = {
            ...results,
            ...context(key)
        }
    })
const proxy = {
    _proxy: {
        proxy: {},
        changeHost: true,
        httpProxy: {
            options: {
                ignorePath: true
            },
            listeners: {
                proxyReq: function (proxyReq, req, res, options) {
                    console.warn('proxyReq', proxyReq)
                }
            }
        }
    },
    ...results
}
module.exports = proxy
