#!/usr/bin/env bash

#编译脚本出现任何错误都退出，否则编译的包无法使用
set -e

echo "------------------------------------------------------------------------"
echo "AIFinanceWeb build start."

VERSION="1.0"
TODAY=`date +%Y%m%d`
PACKAGE_NAME=aifinance-web-frontend-${VERSION}
PACKAGE_TYPE=${1:-hbm}
echo "PACKAGE_TYPE=$PACKAGE_TYPE"
PACKAGE_TYPE_ARR=(${PACKAGE_TYPE})
CUR_DIR=$(cd $(dirname "${BASH_SOURCE[0]}"); pwd
cd ${CUR_DIR}

# node_modules/ejs 是一个上库的文件,暂时先不删除node_modules目录,编译时都是新克隆的，没有什么影响
# rm -rf node_modules
rm -rf res/js
rm -rf logs
rm -rf target

#前端编译打包脚本
tar -zxvf node_modules.tar.gz
npm install
git reset --hard HEAD
mkdir -p res/js
npm run build:prod

#打包成果物输出到target目录下

tar -cz -f ${PACKAGE_NAME}.tar.gz res \
scripts \
server \
templates \
app.js \
package.json \
node_modules \
config.json

function package_by_type() {
  cd ${CUR_DIR}
  local TYPE=$1
  BM_PACKAGE_NAME=aifinance-web-frontend-${VERSION}-${TODAY}-${TYPE}
  mkdir -p target/${BM_PACKAGE_NAME}

  cp -r ${TYPE}/* target/${BM_PACKAGE_NAME}
  cp ${PACKAGE_NAME}.tar.gz target/${BM_PACKAGE_NAME}/playbook/roles/function/files

  cd target
  tar -czv -f ${BM_PACKAGE_NAME}.tar.gz ${BM_PACKAGE_NAME}
  rm -rf ${BM_PACKAGE_NAME}
}

for type in ${PACKAGE_TYPE_ARR[@]}; do
  echo "type=${type}"
  package_by_type $type
done

cd ${CUR_DIR}
rm ${PACKAGE_NAME}.tar.gz

echo "AIFinanceWeb build finished."
echo "------------------------------------------------------------------------"
