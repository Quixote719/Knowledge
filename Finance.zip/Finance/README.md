## Requirements

-   `8.x <= node <= 11.x`
-   `npm`
-   `Chrome >= 70`

## 开发环境

-   安装依赖 `npm install 或 yarn install`
-   首次进入或修改 dll 文件时需要先` npm run dll`
-   启动 node 服务 `npm start`

## 项目结构

```
├─public // 模板文件
├─config // 项目配置
├─scripts // npm脚本
├─mock // mock数据
└─src
    ├─assets // 静态文件存放
    ├─commonStyles // 公共样式
    ├─components   // 公共组件
    ├─constants // 常量
    ├─layouts // 布局
    ├─pages // 页面
    ├─servers // 接口
    ├─store
    ├─index.js // 入口文件
    ├─index.less // 全局样式
    └─utils //工具方法
... // 其他配置文件
```
