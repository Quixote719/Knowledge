import React from 'react'
import styles from './index.less'
const NotFoundPage = () => {
    return <div className={styles.notFoundPage}>页面不存在</div>
}
export default NotFoundPage
