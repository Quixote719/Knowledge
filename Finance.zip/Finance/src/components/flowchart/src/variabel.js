/**
 * 全局变量
 * 多处需要控制
 */
var global = {
    //画布信息
    metadata: {},
    //图片全局变量
    IMGS: []
}

export default global
