import React from 'react'
import { Form, Input, Icon, message } from 'antdForHik'
import { cloneDeep } from 'lodash'

import * as styles from './index.less'

// Object.entries() 方法返回一个给定对象自身可枚举属性的键值对数组, 所以每个数组元素，索引0代表Key，索引1代表Value
const KEY = 0
const VALUE = 1

class KeyValueInput extends React.Component {
    constructor(props) {
        super(props)

        const prevState = this.updatePrevState(this.props.extraParams)
        this.state = {
            extraParams: cloneDeep(prevState.extraParams),
            appendParamIndexs: cloneDeep(prevState.appendParamIndexs)
        }
    }

    componentWillReceiveProps(nextProps) {
        if (nextProps.extraParams !== this.props.extraParams) {
            this.updatePrevState(nextProps.extraParams)
        }
    }

    updatePrevState = params => {
        const extraParams = Object.entries(params || {})
        let appendParamIndexs = []
        extraParams.forEach((item, idx) => {
            if (idx !== 0) appendParamIndexs.push(idx)
        })

        this.rows = extraParams.length
        this.prevState = {
            extraParams: cloneDeep(extraParams),
            appendParamIndexs: cloneDeep(appendParamIndexs)
        }

        return this.prevState
    }

    getNewExtraParams = extraParams => {
        let newExtraParams = {}
        extraParams.forEach(param => {
            if (param[KEY] && param[VALUE]) {
                newExtraParams[param[KEY]] = param[VALUE]
            }
        })
        return newExtraParams
    }

    handleSave = () => {
        const fields = ['0', ...this.prevState.appendParamIndexs].map(idx => `param_${idx}`)
        this.props.form.validateFields(fields, { force: true }, err => {
            if (err) {
                message.warn('请正确填写参数配置')
            } else if (this.props.handleSave) {
                this.props.handleSave(this.getNewExtraParams(this.state.extraParams))
            }
        })
    }

    addParam = (type, value, index) => {
        let { extraParams } = this.state
        if (!value) {
            extraParams[index][type] = ''
            return extraParams
        } else {
            extraParams[index][type] = value
        }
        this.setState({ extraParams })
        return extraParams
    }

    remove = idx => {
        const { appendParamIndexs } = this.state
        if (appendParamIndexs.length === 0) {
            return
        }
        this.setState({ appendParamIndexs: appendParamIndexs.filter(index => index !== idx) })
        // 删除对应参数键值对
        this.addParam(KEY, '', idx)
        const extraParams = this.addParam(VALUE, '', idx)
        if (this.props.updateParams) {
            this.props.updateParams(this.getNewExtraParams(extraParams))
        }
    }

    add = () => {
        const { appendParamIndexs } = this.state
        this.setState({ appendParamIndexs: appendParamIndexs.concat(++this.rows) })
    }

    isRepeat = currentName => {
        const { extraParams } = this.state
        let names = []
        let isRepeat = false
        extraParams.forEach((param, idx) => {
            if (param[KEY] !== '') {
                names[idx] = param[KEY]
            }
        })
        if (names.indexOf(currentName) !== names.lastIndexOf(currentName)) isRepeat = true

        return isRepeat
    }

    validateEntries = (rule, value, callback) => {
        const i = rule.field.split('_')[1]
        const { extraParams } = this.state
        if (!extraParams[i][KEY] ^ !extraParams[i][VALUE]) {
            callback('请填写完整键值对')
        } else if (this.isRepeat(extraParams[i][KEY])) {
            callback('name值不能重复！')
        } else {
            if (this.props.updateParams) {
                this.props.updateParams(this.getNewExtraParams(extraParams))
            }
        }
        callback()
    }

    renderKeyInput = inputIdx => {
        const { extraParams } = this.state
        let style = {}
        if (this.props.inputWidth) {
            style.width = this.props.inputWidth
        }
        return (
            <Input
                className={styles.input}
                size="small"
                style={style}
                onChange={e => this.addParam(KEY, e.target.value, inputIdx)}
                value={extraParams[inputIdx] ? extraParams[inputIdx][KEY] : ''}
            />
        )
    }

    renderValueInput = inputIdx => {
        const { extraParams } = this.state
        let style = {}
        if (this.props.inputWidth) {
            style.width = this.props.inputWidth
        }
        return (
            <Input
                className={styles.input}
                size="small"
                style={style}
                onChange={e => this.addParam(VALUE, e.target.value, inputIdx)}
                value={extraParams[inputIdx] ? extraParams[inputIdx][VALUE] : ''}
            />
        )
    }

    renderRow = rowIdx => {
        return (
            <div className={styles.inputWrap}>
                <div className={styles.left}>{this.renderKeyInput(rowIdx)}</div>
                <div className={styles.right}>
                    {this.renderValueInput(rowIdx)}
                    {rowIdx > 0 ? (
                        <Icon className={styles.icon} type="minus-circle" onClick={() => this.remove(rowIdx)} />
                    ) : (
                        <Icon className={styles.icon} type="plus-circle" onClick={this.add} />
                    )}
                </div>
            </div>
        )
    }

    render() {
        const { appendParamIndexs } = this.state
        // const { getFieldDecorator } = this.props.form
        // console.log(this.props.form, 'this.props.form')
        const formItems = ['0', ...appendParamIndexs].map(rowIdx => {
            // console.log(rowIdx, 'rowIdx')
            return (
                <Form.Item
                    style={{ marginTop: -10 }}
                    key={rowIdx}
                    name={`param_${rowIdx}`}
                    rules={[
                        {
                            validator: this.validateEntries
                        }
                    ]}>
                    {/* {this.renderRow(rowIdx)}
                     */}
                    123
                </Form.Item>
            )
        })
        return (
            <Form className={styles.form}>
                <Form.Item style={{ marginBottom: -10 }}>
                    <div className={styles.column + ' ' + styles.title}>
                        <span className={styles.key}>Key</span>
                        <span className={styles.value}>Value</span>
                        <span className={styles.action}>操作</span>
                    </div>
                </Form.Item>
                {formItems}
                <div className={styles.add}>添加</div>
            </Form>
        )
    }
}
export default KeyValueInput
