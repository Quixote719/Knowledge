import React, { useState } from 'react'
import { Input, Select } from 'antdForHik'
import { has } from 'lodash'

const { Option } = Select
const { Search } = Input
const CompactInput = props => {
    // 搜索条件值
    const [selectValue, setSelectValue] = useState(props.selectValue || props.selectDefaultValue)
    // 搜索值
    const [searchValue, setSelectOptionValue] = useState(
        has(props, 'searchValue') ? props.searchValue : props.searchDefaultValue
    )
    return (
        <div style={{ display: 'flex' }}>
            <Select
                className={props.selectClassName}
                onChange={(val, option) => {
                    if (props.onSelectChange) {
                        props.onSelectChange(val, option)
                    }
                    if (!props.selectValue) {
                        setSelectValue(val)
                    }
                }}
                defaultValue={props.selectDefaultValue}
                value={props.selectValue || selectValue}>
                {props.selectOptions.map(item => (
                    <Option value={item.value}>{item.text}</Option>
                ))}
            </Select>
            <Search
                defaultValue={props.searchDefaultValue}
                value={has(props, 'searchValue') ? props.searchValue : searchValue}
                onChange={e => {
                    if (props.onSearchChange) {
                        props.onSearchChange(e.target.value)
                    }
                    if (!has(props, 'searchValue')) {
                        setSelectOptionValue(e.target.value)
                    }
                }}
                onSearch={value => {
                    if (props.onSearch) {
                        props.onSearch(props.selectValue || selectValue, value)
                    }
                }}
                placeholder={props.placeholder}
            />
        </div>
    )
}

export default CompactInput
