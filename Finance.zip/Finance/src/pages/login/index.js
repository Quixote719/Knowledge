import React, { memo, useCallback, useState } from 'react'
import { withRouter } from 'react-router-dom'
import { Button, Input, Checkbox } from 'antdForHik'
import CryptoJs from 'crypto-js'
import { inject } from 'mobx-react'
import styles from './index.less'
import logo from '@/assets/img/loginlogo.svg'
import user from '@/assets/img/user.png'
import passwordIcon from '@/assets/img/password.png'

const Login = memo(props => {
    const [username, setUserName] = useState('')
    const [password, setPassword] = useState('')
    const routeProcessManage = useCallback(() => {
        props.history.push('/ProcessManagement')
    }, [props.history])

    const handleLogin = () => {
        props.appStore.requestLogin({ userName: username, password: CryptoJs.SHA256(password).toString() }, () => {
            props.history.push('/ProjectManage')
        })
        // console.warn(CryptoJs.SHA256(password).toString())
    }
    return (
        <div className={styles.bg}>
            <div className={styles.header}>
                <img src={logo} alt="logo" className={styles.logo} onClick={routeProcessManage} />
                金融算法引擎
            </div>
            <div className={styles.container}>
                <header>欢迎登录</header>
                <Input
                    onChange={e => setUserName(e.target.value)}
                    placeholder="请输入用户名"
                    className={styles.input}
                    prefix={<img src={user} alt="user" />}></Input>
                <Input.Password
                    onChange={e => setPassword(e.target.value)}
                    placeholder="请输入密码"
                    className={styles.input}
                    prefix={<img src={passwordIcon} alt="password" />}></Input.Password>
                <Checkbox>记住密码</Checkbox>
                <Button type={'primary'} className={styles.button} onClick={handleLogin}>
                    登录
                </Button>
            </div>
            <div className={styles.footer}>
                <p> 杭州海康威视数字技术股份有限公司 版权所有</p>
            </div>
        </div>
    )
})

export default withRouter(inject('appStore')(Login))
