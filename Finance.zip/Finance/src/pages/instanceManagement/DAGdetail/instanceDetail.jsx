import React from 'react'
import { Breadcrumb, Popover, Button, Modal } from 'antdForHik'
import { withRouter } from 'react-router-dom'
import { inject, observer } from 'mobx-react'
import classnames from 'classnames'
import FlowChart from '@/components/flowchart/src/main'
import styles from '../index.less'
import DAGTemplate from './DAGTemplate'
import { message } from 'antdForHik'
import { loadDAGData } from '@/utils/DAG'
import { componentNameMap, taskRunningStatus } from '@/constants/task'
import { fetchLogs } from '@/serves/instance'

const instanceStatusMap = {
    SUCCESS: '成功',
    FAILED: '失败',
    RUNNING: '运行中',
    STOPPED: '已停止',
    WAITING: '等待中',
    ALL: '所有状态'
}

@inject('processStore', 'instanceStore')
@observer
class InstanceDetail extends React.PureComponent {
    constructor(props) {
        super(props)
        this.state = {
            showRight: false,
            showLogs: false,
            currentComponent: null,
            logContent: ''
        }
    }

    onWindowResize = () => {
        if (typeof this.flowChart != 'undefined' && this.flowChart && typeof this.flowChart.resize != 'undefined') {
            this.flowChart.resize()
        }
    }
    messageTip = data => {
        message.warning(data)
    }
    onDagDidMount = () => {
        const { match, instanceStore } = this.props
        window.addEventListener('resize', this.onWindowResize)
        this.onWindowResize()

        this.props.processStore
            .fetchTaskLists()
            .then(instanceStore.getInstanceDetail({ processInstanceId: match.params.instanceId }))
            .then(() => {
                //在获取组件接口数据之后再初始化DAG的设置
                let param = {
                    dom: document.getElementById('canvasBody'),
                    canvasName: {
                        isShow: false
                    },
                    eagleEye: {
                        isCreate: true,
                        alwaysDraw: false
                    },
                    // 节点配置
                    node: {
                        nodeStyle: {
                            image: {
                                // urlPrefix: `assets/img/menutype/dag_icon_`,
                                urlSuffix: '.svg'
                            }
                        },
                        //设定何状态下使用图标点击事件
                        imageClick: {
                            runStatus: ['EDITSTATUS']
                        }
                    },
                    //组件类描述信息
                    classInfomation: {
                        classInfo: this.props.processStore.classInfomation
                    },
                    //运行状态,相关菜单和按钮的显示相关
                    runStatus: {
                        //浏览状态
                        VIEW: {
                            name: 'VIEW',
                            isShowTip: false,
                            //是否支持菜单
                            isShowMenu: true,
                            //是否支持编辑 主要是图形的位置及图形的拓扑关系
                            isEditPosition: false,
                            isEditTopology: false,
                            isPanScale: true
                        }
                    },
                    //按钮排，使用用户定义的dom，接收用户传入的宽高，使用相对于主DOM的位置 left top bottom right 调用默认的事件 框选、删除选中、画布自适应、放大、缩小
                    toolbar: {
                        //是否显示，决定了是否进行初始化
                        isShow: true,
                        // 是否分区域
                        isDivide: true,
                        image: {
                            size: 24,
                            //单个的左右间距
                            margin: 8,
                            //前缀和后缀
                            urlSuffix: '.svg',
                            isHover: false,
                            hoverSuffix: '_hover',
                            isActive: false,
                            activeSuffix: '_active'
                        },
                        list: [
                            {
                                img: 'search', //图片url
                                title: '查询',
                                //可显示状态 和下面的是并集的关系
                                show: {
                                    // 编辑、运行中可见
                                    runStatus: ['VIEW']
                                },
                                //不可显示状态
                                unShow: {},
                                //业务来决定的是否显示
                                showFun: function () {},
                                event: 'searchSelect',
                                // 分割线标记
                                divider: true
                            },
                            {
                                img: 'self-adaption', //图片url
                                title: '画布自适应',
                                //可显示状态 和下面的是并集的关系
                                show: {
                                    //运行状态：在编辑状态
                                    runStatus: ['VIEW']
                                },
                                //不可显示状态
                                unShow: {},
                                //业务来决定的是否显示
                                showFun: function () {},
                                event: 'resizeChart'
                            },
                            {
                                img: 'enlarge', //图片url
                                title: '放大',
                                //可显示状态 和下面的是并集的关系
                                show: {
                                    //运行状态：在编辑状态
                                    runStatus: ['VIEW']
                                },
                                //不可显示状态
                                unShow: {},
                                //业务来决定的是否显示
                                showFun: function () {},
                                event: 'scaleEnlarged' //通过判断事件依赖，来判定是否显示，，需要定义事件对应的执行依赖
                            },
                            {
                                img: 'narrow', //图片url
                                title: '缩小',
                                //可显示状态 和下面的是并集的关系
                                show: {
                                    runStatus: ['VIEW']
                                },
                                //不可显示状态
                                unShow: {},
                                //业务来决定的是否显示
                                showFun: function () {},
                                event: 'scaleReduce'
                            }
                        ]
                    },
                    //不传表示菜单为false
                    menu: {
                        isShow: true, //默认false
                        runStatus: ['EDITSTATUS', 'EXECUTING'],
                        image: {
                            isImage: false,
                            isFront: true,
                            imageW: 24,
                            imageH: 24,
                            //前缀和后缀
                            // urlPrefix: `${window.basename}/img/menucanvas/`,
                            urlSuffix: '.svg'
                        },
                        // 右键菜单
                        menuList: []
                    }
                }
                this.flowChart = new FlowChart(param)
                window.FLOWCHART = this.flowChart
                this.flowChart.bind('selectElement', data => {
                    this.props.instanceStore.selectComponentsFromCanvas(data, value => {
                        this.setState(
                            {
                                showRight: value,
                                currentComponent: this.props.instanceStore.currentComponent
                            },
                            () => {
                                this.onWindowResize()
                            }
                        )
                    })
                })

                // 绑定画布提示事件
                this.flowChart.bind('messageTip', data => {
                    this.messageTip(data)
                })

                this.flowChart.bind('messageSuccess', data => {
                    message.success(data)
                })

                window.addEventListener('resize', () => {
                    this.onWindowResize(this)
                })
                const currentDag = this.props.processStore.currentDag
                if (currentDag) {
                    loadDAGData(currentDag, {
                        loadFrom: 'SELECT_EXPR'
                    })
                }
            })
    }
    onDagDidUnmount = () => {
        if (typeof this.flowChart != 'undefined' && this.flowChart) {
            this.flowChart.removeAll()
        }
        window.FLOWCHART = undefined
    }

    showRightHandle = () => {
        this.setState(
            {
                showRight: !this.state.showRight
            },
            () => {
                this.flowChart.resize()
            }
        )
    }
    renderIntanceDetail = () => {
        const { instanceStore } = this.props
        const { instanceDetail } = instanceStore
        const { processInfo = {}, processInstanceInfo = {} } = instanceDetail
        return (
            <div className={styles.configFlexBox}>
                <div className={styles.configBox}>
                    <div>流程名称</div>
                    <div className={styles.configBoxContent}>{processInfo.processName}</div>
                </div>
                <div className={styles.configBox}>
                    <div>流程描述</div>
                    <div className={styles.configBoxContent}>{processInfo.processDescribe}</div>
                </div>
                <div className={styles.configBox}>
                    <div>流程实例名称</div>
                    <div className={styles.configBoxContent}>{processInstanceInfo.processInstanceName}</div>
                </div>
                <div className={styles.configBox}>
                    <div>流程实例状态</div>
                    <div className={styles.configBoxContent}>
                        {instanceStatusMap[processInstanceInfo.processInstanceStatus] ||
                            processInstanceInfo.processInstanceStatus}
                    </div>
                </div>
                <div className={styles.configBox}>
                    <div>开始时间</div>
                    <div className={styles.configBoxContent}>{processInstanceInfo.beginTime}</div>
                </div>
                <div className={styles.configBox}>
                    <div>结束时间</div>
                    <div className={styles.configBoxContent}>{processInstanceInfo.endTime}</div>
                </div>
            </div>
        )
    }
    searchLogs = async () => {
        const { match } = this.props
        const res = await fetchLogs({
            processInstanceId: match.params.instanceId
        })
        console.warn(res, 'res')
        this.setState({
            showLogs: true,
            logContent: res?.data?.logContent
        })
    }
    renderLogs = () => {
        const { showLogs, logContent } = this.state
        // Modal.info({
        //     title: 'This is a notification message',
        //     content: (
        //         <div>
        //             <p>some messages...some messages...</p>
        //             <p>some messages...some messages...</p>
        //         </div>
        //     ),
        //     onOk() {}
        // })
        return (
            <Modal
                visible={showLogs}
                title={'查看日志'}
                centered
                width={600}
                onCancel={() => {
                    this.setState({
                        showLogs: false,
                        logContent: ''
                    })
                }}
                onOk={() => {
                    this.setState({
                        showLogs: false,
                        logContent: ''
                    })
                }}>
                <div className={styles.logModal}>{logContent}</div>
            </Modal>
        )
    }
    render() {
        const { showRight, currentComponent, showLogs } = this.state

        // console.log(this.props.instanceStore.currentComponent, currentComponent, 'currentDag')
        return (
            <div className={styles.container}>
                <div className={styles.topSection}>
                    <Breadcrumb className={styles.breadcrumbBlock} separator=">">
                        <Breadcrumb.Item
                            className={styles.breadcrumbRoute}
                            onClick={() => this.props.history.push('/InstanceManage')}>
                            实例管理
                        </Breadcrumb.Item>
                        <Breadcrumb.Item>流程实例详情</Breadcrumb.Item>
                    </Breadcrumb>
                    {this.renderIntanceDetail()}
                </div>
                <div className={styles.bottomSection}>
                    <DAGTemplate
                        onDagDidMount={this.onDagDidMount}
                        onDagDidUnmount={this.onDagDidUnmount}
                        style={{ width: showRight ? 'calc(100% - 300px)' : '100%', height: '620px' }}
                    />
                    <Popover content={showRight ? '收起' : '展开'} placement="left">
                        <div
                            className={classnames(styles.toggleRight, {
                                [styles.toggleShowRight]: !showRight,
                                [styles.toggleFoldRight]: showRight
                            })}
                            onClick={() => this.showRightHandle()}></div>
                    </Popover>
                    <div
                        className={styles.right}
                        style={{
                            right: showRight ? 0 : '-300px'
                            // right: 0
                        }}>
                        <div className={styles.title}>{currentComponent?.name}详情</div>
                        <div className={styles.section}>
                            <div>
                                <div className={styles.header}>任务名称</div>
                                <div className={styles.item}>{currentComponent?.name}</div>
                            </div>
                            <div>
                                <div className={styles.header}>任务类型</div>
                                <div className={styles.item}>{componentNameMap[currentComponent?.compId]}</div>
                            </div>
                            <div>
                                <div className={styles.header}>开始时间</div>
                                <div className={styles.item}>{currentComponent?.beginTime}</div>
                            </div>
                            <div>
                                <div className={styles.header}>结束时间</div>
                                <div className={styles.item}>{currentComponent?.endTime}</div>
                            </div>
                            <div>
                                <div className={styles.header}>任务状态</div>
                                <div className={styles.item}>{taskRunningStatus[currentComponent?.taskStatusEnum]}</div>
                            </div>
                            <div>
                                <div className={styles.header}>超时停止</div>
                                <div className={styles.item}>
                                    {currentComponent?.configParams?.timeOutStop ? '是' : '否'}
                                </div>
                            </div>
                            <div>
                                <div className={styles.header}>失败重试</div>
                                <div className={styles.item}>
                                    {currentComponent?.configParams?.failureRetry ? '是' : '否'}
                                </div>
                            </div>
                            <div>
                                <div className={styles.header}>日志</div>
                                <div className={styles.item}>
                                    <Button onClick={this.searchLogs}>查看日志</Button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                {showLogs && this.renderLogs()}
            </div>
        )
    }
}

export default withRouter(InstanceDetail)
