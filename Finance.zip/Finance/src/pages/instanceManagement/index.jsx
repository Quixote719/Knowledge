import React from 'react'
import styles from './index.less'
import CompactInput from '@/components/compactInput'
import { withRouter } from 'react-router-dom'
import { observer, inject } from 'mobx-react'
import { Popover, DatePicker } from 'antdForHik'
import WithPaginationTable from '@/components/withSearchPaginationTable'
import refresh from '@/assets/img/common_reflash.svg'
import detailIcon from '@/assets/img/common_export.svg'
import stopIcon from '@/assets/img/common_status_stop.svg'
import deleteIcon from '@/assets/img/common_delete.svg'
import pauseIcon from '@/assets/img/status_pause.svg'
import failureIcon from '@/assets/img/status_failure.svg'
import runningIcon from '@/assets/img/status_running.svg'
import successIcon from '@/assets/img/status_success.svg'
import waitIcon from '@/assets/img/status_waiting.svg'

const { RangePicker } = DatePicker
const SearchOpt = [
    { text: '流程ID', value: 'processId' },
    { text: '流程名称', value: 'processName' },
    {
        text: '流程实例ID',
        value: 'processInstanceId'
    },
    {
        text: '流程实例名称',
        value: 'processInstanceName'
    }
]

const instanceStatusMap = [
    { text: '成功', value: 'SUCCESS' },
    { text: '失败', value: 'FAILED' },
    { text: '运行中', value: 'RUNNING' },
    { text: '已停止', value: 'STOPPED' },
    { text: '等待中', value: 'WAITING' },
    { text: '所有状态', value: 'ALL' }
]
const instanceCols = [
    {
        title: '流程实例ID',
        dataIndex: 'dolphinProcessInstanceId',
        filterMultiple: true
    },
    {
        title: '流程实例名称',
        dataIndex: 'processInstanceName'
    },
    {
        title: '流程ID',
        dataIndex: 'processId'
    },
    {
        title: '流程名称',
        dataIndex: 'processName'
    },
    {
        title: '状态',
        dataIndex: 'processInstanceStatus'
    },
    {
        title: '开始时间',
        dataIndex: 'beginTime'
    },
    {
        title: '结束时间',
        dataIndex: 'endTime'
    }
]

const statusMap = {
    ALL: <span style={{ color: '#2949F0' }}>所有状态</span>,
    SUCCESS: (
        <span style={{ color: '#02BF0F' }}>
            <img className={styles.statusIcon} src={successIcon} alt="" />
            成功
        </span>
    ),
    FAILED: (
        <span style={{ color: '#E81123' }}>
            <img className={styles.statusIcon} src={failureIcon} alt="" />
            失败
        </span>
    ),
    RUNNING: (
        <span style={{ color: '#2196F3' }}>
            <img className={styles.statusIcon} src={runningIcon} alt="" />
            运行中
        </span>
    ),
    STOPPED: (
        <span style={{ color: '#B3B3B3' }}>
            <img className={styles.statusIcon} src={pauseIcon} alt="" />
            已停止
        </span>
    ),
    WAITING: (
        <span style={{ color: '#2949F0' }}>
            <img className={styles.statusIcon} src={waitIcon} alt="" />
            等待中
        </span>
    )
}
class InstanceManage extends React.PureComponent {
    constructor(props) {
        super(props)
        this.state = {
            tableLoading: true,
            searchKey: SearchOpt[3].value,
            searchValue: '',
            pageNo: 1,
            pageSize: 10,
            instanceStatus: ['ALL'],
            timeRange: [undefined, undefined]
        }
        this.initInstanceCols()
    }
    initInstanceCols() {
        this.instanceCols = instanceCols.filter(item => item.title !== '操作')
        this.instanceCols.push({
            title: '操作',
            dataIndex: 'handle',
            width: 200,
            render: (text, row) => {
                return (
                    <span>
                        <Popover content="详情">
                            <img
                                className={styles.operationIcon}
                                src={detailIcon}
                                onClick={() => {
                                    this.props.history.push(
                                        `/InstanceManage/instanceDetail/${row.dolphinProcessInstanceId}`
                                    )
                                }}
                                alt={'详情'}
                                style={{
                                    pointerEvents: row?.action?.enableEdit === false ? 'none' : 'auto',
                                    filter: row?.action?.enableEdit === false ? 'opacity(30%)' : 'none'
                                }}
                            />
                        </Popover>
                        <Popover content="停止">
                            <img
                                className={styles.operationIcon}
                                src={stopIcon}
                                alt={'停止'}
                                onClick={() => {
                                    this.stopInstance(row)
                                }}
                                style={{
                                    pointerEvents: row?.action?.enableStop === false ? 'none' : 'auto',
                                    filter: row?.action?.enableStop === false ? 'opacity(30%)' : 'none'
                                }}
                            />
                        </Popover>
                        <Popover content="删除">
                            <img
                                className={styles.operationIcon}
                                src={deleteIcon}
                                alt={'删除'}
                                onClick={() => {
                                    this.deleteInstance(row)
                                }}
                                style={{
                                    pointerEvents: row?.action?.enableDelete === false ? 'none' : 'auto',
                                    filter: row?.action?.enableDelete === false ? 'opacity(30%)' : 'none'
                                }}
                            />
                        </Popover>
                    </span>
                )
            }
        })
        let statusCol = this.instanceCols.find(item => item.dataIndex === 'processInstanceStatus')
        statusCol.render = (text, row) => {
            return <span>{statusMap[text] || text}</span>
        }
        statusCol.filters = instanceStatusMap
        statusCol.onFilter = (value, data) => {
            let InstanceStatus = value.map(item => {
                let targetStatus = instanceStatusMap.find(status => status.text === item)
                return targetStatus ? targetStatus.value : null
            })
            this.setState({ instanceStatus: InstanceStatus })
            this.requestInstanceList(this.state.searchKey, this.state.searchValue, InstanceStatus)
        }
    }
    componentDidMount() {
        this.requestInstanceList(this.state.searchKey, this.state.searchValue)
    }
    requestInstanceList = (searchKey, searchValue, status, timeRange) => {
        const { pageNo, pageSize } = this.state
        if (this.timer) {
            clearTimeout(this.timer)
        }
        this.timer = setTimeout(
            () =>
                this.props.instanceStore.getinstanceLists(
                    {
                        beginTime: timeRange ? timeRange[0] : this.state.timeRange[0],
                        endTime: timeRange ? timeRange[1] : this.state.timeRange[1],
                        // endTime: '2021-03-07 20:00:00',
                        pageAndSortRequest: {
                            pageNo,
                            pageSize,
                            sortby: ['createTime'],
                            order: ['DESC']
                        },
                        searchKey: searchKey || this.state.searchKey,
                        searchValue: searchValue || this.state.searchValue,
                        statusEnum:
                            (status || this.state.instanceStatus)?.length > 0
                                ? status || this.state.instanceStatus
                                : ['ALL']
                    },
                    () => {
                        this.setState({ tableLoading: false })
                    }
                ),
            200
        )
    }

    pageChange = (pageNo, pageSize) => {
        this.setState({ tableLoading: true, pageNo, pageSize })
        const { searchKey, searchValue } = this.state
        this.props.instanceStore.getinstanceLists(
            {
                pageAndSortRequest: {
                    pageNo,
                    pageSize,
                    sortby: ['createTime'],
                    order: ['DESC']
                },
                searchKey,
                searchValue,
                statusEnum: this.state.instanceStatus?.length > 0 ? this.state.instanceStatus : ['ALL']
            },
            () => {
                this.setState({ tableLoading: false })
            }
        )
    }
    stopInstance = params => {
        this.props.instanceStore.stopInstance({ processInstanceId: params?.dolphinProcessInstanceId }, () =>
            this.requestInstanceList(this.state.searchKey, this.state.searchValue)
        )
    }

    deleteInstance = params => {
        this.props.instanceStore.deleteInstance({ processInstanceId: params?.dolphinProcessInstanceId }, () =>
            this.requestInstanceList(this.state.searchKey, this.state.searchValue)
        )
    }

    timeChangeRequest = (date, timeRange) => {
        this.setState({ timeRange })
        if (Array.isArray(timeRange) && timeRange[0] && timeRange[1]) {
            this.requestInstanceList(null, null, null, timeRange)
        }
    }
    // beginTimeChangeRequest = (date, dateString) => {
    //     this.setState({ beginTime: dateString })
    //     this.requestInstanceList(null, null, null, dateString)
    // }

    render() {
        const { searchKey, searchValue, tableLoading } = this.state
        const { instanceList = {} } = this.props.instanceStore
        return (
            <div className={styles.contentSection}>
                <div className={styles.operateBtn}>
                    <img className={styles.btnImage} src={refresh} alt="refresh" />
                    <div
                        className={styles.btnText}
                        onClick={() => {
                            this.requestInstanceList(this.state.searchKey, this.state.searchValue)
                        }}>
                        刷新
                    </div>
                </div>
                <div className={styles.searchBlock}>
                    <div style={{ display: 'inline-block' }}>
                        {/* <DatePicker
                            onChange={(date, dateString) => {
                                this.beginTimeChangeRequest(date, dateString)
                            }}
                            showTime
                        /> */}
                        <RangePicker
                            onChange={(date, dateString) => {
                                this.timeChangeRequest(date, dateString)
                            }}
                            showTime
                        />
                    </div>
                    <div style={{ display: 'inline-block' }}>
                        <CompactInput
                            placeholder={'搜索'}
                            selectValue={searchKey}
                            searchValue={searchValue}
                            onSelectChange={value => {
                                this.setState({ searchKey: value })
                                this.requestInstanceList(value, this.state.searchValue)
                            }}
                            onSearchChange={value => {
                                this.setState({ searchValue: value })
                                this.requestInstanceList(this.state.searchKey, value)
                            }}
                            onSearch={(selectValue, inputValue) => {
                                this.requestInstanceList(selectValue, inputValue)
                            }}
                            selectClassName={styles.featureSelect}
                            selectOptions={SearchOpt}
                        />
                    </div>
                </div>
                <WithPaginationTable
                    total={instanceList.total}
                    onChange={(pagination, filters, sorter, extra) => {
                        console.warn('params', pagination, filters, sorter, extra)
                    }}
                    pageSize={instanceList.pageSize}
                    columns={this.instanceCols}
                    onPageChange={(pageNo, pageSize) => {
                        this.pageChange(pageNo, pageSize)
                    }}
                    datas={instanceList.list}
                    loading={tableLoading}
                />
            </div>
        )
    }
}

export default withRouter(inject('instanceStore')(observer(InstanceManage)))
