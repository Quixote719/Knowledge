import React from 'react'
import StatisticsBar from './components/statisticsBar'
import { withRouter } from 'react-router-dom'
// import { toJS } from 'mobx'
import { inject, observer } from 'mobx-react'
import ReactEcharts from 'echarts-for-react'
import { Checkbox } from 'antdForHik'
import styles from './index.less'

// @inject('dashboardStore')
// @observer
class financeDashboard extends React.PureComponent {
    constructor(props) {
        super(props)
        this.state = {}
    }
    componentDidMount = () => {
        const { dashboardStore } = this.props
        dashboardStore.clearDashBoardStatistics()
        dashboardStore.getdashboardLists()
        dashboardStore.getProcessTotal()
        dashboardStore.getInstanceTotal()
        dashboardStore.getInstanceStatistics()
    }
    getOption() {
        const { dashboardStore } = this.props
        const { instanceStatistics } = dashboardStore
        const dateForXAxis = Object.keys(instanceStatistics).sort()
        let statusForYAxis = []
        dateForXAxis.forEach(key => {
            statusForYAxis.push(instanceStatistics[key])
        })
        const successStatusArr = statusForYAxis.map(item => item.SUCCESS)
        const failedStatusArr = statusForYAxis.map(item => item.FAILED)
        const otherStatusArr = statusForYAxis.map(item => item.OTHER)
        let barModeSettings = [
            {
                name: '成功',
                type: 'bar',
                barCategoryGap: '55%',
                itemStyle: { barBorderRadius: [5] },
                data: successStatusArr
            },
            {
                name: '失败',
                type: 'bar',
                barCategoryGap: '55%',
                itemStyle: { barBorderRadius: [5] },
                data: failedStatusArr
            },
            {
                name: '其他',
                type: 'bar',
                barCategoryGap: '55%',
                itemStyle: { barBorderRadius: [5] },
                data: otherStatusArr
            }
        ]
        let lineModeSettings = [
            {
                name: '成功',
                type: 'line',
                data: successStatusArr
            },
            {
                name: '失败',
                type: 'line',
                data: failedStatusArr
            },
            {
                name: '其他',
                type: 'line',
                data: otherStatusArr
            }
        ]
        let opt = {
            color: ['#02BF0F', '#F73748', '#2949F0'],
            tooltip: {},
            textStyle: {
                fontSize: 14,
                // fontWeight: 'bolder',
                color: '#9A9A9A' // 主标题文字颜色
            },
            subtextStyle: {
                color: '#9A9A9A' // 副标题文字颜色
            },
            bar: {
                itemStyle: {
                    normal: {
                        // color: '各异',
                        barBorderColor: '#9A9A9A', // 柱条边线
                        barBorderRadius: 7
                    }
                }
            },
            legend: {
                itemGap: 70,
                data: ['成功', '失败', '其他'],
                textStyle: {
                    color: '#B4B4B4' // 图例文字颜色
                }
            },
            xAxis: {
                type: 'category',
                axisLine: {
                    lineStyle: { color: ['#555555'] }
                },
                splitLine: {
                    lineStyle: {
                        color: ['#555555'],
                        width: 1,
                        type: 'solid'
                    }
                },
                data: dateForXAxis
            },
            yAxis: {
                axisLine: {
                    lineStyle: { color: ['#555555'] }
                },
                splitLine: {
                    lineStyle: {
                        color: ['#555555'],
                        width: 1,
                        type: 'solid'
                    }
                }
            },
            series: this.state.lineModeChart ? lineModeSettings : barModeSettings
        }
        return opt
    }

    onChartClick = param => {
        console.warn(param)
    }

    chartModeChange = e => {
        this.setState({ lineModeChart: e.target.checked })
    }

    onEvents = {
        click: this.onChartClick.bind(this)
    }

    render() {
        const { dashboardStore } = this.props
        const { resourceStatistics, processTotal, instanceTotal } = dashboardStore
        const { yarnResourceStatistics, kubernetesResourceStatistics } = resourceStatistics
        let statisticsArray = [
            { attribute: '流程总数（个）', figure: processTotal?.processTotal, popover: '统计已启用的流程' },
            {
                attribute: '流程实例总数（个）',
                figure: instanceTotal?.processInstanceTotal,
                popover: '统计运行中的流程实例总数'
            },
            {
                attribute: 'Yarn 内存（G）',
                figure: yarnResourceStatistics?.usedMemory,
                popover: '统计Yarn队列已用内存资源'
            },
            {
                attribute: 'Yarn CPU（核）',
                figure: yarnResourceStatistics?.usedCore,
                popover: '统计Yarn队列已用核数'
            },
            {
                attribute: 'Kubernetes 内存（G）',
                figure: kubernetesResourceStatistics?.usedMemory,
                popover: '统计Kubernetes namespace已用内存资源'
            },
            {
                attribute: 'Kubernetes CPU（核）',
                figure: kubernetesResourceStatistics?.usedCore,
                popover: '统计Kubernetes namespace已用核数'
            }
        ]
        return (
            <div>
                <div className={styles.dashBoardTopSection}>
                    <StatisticsBar statistics={statisticsArray} />
                </div>
                <div className={styles.bottomSection}>
                    <div className={styles.chartTitle}>七日流程状态实例统计</div>
                    <div className={styles.trendSwitchBlock}>
                        <Checkbox size="small" className={styles.trendSwitch} onChange={this.chartModeChange} />
                        <div className={styles.trendSwitchTitle}>趋势线</div>
                    </div>
                    <ReactEcharts
                        option={this.getOption()}
                        notMerge={true}
                        lazyUpdate={true}
                        onEvents={this.onEvents}
                        style={{ width: '100%', minHeight: 'calc(100vh - 420px)' }}
                    />
                </div>
            </div>
        )
    }
}

export default withRouter(inject('dashboardStore')(observer(financeDashboard)))
