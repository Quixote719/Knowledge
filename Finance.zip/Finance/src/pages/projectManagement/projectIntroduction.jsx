import React from 'react'
import { inject } from 'mobx-react'
import { Button, Modal } from 'antdForHik'
import { withRouter } from 'react-router-dom'
import ProjectCard from 'src/pages/projectManagement/components/projectCard'
import styles from '@/pages/projectManagement/index.less'
import { setUserProjectInfo } from '@/utils/auth'
import { QuestionCircleFilled } from '@ant-design/icons'

class ProjectManage extends React.PureComponent {
    constructor(props) {
        super(props)
        this.state = {}
    }
    componentDidMount = () => {
        this.props.projectStore.getprojectLists(
            {
                projectName: '',
                sortBy: 'createTime',
                order: 'DESC',
                pageNo: 1,
                pageSize: 10
            },
            () => {
                this.setState({ receiveProjectInfo: true })
            }
        )
    }
    createProject = () => {
        this.props.projectStore.clearProjectDetail()
        this.props.history.push('/ProjectManage/createProject')
    }
    enterProject = params => {
        if (params?.id) {
            setUserProjectInfo(params.id)
            this.props.history.push('/FinanceDashboard')
        }
    }
    editProject(params) {
        this.props.projectStore.clearProjectDetail()
        if (params?.id) {
            setUserProjectInfo(params.id)
            this.props.history.push({ pathname: '/ProjectManage/createProject', state: params.id })
        }
    }
    deleteProject(param) {
        if (param?.id) {
            this.props.projectStore.deleteProject({ projectId: param.id })
        }
    }
    confirmDeleteProject = param => {
        const deleteText = '请确认是否删除信用卡开卡风险算法项目。仅删除项目业务数据，请谨慎操作！'
        Modal.confirm({
            icon: <QuestionCircleFilled style={{ fontSize: 40 }} />,
            content: deleteText,
            onOk: () => {
                this.deleteProject(param)
                // return false
            },
            onCancel: () => {
                return false
            }
        })
    }
    render() {
        const { receiveProjectInfo } = this.state
        const { projectListInfo = {} } = this.props.projectStore
        const projectList = projectListInfo?.list || []
        let projectListSample = projectList.slice(0, 4)
        return (
            <div>
                <div className={styles.topSection}>
                    <div className={styles.FMtitle}>金融算法引擎</div>
                    <div className={styles.FMDescription}>金融算法引擎简介</div>
                    <Button onClick={this.createProject} type={'primary'}>
                        创建项目
                    </Button>
                </div>
                <div className={styles.bottomSection}>
                    <div>
                        <div className={styles.textBar}>{`显示最近${Math.min(4, projectList.length)}个项目`}</div>
                        <div
                            onClick={() => this.props.history.push('/ProjectManage/ProjectListPage')}
                            className={`${styles.textBar} ${styles.rightRedirectText}`}>
                            查看更多
                        </div>
                    </div>
                    <div>
                        {receiveProjectInfo &&
                            projectListSample.map(item => {
                                return (
                                    <ProjectCard
                                        info={item}
                                        cardClick={params => {
                                            this.enterProject(params)
                                        }}
                                        editCard={params => this.editProject(params)}
                                        deleteCard={params => this.confirmDeleteProject(params)}
                                    />
                                )
                            })}
                    </div>
                </div>
            </div>
        )
    }
}

export default inject('projectStore')(withRouter(ProjectManage))
