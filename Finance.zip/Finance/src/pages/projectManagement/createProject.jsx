import React, { useState, useEffect } from 'react'
import { Breadcrumb, Input, Form, Button, Radio, Tabs, Upload, Popover, Checkbox } from 'antdForHik'
import { inject, observer } from 'mobx-react'
import { validateRules } from './constant'
import { withRouter } from 'react-router-dom'
import styles from '@/pages/projectManagement/index.less'
import {
    InfoCircleOutlined,
    EyeInvisibleOutlined,
    EyeOutlined,
    UploadOutlined
    // SettingOutlined
} from '@ant-design/icons'

const FormItem = Form.Item
const { TabPane } = Tabs
const clusterOptions = [
    { label: 'Hadoop集群', value: 'Hadoop', disabled: true },
    { label: 'Kubernetes集群', value: 'Kubernetes' }
]
const { TextArea } = Input
const CreateProject = props => {
    const [clusterConfigCheck, updateClusterConfigCheck] = useState(['Hadoop'])
    const [clusterActiveKey, updateClusterActiveKey] = useState('Hadoop')
    const [HDAuthMethod, updateHDAuthMethod] = useState(null)
    const [KBAuthMethod, updateKBAuthMethod] = useState(null)
    const [keytabFileList, updateKeytabFileList] = useState([])
    const [projectId, setProjectId] = useState(null)
    const [initialFormVals, updateInitialFormVals] = useState({})
    let authUploadStatus = false
    const [isFormReady, updateIsFormReady] = useState(false)
    useEffect(() => {
        updateIsFormReady(Object.keys(props.projectStore.projectDetail).length > 0 || !props.history.location.state)
    }, [props.projectStore.projectDetail, props.history.location.state])

    useEffect(() => {
        let projectFormParam = {}
        let projectDetail = props.projectStore.projectDetail

        if (projectDetail) {
            projectFormParam = { ...projectDetail, ...projectDetail.kubernetesConfig, ...projectDetail.hadoopConfig }
        }
        updateInitialFormVals(projectFormParam)
        updateHDAuthMethod(projectDetail?.hadoopConfig?.hadoopAuthEnum)
        updateKBAuthMethod(projectDetail?.kubernetesAuthEnum?.kubernetesAuthEnum)
        if (projectDetail?.keyTabFileName) {
            let updateFileList = [
                {
                    uid: '-1',
                    name: projectDetail?.keyTabFileName,
                    status: 'done'
                }
            ]
            updateKeytabFileList(updateFileList)
        }
        if (projectDetail?.kubernetesConfig) {
            updateClusterConfigCheck(['Hadoop', 'Kubernetes'])
        }
    }, [props.projectStore.projectDetail])

    useEffect(() => {
        if (props.history.location.state && projectId === null) {
            setProjectId(props.history.location.state)
            props.projectStore.getprojectDetail({ projectId: props.history.location.state })
        }
    }, [projectId])

    const keytabUploadProps = {
        fileList: keytabFileList,
        headers: {
            authorization: 'authorization-text'
        },
        beforeUpload: file => {
            authUploadStatus = false
            return true
        },
        onChange: (info, target) => {
            // file.status is empty when beforeUpload return false
            info.fileList.forEach(file => {
                if (file.status === 'error') {
                    file.status = 'success'
                }
            })
            let resFileList = info.fileList.filter(file => !!file.status)
            let targetList = resFileList.length >= 1 ? [resFileList.pop()] : []
            updateKeytabFileList(targetList)
            if (
                targetList[0] &&
                authUploadStatus === false &&
                typeof props.projectStore.uploadAuthFile === 'function'
            ) {
                authUploadStatus = true
                props.projectStore.uploadAuthFile({ file: targetList[0].originFileObj })
            }
        }
    }

    const saveProjectConfig = form => {
        if (form) {
            let createProjectParams = {
                department: form.department,
                description: form.description,
                hadoopConfig: {
                    hadoopAuthEnum: form.hadoopAuthEnum,
                    hadoopPrincipal: form.hadoopPrincipal,
                    hadoopUserName: form.hadoopUserName,
                    queueName: form.queueName,
                    hdfsStoreDir: form.hdfsStoreDir,
                    hiveDatabase: form.hiveDatabase,
                    otherConfig: {}
                },
                // existKubernetes:true,
                kubernetesConfig: {
                    apiSeverAddress: form.apiSeverAddress || initialFormVals.apiSeverAddress,
                    kubernetesAuthEnum: form.kubernetesAuthEnum || initialFormVals.kubernetesAuthEnum,
                    namespace: form.namespace || initialFormVals.namespace,
                    password: form.password ? btoa(form.password) : undefined,
                    token: form.token || initialFormVals.token,
                    userName: form.userName || initialFormVals.namespace,
                    registrySecretKey: form.userName || null
                },
                lotNum: form.hadoopAuthEnum === 'SIMPLE' ? null : props.projectStore.authLotNum,
                name: form.name,
                personInCharge: form.personInCharge
            }
            if (!clusterConfigCheck.includes('Kubernetes')) {
                delete createProjectParams.kubernetesConfig
                // createProjectParams.lotNum = props.projectStore.authLotNum
            } else {
                createProjectParams.existKubernetes = true
            }
            if (projectId === null) {
                props.projectStore.createProject(createProjectParams)
            } else {
                createProjectParams.dolphinProjectId = initialFormVals.dolphinProjectId
                props.projectStore.updateProject(createProjectParams)
            }
        }
    }
    const manageConfigError = form => {
        console.warn('error', form)
    }
    const changeHBAuthMethod = e => {
        updateHDAuthMethod(e.target.value)
    }
    const changeKBAuthMethod = e => {
        updateKBAuthMethod(e.target.value)
    }

    const renderHadoopForm = () => {
        return (
            <div>
                <FormItem label={'鉴权方式'} name="hadoopAuthEnum" rules={[{ required: true, message: '必选' }]}>
                    <Radio.Group onChange={changeHBAuthMethod}>
                        <Radio value={'KERBEROS'}>Kerberos</Radio>
                        <Radio value={'SIMPLE'}>Simple</Radio>
                    </Radio.Group>
                </FormItem>
                {HDAuthMethod === 'KERBEROS' && (
                    <FormItem label={'Principal'} name="hadoopPrincipal" rules={[{ required: true, message: '必填' }]}>
                        <Input maxLength={100} />
                    </FormItem>
                )}
                {HDAuthMethod === 'SIMPLE' && (
                    <FormItem
                        label={'用户名'}
                        name="hadoopUserName"
                        rules={[{ required: true, message: '必填' }, validateRules.letterNumSpace]}>
                        <Input maxLength={30} />
                    </FormItem>
                )}
                {HDAuthMethod === 'KERBEROS' && (
                    <FormItem
                        label={'Keytab'}
                        name="Keytab"
                        rules={[projectId === null ? { required: true, message: '必填' } : {}]}>
                        <Upload {...keytabUploadProps}>
                            <Button>
                                <UploadOutlined />
                                上传
                            </Button>
                        </Upload>
                    </FormItem>
                )}
                <FormItem label={'计算队列'} name="queueName" rules={[{ required: true, message: '必填' }]}>
                    <Input placeholder="root.awaken.streaming" />
                </FormItem>
                <FormItem label={'HDFS存储目录'} name="hdfsStoreDir" rules={[{ required: true, message: '必填' }]}>
                    <Input maxLength={100} />
                </FormItem>
                <FormItem label={'Hive数据库'} name="hiveDatabase">
                    <Input maxLength={100} placeholder="awaken_db1" />
                </FormItem>
            </div>
        )
    }

    const renderKubernetesForm = () => {
        return (
            <div>
                <FormItem
                    label={'鉴权方式'}
                    name="kubernetesAuthEnum"
                    onChange={changeKBAuthMethod}
                    rules={[{ required: true, message: '必选' }]}>
                    <Radio.Group>
                        <Radio value={'TOKEN'}>Token</Radio>
                        <Radio value={'USER_PASSWORD'}>用户名/密码</Radio>
                    </Radio.Group>
                </FormItem>
                {(KBAuthMethod === 'TOKEN' || initialFormVals?.token) && (
                    <FormItem label={'Token'} name="token" rules={[{ required: true, message: '必填' }]}>
                        <Input />
                    </FormItem>
                )}
                {KBAuthMethod === 'USER_PASSWORD' && (
                    <FormItem
                        label={'用户名'}
                        name="userName"
                        rules={[{ required: true, message: '必填' }, validateRules.letterNumSpace]}>
                        <Input maxLength={64} />
                    </FormItem>
                )}
                {KBAuthMethod === 'USER_PASSWORD' && (
                    <FormItem
                        label={'密码'}
                        name="password"
                        rules={[{ required: true, message: '必填' }, validateRules.letterNumSpace]}>
                        <Input.Password
                            maxLength={64}
                            iconRender={visible => (visible ? <EyeOutlined /> : <EyeInvisibleOutlined />)}
                        />
                    </FormItem>
                )}
                <FormItem
                    label={
                        <span>
                            <Popover placement={'left'} content={'api server对应的IP：port'}>
                                <InfoCircleOutlined className={styles.formInfoIcon} />
                            </Popover>
                            API服务器地址
                        </span>
                    }
                    name="apiSeverAddress"
                    rules={[{ required: true, message: '必填' }]}>
                    <Input placeholder="10.3.71.120:6443" />
                </FormItem>
                <FormItem
                    label={
                        <span>
                            <Popover placement={'left'} content={'namespace'}>
                                <InfoCircleOutlined className={styles.formInfoIcon} />
                            </Popover>
                            命名空间
                        </span>
                    }
                    name="namespace"
                    rules={[{ required: true, message: '必填' }]}>
                    <Input maxLength={64} />
                </FormItem>
                <FormItem
                    label={
                        <span>
                            {/* <Popover placement={'left'} content={'registrySecretKey'}>
                                <InfoCircleOutlined className={styles.formInfoIcon} />
                            </Popover> */}
                            镜像密钥名称
                        </span>
                    }
                    name="registrySecretKey">
                    <Input maxLength={64} />
                </FormItem>
            </div>
        )
    }
    return (
        <div className={styles.pageContent}>
            <Breadcrumb className={styles.breadcrumbBlock} separator=">">
                <Breadcrumb.Item
                    className={styles.breadcrumbRoute}
                    onClick={() => props.history.push('/ProjectManage')}>
                    我的项目
                </Breadcrumb.Item>
                <Breadcrumb.Item>创建项目</Breadcrumb.Item>
            </Breadcrumb>
            {isFormReady && (
                <Form
                    className={styles.formSection}
                    layout={'vertical'}
                    initialValues={initialFormVals}
                    onFinish={saveProjectConfig}
                    onFinishFailed={manageConfigError}>
                    <FormItem
                        label={'项目名称'}
                        name="name"
                        required={true}
                        rules={[{ required: true, message: '必填' }, validateRules.baseRule]}>
                        <Input maxLength={30} />
                    </FormItem>
                    <FormItem label={'需求部门'} name="department" rules={[validateRules.baseRule]}>
                        <Input maxLength={30} />
                    </FormItem>
                    <FormItem label={'负责人'} name="personInCharge" rules={[validateRules.baseRule]}>
                        <Input maxLength={30} />
                    </FormItem>
                    <FormItem label={'项目备注'} name="description">
                        <TextArea maxLength={60} />
                    </FormItem>
                    <div>集群配置</div>
                    <Checkbox.Group
                        style={{ margin: '8px 0 24px 0' }}
                        options={clusterOptions}
                        defaultValue={initialFormVals?.kubernetesConfig ? ['Hadoop', 'Kubernetes'] : ['Hadoop']}
                        onChange={val => updateClusterConfigCheck(val)}
                    />

                    {clusterConfigCheck.includes('Kubernetes') && (
                        <Tabs activeKey={clusterActiveKey} onChange={val => updateClusterActiveKey(val)}>
                            <TabPane tab="Hadoop集群" className={styles.darkTabPane} key="Hadoop">
                                {renderHadoopForm()}
                            </TabPane>
                            <TabPane tab="Kubernetes集群" className={styles.darkTabPane} key="Kubernetes">
                                {renderKubernetesForm()}
                            </TabPane>
                        </Tabs>
                    )}
                    {!clusterConfigCheck.includes('Kubernetes') && renderHadoopForm()}
                    <Button type={'primary'} htmlType="submit">
                        保存
                    </Button>
                </Form>
            )}
        </div>
    )
}

export default withRouter(inject('projectStore')(observer(CreateProject)))
