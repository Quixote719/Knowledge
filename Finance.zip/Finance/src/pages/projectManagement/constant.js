const validateRules = {
    letterNumSpace: { pattern: /^[a-zA-Z0-9_]+$/, message: '用户名必须是英文、数字或下划线组成' },
    baseRule: { pattern: /^([a-zA-Z0-9_\u4E00-\u9FA5])*$/g, message: '允许中文、字母、数字、下划线' }
}

export { validateRules }
