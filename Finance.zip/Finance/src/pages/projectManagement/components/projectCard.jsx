import React, { useState } from 'react'
import styles from '../index.less'
import { FormOutlined, DeleteOutlined } from '@ant-design/icons'

const ProjectCard = props => {
    const [showIconBtn, setShowIconBtn] = useState(false)
    const onMouseOver = () => {
        setShowIconBtn(true)
    }
    const onMouseLeave = () => {
        setShowIconBtn(false)
    }
    const onCardClick = () => {
        const { cardClick } = props
        if (typeof cardClick === 'function') {
            cardClick(props.info)
        }
    }
    const onEditCard = e => {
        const { editCard } = props
        e.stopPropagation()
        if (typeof editCard === 'function') {
            editCard(props.info)
        }
    }
    const onDeleteCard = () => {
        const { deleteCard } = props
        if (typeof deleteCard === 'function') {
            deleteCard(props.info)
        }
    }

    return (
        <div
            onClick={() => onCardClick()}
            onMouseOver={() => onMouseOver()}
            onMouseLeave={() => onMouseLeave()}
            className={styles.projectCard}
            style={{ height: props.size === 'small' ? 325 : 360 }}>
            <div className={styles.cardTitle}>{props.info?.name || 'name'}</div>
            <div className={styles.cardContent}>
                <div className={styles.cardContentBlock}>
                    <div className={styles.cardContentKey}>需求部门：</div>
                    <div className={styles.cardContentValue}>{props.info?.department}</div>
                </div>
                <div className={styles.cardContentBlock}>
                    <div className={styles.cardContentKey}>负责人：</div>
                    <div className={styles.cardContentValue}>{props.info?.personInCharge}</div>
                </div>
                <div className={styles.cardContentBlock}>
                    <div className={styles.cardContentKey}>项目备注：</div>
                    <div className={styles.cardContentValue}>{props.info?.description}</div>
                </div>
                <div className={styles.cardContentBlock}>
                    <div className={styles.cardContentKey}>创建时间：</div>
                    <div className={styles.cardContentValue}>{props.info?.createTime}</div>
                </div>
            </div>
            {showIconBtn && (
                <div className={styles.actionIconBlock}>
                    <FormOutlined onClick={e => onEditCard(e)} style={{ fontSize: 25, marginRight: 25 }} />
                    <DeleteOutlined onClick={onDeleteCard} style={{ fontSize: 25, marginRight: 25 }} />
                </div>
            )}
        </div>
    )
}

export default ProjectCard
