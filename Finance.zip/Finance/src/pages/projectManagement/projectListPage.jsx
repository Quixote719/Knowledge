import React from 'react'
import { withRouter } from 'react-router-dom'
import { inject, observer } from 'mobx-react'
import ProjectCard from 'src/pages/projectManagement/components/projectCard'
import WithPaginationTable from '@/components/withSearchPaginationTable'
import styles from '@/pages/projectManagement/index.less'
import { Breadcrumb, Input, Popover, Modal, Pagination } from 'antdForHik'
import { QuestionCircleFilled } from '@ant-design/icons'
import listIcon from '@/assets/img/common_list.svg'
import cardIcon from '@/assets/img/common_menu_sm.svg'
import refresh from '@/assets/img/common_reflash.svg'
import detailIcon from '@/assets/img/common_export.svg'
import editIcon from '@/assets/img/common_edit.svg'
import deleteIcon from '@/assets/img/common_delete.svg'
import { setUserProjectInfo } from '@/utils/auth'
const { Search } = Input

const projectCols = [
    {
        title: '项目名称',
        dataIndex: 'name',
        filterMultiple: true
    },
    {
        title: '需求部门',
        dataIndex: 'department',
        filterMultiple: true
    },
    {
        title: '负责人',
        dataIndex: 'personInCharge',
        filterMultiple: true
    },
    {
        title: '创建时间',
        dataIndex: 'createTime',
        filterMultiple: true
    },
    {
        title: '备注信息',
        dataIndex: 'description',
        filterMultiple: true
    }
]
class ProjectManage extends React.PureComponent {
    constructor(props) {
        super(props)
        this.state = {
            projectViewType: 'card',
            searchKeyWord: '',
            pageNo: 1,
            pageSize: 10
        }
        this.initProjectCol()
    }
    initProjectCol = () => {
        this.projectCols = [...projectCols]
        this.projectCols.push({
            title: '操作',
            dataIndex: 'handle',
            width: 200,
            render: (text, row) => {
                return (
                    <span>
                        <Popover content="详情">
                            <img
                                src={detailIcon}
                                onClick={() => {
                                    this.props.history.push({
                                        pathname: '/FinanceDashboard',
                                        state: row?.id
                                    })
                                }}
                                alt={'详情'}
                            />
                        </Popover>
                        <Popover content="编辑">
                            <img
                                style={{ color: '#FFFFFF' }}
                                src={editIcon}
                                alt={'编辑'}
                                onClick={() => {
                                    this.editProject(row)
                                }}
                            />
                        </Popover>
                        <Popover content="删除">
                            <img
                                src={deleteIcon}
                                alt={'删除'}
                                onClick={() => {
                                    this.deleteProject(row)
                                }}
                            />
                        </Popover>
                    </span>
                )
            }
        })
    }
    componentDidMount = () => {
        this.requestCardList()
    }
    editProject = params => {
        this.props.projectStore.clearProjectDetail()
        if (params?.id) {
            setUserProjectInfo(params.id)
            this.props.history.push({ pathname: '/ProjectManage/createProject', state: params.id })
        }
    }
    deleteProject = param => {
        if (param?.id) {
            this.props.projectStore.deleteProject({ projectId: param.id })
        }
    }
    enterProject = params => {
        if (params?.id) {
            setUserProjectInfo(params.id)
            this.props.history.push('/FinanceDashboard')
        }
    }
    confirmDeleteProject = param => {
        const deleteText = '请确认是否删除信用卡开卡风险算法项目。仅删除项目业务数据，请谨慎操作！'
        Modal.confirm({
            icon: <QuestionCircleFilled style={{ fontSize: 40 }} />,
            content: deleteText,
            onOk: () => {
                this.deleteProject(param)
                // return false
            },
            onCancel: () => {
                return false
            }
        })
    }
    requestCardList = (number, size, keyWord) => {
        const { pageNo, pageSize, searchKeyWord } = this.state
        if (this.timer) {
            clearTimeout(this.timer)
        }
        this.timer = setTimeout(() => {
            this.props.projectStore.getprojectLists(
                {
                    projectName: keyWord !== undefined ? keyWord : searchKeyWord,
                    sortBy: 'createTime',
                    order: 'DESC',
                    pageNo: number || pageNo,
                    pageSize: size || pageSize
                },
                () => {
                    this.setState({ receiveProjectInfo: true })
                }
            )
        }, 200)
    }
    setProjectView = param => {
        this.setState({ projectViewType: param })
    }
    pageChange = (pageNo, pageSize) => {
        this.setState({ receiveProjectInfo: true, pageNo, pageSize })
        this.requestCardList(pageNo, pageSize)
    }
    handleProjectSearch = e => {
        this.setState({ searchKeyWord: e.target.value })
        this.requestCardList(null, null, e.target.value)
    }
    render() {
        const { projectListInfo = {} } = this.props.projectStore
        const { projectViewType, receiveProjectInfo } = this.state
        const btnActiveStyle = { background: '#4863E4', borderColor: '#4863E4' }
        const projectList = projectListInfo?.list || []
        return (
            <div className={styles.pageContent}>
                <Breadcrumb className={styles.breadcrumbBlock} separator=">">
                    <Breadcrumb.Item
                        className={styles.breadcrumbRoute}
                        onClick={() => this.props.history.push('/ProjectManage')}>
                        我的项目
                    </Breadcrumb.Item>
                    <Breadcrumb.Item>全部项目</Breadcrumb.Item>
                </Breadcrumb>

                <div style={{ marginTop: 10 }}>
                    <div className={styles.operateBtn}>
                        <img className={styles.btnImage} src={refresh} alt="refresh" />
                        <div
                            className={styles.btnText}
                            onClick={() => {
                                this.requestCardList()
                            }}>
                            刷新
                        </div>
                    </div>
                    <div style={{ float: 'right' }}>
                        <div style={{ width: 300, marginRight: 8, display: 'inline-block' }}>
                            <Search onChange={e => this.handleProjectSearch(e)} />
                        </div>
                        <div style={{ display: 'inline-block' }}>
                            <div
                                onClick={() => {
                                    this.setProjectView('table')
                                }}
                                style={projectViewType === 'table' ? { ...btnActiveStyle } : {}}
                                className={styles.iconDiv}>
                                <img alt="" src={listIcon} />
                            </div>
                            <div
                                onClick={() => {
                                    this.setProjectView('card')
                                }}
                                style={projectViewType === 'card' ? { ...btnActiveStyle } : {}}
                                className={styles.iconDiv}>
                                <img alt="" src={cardIcon} />
                            </div>
                        </div>
                    </div>
                </div>
                {projectViewType === 'card' && (
                    <div>
                        <div className={styles.cardFlexBox}>
                            {receiveProjectInfo &&
                                projectList.map(item => {
                                    return (
                                        <ProjectCard
                                            size={'small'}
                                            info={item}
                                            editCard={params => this.editProject(params)}
                                            cardClick={params => {
                                                this.enterProject(params)
                                            }}
                                            deleteCard={params => this.confirmDeleteProject(params)}
                                        />
                                    )
                                })}
                        </div>
                        <Pagination
                            total={projectListInfo.total}
                            pageSize={projectListInfo.pageSize}
                            showTotal={total => `共 ${total} 条`}
                            defaultPageSize={10}
                            showSizeChanger={true}
                            showQuickJumper={true}
                            className={styles.pageination}
                            onChange={(pageNo, pageSize) => {
                                this.pageChange(pageNo, pageSize)
                            }}
                        />
                    </div>
                )}
                {projectViewType === 'table' && (
                    <div style={{ margin: 20 }}>
                        <WithPaginationTable
                            columns={this.projectCols}
                            total={projectListInfo.total}
                            pageSize={projectListInfo.pageSize}
                            rowKey={'processId'}
                            loading={!receiveProjectInfo}
                            onPageChange={(pageNo, pageSize) => {
                                this.pageChange(pageNo, pageSize)
                            }}
                            datas={projectList}
                        />
                    </div>
                )}
            </div>
        )
    }
}

export default withRouter(inject('projectStore')(observer(ProjectManage)))
