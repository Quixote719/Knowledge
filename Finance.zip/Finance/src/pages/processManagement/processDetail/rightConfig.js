import React from 'react'
import { Form, Input, Tabs, Radio, Select, Switch, Upload, Button, message } from 'antdForHik'
import { getToken } from '@/utils/auth'
import { fetchPythonImageType, zipUploadUrl, jarUploadUrl } from '@/serves/process'
import { UploadOutlined } from '@ant-design/icons'
import { inject, observer } from 'mobx-react'
import styles from './rightConfig.less'
import ParamsModal from './paramsModal'
import { PYTHONCOMPID, SPARKCOMPID, SHELLCOMPID } from '@/constants/task'
import { VALIDATING } from '@/constants/index'
import { getQueryString } from '@/utils/index'
import { getFileName } from '@/utils/DAG'
import { validatorName, getFormItemState, validatorNumber, validatorRange10, validatorRange100 } from '@/utils/formItem'
const FormItem = Form.Item
const { TabPane } = Tabs
const { Option } = Select
const { TextArea } = Input
@inject('processStore')
@observer
export default class RightConfig extends React.Component {
    taskConfigFormRef = React.createRef()
    paramsConfigFormRef = React.createRef()
    constructor(props) {
        super(props)
        this.state = {
            // python环境依赖列表
            imageTypeLists: [],
            // python类型
            execType: null,
            // 展示超时停止
            showTimeOut: null,
            // 失败重试
            showFailureRetry: null,
            // 表单失焦保存状态
            saveStatus: {},
            // python zipFileList
            zipFileList: [],
            // spark jarFileList
            jarFileList: [],
            showExtraParamsModal: false,
            // showBusinessParamsModal: true
            showBusinessParamsModal: false
        }
    }
    async componentDidMount() {
        const result = await fetchPythonImageType()
        this.setState({
            imageTypeLists: result?.data?.list || []
        })
    }
    componentWillReceiveProps(nextProps) {
        const currentComponent = nextProps?.currentComponent
        const configParams = currentComponent?.configParams
        if (currentComponent?.id !== this.props?.currentComponent?.id) {
            this.setState({
                showTimeOut: configParams.timeOutStop,
                showFailureRetry: configParams.failureRetry,
                execType: configParams?.taskConfig?.execType
            })
            if (currentComponent?.compId === PYTHONCOMPID && configParams?.taskConfig?.taskFilePath) {
                this.setState({
                    zipFileList: [
                        {
                            uid: '-1',
                            name: getFileName(configParams?.taskConfig?.taskFilePath),
                            status: 'done'
                        }
                    ]
                })
            }
            if (currentComponent?.compId === SPARKCOMPID && configParams?.taskConfig?.fileName) {
                this.setState({
                    jarFileList: [
                        {
                            uid: '-1',
                            name: configParams?.taskConfig?.fileName,
                            status: 'done'
                        }
                    ]
                })
            }
            setTimeout(() => {
                if (this.taskConfigFormRef.current) {
                    // 设置任务配置
                    this.taskConfigFormRef.current.resetFields()
                    this.taskConfigFormRef.current.setFieldsValue({
                        ...configParams,
                        ...configParams?.taskConfig
                    })
                }
                if (this.paramsConfigFormRef.current) {
                    // 设置参数配置
                    this.paramsConfigFormRef.current.resetFields()
                    this.paramsConfigFormRef.current.setFieldsValue({
                        ...configParams,
                        ...configParams?.taskConfig,
                        businessParams: JSON.stringify(configParams?.taskConfig?.businessParams),
                        extraParams: JSON.stringify(configParams?.taskConfig?.extraParams)
                    })
                }
            }, 100)
        }
    }

    // 失焦保存
    saveDag = ({ fromRef, validateName, directSave, value }) => {
        const { validateFields } = fromRef.current
        validateFields([`${validateName}`])
            .then(async data => {
                // 直接储存需要设置value
                if (directSave) {
                    this.props.processStore.changeParmasToSave({ key: validateName, value: value }).then(res => {
                        if (res) {
                            // 有保存状态时先给与一个1秒的loading状态
                            this.setState(
                                {
                                    saveStatus: { [validateName]: VALIDATING }
                                },
                                () => {
                                    setTimeout(() => {
                                        this.setState({
                                            saveStatus: { [validateName]: res }
                                        })
                                    }, 1000)
                                }
                            )
                        }
                    })
                    return
                }
                // 格式验证成功
                if (data) {
                    this.props.processStore
                        .changeParmasToSave({ key: validateName, value: Object.values(data)[0] })
                        .then(res => {
                            if (res) {
                                // 有保存状态时先给与一个1秒的loading状态
                                this.setState(
                                    {
                                        saveStatus: { [validateName]: VALIDATING }
                                    },
                                    () => {
                                        setTimeout(() => {
                                            this.setState({
                                                saveStatus: { [validateName]: res }
                                            })
                                        }, 1000)
                                    }
                                )
                            }
                        })
                }
            })
            .catch(e => {
                console.warn(e, 'e')
            })
    }
    // 任务配置公共部分
    renderCommonTaskConfig() {
        const { showTimeOut, showFailureRetry } = this.state
        // console.log('configParams', this.props.processStore.currentComponent.configParams)
        return (
            <>
                <FormItem
                    label={'描述'}
                    name="taskDescription"
                    {...getFormItemState(this.state.saveStatus['taskDescription'])}>
                    <TextArea
                        placeholder="请输入描述..."
                        onBlur={() =>
                            this.saveDag({
                                fromRef: this.taskConfigFormRef,
                                validateName: 'taskDescription'
                            })
                        }
                    />
                </FormItem>
                {/* swith在form中无法拿到name 手动设置成受控组件 */}
                <FormItem name="timeOutStop" {...getFormItemState(this.state.saveStatus['timeOutStop'])}>
                    <span className={styles.label}>超时停止</span>
                    <Switch
                        onChange={value => {
                            this.setState({
                                showTimeOut: value
                            })

                            this.saveDag({
                                fromRef: this.taskConfigFormRef,
                                validateName: 'timeOutStop',
                                value,
                                directSave: true
                            })
                        }}
                        checked={showTimeOut}></Switch>
                </FormItem>
                {showTimeOut && (
                    <FormItem
                        label={'超时时间'}
                        name="timeOutDuration"
                        required={true}
                        rules={[{ required: true, message: '必填' }, validatorNumber]}
                        {...getFormItemState(this.state.saveStatus['timeOutDuration'])}>
                        <Input
                            maxLength={30}
                            suffix="分"
                            onBlur={e => {
                                this.saveDag({
                                    fromRef: this.taskConfigFormRef,
                                    validateName: 'timeOutDuration',
                                    directSave: true,
                                    value: Number(e.target.value)
                                })
                            }}
                        />
                    </FormItem>
                )}

                <FormItem
                    name="failureRetry"
                    required={true}
                    {...getFormItemState(this.state.saveStatus['failureRetry'])}>
                    <span className={styles.label}>失败重试</span>
                    <Switch
                        onChange={value => {
                            this.setState({
                                showFailureRetry: value
                            })
                            this.saveDag({
                                fromRef: this.taskConfigFormRef,
                                validateName: 'failureRetry',
                                value,
                                directSave: true
                            })
                        }}
                        checked={showFailureRetry}></Switch>
                </FormItem>

                {showFailureRetry && (
                    <>
                        <FormItem
                            label={'失败重试次数'}
                            name="retryNumber"
                            required={true}
                            rules={[{ required: true, message: '必填' }, validatorRange10]}
                            {...getFormItemState(this.state.saveStatus['retryNumber'])}>
                            <Input
                                maxLength={30}
                                suffix="次"
                                onBlur={e =>
                                    this.saveDag({
                                        fromRef: this.taskConfigFormRef,
                                        validateName: 'retryNumber',
                                        directSave: true,
                                        value: Number(e.target.value)
                                    })
                                }
                            />
                        </FormItem>
                        <FormItem
                            label={'失败重试间隔'}
                            name="retryInterval"
                            required={true}
                            rules={[{ required: true, message: '必填' }, validatorNumber]}
                            {...getFormItemState(this.state.saveStatus['retryInterval'])}>
                            <Input
                                maxLength={30}
                                suffix="分"
                                onBlur={e =>
                                    this.saveDag({
                                        fromRef: this.taskConfigFormRef,
                                        validateName: 'retryInterval',
                                        directSave: true,
                                        value: Number(e.target.value)
                                    })
                                }
                            />
                        </FormItem>
                    </>
                )}
            </>
        )
    }
    // 展示python任务
    renderPythonTaskConfig() {
        const { imageTypeLists, execType, saveStatus, zipFileList } = this.state
        const id = this.props.processStore.currentComponent?.id
        const that = this
        const zipUploadProps = {
            action: `${zipUploadUrl}?processId=${getQueryString().processId}&localId=${id}`,
            accept: '.zip',
            name: 'zipFile', //发到后台的文件参数名
            headers: {
                'X-User-Id': getToken() || '123'
            },
            onChange(info) {
                //把fileList拿出来
                let { fileList } = info
                const status = info.file.status

                if (status === 'done') {
                    if (fileList[0]?.response?.data?.result) {
                        that.saveDag({
                            fromRef: that.taskConfigFormRef,
                            validateName: 'taskFilePath',
                            directSave: true,
                            value: fileList[0]?.response?.data?.result
                        })
                    }
                }
                if (status === 'error') {
                    message.error(`${info.file.name}上传失败`)
                }

                //重新设置state,只设置留下一个文件
                that.setState({ zipFileList: fileList?.length > 0 ? [fileList[fileList?.length - 1]] : [] })
            },
            fileList: zipFileList
        }
        return (
            <>
                <FormItem label={'类型'} name="execType" required={true} {...getFormItemState(saveStatus['execType'])}>
                    <Radio.Group
                        onChange={e => {
                            this.setState({
                                execType: e.target.value
                            })
                        }}>
                        <Radio
                            value={'code'}
                            onBlur={() =>
                                this.saveDag({
                                    fromRef: this.taskConfigFormRef,
                                    validateName: 'execType'
                                })
                            }>
                            代码
                        </Radio>
                        <Radio
                            value={'image'}
                            onBlur={() =>
                                this.saveDag({
                                    fromRef: this.taskConfigFormRef,
                                    validateName: 'execType'
                                })
                            }>
                            镜像
                        </Radio>
                    </Radio.Group>
                </FormItem>
                {execType === 'code' && (
                    <>
                        <FormItem
                            label={'环境依赖'}
                            name="imageType"
                            required={true}
                            {...getFormItemState(saveStatus['imageType'])}
                            rules={[{ required: true, message: '必选' }]}>
                            <Select
                                onBlur={() =>
                                    this.saveDag({
                                        fromRef: this.taskConfigFormRef,
                                        validateName: 'imageType'
                                    })
                                }>
                                {imageTypeLists.map(item => (
                                    <Option value={item?.imageName}>{item?.imageDescription}</Option>
                                ))}
                            </Select>
                        </FormItem>
                        <FormItem label={'ZIP文件'} name="taskFilePath" required={true}>
                            <Upload {...zipUploadProps}>
                                <Button>
                                    <UploadOutlined />
                                    上传
                                </Button>
                            </Upload>
                        </FormItem>
                        <FormItem label={'主文件'} name="mainClass" {...getFormItemState(saveStatus['mainClass'])}>
                            <Input
                                maxLength={60}
                                onBlur={() =>
                                    this.saveDag({
                                        fromRef: this.taskConfigFormRef,
                                        validateName: 'mainClass'
                                    })
                                }
                            />
                        </FormItem>
                        <FormItem label={'主函数参数'} name="mainArgs" {...getFormItemState(saveStatus['mainArgs'])}>
                            <Input
                                onBlur={() =>
                                    this.saveDag({
                                        fromRef: this.taskConfigFormRef,
                                        validateName: 'mainArgs'
                                    })
                                }
                            />
                        </FormItem>
                    </>
                )}
                {execType === 'image' && (
                    <>
                        <FormItem
                            label={'镜像名称'}
                            name="imageType"
                            required={true}
                            {...getFormItemState(saveStatus['imageType'])}>
                            <Input
                                maxLength={30}
                                onBlur={() =>
                                    this.saveDag({
                                        fromRef: this.taskConfigFormRef,
                                        validateName: 'imageType'
                                    })
                                }
                            />
                        </FormItem>
                        <FormItem label={'执行命令'} name="mainArgs" {...getFormItemState(saveStatus['mainArgs'])}>
                            <TextArea
                                placeholder="请输入代码..."
                                maxLength={255}
                                onBlur={() =>
                                    this.saveDag({
                                        fromRef: this.taskConfigFormRef,
                                        validateName: 'mainArgs'
                                    })
                                }
                            />
                        </FormItem>
                    </>
                )}
            </>
        )
    }

    renderSparkTaskConfig() {
        const { saveStatus, jarFileList } = this.state
        const id = this.props.processStore.currentComponent?.id
        const that = this
        const jarUploadProps = {
            action: `${jarUploadUrl}?processId=${getQueryString().processId}&localId=${id}`,
            accept: '.jar',
            name: 'jarFile', //发到后台的文件参数名
            headers: {
                'X-User-Id': getToken() || '123'
            },
            // jar包上传直接使用name
            onChange(info) {
                //把fileList拿出来
                let { fileList } = info
                const status = info.file.status
                if (status === 'done') {
                    if (fileList[0]?.response?.data?.result) {
                        that.saveDag({
                            fromRef: that.taskConfigFormRef,
                            validateName: 'fileName',
                            directSave: true,
                            value: fileList[0]?.name
                        })
                    }
                }
                if (status === 'error') {
                    message.error(`${info.file.name}上传失败`)
                }

                //重新设置state,只设置留下一个文件
                that.setState({ jarFileList: fileList?.length > 0 ? [fileList[fileList?.length - 1]] : [] })
            },
            fileList: jarFileList
        }
        return (
            <>
                <FormItem label={'JAR文件'} name="fileName" required={true}>
                    <Upload {...jarUploadProps}>
                        <Button>
                            <UploadOutlined />
                            上传
                        </Button>
                    </Upload>
                </FormItem>
                <FormItem label={'主函数'} name="mainClass" {...getFormItemState(saveStatus['mainClass'])}>
                    <Input
                        maxLength={100}
                        onBlur={() =>
                            this.saveDag({
                                fromRef: this.taskConfigFormRef,
                                validateName: 'mainClass'
                            })
                        }
                    />
                </FormItem>
                <FormItem label={'主函数参数'} name="mainArgs" {...getFormItemState(saveStatus['mainArgs'])}>
                    <Input
                        onBlur={() =>
                            this.saveDag({
                                fromRef: this.taskConfigFormRef,
                                validateName: 'mainArgs'
                            })
                        }
                    />
                </FormItem>
            </>
        )
    }
    renderShellTaskConfig() {
        const { saveStatus } = this.state
        return (
            <>
                <FormItem label={'shell脚本'} name="shellScript" {...getFormItemState(saveStatus['shellScript'])}>
                    <TextArea
                        placeholder="请输入代码运行"
                        onBlur={() =>
                            this.saveDag({
                                fromRef: this.taskConfigFormRef,
                                validateName: 'shellScript'
                            })
                        }
                    />
                </FormItem>
                <FormItem label={'IP(SSH)'} name="destIp" required={true} {...getFormItemState(saveStatus['destIp'])}>
                    <Input
                        maxLength={30}
                        onBlur={() =>
                            this.saveDag({
                                fromRef: this.taskConfigFormRef,
                                validateName: 'destIp'
                            })
                        }
                    />
                </FormItem>
                <FormItem label={'端口'} name="destPort" required={true} {...getFormItemState(saveStatus['destPort'])}>
                    <Input
                        maxLength={30}
                        onBlur={() =>
                            this.saveDag({
                                fromRef: this.taskConfigFormRef,
                                validateName: 'destPort'
                            })
                        }
                    />
                </FormItem>
                <FormItem
                    label={'用户名'}
                    name="destUserName"
                    required={true}
                    {...getFormItemState(saveStatus['destUserName'])}>
                    <Input
                        maxLength={30}
                        onBlur={() =>
                            this.saveDag({
                                fromRef: this.taskConfigFormRef,
                                validateName: 'destUserName'
                            })
                        }
                    />
                </FormItem>
                <FormItem
                    label={'密码'}
                    name="destPassword"
                    required={true}
                    {...getFormItemState(saveStatus['destPassword'])}>
                    <Input.Password
                        maxLength={30}
                        onBlur={() =>
                            this.saveDag({
                                fromRef: this.taskConfigFormRef,
                                validateName: 'destPassword'
                            })
                        }
                    />
                </FormItem>
            </>
        )
    }

    // python 参数配置
    renderPythonParamsConfig() {
        return (
            <>
                <FormItem
                    label={'Memory'}
                    name="memory"
                    required={true}
                    {...getFormItemState(this.state.saveStatus['memory'])}
                    rules={[{ required: true, message: '必填' }, validatorNumber]}>
                    <Input
                        maxLength={30}
                        onBlur={e =>
                            this.saveDag({
                                fromRef: this.paramsConfigFormRef,
                                validateName: 'memory',
                                directSave: true,
                                value: Number(e.target.value)
                            })
                        }
                        suffix="MB"
                    />
                </FormItem>

                <FormItem
                    label={'CPU'}
                    name="cores"
                    required={true}
                    {...getFormItemState(this.state.saveStatus['cores'])}
                    rules={[{ required: true, message: '必填' }, validatorRange10]}>
                    <Input
                        maxLength={30}
                        onBlur={e =>
                            this.saveDag({
                                fromRef: this.paramsConfigFormRef,
                                validateName: 'cores',
                                directSave: true,
                                value: Number(e.target.value)
                            })
                        }
                        suffix="个"
                    />
                </FormItem>
            </>
        )
    }
    renderSparkParamsConfig() {
        return (
            <>
                <div>资源参数</div>
                <FormItem
                    label={'driverCores'}
                    name="driverCores"
                    required={true}
                    {...getFormItemState(this.state.saveStatus['driverCores'])}
                    rules={[{ required: true, message: '必填' }, validatorRange100]}>
                    <Input
                        maxLength={30}
                        onBlur={e =>
                            this.saveDag({
                                fromRef: this.paramsConfigFormRef,
                                validateName: 'driverCores',
                                directSave: true,
                                value: Number(e.target.value)
                            })
                        }
                    />
                </FormItem>
                <FormItem
                    label={'driverMemory'}
                    name="driverMemory"
                    required={true}
                    {...getFormItemState(this.state.saveStatus['driverMemory'])}
                    rules={[{ required: true, message: '必填' }, validatorNumber]}>
                    <Input
                        maxLength={30}
                        onBlur={e =>
                            this.saveDag({
                                fromRef: this.paramsConfigFormRef,
                                validateName: 'driverMemory',
                                directSave: true,
                                value: Number(e.target.value)
                            })
                        }
                    />
                </FormItem>
                <FormItem
                    label={'executorCores'}
                    name="executorCores"
                    required={true}
                    {...getFormItemState(this.state.saveStatus['executorCores'])}
                    rules={[{ required: true, message: '必填' }, validatorRange100]}>
                    <Input
                        onBlur={e =>
                            this.saveDag({
                                fromRef: this.paramsConfigFormRef,
                                validateName: 'executorCores',
                                directSave: true,
                                value: Number(e.target.value)
                            })
                        }
                    />
                </FormItem>
                <FormItem
                    label={'executorMemory'}
                    name="executorMemory"
                    required={true}
                    {...getFormItemState(this.state.saveStatus['executorMemory'])}
                    rules={[{ required: true, message: '必填' }, validatorNumber]}>
                    <Input
                        onBlur={e =>
                            this.saveDag({
                                fromRef: this.paramsConfigFormRef,
                                validateName: 'executorMemory',
                                directSave: true,
                                value: Number(e.target.value)
                            })
                        }
                    />
                </FormItem>
                <FormItem
                    label={'numExecutor'}
                    name="numExecutor"
                    required={true}
                    {...getFormItemState(this.state.saveStatus['numExecutor'])}
                    rules={[{ required: true, message: '必填' }, validatorNumber]}>
                    <Input
                        onBlur={e =>
                            this.saveDag({
                                fromRef: this.paramsConfigFormRef,
                                validateName: 'numExecutor',
                                directSave: true,
                                value: Number(e.target.value)
                            })
                        }
                    />
                </FormItem>
                <FormItem
                    label={'拓展参数'}
                    name="extraParams"
                    {...getFormItemState(this.state.saveStatus['extraParams'])}>
                    <Button
                        onClick={() => {
                            this.setState({
                                showExtraParamsModal: true
                            })
                        }}>
                        配置拓展参数
                    </Button>
                </FormItem>
            </>
        )
    }
    renderBusinessParamsModal() {
        const { showBusinessParamsModal } = this.state
        return (
            <ParamsModal
                visible={showBusinessParamsModal}
                title={'配置业务参数'}
                onCancel={() => {
                    this.setState({
                        showBusinessParamsModal: false
                    })
                }}
            />
        )
    }
    renderExtraParamsParamsModal() {
        const { showExtraParamsModal } = this.state
        return (
            <ParamsModal
                visible={showExtraParamsModal}
                title={'配置拓展参数'}
                onCancel={() => {
                    this.setState({
                        showExtraParamsModal: false
                    })
                }}
            />
        )
    }
    render() {
        const { currentComponentName } = this.props.processStore
        const { currentComponent } = this.props
        const { saveStatus, showExtraParamsModal, showBusinessParamsModal } = this.state
        return (
            <div className={styles.rightConfig}>
                <div className={styles.title}>{currentComponentName}</div>
                <div className={styles.tabs}>
                    <Tabs defaultActiveKey="params">
                        <TabPane tab={'任务配置'} key="task" forceRender={true}>
                            {currentComponent && (
                                <Form
                                    className={styles.formSection}
                                    layout={'vertical'}
                                    name="taskConfig"
                                    ref={this.taskConfigFormRef}
                                    autoComplete={'off'}>
                                    <FormItem
                                        label={'名称'}
                                        name="name"
                                        {...getFormItemState(saveStatus['name'])}
                                        required={true}
                                        rules={[{ required: true, message: '必填' }, validatorName]}>
                                        <Input
                                            maxLength={30}
                                            onBlur={() =>
                                                this.saveDag({
                                                    fromRef: this.taskConfigFormRef,
                                                    validateName: 'name'
                                                })
                                            }
                                        />
                                    </FormItem>
                                    {currentComponent?.compId === PYTHONCOMPID && this.renderPythonTaskConfig()}
                                    {currentComponent?.compId === SPARKCOMPID && this.renderSparkTaskConfig()}
                                    {currentComponent?.compId === SHELLCOMPID && this.renderShellTaskConfig()}
                                    {this.renderCommonTaskConfig()}
                                </Form>
                            )}
                        </TabPane>
                        <TabPane tab={'参数配置'} key="params" forceRender={true}>
                            <Form
                                className={styles.formSection}
                                layout={'vertical'}
                                name="paramsConfig"
                                autoComplete={'off'}
                                ref={this.paramsConfigFormRef}>
                                <FormItem
                                    label={'业务参数'}
                                    name="businessParams"
                                    {...getFormItemState(this.state.saveStatus['businessParams'])}>
                                    <Button
                                        onClick={() => {
                                            this.setState({
                                                showBusinessParamsModal: true
                                            })
                                        }}>
                                        配置业务参数
                                    </Button>
                                </FormItem>
                                {currentComponent?.compId === PYTHONCOMPID && this.renderPythonParamsConfig()}
                                {currentComponent?.compId === SPARKCOMPID && this.renderSparkParamsConfig()}
                            </Form>
                        </TabPane>
                    </Tabs>

                    {showBusinessParamsModal && this.renderBusinessParamsModal('businessParams')}
                    {showExtraParamsModal && this.renderExtraParamsParamsModal('extraParams')}
                </div>
            </div>
        )
    }
}
