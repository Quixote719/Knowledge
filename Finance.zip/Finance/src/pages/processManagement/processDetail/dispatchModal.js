import React, { useState, useCallback } from 'react'
import { Modal, Form, Input, Button, message } from 'antdForHik'
import { inject } from 'mobx-react'
import { checkCron, saveCron } from '@/serves/process'
import { getQueryString } from '@/utils/index'
import { getFormItemState } from '@/utils/formItem'
import styles from './index.less'
import { SUCCESS, VALIDATING, ERROR } from '@/constants/index'

const DispatchModal = props => {
    const { visible, onCancel, processInfo, cronExpression } = props

    // 表达式保存状态
    const [cronExpressionStatus, setCronExpressionStatus] = useState('')

    const [form] = Form.useForm()
    const onOk = async () => {
        const value = form.getFieldsValue()
        if (cronExpressionStatus === SUCCESS) {
            const response = await saveCron({ processId: getQueryString().processId, ...value })
            if (response?.data?.cronExpression) {
                onCancel()
            }
        } else if (cronExpressionStatus === '') {
            message.warn('请先验证corn表达式')
        } else {
            message.error('corn表达式不合法')
        }
    }
    const checkCronHandle = useCallback(async () => {
        const value = form.getFieldsValue()
        setCronExpressionStatus(VALIDATING)
        const response = await checkCron({ cronExpression: value.cronExpression })
        if (response?.data?.result) {
            setCronExpressionStatus(SUCCESS)
        } else {
            setCronExpressionStatus(ERROR)
        }
    }, [form])

    return (
        <Modal centered title={'调度设置'} visible={visible} width={592} onCancel={onCancel} onOk={onOk}>
            <Form
                autoComplete="off"
                form={form}
                layout="vertical"
                initialValues={{ cronExpression }}
                name="form_in_modal"
                className={styles.form}>
                <div className={styles.info} key="processName">
                    <span className={styles.title}>任务名称</span>
                    <span>{processInfo?.processName}</span>
                </div>
                <div className={styles.info} key="processDescribe">
                    <span className={styles.title}>描述</span>
                    <span>{processInfo?.processDescribe}</span>
                </div>
                <Form.Item
                    name="cronExpression"
                    label="时间设置"
                    {...getFormItemState(cronExpressionStatus)}
                    initialValue={cronExpression}>
                    <Input placeholder={'请输入cron表达式'} />
                </Form.Item>

                <Button onClick={checkCronHandle}>验证Cron</Button>
            </Form>
        </Modal>
    )
}

export default inject('processStore')(DispatchModal)
