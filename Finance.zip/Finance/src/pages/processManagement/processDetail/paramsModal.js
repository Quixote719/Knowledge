import React from 'react'
import { Modal } from 'antdForHik'
import KeyValueInput from '@/components/keyValueInput/index.jsx'
import { inject } from 'mobx-react'
// import styles from './paramsModal.less'
import './paramsModal.less'

const ParamsModal = props => {
    const { visible, onCancel, title } = props
    // console.log(title, 'title')
    // const onOk = () => {
    //     const value = form.getFieldsValue()
    // }
    return (
        <Modal centered title={title} visible={visible} width={480} onCancel={onCancel}>
            <KeyValueInput />
        </Modal>
    )
}

export default inject('processStore')(ParamsModal)
