import React, { useState, useCallback, useEffect } from 'react'
import styles from './index.less'
// import { Popover, message } from 'antdForHik'
import { Popover } from 'antdForHik'
import { withRouter } from 'react-router-dom'
import CompactInput from '@/components/compactInput'
import { inject } from 'mobx-react'
import { defaultSearchOption } from '@/constants/index'
import ConfirmModal from '@/components/confirmModal/confirmModal'
import addIcon from '@/assets/img/common_add.svg'
import reflash from '@/assets/img/common_reflash.svg'
import WithPaginationTable from '@/components/withSearchPaginationTable'
import CreateModal from './createModal'
import { translateTimesTampToString } from '@/utils/index'

import userEdit from '@/assets/img/common_edit.svg'
import start from '@/assets/img/common_start.svg'
import play from '@/assets/img/ptz_play.svg'
import stop from '@/assets/img/common_disable.svg'
import more from '@/assets/img/common_more_hori.svg'
import deleteIcon from '@/assets/img/common_delete.svg'
import enable from '@/assets/img/common_feedback_success_sm.svg'

import { processStatus, processStatusMap } from '@/constants/index'
const SearchOpt = [
    { text: '流程ID', value: 'processId' },
    { text: '流程名称', value: 'processName' }
]
const defaultCompactInputValue = {
    selectValue: SearchOpt[0].value,
    searchValue: ''
}

const ProcessManagement = props => {
    // 删除确认
    const [deleteModalVisible, setDeleteModalVisible] = useState(false)
    // 创建弹窗
    const [createModalVisible, setCreateModalVisible] = useState(false)
    // 修改流程信息
    const [modifyProcess, setModifyProcess] = useState(null)
    // 禁用弹窗
    const [disableModalVisible, setDisableModalVisible] = useState(false)
    // 启用弹窗
    const [enableModalVisible, setEnableeModalVisible] = useState(false)
    // 运行弹窗
    const [runModalVisible, setRunModalVisible] = useState(false)
    // 表格loading
    const [tableLoading, setTableLoading] = useState(null)
    const [current, setCurrent] = useState(1)
    const [pageSize, setPageSize] = useState(10)
    // 设置组合搜索框
    const [selectValue, setSelectValue] = useState(defaultCompactInputValue.selectValue)
    const [searchValue, setSearchValue] = useState(defaultCompactInputValue.searchValue)

    const { processList, processData, setProcessSearchOption } = props.processStore

    const resetSearchList = {}
    SearchOpt.map(item => {
        resetSearchList[item.value] = null
        return item
    })
    useEffect(() => {
        fetchProcessLists(defaultSearchOption)
    }, [])

    const resetModifyProcess = () => {
        setDeleteModalVisible(false)
        setDisableModalVisible(false)
        setEnableeModalVisible(false)
        setRunModalVisible(false)
        setModifyProcess(null)
    }
    const renderDeleteModal = () => {
        return (
            <ConfirmModal
                text={`确认删除流程${modifyProcess?.processName}吗？`}
                onConfirm={() => {
                    props.processStore.deleteProcess(
                        {
                            processId: modifyProcess.processId
                        },
                        () => {
                            fetchProcessLists()
                            resetModifyProcess()
                        }
                    )
                }}
                visible={deleteModalVisible}
                onCancel={() => resetModifyProcess()}
            />
        )
    }
    const renderDisableModal = () => {
        return (
            <ConfirmModal
                text={`确认禁用流程${modifyProcess?.processName}吗？`}
                onConfirm={() => setProcessStatus('disable')}
                visible={disableModalVisible}
                onCancel={() => resetModifyProcess()}
            />
        )
    }
    const renderEnableModal = () => {
        return (
            <ConfirmModal
                text={`确认启用流程${modifyProcess?.processName}吗？`}
                onConfirm={() => setProcessStatus('enable')}
                visible={enableModalVisible}
                onCancel={() => resetModifyProcess()}
            />
        )
    }
    const renderRunModal = () => {
        return (
            <ConfirmModal
                text={`确认运行流程${modifyProcess?.processName}吗？`}
                onConfirm={() => {
                    props.processStore.startProcess(
                        {
                            processId: modifyProcess.processId
                        },
                        () => {
                            fetchProcessLists()
                            resetModifyProcess()
                        }
                    )
                }}
                visible={runModalVisible}
                onCancel={() => resetModifyProcess()}
            />
        )
    }
    const renderCreateModal = () => {
        return (
            <CreateModal
                {...(modifyProcess || {})}
                visible={createModalVisible}
                onConfirm={() => {
                    fetchProcessLists()
                    setCreateModalVisible(false)
                }}
                onCancel={() => {
                    setModifyProcess(null)
                    setCreateModalVisible(false)
                }}
            />
        )
    }

    // 获取
    const fetchProcessLists = (params = defaultSearchOption, init = false) => {
        setTableLoading(true)
        setProcessSearchOption(params, init)
        props.processStore.getProcessLists(() => {
            setTableLoading(false)
        })
    }
    const jumpToDetail = useCallback(
        processId => {
            props.history.push(`/ProcessManagement/Detail?processId=${processId}`)
        },
        [props.history]
    )

    const setProcessStatus = useCallback(
        value => {
            props.processStore.setProcessStatus(
                {
                    processId: modifyProcess?.processId,
                    processEnable: value
                },
                () => {
                    fetchProcessLists()
                    resetModifyProcess()
                }
            )
        },
        [modifyProcess]
    )
    const columns = [
        {
            title: '流程ID',
            dataIndex: 'processId'
        },
        {
            title: '流程名称',
            dataIndex: 'processName',
            render: (text, row) => (
                <span
                    className={styles.processName}
                    onClick={() => {
                        jumpToDetail(row.processId)
                    }}>
                    {text}
                </span>
            )
        },
        {
            title: '状态',
            dataIndex: 'processEnable',
            filters: [
                { text: '启用', value: 'enable' },
                { text: '禁用', value: 'disable' }
            ],
            onFilter: (value, data) => {
                if (value.length > 1) {
                    fetchProcessLists({ processEnable: null })
                } else {
                    fetchProcessLists({ processEnable: processStatusMap[value[0]] })
                }
            },
            filterMultiple: true,
            render: text => {
                return (
                    <div className={styles.status}>
                        <img src={text === 'enable' ? enable : stop} alt="" />
                        {processStatus[text]}
                    </div>
                )
            }
        },
        {
            title: 'cron表达式',
            dataIndex: 'cronExpression'
        },
        {
            title: '创建时间',
            dataIndex: 'createTime',
            sorter: true,
            render: text => translateTimesTampToString(text)
        },
        {
            title: '更新时间',
            dataIndex: 'updateTime',
            sorter: true,
            render: text => translateTimesTampToString(text)
        },
        {
            title: '描述',
            dataIndex: 'description'
        },
        {
            title: '操作',
            dataIndex: 'handle',
            width: 200,
            fixed: 'right',
            render: (text, row) => {
                // 流程启用
                const enable = row.processEnable === 'enable'
                return (
                    <span className={styles.handle}>
                        <Popover content="编辑">
                            <img
                                src={userEdit}
                                alt={'edit'}
                                onClick={() => {
                                    if (!enable) {
                                        jumpToDetail(row.processId)
                                    }
                                }}
                                disabled={enable}
                            />
                        </Popover>
                        <Popover content="运行">
                            <img
                                src={start}
                                alt={'运行'}
                                disabled={!enable}
                                onClick={() => {
                                    if (enable) {
                                        setModifyProcess(row)
                                        setRunModalVisible(true)
                                    }
                                }}
                            />
                        </Popover>
                        <Popover content={enable ? '禁用' : '启用'}>
                            {enable ? (
                                <img
                                    src={stop}
                                    alt={'禁用'}
                                    onClick={() => {
                                        setModifyProcess(row)
                                        setDisableModalVisible(true)
                                    }}
                                />
                            ) : (
                                <img
                                    src={play}
                                    alt={'启用'}
                                    onClick={() => {
                                        setModifyProcess(row)
                                        setEnableeModalVisible(true)
                                    }}
                                />
                            )}
                        </Popover>
                        <Popover content="删除">
                            <img
                                src={deleteIcon}
                                alt={'删除'}
                                disabled={enable}
                                onClick={() => {
                                    if (!enable) {
                                        setModifyProcess(row)
                                        setDeleteModalVisible(true)
                                    }
                                }}
                            />
                        </Popover>
                        <Popover
                            overlayClassName={styles.projPopover}
                            placement="bottom"
                            content={
                                <ul>
                                    <li
                                        onClick={() => {
                                            setModifyProcess({
                                                type: 'modify',
                                                initialValues: {
                                                    processName: row?.processName,
                                                    desc: row?.description,
                                                    processId: row?.processId
                                                }
                                            })
                                            setCreateModalVisible(true)
                                        }}>
                                        修改信息
                                    </li>
                                    {/* 跳转至实例列表页面,填充流程名称*/}
                                    <li onClick={() => {}}>查看实例</li>
                                </ul>
                            }>
                            <img src={more} alt={'更多'} />
                        </Popover>
                    </span>
                )
            }
        }
    ]
    return (
        <div className={styles.container}>
            <header>
                <div>
                    <span className={styles.headerButton} onClick={() => setCreateModalVisible(true)}>
                        <img src={addIcon} alt="add" />
                        创建流程
                    </span>
                    <span
                        className={styles.headerButton}
                        onClick={() => {
                            // 初始化页码
                            setCurrent(1)
                            setPageSize(10)
                            setSearchValue(defaultCompactInputValue.searchValue)
                            setSelectValue(defaultCompactInputValue.selectValue)
                            fetchProcessLists(defaultSearchOption, true)
                        }}>
                        <img src={reflash} alt="reflash" />
                        刷新
                    </span>
                </div>
                <CompactInput
                    placeholder={'搜索'}
                    onSearch={(_, value) => {
                        fetchProcessLists({ ...resetSearchList, [selectValue]: value })
                    }}
                    selectOptions={SearchOpt}
                    selectValue={selectValue}
                    searchValue={searchValue}
                    onSelectChange={value => {
                        setSelectValue(value)
                    }}
                    onSearchChange={value => {
                        setSearchValue(value)
                    }}
                />
            </header>
            {deleteModalVisible && renderDeleteModal()}
            {createModalVisible && renderCreateModal()}
            {enableModalVisible && renderEnableModal()}
            {disableModalVisible && renderDisableModal()}
            {runModalVisible && renderRunModal()}

            <WithPaginationTable
                onChange={(pagination, filters, sorter, extra) => {
                    // 点击排序
                    if (sorter.order) {
                        fetchProcessLists({
                            sortList: [
                                {
                                    sortBy: sorter.field,
                                    order: sorter.order === 'descend' ? 'desc' : 'asc'
                                }
                            ]
                        })
                    } else {
                        // 取消排序
                        fetchProcessLists()
                    }
                }}
                columns={columns}
                total={processData?.total}
                rowKey={'processId'}
                loading={tableLoading}
                pageSize={pageSize}
                current={current}
                onPageChange={(page, pageSize) => {
                    setCurrent(page)
                    setPageSize(pageSize)
                    fetchProcessLists({
                        pageNo: page,
                        pageSize: pageSize
                    })
                }}
                datas={processList}
            />
        </div>
    )
}

export default inject('processStore')(withRouter(ProcessManagement))
