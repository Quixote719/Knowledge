import fetchProxy from '@/utils/fetchProxy'
import { getProjectId } from '@/utils/auth'
import { recombineUrl } from '@/utils/method'
// 查询流程列表
export const getInstanceLists = async params => {
    return fetchProxy(`/api/v1/project/${getProjectId()}/process/instance/search`, {
        method: 'post',
        payload: params
    })
}

export const getInstanceDetail = async params => {
    return fetchProxy(
        recombineUrl(`/api/v1/project/${getProjectId()}/process/instance/{processInstanceId}/get`, params),
        {
            method: 'get'
        }
    )
}

export const stopInstance = async params => {
    return fetchProxy(
        recombineUrl(`/api/v1/project/${getProjectId()}/process/instance/{processInstanceId}/stop`, params),
        {
            method: 'get'
        }
    )
}

export const deleteInstance = async params => {
    return fetchProxy(
        recombineUrl(`/api/v1/project/${getProjectId()}/process/instance/{processInstanceId}/delete`, params),
        {
            method: 'delete'
        }
    )
}
// 获取日志
export const fetchLogs = async params => {
    return fetchProxy(`/api/v1/project/${getProjectId()}/process/instance/task_log/${params.processInstanceId}/get`, {
        method: 'post',
        payload: params.payload
    })
}
