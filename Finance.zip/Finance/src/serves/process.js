import fetchProxy from '@/utils/fetchProxy'
import { getProjectId } from '@/utils/auth'

const urlPrefix = () => {
    return `/api/v1/projects/${getProjectId()}/process/`
}
export const zipUploadUrl = `${urlPrefix()}zip-file/upload`
export const jarUploadUrl = `${urlPrefix()}jar-file/upload`
// 查询流程列表
export const getProcessLists = async params => {
    return fetchProxy(`${urlPrefix()}search`, {
        method: 'post',
        payload: params
    })
}

// 设置流程禁启用状态
export const setProcessStatus = async params => {
    return fetchProxy(`${urlPrefix()}status/update`, {
        method: 'get',
        payload: params,
        showMsg: true
    })
}

// 创建流程
export const creatProcess = async params => {
    return fetchProxy(`${urlPrefix()}create`, {
        method: 'post',
        payload: params,
        showMsg: true
    })
}

// 修改流程信息
export const saveProcess = async params => {
    return fetchProxy(`${urlPrefix()}save`, {
        method: 'post',
        payload: params,
        showMsg: true
    })
}

// 删除流程
export const deleteProcess = async params => {
    return fetchProxy(`${urlPrefix()}remove`, {
        method: 'delete',
        payload: params,
        showMsg: true
    })
}

// 创建流程
export const startProcess = async params => {
    return fetchProxy(`${urlPrefix()}start`, {
        method: 'get',
        payload: params,
        showMsg: true
    })
}

// 获取任务列表
export const fetchTaskLists = async params => {
    return fetchProxy(`${urlPrefix()}task`, {
        method: 'get',
        payload: params
    })
}

// 获取当前画布信息
export const fetchCanvasDetail = async params => {
    return fetchProxy(`${urlPrefix()}canvas/search`, {
        method: 'get',
        payload: params
    })
}

// 获取cron表达式
export const fetchCron = async params => {
    return fetchProxy(`${urlPrefix()}cron`, {
        method: 'get',
        payload: params
    })
}

// 验证cron表达式
export const checkCron = async params => {
    return fetchProxy(`${urlPrefix()}cron/validate`, {
        method: 'get',
        payload: params
    })
}

// 保存cron表达式
export const saveCron = async params => {
    return fetchProxy(`${urlPrefix()}cron/save`, {
        method: 'get',
        payload: params,
        showMsg: true
    })
}

// 保存dag
export const saveDag = async params => {
    return fetchProxy(`${urlPrefix()}canvas`, {
        method: 'post',
        payload: params
    })
}

// 获取python环境依赖
export const fetchPythonImageType = async params => {
    return fetchProxy(`${urlPrefix()}env`, {
        method: 'get',
        payload: params
    })
}
