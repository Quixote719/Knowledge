import fetchProxy from '@/utils/fetchProxy'
import { getProjectId } from '@/utils/auth'
import { recombineUrl } from '@/utils/method'

// 查询流程列表
const getProjectLists = async params => {
    return fetchProxy(`/api/v1/project/search`, {
        method: 'post',
        payload: params
    })
}

const getProjectDetail = async params => {
    return fetchProxy(recombineUrl(`/api/v1/project/{projectId}/get`, params), {
        method: 'get',
        payload: params
    })
}

const deleteProject = async params => {
    return fetchProxy(recombineUrl(`/api/v1/project/{projectId}/delete`, params), {
        method: 'delete'
    })
}

const createProject = async params => {
    return fetchProxy(recombineUrl(`/api/v1/project/create`, params), {
        method: 'post',
        payload: params
    })
}

const updateProject = async params => {
    return fetchProxy(recombineUrl(`/api/v1/project/${getProjectId()}/update`, params), {
        method: 'post',
        payload: params
    })
}

const uploadAuthFile = async params => {
    return fetchProxy(recombineUrl(`/api/v1/project/auth_file/upload`, params), {
        method: 'post',
        payload: params,
        upload: true
    })
}

export { getProjectLists, getProjectDetail, deleteProject, createProject, updateProject, uploadAuthFile }
