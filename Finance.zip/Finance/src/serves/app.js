import fetchProxy from '@/utils/fetchProxy'
import { recombineUrl } from '@/utils/method'

const login = async params => {
    return fetchProxy(recombineUrl(`/api/v1/login`, params), {
        method: 'post',
        payload: params
    })
}

export { login }
