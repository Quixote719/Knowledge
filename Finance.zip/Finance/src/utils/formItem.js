import { SUCCESS, VALIDATING, ERROR } from '@/constants/index'
export function getFormItemState(state) {
    switch (state) {
        case SUCCESS:
            return {
                validateStatus: 'success',
                hasFeedback: true
            }
        case VALIDATING:
            return {
                validateStatus: 'validating',
                hasFeedback: true
            }
        case ERROR: {
            return {
                validateStatus: 'error',
                hasFeedback: true
            }
        }
        default:
            return {}
    }
}

export const validatorName = {
    pattern: /^([\a-\z\A-\Z0-9\u4E00-\u9FA5_])*$/g,
    message: '请输入字母、数字、中文、下划线'
}

export const validatorNumber = {
    pattern: /^([0-9])*$/g,
    message: '请输入整数'
}

export const validatorRange10 = {
    pattern: /^([1-9]|10)$/g,
    message: '允许1-10的整数'
}

export const validatorRange100 = {
    pattern: /^(?:1|[1-9][0-9]?|99)$/,
    message: '允许大于0小于100的整数'
}
