import { isArray, isObject } from 'lodash'
import moment from 'moment'

// 拍平树
export const flatTree = (source, result = []) => {
    source.forEach(el => {
        result.push(el)
        if (isArray(el.children) && el.children.length > 0) {
            flatTree(el.children, result)
        }
    })
    return result
}

// 转换时间戳为字符串
export const translateTimesTampToString = (TimesTamp, format = 'YYYY-MM-DD HH:mm:ss') => {
    if (TimesTamp) {
        return moment(TimesTamp).format(format)
    } else {
        return ''
    }
}

// 对象转换为query参数
export const queryFy = data => {
    if (!isObject(data) || !data) {
        return
    }
    let _result = []
    for (let key in data) {
        let value = data[key]
        if (isArray(value)) {
            value.forEach(_value => {
                _result.push(key + '=' + _value)
            })
        } else {
            _result.push(key + '=' + value)
        }
    }
    return _result.join('&')
}

/*
 * 获取URLsearch参数
 */
export const getQueryString = (string = window.location.search) => {
    let search = string
    let obj = {}
    let str = search.substr(1)
    let arr = str.split('&')
    for (let i = 0; i < arr.length; i++) {
        let newArr = arr[i].split('=')
        obj[newArr[0]] = newArr[1]
    }
    return obj
}
