export const recombineUrl = (url, params) => {
    if (url && params) {
        for (let key in params) {
            url = url.replace(`{${key}}`, params[key])
        }
    }
    return url
}
