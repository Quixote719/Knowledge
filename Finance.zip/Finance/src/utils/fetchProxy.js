import { message } from 'antdForHik'

import { getToken, getUserId } from '@/utils/auth'
import { queryFy } from '@/utils/index'
/* eslint-disable */
const JSONbig = require('json-bigint')({ storeAsString: true })
/* eslint-enable */

// const { backend_host } = window
const doFetch = (url, param = {}) => {
    // if (!url.startsWith('http://') && !param.noCrossOrigin) {
    //     url = backend_host + url
    // }
    let method = param.method || 'get'
    const token = getToken()
    const userId = getUserId()
    // if (!token) {
    //     window.location.push('./Login')
    // }
    let headers = {
        'Cache-Control': 'no-cache',
        Pragma: 'no-cache',
        'X-User-Id': userId,
        'X-TOKEN': token
    }

    let commonHeader = {
        mode: 'cors'
    }

    if (['get', 'delete'].includes(method.toLowerCase())) {
        let hasPayload = queryFy(param?.payload) ? `?${queryFy(param?.payload)}` : ''
        return fetch(`${url}${hasPayload}`, {
            headers,
            method: method,
            ...commonHeader
        }).catch(err => {
            console.warn(err)
        })
    } else if (param.upload) {
        const { payload } = param
        let params = new FormData()
        for (let key in payload) {
            params.append(`${key}`, payload[key])
        }
        return fetch(url, {
            method: method.toLowerCase(),
            ...commonHeader,
            body: params,
            headers: {
                ...headers,
                'Content-Type': 'multipart/form-data'
            }
        }).catch(err => {
            console.error(err)
        })
    } else {
        let payload = param.payload || {}
        payload = typeof payload === 'string' ? payload : JSON.stringify(payload)

        return fetch(url, {
            method: method,
            headers: {
                ...headers,
                'Content-Type': 'application/json'
            },
            ...commonHeader,
            body: payload
        }).catch(err => {
            console.warn(err)
        })
    }
}

const fetchProxy = async (url, param = {}) => {
    try {
        let res = await doFetch(url, param)
        if (res && res.status !== 200) {
            const result = JSONbig.parse(await res.text())
            let msg = result.message || result.msg || '服务器运行异常'
            switch (res.status) {
                case 404:
                    message.error(msg || '服务器地址或资源不存在')
                    break
                case 400:
                    message.error(msg || '接口请求异常')
                    break
                case 401: {
                    message.error(msg || '接口请求异常')
                    window.location.href = './Login'
                    // logout()
                    break
                }
                case 422: {
                    message.error(msg || '服务器运行异常')
                    break
                }
                default:
                    message.error(msg || '服务器运行异常')
                    break
            }
            return result
        } else {
            if (param.file) {
                const blob = await res.blob()
                const a = document.createElement('a')
                const url = window.URL.createObjectURL(blob)
                const filename = res.headers.get('Content-Disposition').split('filename=')[1]
                a.href = url
                a.download = filename
                a.click()
                window.URL.revokeObjectURL(url)
            } else {
                const result = JSONbig.parse(await res.text())
                const { msg = '' } = result
                if (param.showMsg) {
                    message.destroy()
                    message.success(param.successMsg || msg)
                }
                return result
            }
        }
    } catch (err) {
        if (!param.noErrorTip) {
            message.destroy()
            message.error(err.toString())
        }
        throw err
    }
}

export default fetchProxy
