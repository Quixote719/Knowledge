import { ComponentConfigInitParamsMap } from '@/constants/task'
import { has } from 'lodash'
/*
 * 加载dagData
 * loadFrom 调用方式
 *  'SELECT_EXPR' 选择切换流程图或初始化
 *  'URL_CHANGE' 非流程图的切换,产生原因，单页面应用问题，切换了页面，但是画布状态要保持
 *  'SAVE_FAIL' 'SAVE_SUCCESS' 更新结果
 *  'UPDATE_STATE' 更新状态信息
 */

export const loadDAGData = (dag = {}, { loadFrom }) => {
    const dagData = dag
    if (typeof window.FLOWCHART != 'undefined') {
        window.FLOWCHART.changeCanvas({
            metadata: dagData.metadata,
            components: dagData.components,
            loadFrom
        })
    }
}

/**
 * 接收点击组件拖拽事件
 * @param {Component} component  组件
 */
export const mouseDownComponent = (component, e) => {
    window.FLOWCHART.triggerEvent('mouseDownAdd', e, {
        name: component.name,
        compId: component.compId,
        id: nextComponentID()
    })
}

//生成id给dag画布使用. dag画布中创建组件后会返回该id, 然后dag可以根据此id将其在dag中实例化
export const nextComponentID = () => {
    //id必须小于16位, 否则js会将id超出16位的数值改为0. 现在设置的id为毫秒级时间戳+0-9之间的随机数
    let date = new Date()
    let id = Date.parse(date).toString().substr(0, 10) + date.getMilliseconds() + '' + Math.floor(Math.random() * 10)
    id = parseInt(id)
    return id
}

// 查找画布内组件类型
export const findComponentType = ({ components = [], componentId = '', classInfomation = [] }) => {
    const item = findComponentFromDag({ components, componentId })
    return classInfomation.find(component => {
        return component.compId === item?.compId
    })?.name
}

// 查找当前画布组件
export const findComponentFromDag = ({ components = [], componentId = '' }) => {
    return components.find(item => {
        return item.id === componentId
    })
}

export const getNameIndex = (name, nameIndexMap) => {
    name = name.toLowerCase()
    if (has(nameIndexMap, name)) {
        nameIndexMap[name]++
        return nameIndexMap[name]
    } else {
        nameIndexMap[name] = 0
        return nameIndexMap[name]
    }
}

// 转换当前组件信息转化为后端所用信息
export const translateComponentToBackEndData = (components = [], nameIndexMap) => {
    let bizNodes = []
    let directedEdges = []
    components.forEach((comp, i) => {
        let configParams = {}
        if (comp.configParams) {
            configParams = comp.configParams
        } else {
            // 初始化时无configParams
            configParams = { ...ComponentConfigInitParamsMap[comp.compId], localId: String(comp.id) }
        }
        // 优先读取configParams?.name
        const componentName = comp?.configParams?.name || comp.name
        bizNodes.push({
            ...configParams,
            // 增加编号后缀
            name:
                componentName.lastIndexOf('_') === -1
                    ? `${componentName}_${getNameIndex(componentName, nameIndexMap)}`
                    : componentName,
            webUse: JSON.stringify({ position: comp.position })
        })
        let componentsChildren = comp?.children
        if (componentsChildren?.length > 0) {
            componentsChildren.forEach(child => {
                directedEdges.push({
                    fromLocalId: String(comp.id),
                    toLocalId: child[0].replace(/\-[0-9]*/i, '')
                })
            })
        }
    })

    const res = {
        bizNodes,
        directedEdges
    }
    return res
}

export const getFileName = string => {
    const index = string.lastIndexOf('/')
    if (index !== -1) {
        return string.slice(index + 1)
    }
}

export const calcNameIndexMap = componentList => {
    const nameIndexMap = {}
    componentList.forEach(comp => {
        let name = comp.name || ''
        let index = name.lastIndexOf('_')
        if (index !== -1) {
            let suffix = name.slice(index + 1)
            let prefix = name.slice(0, index).toLowerCase()
            suffix = parseInt(suffix)
            if (Number.isInteger(suffix) && suffix >= 0) {
                if (!nameIndexMap[prefix] || suffix > nameIndexMap[prefix]) {
                    nameIndexMap[prefix] = suffix
                }
            }
        }
    })
    return nameIndexMap
}
