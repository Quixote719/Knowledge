import Python from '@/assets/menutypeImg/Python.svg'
import Shell from '@/assets/menutypeImg/Shell.svg'
import Spark from '@/assets/menutypeImg/Spark.svg'

export const BASENAME = '/AIFinance'
export const HOME_PAGE = '/ProjectManage'
export const LOGIN = '/Login'
// 流程状态
export const processStatus = {
    enable: '启用',
    disable: '禁用'
}

// 流程状态map
export const processStatusMap = {
    启用: 'enable',
    禁用: 'disable'
}

// 流程列表默认查询状态
export const defaultSearchOption = {
    pageNo: 1,
    pageSize: 10,
    sortList: []
}

// 任务列表地址map
export const taskListMap = {
    'Python.svg': Python,
    'Shell.svg': Shell,
    'Spark.svg': Spark
}

// formItem验证状态
export const SUCCESS = 'success'
export const VALIDATING = 'validating'
export const ERROR = 'error'
