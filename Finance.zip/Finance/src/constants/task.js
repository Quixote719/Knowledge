// 流程任务示例数据

export const Spark = {
    localId: 'task-1',
    name: 'spark-test',
    compId: 2,
    retryInterval: 0,
    retryNumber: 0,
    webUse: '',
    taskConfig: {
        type: 'Spark',
        mainClass: 'com.awaken.spark.SparkPi',
        fileName: 'spark.example-1.0-SNAPSHOT.jar',
        businessParams: {
            'user.slices': '1000'
        },
        driverCores: 1,
        driverMemory: 1024,
        executorMemory: 1024,
        executorCores: 2,
        extraParams: {},
        numExecutor: 2
    },
    taskDescription: 'spark task test',
    timeOutDuration: 0,
    timeOutStop: false,
    failureRetry: false
}

export const Python = {
    localId: 'node1',
    name: 'node1',
    webUse: 'string',
    compId: 1,
    taskConfig: {
        type: 'Python',
        // 代码类型 code 镜像 image
        execType: 'code',
        // code类型 imageType：环境依赖 image类型 镜像名称
        imageType: 'ai-finance-pytorch:1.0.0',
        // 主函数参数
        mainArgs: '${additionalProp1}',
        // code 为主函数 image 为执行命令
        mainClass: 'stage3_getEmbedding.py',
        taskFilePath: '/yyy/f7b4c2e8ad684bcb81927febe304a3b4/133/node1/stage3_getEmbedding.zip',
        taskParam: { dataDir: '/user/pns/test', hiveDatabaseDir: '/user/hive/warehouse/autofinance.db' },
        cores: 2,
        memory: 2048
    },
    taskDescription: 'node1',
    timeOutStop: false,
    timeOutDuration: 0,
    failureRetry: false,
    retryNumber: 0,
    retryInterval: 0,
    status: 'NOT_EXECUTE'
}

export const Shell = {
    localId: 'task-1',
    name: 'shell-test',
    compId: 3,
    retryInterval: 0,
    retryNumber: 0,
    webUse: '',
    taskConfig: {
        type: 'Shell',
        shellScript:
            'echo ${af_p1};/usr/lib/hikcluster001/SERVICE-HADOOP-ddb855d088d24f3f888d46ac5d6386d7/bin/hadoop fs -get /test.log /root/temp/',
        destIp: '10.3.70.128',
        destPort: '22',
        destUserName: 'root',
        destPassword: 'algo12345+',
        businessParams: {
            p1: '1000'
        }
    },
    taskDescription: 'spark task test',
    timeOutDuration: 0,
    timeOutStop: false,
    failureRetry: false
}

/*
    初始化任务数据
*/
export const initPython = {
    localId: null,
    name: null,
    compId: 1,
    webUse: '',
    taskConfig: {
        type: 'Python',
        execType: null,
        imageType: null,
        mainClass: null,
        taskFilePath: null,
        businessParams: {},
        cores: null,
        memory: null,
        mainArgs: null
    },
    taskDescription: null,
    timeOutStop: false,
    timeOutDuration: null,
    failureRetry: false,
    retryNumber: null,
    retryInterval: null,
    status: 'NOT_EXECUTE'
}

export const initSpark = {
    localId: 'task-1',
    name: null,
    compId: 2,
    webUse: '',
    taskConfig: {
        type: 'Spark',
        mainClass: null,
        fileName: null,
        businessParams: {},
        driverCores: null,
        driverMemory: null,
        executorMemory: null,
        executorCores: null,
        extraParams: {},
        numExecutor: null
    },
    taskDescription: null,
    timeOutDuration: null,
    timeOutStop: false,
    failureRetry: false,
    retryInterval: null,
    retryNumber: null,
    status: 'NOT_EXECUTE'
}

export const initShell = {
    localId: 'Shell-1',
    name: null,
    compId: 3,
    webUse: '',
    taskConfig: {
        type: 'Shell',
        shellScript: null,
        destIp: null,
        destPort: null,
        destUserName: null,
        destPassword: null,
        businessParams: {}
    },
    taskDescription: null,
    timeOutDuration: null,
    timeOutStop: false,
    failureRetry: false,
    retryInterval: null,
    retryNumber: null,
    status: 'NOT_EXECUTE'
}

// 组件类型id
export const PYTHONCOMPID = 1
export const SPARKCOMPID = 2
export const SHELLCOMPID = 3

// 组件初始化参数
export const ComponentConfigInitParamsMap = {
    1: initPython,
    2: initSpark,
    3: initShell
}

export const componentNameMap = {
    1: 'Python',
    2: 'Spark',
    3: 'Shell'
}

export const taskRunningStatus = {
    SUCCESS: '成功',
    FAILED: '失败',
    RUNNING: '运行中',
    STOPPED: '停止',
    NONE: '等待'
}
