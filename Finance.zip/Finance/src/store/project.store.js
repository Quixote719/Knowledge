import { observable, action, runInAction, makeObservable } from 'mobx'
import * as projectAPI from '@/serves/project'
import { message } from 'antdForHik'

const projectDefaultParam = {
    projectName: '',
    sortBy: 'createTime',
    order: 'DESC',
    pageNo: 1,
    pageSize: 10
}
class ProjectStore {
    constructor() {
        // 添加makeObservable, mobx 6.0需要添加此代码才能触发视图渲染
        makeObservable(this, {
            projectListInfo: observable,
            projectDetail: observable,
            authLotNum: observable,
            getprojectLists: action,
            getprojectDetail: action,
            deleteProject: action,
            createProject: action,
            updateProject: action,
            uploadAuthFile: action,
            clearProjectDetail: action
        })
    }

    authLotNum = null
    projectListInfo = []
    projectDetail = {}

    getprojectLists(params = {}, callBack) {
        projectAPI.getProjectLists(params).then(res => {
            if (res) {
                this.projectListInfo = res
            }
            if (callBack) {
                callBack()
            }
        })
    }

    async getprojectDetail(params = {}, callBack) {
        let res = await projectAPI.getProjectDetail(params)
        if (res?.data) {
            runInAction(() => {
                this.projectDetail = res.data
                console.warn(this.projectDetail)
            })
        }
        if (callBack) {
            callBack()
        }
    }

    clearProjectDetail() {
        this.projectDetail = {}
        this.authLotNum = null
    }

    deleteProject(params = {}, callBack) {
        projectAPI.deleteProject(params).then(res => {
            if (res?.data) {
                message.success('删除项目成功')
                this.getprojectLists(projectDefaultParam)
            }
            if (callBack) {
                callBack()
            }
        })
    }

    createProject(params = {}, callBack) {
        projectAPI.createProject(params).then(res => {
            if (res?.data) {
                if (res.code == 0) {
                    message.success('创建项目成功')
                } else {
                    message.error(res.msg || res.message)
                }
                this.getprojectLists(projectDefaultParam)
            }
            if (callBack) {
                callBack()
            }
        })
    }

    updateProject(params = {}, callBack) {
        projectAPI.updateProject(params).then(res => {
            if (res?.data) {
                if (res.code == 0) {
                    message.success('更新项目成功')
                }
                this.getprojectLists(projectDefaultParam)
            }
            if (callBack) {
                callBack()
            }
        })
    }

    // uploadConfigFile(params = {}, callBack) {
    //     projectAPI.uploadConfigFile(params).then(res => {
    //         if (res?.data) {
    //             message.success('上传配置文件')
    //         }
    //         if (callBack) {
    //             callBack()
    //         }
    //     })
    // }

    uploadAuthFile(params = {}, callBack) {
        projectAPI.uploadAuthFile(params).then(res => {
            if (res?.data) {
                message.destroy()
                message.success('上传认证文件成功')
                this.authLotNum = res.data.lotNum
            }
            if (callBack) {
                callBack()
            }
        })
    }

    // yarnConfigParse(params = {}, callBack) {
    //     projectAPI.yarnConfigParse(params).then(res => {
    //         if (res?.data) {
    //             // message.success('')
    //         }
    //         if (callBack) {
    //             callBack()
    //         }
    //     })
    // }
}

const projectStore = new ProjectStore()

export default projectStore
