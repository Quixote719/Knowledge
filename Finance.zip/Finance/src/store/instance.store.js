import { observable, action, runInAction, makeObservable } from 'mobx'
import { message } from 'antdForHik'
import * as instanceAPI from '@/serves/instance'
import { loadDAGData, findComponentFromDag } from '@/utils/DAG'
import { componentNameMap } from '@/constants/task'

class InstanceStore {
    constructor() {
        // 添加makeObservable, mobx 6.0需要添加此代码才能触发视图渲染
        makeObservable(this, {
            instanceList: observable,
            instanceDetail: observable,
            refreshInsList: observable,
            getinstanceLists: action,
            getInstanceDetail: action,
            deleteInstance: action,
            finishInstanceRequest: action
        })
    }

    // 当前流程画布
    @observable
    currentDag = null
    // 当前选中组件
    @observable
    currentComponent = {}

    instanceList = []
    instanceDetail = {}
    refreshInsList = false

    getinstanceLists(params = {}, callBack) {
        instanceAPI.getInstanceLists(params).then(res => {
            if (res?.list) {
                this.instanceList = res
            }
            if (callBack) {
                callBack()
            }
        })
    }

    finishInstanceRequest() {
        this.refreshInsList = false
    }
    // 获取详情信息
    getInstanceDetail(params = {}, callBack) {
        instanceAPI.getInstanceDetail(params).then(res => {
            if (res?.data) {
                this.instanceDetail = res?.data
                const { metaData = {}, bizNodes = [], directedEdges = [], processInfo = {} } = res.data
                // 转成canvas读取数据类型
                const { canvasStatus } = metaData
                let components = []
                if (bizNodes) {
                    components = bizNodes.map(node => {
                        const { localId, name, status, compId, webUse } = node
                        let children = []
                        let parents = []
                        if (directedEdges) {
                            children = directedEdges
                                .filter(edge => edge.fromLocalId === localId)
                                .map(edge => {
                                    return { 0: `${edge.toLocalId}-0` }
                                })
                            parents = directedEdges
                                .filter(edge => edge.toLocalId === localId)
                                .map(edge => {
                                    return { 0: `${edge.fromLocalId}-0` }
                                })
                        }
                        return {
                            // 组件字段转换用于渲染
                            id: localId,
                            name,
                            compId,
                            children,
                            parents,
                            // status,
                            status,
                            position: JSON.parse(webUse)?.position || { x: null, y: null },
                            // 组件配置内容参数
                            configParams: {
                                ...node
                            }
                        }
                    })
                }
                const dagData = {
                    metadata: {
                        status: canvasStatus,
                        id: processInfo?.processId
                    },
                    components
                }

                // 当前画布信息
                this.currentDag = dagData

                // 获取到最新画布信息后渲染画布信息
                if (this.currentDag) {
                    loadDAGData(this.currentDag, {
                        loadFrom: 'SELECT_EXPR'
                    })
                }
            }
            if (callBack) {
                callBack()
            }
        })
    }

    stopInstance(params = {}, callBack) {
        instanceAPI.stopInstance(params).then(res => {
            if (res?.data) {
                message.success('停止流程实例成功')
                // this.getinstanceLists(instanceDefaultParam)
                this.refreshInsList = true
            }
            if (callBack) {
                callBack()
            }
        })
    }

    deleteInstance(params = {}, callBack) {
        instanceAPI.deleteInstance(params).then(res => {
            if (res?.data) {
                message.success('删除流程实例成功')
                // this.getinstanceLists(instanceDefaultParam)
                runInAction(() => {
                    this.refreshInsList = true
                })
            }
            if (callBack) {
                callBack()
            }
        })
    }

    // 选中组件或画布
    selectComponentsFromCanvas = (data, callBack) => {
        // 选中单个组件
        if (data.length === 1) {
            const finedComponet = findComponentFromDag({
                components: this.currentDag?.components,
                componentId: data[0]
            })
            // console.log(finedComponet, data[0], this.currentDag, 'finedComponet')
            const { configParams } = finedComponet
            this.currentComponent = {
                type: componentNameMap[configParams?.compId],
                ...configParams
            }
            if (callBack) {
                callBack(true)
            }
        } else {
            if (data.length === 0) {
                if (callBack) {
                    callBack(false)
                }
            }
        }
    }
}

const instanceStore = new InstanceStore()

export default instanceStore
