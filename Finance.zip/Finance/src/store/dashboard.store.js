import { observable, action, makeObservable } from 'mobx'

import * as dashboardAPI from '@/serves/dashboard'
class DashboardStore {
    constructor() {
        makeObservable(this, {
            resourceStatistics: observable,
            processTotal: observable,
            instanceTotal: observable,
            instanceStatistics: observable,
            getdashboardLists: action,
            getProcessTotal: action,
            getInstanceTotal: action,
            getInstanceStatistics: action,
            clearDashBoardStatistics: action
        })
    }

    resourceStatistics = {}
    processTotal = {}
    instanceTotal = {}
    instanceStatistics = {}

    clearDashBoardStatistics() {
        this.resourceStatistics = {}
        this.processTotal = {}
        this.instanceTotal = {}
        this.instanceStatistics = {}
    }

    getdashboardLists(params = {}, callBack) {
        dashboardAPI.getDashboardStatistics(params).then(res => {
            if (res?.data) {
                this.resourceStatistics = res?.data
                console.warn('this.resourceStatistics', this.resourceStatistics)
            }
            if (callBack) {
                callBack()
            }
        })
    }

    getProcessTotal(params = {}, callBack) {
        dashboardAPI.getProcessTotal(params).then(res => {
            console.warn('res', res)
            if (res?.data) {
                this.processTotal = res?.data
            }
            if (callBack) {
                callBack()
            }
        })
    }

    getInstanceTotal(params = {}, callBack) {
        dashboardAPI.getInstanceTotal(params).then(res => {
            console.warn('res', res)
            if (res?.data) {
                this.instanceTotal = res?.data
            }
            if (callBack) {
                callBack()
            }
        })
    }

    getInstanceStatistics(params = {}, callBack) {
        dashboardAPI.getInstanceStatistics(params).then(res => {
            if (res?.data) {
                this.instanceStatistics = res?.data
                console.warn('this.instanceStatistics', this.instanceStatistics)
            }
            if (callBack) {
                callBack()
            }
        })
    }
}

const dashboardStore = new DashboardStore()

export default dashboardStore
