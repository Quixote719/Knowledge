import { observable, action } from 'mobx'
import { throttle, cloneDeep, has, isNull, isUndefined } from 'lodash'
import * as processAPI from '@/serves/process'
import { defaultSearchOption, SUCCESS, ERROR } from '@/constants/index'
import { ComponentConfigInitParamsMap } from '@/constants/task'
import {
    findComponentType,
    loadDAGData,
    findComponentFromDag,
    translateComponentToBackEndData,
    getNameIndex,
    calcNameIndexMap
} from '@/utils/DAG'

class ProcessStore {
    // 流程列表
    @observable
    processList = []
    // 流程列表页码信息
    @observable
    processData = {}
    // 流程列表查询条件
    @observable
    processSearchOption = defaultSearchOption
    // 当前流程画布
    @observable
    currentDag = null
    // 画布组件名称map
    nameIndexMap = {}
    // 缓存旧画布信息
    @observable
    preProcessCanvasVO = null
    // 任务种类
    @observable
    classInfomation = []
    // 流程画布基础信息
    @observable
    processInfo = {}
    // 当前选中组件
    @observable
    currentComponent = {}
    // 当前组件名称
    @observable
    currentComponentName = ''

    // 设置查询条件
    @action setProcessSearchOption = (value, init) => {
        this.processSearchOption = init ? value : { ...this.processSearchOption, ...value }
    }

    // 设置流程画布基础信息
    @action setProcessInfo = value => {
        this.processInfo = value
    }
    // 获取流程列表
    getProcessLists(callBack) {
        processAPI
            .getProcessLists(this.processSearchOption)
            .then(res => {
                if (res?.data?.list) {
                    this.processList = res?.data?.list
                    this.processData = res?.data
                }
                if (callBack) {
                    callBack(res?.data)
                }
            })
            .finally(error => {
                if (callBack) {
                    callBack(error)
                }
            })
    }
    // 修改流程状态
    setProcessStatus(params, callBack) {
        processAPI.setProcessStatus(params).then(res => {
            if (callBack) {
                callBack()
            }
        })
    }
    // 创建流程
    creatProcess(params, callBack) {
        processAPI.creatProcess(params).then(res => {
            if (callBack) {
                callBack()
            }
        })
    }
    // 修改流程信息
    saveProcess(params, callBack) {
        processAPI.saveProcess(params).then(res => {
            if (callBack) {
                callBack()
            }
        })
    }
    // 删除
    deleteProcess(params, callBack) {
        processAPI.deleteProcess(params).then(res => {
            if (callBack) {
                callBack()
            }
        })
    }
    // 启动
    startProcess(params, callBack) {
        processAPI.startProcess(params).then(res => {
            if (callBack) {
                callBack()
            }
        })
    }
    // 获取画布任务列表
    fetchTaskLists(params, callBack) {
        // 返回promise对象
        return processAPI.fetchTaskLists(params).then(res => {
            const resultList = res?.data?.list || []
            const newClassInfomation = []
            resultList.forEach(element => {
                newClassInfomation.push({
                    ...element,
                    image: element?.webImage,
                    name: element?.typeName,
                    input: element?.input,
                    // output: [{ name: 'data', type: 'data', index: '0', description: '适配前端' }]
                    output: element?.output
                })
            })
            this.classInfomation = newClassInfomation
            if (callBack) {
                callBack()
            }
        })
    }

    // 获取当前画布信息
    fetchCanvasDetail = async params => {
        processAPI.fetchCanvasDetail(params).then(res => {
            if (res && res.data) {
                const { metaData = {}, bizNodes = [], directedEdges = [], processInfo = {} } = res.data
                this.setProcessInfo(res?.data?.processInfo)
                // 转成canvas读取数据类型
                const { canvasStatus } = metaData
                let components = []
                if (bizNodes) {
                    components = bizNodes.map(node => {
                        const { localId, name, status, compId, webUse } = node
                        let children = []
                        let parents = []
                        if (directedEdges) {
                            children = directedEdges
                                .filter(edge => edge.fromLocalId === localId)
                                .map(edge => {
                                    return { 0: `${edge.toLocalId}-0` }
                                })
                            parents = directedEdges
                                .filter(edge => edge.toLocalId === localId)
                                .map(edge => {
                                    return { 0: `${edge.fromLocalId}-0` }
                                })
                        }
                        return {
                            // 组件字段转换用于渲染
                            id: localId,
                            name,
                            compId,
                            children,
                            parents,
                            // status,
                            status,
                            position: JSON.parse(webUse)?.position,
                            // 组件配置内容参数
                            configParams: {
                                ...node
                            }
                        }
                    })
                }
                const dagData = {
                    metadata: {
                        status: canvasStatus,
                        id: processInfo?.processId
                    },
                    components
                }
                // 储存画布名称map
                this.nameIndexMap = calcNameIndexMap(components)
                // 缓存旧画布信息
                this.preProcessCanvasVO = res.data
                // 当前画布信息
                this.currentDag = dagData
                // 如果当前有组件选中
                if (this.currentComponent?.id) {
                    const findIndex = components.findIndex(item => {
                        return item.id === this.currentComponent.id
                    })
                    // 将新的当前组件从新数据中获取出来
                    this.currentComponent = components[findIndex]
                }
                // 获取到最新画布信息后渲染画布信息，这里就能保证修改画布后无论成功还是失败都更新画布为最新画布
                if (this.currentDag) {
                    loadDAGData(this.currentDag, {
                        loadFrom: 'SELECT_EXPR'
                    })
                }
            }
        })
    }
    // 保存当前画布信息
    saveDag = throttle(components => {
        const params = {
            processCanvasVO: {
                processInfo: this.processInfo,
                metaData: this.preProcessCanvasVO?.metaData,
                ...translateComponentToBackEndData(components, this.nameIndexMap)
            },
            preProcessCanvasVO: this.preProcessCanvasVO
        }

        return processAPI
            .saveDag(params)
            .then(data => {
                // 画布已被其他人操作修改，这里协助刷新
                if (data.code === '0x0083023') {
                    setTimeout(() => {
                        window.location.reload()
                    }, 3000)
                    return ERROR
                }
                //  获取到metaData即为保存成功
                if (data?.data?.metaData) {
                    // 保存成功即请求画布最新信息
                    this.fetchCanvasDetail({
                        processId: this.processInfo.processId
                    })
                    return SUCCESS
                } else {
                    return ERROR
                }
            })
            .catch(() => {
                return ERROR
            })
    }, 600)

    // 选中组件或画布
    selectComponentsFromCanvas = (data, callBack) => {
        // 选中单个组件
        if (data.length === 1) {
            const finedComponet = findComponentFromDag({
                components: this.currentDag?.components,
                componentId: data[0]
            })

            // 初始化当前组件为ComponentConfigInitParamsMap中的组件
            this.currentComponent = finedComponet?.configParams
                ? finedComponet
                : {
                      ...finedComponet,
                      configParams: {
                          ...ComponentConfigInitParamsMap[finedComponet?.compId],
                          name:
                              finedComponet?.name.lastIndexOf('_') === -1
                                  ? `${finedComponet?.name}_${getNameIndex(finedComponet?.name, this.nameIndexMap) - 1}`
                                  : finedComponet?.name,
                          localId: String(finedComponet?.id)
                      }
                  }
            this.currentComponentName = findComponentType({
                components: this.currentDag?.components,
                componentId: data[0],
                classInfomation: this.classInfomation
            })
            if (callBack) {
                callBack(true)
            }
        } else {
            if (data.length === 0) {
                if (callBack) {
                    callBack(false)
                }
            }
        }
    }

    // 实例currentComponent
    // {
    //     "id": "16164679802996",
    //     "name": "Pytho_0",
    //     "compId": 1,
    //     "children": [],
    //     "parents": [],
    //     "status": "NOT_EXECUTE",
    //     "position": {
    //         "x": 407.16666666666623,
    //         "y": -729.5833333333329
    //     },
    //     "configParams": {
    //         "localId": "16164679802996",
    //         "name": "Pytho_0",
    //         "compId": 1,
    //         "webUse": "{\"position\":{\"x\":407.16666666666623,\"y\":-729.5833333333329}}",
    //         "taskConfig": {
    //             "type": "Python",
    //             "execType": null,
    //             "imageType": null,
    //             "mainClass": null,
    //             "taskFilePath": null,
    //             "businessParams": {},
    //             "cores": null,
    //             "memory": null,
    //             "mainArgs": null
    //         },
    //         "taskDescription": null,
    //         "timeOutStop": null,
    //         "timeOutDuration": null,
    //         "failureRetry": null,
    //         "retryNumber": null,
    //         "retryInterval": null,
    //         "status": "NOT_EXECUTE"
    //     },
    //     "runStatus": "没有运行"
    // }
    // 改变组件参数并保存
    async changeParmasToSave({ key, value }) {
        const components = cloneDeep(this.currentDag.components)
        const currentComponent = cloneDeep(this.currentComponent)

        const configParams = currentComponent?.configParams
        // console.log(configParams, 'configParams')
        // 传入value为null或者undefined 不保存
        if (isNull(value) || isUndefined(value)) {
            return false
        }
        // 失焦保存的值与当前组件值不同,参数key在第一层中
        if (has(configParams, key)) {
            if (configParams[key] !== value) {
                configParams[key] = value

                const findIndex = components.findIndex(item => {
                    return item.id === currentComponent.id
                })
                if (findIndex > -1) {
                    components.splice(findIndex, 1, currentComponent)
                }
                const res = await this.saveDag(components)
                return res
            }
        }
        // 失焦保存的值与当前组件值不同,参数key在第二层中
        if (has(configParams.taskConfig, key)) {
            if (configParams.taskConfig[key] !== value) {
                configParams.taskConfig[key] = value
                const findIndex = components.findIndex(item => {
                    return item.id === currentComponent.id
                })
                if (findIndex > -1) {
                    components.splice(findIndex, 1, currentComponent)
                }
                const res = await this.saveDag(components)
                return res
            }
        }

        // 返回false代表不发起保存
        return false
    }
}

const processStore = new ProcessStore()

export default processStore
