// 画布最简参数
export const testData = {
    metadata: {
        status: 'EDITSTATUS',
        id: 721
    },
    components: [
        {
            id: '16148436484728',
            name: 'Shell任务-0',
            status: 'READY',
            position: { x: 185, y: 269 },
            parents: [],
            children: [{ 0: '16148436517690-0' }],
            compId: 2
        },
        {
            id: '16148436517690',
            name: 'Python任务-0',
            status: 'READY',
            classname: 'Python任务',
            position: { x: 158, y: 382 },
            parents: [{ 0: '16148436484728-0' }],
            children: [],
            compId: 1
        }
    ]
}

export const classInfomation = [
    {
        id: 16,
        name: 'Python任务',
        image: 'dataedit.png',
        url: 'dataedit.png',
        description: 'Python任务',
        clazz: 'org.apache.spark.ml.awaken.platform.component.ml.io.datasource.transformers.IOOutputTransformer',
        version: null,
        compId: 1,
        paramType: 'IO',
        clipType: 'DATASOURCE',
        parentId: 8,
        isParent: '0',
        componentContentId: 1,
        input: [{ name: 'data', type: 'data', image: null, index: '0', description: '输入数据', typeId: 2 }],
        output: [{ name: 'data', type: 'data', image: null, index: '0', description: '输出数据', typeId: 2 }]
    },
    {
        id: 17,
        name: 'Shell任务',
        image: 'datainout.png',
        url: 'datainout.png',
        description: 'Shell任务',
        clazz: 'org.apache.spark.ml.awaken.platform.component.ml.io.datasource.transformers.IOInputTransformer',
        version: null,
        compId: 2,
        paramType: 'IO',
        clipType: 'DATASOURCE',
        parentId: 8,
        isParent: '0',
        componentContentId: 2,
        input: [],
        output: [{ name: 'data', type: 'data', image: null, index: '0', description: '输出数据', typeId: 2 }]
    }
]

export const realComponents = [
    {
        comId: 1,
        description: 'Python任务',
        webImage: 'Python.svg',
        typeName: 'Python任务',
        input: { name: 'data', type: 'data', index: '0', description: '适配前端' },
        output: { name: 'data', type: 'data', index: '0', description: '适配前端' }
    },
    {
        comId: 2,
        description: 'Spark任务',
        webImage: 'Spark.svg',
        typeName: 'Spark任务',
        input: { name: 'data', type: 'data', index: '0', description: '适配前端' },
        output: { name: 'data', type: 'data', index: '0', description: '适配前端' }
    },
    {
        comId: 3,
        description: 'Shell任务',
        webImage: 'Shell.svg',
        typeName: 'Shell任务',
        input: { name: 'data', type: 'data', index: '0', description: '适配前端' },
        output: { name: 'data', type: 'data', index: '0', description: '适配前端' }
    }
]

// 储存dag所需数据格式
export const saveDagData = {
    processCanvasVO: {
        processInfo: {
            processId: 17,
            processName: 'kcy_0318',
            processDescribe: ''
        },
        metaData: { canvasStatus: 'EDITSTATUS' },
        bizNodes: [
            {
                localId: 'local-1',
                name: 'node1',
                compId: 1,
                webUse:
                    '{"params":{},"position":{"x":-45.01500960614791,"y":-127.60108969740637},"depSchema":{},"advancedOptionVisible":false,"configTabKey":"normal","gridSearchValidDefaultValues":{},"fillColor":""}',
                taskConfig: {
                    type: 'Python',
                    execType: 'code',
                    imageType: 'string',
                    mainClass: 'ai-finance-anaconda:1.0.0',
                    taskFilePath: '/user/aifinance/a2359d36bedb4b78a66df4193de09f9b/code/13/node1/main_task.zip',
                    businessParams: {
                        additionalProp1: 'args1',
                        additionalProp2: 'args2',
                        additionalProp3: 'args3'
                    },
                    cores: 1,
                    memory: 100,
                    mainArgs: '${additionalProp1}'
                },
                taskDescription: 'string',
                timeOutStop: false,
                timeOutDuration: 0,
                failureRetry: false,
                retryNumber: 0,
                retryInterval: 0,
                status: 'READY'
            }
        ],
        directedEdges: []
    },
    preProcessCanvasVO: {
        processInfo: {
            processId: 17,
            processName: 'kcy_0318',
            processDescribe: ''
        },
        metaData: { canvasStatus: 'EDITSTATUS' },

        bizNodes: [
            {
                localId: 'local-1',
                name: 'node1',
                compId: 1,
                webUse:
                    '{"params":{},"position":{"x":-45.01500960614791,"y":-127.60108969740637},"depSchema":{},"advancedOptionVisible":false,"configTabKey":"normal","gridSearchValidDefaultValues":{},"fillColor":""}',
                taskConfig: {
                    type: 'Python',
                    execType: 'code',
                    imageType: 'string',
                    mainClass: 'ai-finance-anaconda:1.0.0',
                    taskFilePath: '/user/aifinance/a2359d36bedb4b78a66df4193de09f9b/code/13/node1/main_task.zip',
                    businessParams: {
                        additionalProp1: 'args1',
                        additionalProp2: 'args2',
                        additionalProp3: 'args3'
                    },
                    cores: 1,
                    memory: 100,
                    mainArgs: '${additionalProp1}'
                },
                taskDescription: 'string',
                timeOutStop: false,
                timeOutDuration: 0,
                failureRetry: false,
                retryNumber: 0,
                retryInterval: 0,
                status: 'READY'
            }
        ],
        directedEdges: []
    }
}
