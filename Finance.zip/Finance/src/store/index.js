import appStore from './app.store'
import projectStore from './project.store'
import processStore from './process.store'
import instanceStore from './instance.store'
import operationStore from './operation.store'
import dashboardStore from './dashboard.store'

export default { projectStore, processStore, instanceStore, operationStore, dashboardStore, appStore }
