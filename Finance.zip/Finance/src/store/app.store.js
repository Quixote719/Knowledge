import { action, makeObservable } from 'mobx'
import { message } from 'antdForHik'
import * as appAPI from '@/serves/app'
import { setToken, setUserId } from '@/utils/auth'
class AppStore {
    constructor() {
        // 添加makeObservable, mobx 6.0需要添加此代码才能触发视图渲染
        makeObservable(this, {
            requestLogin: action
        })
    }

    requestLogin(params = {}, callBack) {
        appAPI.login(params).then(res => {
            if (res.code === '0' && res?.data) {
                message.success('登录成功')
                setToken(res?.data?.token)
                setUserId(res?.data?.userId)
                if (callBack) {
                    callBack()
                }
            }
        })
    }
}

const appStore = new AppStore()

export default appStore
