const requireContext = require('require-context')
// const localHost = 'http://127.0.0.1:3000/'
let results = {}
const context = requireContext(__dirname, false, /\.js$/)
context
    .keys()
    .filter(item => !['index.js', 'config.js'].includes(item))
    .forEach(key => {
        results = {
            ...results,
            ...context(key)
        }
    })
const proxy = {
    _proxy: {
        proxy: {
            // Turn a path string such as `/user/:name` into a regular expression.
            // https://www.npmjs.com/package/path-to-regexp
            // '/api/v1/projects/(.*)': localHost,
            // '/api/v1/project/(.*)': localHost,
            // '/api/v1/login': localHost
        },
        changeHost: true,
        httpProxy: {
            options: {
                ignorePath: true
            },
            listeners: {
                proxyReq: function (proxyReq, req, res, options) {
                    console.warn('proxyReq', proxyReq)
                }
            }
        }
    },
    ...results
}
module.exports = proxy
