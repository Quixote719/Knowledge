module.exports = {
    'POST /api/v1/login': {
        code: 'string',
        msg: 'string',
        suggestion: 'string',
        duration: 0,
        data: 'string'
    }
}
