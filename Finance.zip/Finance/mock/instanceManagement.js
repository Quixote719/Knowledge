// module.exports = {
//     'POST /api/v1/projects/:id/instance/12323': {
//         data: {
//             list: [
//                 {
//                     instanceId: '1',
//                     instanceName: 'John Brown',
//                     age: 32,
//                     address: 'New York No. 1 Lake Park'
//                 },
//                 {
//                     instanceId: '3',
//                     instanceName: 'Joe Black',
//                     age: 32,
//                     address: 'Sidney No. 1 Lake Park'
//                 },
//                 {
//                     instanceId: '4',
//                     instanceName: 'Disabled User',
//                     age: 99,
//                     address: 'Sidney No. 1 Lake Park'
//                 },
//                 {
//                     instanceId: '3',
//                     instanceName: 'Joe Black',
//                     age: 32,
//                     address: 'Sidney No. 1 Lake Park'
//                 },
//                 {
//                     instanceId: '4',
//                     instanceName: 'Disabled User',
//                     age: 99,
//                     address: 'Sidney No. 1 Lake Park'
//                 },
//                 {
//                     instanceId: '3',
//                     instanceName: 'Joe Black',
//                     age: 32,
//                     address: 'Sidney No. 1 Lake Park'
//                 }
//             ]
//         }
//     }
// }

const randonNumber = () => {
    return (Math.random() * 10000).toFixed(0)
}

// 流程管理lists
const getInstanceRandomLists = () => {
    const instanceRandomLists = []
    for (let i = 0; i < 60; i++) {
        instanceRandomLists.push({
            instanceId: 'id' + randonNumber(),
            instanceName: 'name' + randonNumber(),
            instanceEnable: randonNumber() % 2 === 0 ? '启用' : '禁用',
            cronExpression: 'cron表达式',
            createTime: 'string',
            updateTime: 'string',
            description: 'string'
        })
    }
    return instanceRandomLists
}

module.exports = {
    'POST /api/v1/projects/:id/instance/search': {
        data: {
            total: 200,
            pageNo: 2,
            pageSize: 20,
            totalPage: 10,
            list: getInstanceRandomLists()
        }
    }
}
