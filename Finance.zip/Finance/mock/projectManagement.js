const randonNumber = () => {
    return (Math.random() * 10000).toFixed(0)
}

// 流程管理lists
const getProjectRandomLists = () => {
    const projectRandomLists = []
    for (let i = 0; i < 60; i++) {
        projectRandomLists.push({
            projectId: 'id' + randonNumber(),
            projectName: 'name' + randonNumber(),
            projectEnable: randonNumber() % 2 === 0 ? '启用' : '禁用',
            cronExpression: 'cron表达式',
            createTime: 'string',
            updateTime: 'string',
            description: 'string'
        })
    }
    return projectRandomLists
}

module.exports = {
    'POST /api/v1/projects/:id/project/search': {
        data: {
            total: 200,
            pageNo: 2,
            pageSize: 20,
            totalPage: 10,
            list: getProjectRandomLists()
        }
    }
}
