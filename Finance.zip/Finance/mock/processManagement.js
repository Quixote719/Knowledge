const randonNumber = () => {
    return (Math.random() * 10000).toFixed(0)
}

// 流程管理lists
const getProcessRandomLists = () => {
    const processRandomLists = []
    for (let i = 0; i < 60; i++) {
        processRandomLists.push({
            processId: 'id' + randonNumber(),
            processName: 'name' + randonNumber(),
            processEnable: randonNumber() % 2 === 0 ? '启用' : '禁用',
            cronExpression: 'cron表达式',
            createTime: 'string',
            updateTime: 'string',
            description: 'string'
        })
    }
    return processRandomLists
}

module.exports = {
    'POST /api/v1/projects/:id/process/search': {
        data: {
            total: 200,
            pageNo: 2,
            pageSize: 20,
            totalPage: 10,
            list: getProcessRandomLists()
        }
    },
    'POST /api/v1/projects/:id/process/task': {
        data: {
            total: 200,
            pageNo: 2,
            pageSize: 20,
            totalPage: 10,
            list: getProcessRandomLists()
        }
    }
}
